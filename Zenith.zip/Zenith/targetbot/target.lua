local targetbotMacro = nil
local config = nil
local lastAction = 0
local cavebotAllowance = 0
local dangerValue = 0
local looterStatus = ""
local attackConfig = {mode="priority", style="melee"}
local mageRunState = {active=false, center=nil}

-- Shared scan/path range for the whole Mage Run stack. "Creature range" is
-- the authoritative detection radius; the kiting max distance only controls
-- spacing from the pack and can never make TargetBot see less than the lure.
local function getMageRunConfigNumber(id, defaultValue, minValue, maxValue)
  local value = defaultValue
  if CaveBot and CaveBot.Config and CaveBot.Config.values
    and CaveBot.Config.values[id] ~= nil then
    value = tonumber(CaveBot.Config.values[id]) or defaultValue
  end
  value = math.floor(value)
  if minValue and value < minValue then value = minValue end
  if maxValue and value > maxValue then value = maxValue end
  return value
end

TargetBot.getMageRunScanRange = function()
  local creatureRange = getMageRunConfigNumber("lureCreatureRange", 8, 1, 15)
  local kiteRange = getMageRunConfigNumber("lureMageRunMaxRange", 6, 2, 15)
  return math.max(6, creatureRange, kiteRange)
end

local targetCandidateCache = {}
local targetCandidateCacheSize = 0


-- One shared, cheap snapshot is produced by TargetBot and reused by CaveBot Lure
-- and the Mage Run movement evaluator. It deliberately contains no per-creature
-- pathfinding; paths are confirmed only for the small target-selection shortlist.
TargetBot.MageRunSnapshot = TargetBot.MageRunSnapshot or {
  createdAt = 0,
  nextRefreshAt = 0,
  playerPos = nil,
  scanRange = 0,
  hazards = {},
  configured = {},
  configuredIds = {},
  paramsById = {},
  selected = nil,
  dangerLevel = 0,
  targets = 0
}

TargetBot.getMageRunSnapshot = function(maxAge)
  local snapshot = TargetBot.MageRunSnapshot
  maxAge = tonumber(maxAge) or 350
  if not snapshot or snapshot.createdAt <= 0 or now - snapshot.createdAt > maxAge then
    return nil
  end
  return snapshot
end

local syntheticPaths = {}
local mageRunTargetSelection = {
  params = nil,
  expiresAt = 0,
  pathConfirmedAt = 0
}

local function creatureId(creature)
  return creature and creature.getId and creature:getId() or tostring(creature)
end

local function getValidCreaturePosition(creature, expectedZ)
  if not creature or not creature.getPosition then return nil, 0 end

  local okPos, creaturePos = pcall(function()
    return creature:getPosition()
  end)
  if not okPos or not creaturePos then return nil, 0 end
  if expectedZ ~= nil and creaturePos.z ~= expectedZ then return nil, 0 end

  local okHp, hp = pcall(function()
    return creature:getHealthPercent()
  end)
  hp = okHp and tonumber(hp) or 0
  if hp <= 0 then return nil, 0 end

  return creaturePos, hp
end

local function isValidMageRunMonster(creature, expectedZ)
  if not creature or not creature.isMonster or not creature:isMonster() then
    return false, nil, 0
  end
  if g_game.getClientVersion() >= 960
    and creature.getType and creature:getType() >= 3 then
    return false, nil, 0
  end
  local creaturePos, hp = getValidCreaturePosition(creature, expectedZ)
  return creaturePos ~= nil, creaturePos, hp
end

local function chebyshevDistance(a, b)
  if not a or not b or a.z ~= b.z then return 99 end
  return math.max(math.abs(a.x - b.x), math.abs(a.y - b.y))
end

local function syntheticPath(length)
  length = math.max(0, math.floor(tonumber(length) or 0))
  if not syntheticPaths[length] then
    local path = {}
    for i = 1, length do path[i] = 0 end
    syntheticPaths[length] = path
  end
  return syntheticPaths[length]
end

-- Lightweight Mage Run priority. Expensive global checks such as isTrapped()
-- are computed once per snapshot, not once per creature.
local function calculateMageRunConfigPriority(creature, creatureConfig, distance, trapped, currentTarget)
  local priority = currentTarget == creature and 1 or 0
  local maxDistance = tonumber(creatureConfig.maxDistance) or 10
  if distance > maxDistance then
    return priority
  end

  priority = priority + (tonumber(creatureConfig.priority) or 0)

  if trapped and distance == 1 then
    priority = priority + 20
  elseif distance <= 5 then
    priority = priority + ((5 - distance + 1) / 5 * 10)
  end

  if creatureConfig.diamondArrows then
    local creaturePos = creature:getPosition()
    if creaturePos then
      local mobCount = getCreaturesInArea(creaturePos, diamondArrowArea, 2)
      priority = priority + (mobCount * 4)
      if creatureConfig.rpSafe
        and getCreaturesInArea(creaturePos, largeRuneArea, 3) > 0 then
        return 0
      end
    end
  end

  local hp = tonumber(creature:getHealthPercent()) or 100
  if creatureConfig.chase and hp < 30 then
    priority = priority + 10
  else
    priority = priority + ((100 - hp) / 100 * 10)
  end

  return priority
end

local function calculateMageRunParams(creature, distance, trapped, currentTarget)
  local configs = TargetBot.Creature.getConfigs(creature)
  local priority = 0
  local danger = 0
  local selectedConfig = nil

  for _, creatureConfig in ipairs(configs) do
    local configPriority = calculateMageRunConfigPriority(
      creature, creatureConfig, distance, trapped, currentTarget
    )
    if configPriority > priority then
      priority = configPriority
      danger = tonumber(creatureConfig.danger) or 0
      selectedConfig = creatureConfig
    end
  end

  return {
    config = selectedConfig,
    creature = creature,
    danger = danger,
    priority = priority,
    pathLength = distance
  }
end

local function getCheapMageRunCandidate(creature, playerPos, trapped, currentTarget)
  local creaturePos = creature:getPosition()
  if not creaturePos then return nil end
  local distance = chebyshevDistance(playerPos, creaturePos)
  return calculateMageRunParams(creature, distance, trapped, currentTarget)
end

local function getConfirmedMageRunCandidate(cheapParams, playerPos, pathRange, trapped, currentTarget)
  if not cheapParams or not cheapParams.creature then return nil end
  local creature = cheapParams.creature
  local creaturePos = creature:getPosition()
  if not creaturePos or creaturePos.z ~= playerPos.z then return nil end

  local path = findPath(playerPos, creaturePos, pathRange, {
    ignoreLastCreature = true,
    ignoreNonPathable = true,
    ignoreCost = true,
    ignoreCreatures = true
  })
  if not path then return nil end
  return calculateMageRunParams(creature, #path, trapped, currentTarget)
end

local function getCachedTargetCandidate(creature, playerPos, pathRange)
  local creaturePos = creature:getPosition()
  local creatureId = creature.getId and creature:getId() or tostring(creature)
  local hp = creature:getHealthPercent() or 0
  local currentTarget = g_game.getAttackingCreature and g_game.getAttackingCreature() or nil
  local currentTargetId = currentTarget and currentTarget.getId and currentTarget:getId() or 0
  local key = table.concat({
    creatureId,
    currentTargetId,
    playerPos.x, playerPos.y, playerPos.z,
    creaturePos.x, creaturePos.y, creaturePos.z,
    hp,
    pathRange
  }, ":")
  local cached = targetCandidateCache[key]
  if cached and cached.expiresAt > now then
    return cached.params
  end

  local path = findPath(playerPos, creaturePos, pathRange, {
    ignoreLastCreature = true,
    ignoreNonPathable = true,
    ignoreCost = true,
    ignoreCreatures = true
  })
  if not path then
    return nil
  end

  local params = TargetBot.Creature.calculateParams(creature, path)
  params.pathLength = #path
  targetCandidateCache[key] = {params=params, expiresAt=now + 160}
  targetCandidateCacheSize = targetCandidateCacheSize + 1

  if targetCandidateCacheSize > 250 then
    targetCandidateCache = {}
    targetCandidateCacheSize = 0
  end

  return params
end
local lastAttackConfigMenu = 0
local lastForcedStopTargetId = 0
local lastForcedStopAt = 0

-- ui
local configWidget = UI.Config()
local ui = UI.createWidget("TargetBotPanel")

ui.list = ui.listPanel.list -- shortcut
TargetBot.targetList = ui.list
TargetBot.Looting.setup()

ui.status.left:setText("Status:")
ui.status.right:setText("Off")
ui.target.left:setText("Target:")
ui.target.right:setText("-")
ui.config.left:setText("Config:")
ui.config.right:setText("-")
ui.danger.left:setText("Danger:")
ui.danger.right:setText("0")

-- ui.editor.debug.onClick = function()
--   local on = ui.editor.debug:isOn()
--   ui.editor.debug:setOn(not on)
--   if on then
--     for _, spec in ipairs(getSpectators()) do
--       spec:clearText()
--     end
--   end
-- end

local oldTibia = g_game.getClientVersion() < 960
local burstArrowArea = [[
  111
  111
  111
]]

local attackModes = {
  {id="priority", text="Default priority"},
  {id="closest", text="Closest creature"},
  {id="farthest", text="Farthest creature"},
  {id="mostHp", text="Highest HP"},
  {id="leastHp", text="Lowest HP"},
  {id="mostHpClosest", text="Highest HP + closest"},
  {id="mostHpFarthest", text="Highest HP + farthest"},
  {id="leastHpClosest", text="Lowest HP + closest"},
  {id="leastHpFarthest", text="Lowest HP + farthest"},
  {id="smartDiamond", text="Smart Diamond Arrow"},
  {id="smartBurst", text="Smart Burst Arrow"}
}

local attackStyles = {
  {id="melee", text="Melee attack"},
  {id="mageRun", text="Mage run"}
}

local function getAttackMode(modeId)
  for _, mode in ipairs(attackModes) do
    if mode.id == modeId then
      return mode
    end
  end
  return attackModes[1]
end

local function updateAttackConfigButton()
  if ui.editor.attackConfig then
    ui.editor.attackConfig:setText("CONFIG")
  end
  if CaveBot and CaveBot.Config and CaveBot.Config.refreshTargetMode then
    CaveBot.Config.refreshTargetMode()
  end
end

local function setAttackConfig(data)
  local mode = data and data.mode or "priority"
  local style = data and data.style or "melee"
  if getAttackMode(mode).id ~= mode then
    mode = "priority"
  end
  local validStyle = false
  for _, attackStyle in ipairs(attackStyles) do
    if attackStyle.id == style then
      validStyle = true
      break
    end
  end
  if not validStyle then
    style = "melee"
  end
  attackConfig = {mode=mode, style=style}
  if style ~= "mageRun" then
    mageRunState.active = false
    mageRunState.center = nil
    if TargetBot.resetMageRunMovement then
      TargetBot.resetMageRunMovement()
    end
  end
  updateAttackConfigButton()
end

local function isSmartAttackMode()
  return attackConfig.mode == "smartDiamond" or attackConfig.mode == "smartBurst"
end

local function getAttackStyle(styleId)
  for _, style in ipairs(attackStyles) do
    if style.id == styleId then
      return style
    end
  end
  return attackStyles[1]
end

local function targetDistance(params)
  return params.pathLength or distanceFromPlayer(params.creature:getPosition())
end

local function targetHp(params)
  return params.creature:getHealthPercent() or 0
end

local function betterByRules(candidate, current, rules)
  if not current then return true end
  for _, rule in ipairs(rules) do
    local a = rule.value(candidate) or 0
    local b = rule.value(current) or 0
    if a ~= b then
      if rule.asc then
        return a < b
      end
      return a > b
    end
  end
  return false
end

local function smartAreaScore(params, area)
  local position = params.creature:getPosition()
  if distanceFromPlayer(position) > 6 then
    return -1
  end
  if params.config.rpSafe and getCreaturesInArea(position, area, 3) > 0 then
    return -1
  end
  return getCreaturesInArea(position, area, 2)
end

local function selectTargetByRules(candidates, rules)
  local selected = nil
  for _, params in ipairs(candidates) do
    if betterByRules(params, selected, rules) then
      selected = params
    end
  end
  return selected
end

local function selectTarget(candidates)
  local mode = attackConfig.mode or "priority"
  local rules = {
    priority = {
      {value=function(params) return params.priority end},
      {value=targetDistance, asc=true},
      {value=targetHp, asc=true}
    },
    closest = {
      {value=targetDistance, asc=true},
      {value=function(params) return params.priority end},
      {value=targetHp, asc=true}
    },
    farthest = {
      {value=targetDistance},
      {value=function(params) return params.priority end},
      {value=targetHp, asc=true}
    },
    mostHp = {
      {value=targetHp},
      {value=targetDistance, asc=true},
      {value=function(params) return params.priority end}
    },
    leastHp = {
      {value=targetHp, asc=true},
      {value=targetDistance, asc=true},
      {value=function(params) return params.priority end}
    },
    mostHpClosest = {
      {value=targetHp},
      {value=targetDistance, asc=true},
      {value=function(params) return params.priority end}
    },
    mostHpFarthest = {
      {value=targetHp},
      {value=targetDistance},
      {value=function(params) return params.priority end}
    },
    leastHpClosest = {
      {value=targetHp, asc=true},
      {value=targetDistance, asc=true},
      {value=function(params) return params.priority end}
    },
    leastHpFarthest = {
      {value=targetHp, asc=true},
      {value=targetDistance},
      {value=function(params) return params.priority end}
    },
    smartDiamond = {
      {value=function(params) return smartAreaScore(params, diamondArrowArea) end},
      {value=targetDistance, asc=true},
      {value=function(params) return params.priority end}
    },
    smartBurst = {
      {value=function(params) return smartAreaScore(params, burstArrowArea) end},
      {value=targetDistance, asc=true},
      {value=function(params) return params.priority end}
    }
  }

  local selected = selectTargetByRules(candidates, rules[mode] or rules.priority)
  if mode == "smartDiamond" and selected and smartAreaScore(selected, diamondArrowArea) < 0 then
    return selectTargetByRules(candidates, rules.priority)
  elseif mode == "smartBurst" and selected and smartAreaScore(selected, burstArrowArea) < 0 then
    return selectTargetByRules(candidates, rules.priority)
  end
  return selected
end

local function copyMageRunCandidatePool(candidates)
  local pool = {}
  for _, candidate in ipairs(candidates) do
    pool[#pool + 1] = candidate
  end
  return pool
end

local function isCloseMageRunTargetCandidate(candidate, best, currentTarget)
  if not candidate then return false end
  if not best or candidate == best then return true end

  local candidatePriority = tonumber(candidate.priority) or 0
  local bestPriority = tonumber(best.priority) or 0
  local candidateDistance = tonumber(candidate.pathLength) or 99
  local bestDistance = tonumber(best.pathLength) or 99
  local currentBonus = 0
  if currentTarget
    and creatureId(candidate.creature) == creatureId(currentTarget) then
    currentBonus = 4
  end

  if candidatePriority + currentBonus >= bestPriority * 0.88 then
    return true
  end
  if candidatePriority + currentBonus + 4 >= bestPriority
    and candidateDistance <= bestDistance + 2 then
    return true
  end
  if candidateDistance <= bestDistance - 2
    and candidatePriority + currentBonus + 7 >= bestPriority then
    return true
  end

  return false
end


local function selectConfirmedMageRunTarget(
  candidates, playerPos, pathRange, configuredIds, trapped, currentTarget
)
  local cheapBest = selectTarget(copyMageRunCandidatePool(candidates))
  local previous = mageRunTargetSelection.params
  if previous and previous.creature then
    local id = creatureId(previous.creature)
    local previousCandidate = nil
    for _, candidate in ipairs(candidates) do
      if creatureId(candidate.creature) == id then
        previousCandidate = candidate
        break
      end
    end

    if previousCandidate and configuredIds[id]
      and isCloseMageRunTargetCandidate(
        previousCandidate, cheapBest, currentTarget
      ) then
      -- Keep an already valid target for one second. Rechecking its path on every
      -- 100-ms cycle was the largest avoidable pathfinding cost.
      if now - mageRunTargetSelection.pathConfirmedAt < 1000 then
        mageRunTargetSelection.params = previousCandidate
        mageRunTargetSelection.expiresAt = now + 1200
        return previousCandidate
      end

      local confirmedPrevious = getConfirmedMageRunCandidate(
        previousCandidate, playerPos, pathRange, trapped, currentTarget
      )
      if confirmedPrevious and confirmedPrevious.config and confirmedPrevious.priority > 0 then
        mageRunTargetSelection.params = confirmedPrevious
        mageRunTargetSelection.pathConfirmedAt = now
        mageRunTargetSelection.expiresAt = now + 1200
        return confirmedPrevious
      end
    end
  end

  local pool = copyMageRunCandidatePool(candidates)

  -- Confirm only the best cheap candidates. This keeps target changes stable
  -- while still allowing a nearby/dangerous creature to take over the pack.
  local attempts = math.min(3, #pool)
  for _ = 1, attempts do
    local cheap = selectTarget(pool)
    if not cheap then break end
    local confirmed = getConfirmedMageRunCandidate(
      cheap, playerPos, pathRange, trapped, currentTarget
    )
    if confirmed and confirmed.config and confirmed.priority > 0 then
      mageRunTargetSelection.params = confirmed
      mageRunTargetSelection.pathConfirmedAt = now
      mageRunTargetSelection.expiresAt = now + 1200
      return confirmed
    end
    for index, candidate in ipairs(pool) do
      if candidate == cheap then
        table.remove(pool, index)
        break
      end
    end
  end

  mageRunTargetSelection.params = nil
  mageRunTargetSelection.expiresAt = 0
  mageRunTargetSelection.pathConfirmedAt = 0
  return nil
end

local function refreshMageRunSnapshot(playerPos, scanRange)
  local specs = g_map.getSpectatorsInRange(playerPos, false, scanRange, scanRange)
  local hazards = {}
  local configured = {}
  local configuredIds = {}
  local paramsById = {}
  local targetCandidates = {}
  local dangerLevel = 0
  local targets = 0
  local trapped = isTrapped()
  local currentTarget = g_game.getAttackingCreature and g_game.getAttackingCreature() or nil

  for _, creature in ipairs(specs) do
    local valid, creaturePos = isValidMageRunMonster(creature, playerPos.z)
    if valid and chebyshevDistance(playerPos, creaturePos) <= scanRange then
      hazards[#hazards + 1] = creature

      local configs = TargetBot.Creature.getConfigs(creature)
      if configs and #configs > 0 then
        local id = creatureId(creature)
        configured[#configured + 1] = creature
        configuredIds[id] = true

        local params = getCheapMageRunCandidate(
          creature, playerPos, trapped, currentTarget
        )
        if params then
          paramsById[id] = params
          dangerLevel = dangerLevel + (params.danger or 0)
          if params.config and params.priority > 0 then
            targets = targets + 1
            targetCandidates[#targetCandidates + 1] = params
            if storage.extras.showTargetPriority then
              creature:setText(params.config.name .. "\n" .. params.priority)
            end
          end
        end
      end
    end
  end

  local pathRange = math.max(7, scanRange + 2)
  local selected = selectConfirmedMageRunTarget(
    targetCandidates, playerPos, pathRange, configuredIds, trapped, currentTarget
  )

  local emergency = TargetBot.isMageRunEmergencyMovement
    and TargetBot.isMageRunEmergencyMovement() or false
  local refreshDelay = emergency and 120 or 250

  local snapshot = {
    createdAt = now,
    nextRefreshAt = now + refreshDelay,
    playerPos = {x=playerPos.x, y=playerPos.y, z=playerPos.z},
    scanRange = scanRange,
    hazards = hazards,
    configured = configured,
    configuredIds = configuredIds,
    paramsById = paramsById,
    selected = selected,
    dangerLevel = dangerLevel,
    targets = targets
  }
  TargetBot.MageRunSnapshot = snapshot
  return snapshot
end

TargetBot.refreshMageRunSnapshot = refreshMageRunSnapshot

local function shouldAllowCaveBotForTarget(params)
  if not params or not params.config then
    return false
  end

  local config = params.config

  if attackConfig.style == "mageRun"
    and mageRunState.active
    and CaveBot
    and CaveBot.isLureIgnoreExitAllowed
    and CaveBot.isLureIgnoreExitAllowed() then
    return true
  end

  if config.stop then
    return false
  end

  if config.chase then
    return false
  end

  if attackConfig.style == "mageRun" and mageRunState.active then
    return false
  end

  return true
end

local function forceStopForTarget(creature)
  if not creature then return end
  local creatureId = creature.getId and creature:getId() or 0
  local sameTarget = creatureId ~= 0 and creatureId == lastForcedStopTargetId
  if sameTarget and lastForcedStopAt + 150 > now and not player:isWalking() then
    return
  end

  if TargetBot.stopWalk then
    TargetBot.stopWalk()
  end

  pcall(function()
    player:stopAutoWalk()
  end)
  pcall(function()
    g_game.stop()
  end)

  lastForcedStopTargetId = creatureId
  lastForcedStopAt = now
end

local function openAttackConfigMenu(mousePos)
  if lastAttackConfigMenu + 100 > now then return end
  lastAttackConfigMenu = now
  local menu = g_ui.createWidget('PopupMenu')
  menu:setId("targetBotAttackConfigMenu")
  menu:setGameMenu(true)
  for _, mode in ipairs(attackModes) do
    local text = mode.text
    if attackConfig.mode == mode.id then
      text = "> " .. text
    end
    menu:addOption(text, function()
      attackConfig.mode = mode.id
      TargetBot.save()
      updateAttackConfigButton()
    end, "")
  end
  menu:addSeparator()
  for _, style in ipairs(attackStyles) do
    local text = style.text
    if attackConfig.style == style.id then
      text = "> " .. text
    end
    menu:addOption(text, function()
      attackConfig.style = style.id
      if style.id ~= "mageRun" then
        mageRunState.active = false
        mageRunState.center = nil
        if TargetBot.resetMageRunMovement then
          TargetBot.resetMageRunMovement()
        end
      end
      TargetBot.save()
      updateAttackConfigButton()
    end, "")
  end
  menu:display(mousePos)
end

-- main loop, controlled by config
targetbotMacro = macro(100, function()
  local pos = player:getPosition()
  local mageRunMode = attackConfig.style == "mageRun"
  local dangerLevel = 0
  local targets = 0
  local highestPriorityParams = nil
  local looting = false
  local mageRunSnapshot = nil

  if mageRunMode then
    local scanRange = TargetBot.getMageRunScanRange()
    local snapshot = TargetBot.getMageRunSnapshot(900)
    local needsRefresh = not snapshot
      or snapshot.nextRefreshAt <= now
      or not snapshot.playerPos
      or snapshot.playerPos.z ~= pos.z

    if needsRefresh then
      snapshot = refreshMageRunSnapshot(pos, scanRange)
    end

    dangerLevel = snapshot and snapshot.dangerLevel or 0
    targets = snapshot and snapshot.targets or 0
    highestPriorityParams = snapshot and snapshot.selected or nil
    mageRunSnapshot = snapshot

    -- A creature object may disappear between snapshot creation and this cycle.
    if highestPriorityParams and highestPriorityParams.creature then
      local creaturePos, hp = getValidCreaturePosition(
        highestPriorityParams.creature, pos.z
      )
      if not creaturePos or hp <= 0 then
        highestPriorityParams = nil
        if snapshot then
          snapshot.selected = nil
          snapshot.nextRefreshAt = 0
        end
      end
    end
  else
    local scanRange = 6
    local specs = g_map.getSpectatorsInRange(pos, false, scanRange, scanRange)
    local monsterCount = 0
    for _, spec in ipairs(specs) do
      if spec:isMonster() then monsterCount = monsterCount + 1 end
    end

    local creatures
    if monsterCount > 10 and not isSmartAttackMode() then
      creatures = g_map.getSpectatorsInRange(pos, false, 3, 3)
    else
      creatures = specs
    end

    local targetCandidates = {}
    for _, creature in ipairs(creatures) do
      local valid = isValidMageRunMonster(creature, pos.z)
      if valid then
        local params = getCachedTargetCandidate(creature, pos, 7)
        if params then
          dangerLevel = dangerLevel + (params.danger or 0)
          if params.config and params.priority > 0 then
            targets = targets + 1
            targetCandidates[#targetCandidates + 1] = params
            if storage.extras.showTargetPriority then
              creature:setText(params.config.name .. "\n" .. params.priority)
            end
          end
        end
      end
    end
    highestPriorityParams = selectTarget(targetCandidates)
  end

  if not mageRunMode then
    TargetBot.walkTo(nil)
  end

  looting = TargetBot.Looting.process(targets, dangerLevel)
  local lootingStatus = TargetBot.Looting.getStatus()
  looterStatus = lootingStatus
  dangerValue = dangerLevel
  ui.danger.right:setText(dangerLevel)

  if highestPriorityParams and not isInPz() then
    local lureIgnoreExitAllowed = CaveBot
      and CaveBot.isLureIgnoreExitAllowed
      and CaveBot.isLureIgnoreExitAllowed()

    if shouldAllowCaveBotForTarget(highestPriorityParams) then
      TargetBot.allowCaveBot(lureIgnoreExitAllowed and 650 or 150)
    else
      TargetBot.disallowCaveBot()
    end

    if highestPriorityParams.config
      and highestPriorityParams.config.stop
      and not lureIgnoreExitAllowed then
      forceStopForTarget(highestPriorityParams.creature)
    end

    ui.target.right:setText(highestPriorityParams.creature:getName())
    ui.config.right:setText(highestPriorityParams.config.name)
    TargetBot.Creature.attack(highestPriorityParams, targets, looting)

    local mageRunMovementState = TargetBot.isMageRunActive
      and TargetBot.isMageRunActive()
      and TargetBot.getMageRunMovementState
      and TargetBot.getMageRunMovementState()

    if mageRunMovementState and mageRunMovementState.reason then
      TargetBot.setStatus("Mage run: " .. mageRunMovementState.reason)
    elseif lootingStatus:len() > 0 then
      TargetBot.setStatus("Attack & " .. lootingStatus)
    elseif cavebotAllowance > now then
      TargetBot.setStatus("Luring using CaveBot")
    else
      TargetBot.setStatus("Attacking")
    end

    if not mageRunMode then
      TargetBot.walk()
    end
    lastAction = now
    return
  elseif TargetBot.isMageRunActive
    and TargetBot.isMageRunActive()
    and not isInPz() then
    local movementState = TargetBot.getMageRunMovementState
      and TargetBot.getMageRunMovementState()
    local hasMageRunPack = mageRunSnapshot
      and #(mageRunSnapshot.configured or {}) > 0

    local lureIgnoreExitAllowed = CaveBot
      and CaveBot.isLureIgnoreExitAllowed
      and CaveBot.isLureIgnoreExitAllowed()

    if hasMageRunPack and not lureIgnoreExitAllowed then
      TargetBot.disallowCaveBot()
      if movementState and movementState.reason then
        TargetBot.setStatus("Mage run: " .. movementState.reason)
      else
        TargetBot.setStatus("Mage run: scanning")
      end
      lastAction = now
      return
    end

    if TargetBot.stopWalk then
      TargetBot.stopWalk()
    end
    TargetBot.allowCaveBot(lureIgnoreExitAllowed and 650 or 150)
    if lureIgnoreExitAllowed then
      TargetBot.setStatus("Mage run: ignore remaining")
    elseif movementState and movementState.reason == "no pack" then
      TargetBot.setStatus("Mage run: no pack")
    else
      TargetBot.setStatus("Mage run: clear")
    end
  elseif isInPz() then
    if g_game.isAttacking() then
      g_game.cancelAttack()
      return
    end
  end

  ui.target.right:setText("-")
  ui.config.right:setText("-")
  lastForcedStopTargetId = 0
  if looting then
    TargetBot.walk()
    lastAction = now
  end
  if lootingStatus:len() > 0 then
    TargetBot.setStatus(lootingStatus)
  else
    TargetBot.setStatus("Waiting")
  end
end)

-- config, its callback is called immediately, data can be nil
config = Config.setup("targetbot_configs", configWidget, "json", function(name, enabled, data)
  if not data then
    ui.status.right:setText("Off")
    return targetbotMacro.setOff() 
  end
  TargetBot.Creature.resetConfigs()
  for _, value in ipairs(data["targeting"] or {}) do
    TargetBot.Creature.addConfig(value)
  end
  TargetBot.Looting.update(data["looting"] or {})
  setAttackConfig(data["attackConfig"] or {})

  -- add configs
  if enabled then
    ui.status.right:setText("On")
  else
    ui.status.right:setText("Off")
  end

  targetbotMacro.setOn(enabled)
  targetbotMacro.delay = nil
end)

-- setup ui
ui.editor.buttons.add.onClick = function()
  TargetBot.Creature.edit(nil, function(newConfig)
    TargetBot.Creature.addConfig(newConfig, true)
    TargetBot.save()
  end)
end

ui.editor.buttons.edit.onClick = function()
  local entry = ui.list:getFocusedChild()
  if not entry then return end
  TargetBot.Creature.edit(entry.value, function(newConfig)
    entry:setText(newConfig.name)
    entry.value = newConfig
    TargetBot.Creature.resetConfigsCache()
    TargetBot.save()
  end)
end

ui.editor.buttons.remove.onClick = function()
  local entry = ui.list:getFocusedChild()
  if not entry then return end
  entry:destroy()
  TargetBot.Creature.resetConfigsCache()
  TargetBot.save()
end

ui.editor.attackConfig.onMouseRelease = function(widget, mousePos, mouseButton)
  if mouseButton ~= 1 then return false end
  openAttackConfigMenu(mousePos)
  return true
end

ui.editor.attackConfig.onClick = function(widget)
  local pos = widget:getPosition()
  local height = widget.getHeight and widget:getHeight() or 20
  openAttackConfigMenu({x=pos.x, y=pos.y + height})
end

updateAttackConfigButton()

-- public function, you can use them in your scripts
TargetBot.isActive = function() -- return true if attacking or looting takes place
  return lastAction + 300 > now
end

TargetBot.isCaveBotActionAllowed = function()
  return cavebotAllowance > now
end

TargetBot.setStatus = function(text)
  return ui.status.right:setText(text)
end

TargetBot.getStatus = function()
  return ui.status.right:getText()
end

TargetBot.isOn = function()
  return config.isOn()
end

TargetBot.isOff = function()
  return config.isOff()
end

TargetBot.setOn = function(val)
  if val == false then  
    return TargetBot.setOff(true)
  end
  config.setOn()
end

TargetBot.setOff = function(val)
  if val == false then  
    return TargetBot.setOn(true)
  end
  config.setOff()
end

TargetBot.getCurrentProfile = function()
  return storage._configs.targetbot_configs.selected
end

local botConfigName = modules.game_bot.contentsPanel.config:getCurrentOption().text
TargetBot.setCurrentProfile = function(name)
  if not g_resources.fileExists("/bot/"..botConfigName.."/targetbot_configs/"..name..".json") then
    return warn("there is no targetbot profile with that name!")
  end
  TargetBot.setOff()
  storage._configs.targetbot_configs.selected = name
  TargetBot.setOn()
end

TargetBot.delay = function(value)
  targetbotMacro.delay = now + value
end

TargetBot.save = function()
  local data = {targeting={}, looting={}, attackConfig=attackConfig}
  for _, entry in ipairs(ui.list:getChildren()) do
    table.insert(data.targeting, entry.value)
  end
  TargetBot.Looting.save(data.looting)
  config.save(data)
end

TargetBot.allowCaveBot = function(time)
  cavebotAllowance = now + time
end

TargetBot.disallowCaveBot = function()
  cavebotAllowance = 0
end

TargetBot.getAttackConfig = function()
  return attackConfig
end

TargetBot.isMageRunMode = function()
  return attackConfig.style == "mageRun"
end

TargetBot.setMageRunLureState = function(active, center)
  local nextActive = active and true or false
  local nextCenter = nil
  if center and center.x and center.y and center.z then
    nextCenter = {x=center.x, y=center.y, z=center.z}
  end

  local centerChanged = false
  if nextCenter then
    centerChanged = not mageRunState.center
      or mageRunState.center.x ~= nextCenter.x
      or mageRunState.center.y ~= nextCenter.y
      or mageRunState.center.z ~= nextCenter.z
  elseif mageRunState.center then
    centerChanged = true
  end

  if not nextActive or not mageRunState.active or centerChanged then
    mageRunTargetSelection.params = nil
    mageRunTargetSelection.expiresAt = 0
    TargetBot.MageRunSnapshot.createdAt = 0
    if TargetBot.resetMageRunMovement then
      TargetBot.resetMageRunMovement()
    end
  end

  mageRunState.active = nextActive
  mageRunState.center = nextActive and nextCenter or nil
end

TargetBot.getMageRunCenter = function()
  return mageRunState.center
end

TargetBot.isMageRunActive = function()
  if attackConfig.style ~= "mageRun" then
    return false
  end
  if not (CaveBot and CaveBot.isOn and CaveBot.isOn()) then
    return false
  end
  if not mageRunState.active then
    return false
  end
  local focused = CaveBot.actionList and CaveBot.actionList:getFocusedChild()
  return focused and focused.action == "endlure" or false
end

TargetBot.Danger = function()
  return dangerValue
end

TargetBot.lootStatus = function()
  return looterStatus
end


-- attacks
local lastSpell = 0
local lastAttackSpell = 0

TargetBot.saySpell = function(text, delay)
  if type(text) ~= 'string' or text:len() < 1 then return end
  if not delay then delay = 500 end
  if g_game.getProtocolVersion() < 1090 then
    lastAttackSpell = now -- pause attack spells, healing spells are more important
  end
  if lastSpell + delay < now then
    say(text)
    lastSpell = now
    return true
  end
  return false
end

TargetBot.sayAttackSpell = function(text, delay)
  if type(text) ~= 'string' or text:len() < 1 then return end
  if not delay then delay = 2000 end
  if lastAttackSpell + delay < now then
    say(text)
    lastAttackSpell = now
    return true
  end
  return false
end

local lastItemUse = 0
local lastRuneAttack = 0

TargetBot.useItem = function(item, subType, target, delay)
  if not delay then delay = 200 end
  if lastItemUse + delay < now then
    local thing = g_things.getThingType(item)
    if not thing or not thing:isFluidContainer() then
      subType = g_game.getClientVersion() >= 860 and 0 or 1
    end
    if g_game.getClientVersion() < 780 then
      local tmpItem = g_game.findPlayerItem(item, subType)
      if not tmpItem then return end
      g_game.useWith(tmpItem, target, subType) -- using item from bp
    else
      g_game.useInventoryItemWith(item, target, subType) -- hotkey
    end
    lastItemUse = now
  end
end

TargetBot.useAttackItem = function(item, subType, target, delay)
  if not delay then delay = 2000 end
  if lastRuneAttack + delay < now then
    local thing = g_things.getThingType(item)
    if not thing or not thing:isFluidContainer() then
      subType = g_game.getClientVersion() >= 860 and 0 or 1
    end
    if g_game.getClientVersion() < 780 then
      local tmpItem = g_game.findPlayerItem(item, subType)
      if not tmpItem then return end
      g_game.useWith(tmpItem, target, subType) -- using item from bp  
    else
      g_game.useInventoryItemWith(item, target, subType) -- hotkey
    end
    lastRuneAttack = now
  end
end

UI.Separator()
