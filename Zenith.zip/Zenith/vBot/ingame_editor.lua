setDefaultTab("Main")

local configName = modules.game_bot.contentsPanel.config:getCurrentOption().text
local scriptsDir = "/bot/" .. configName .. "/ingame_scripts"

if not g_resources.directoryExists(scriptsDir) then
  g_resources.makeDir(scriptsDir)
end

storage.ingameScripts = storage.ingameScripts or {enabled = {}, runOnLoad = {}}
storage.ingameScripts.enabled = storage.ingameScripts.enabled or {}
storage.ingameScripts.runOnLoad = storage.ingameScripts.runOnLoad or {}
storage.ingame_hotkeys = nil

local function normalizeScriptName(name)
  name = (name or ""):trim()
  name = name:gsub("/", "_"):gsub("\\", "_"):gsub(":", "_"):gsub("%*", "_"):gsub("%?", "_"):gsub("\"", "_"):gsub("<", "_"):gsub(">", "_"):gsub("|", "_")
  if name:len() == 0 then
    return nil
  end
  if name:lower():sub(-4) ~= ".lua" then
    name = name .. ".lua"
  end
  return name
end

local function scriptPath(fileName)
  return scriptsDir .. "/" .. fileName
end

local function isLuaFile(fileName)
  return fileName:lower():sub(-4) == ".lua"
end

local function isEnabled(fileName)
  return table.find(storage.ingameScripts.enabled, fileName)
end

local function isRunOnLoad(fileName)
  return table.find(storage.ingameScripts.runOnLoad, fileName)
end

local function enableScript(fileName)
  if not isEnabled(fileName) then
    table.insert(storage.ingameScripts.enabled, fileName)
  end
end

local function disableScript(fileName)
  table.removevalue(storage.ingameScripts.enabled, fileName)
end

local function enableRunOnLoad(fileName)
  enableScript(fileName)
  if not isRunOnLoad(fileName) then
    table.insert(storage.ingameScripts.runOnLoad, fileName)
  end
end

local function disableRunOnLoad(fileName)
  table.removevalue(storage.ingameScripts.runOnLoad, fileName)
end

local function deleteScriptFile(fileName)
  local path = scriptPath(fileName)
  if g_resources.deleteFile then
    return g_resources.deleteFile(path)
  end
  if os and os.remove then
    return os.remove(path)
  end
  return false
end

if not InGameScriptRuntime then
  error("InGameScriptRuntime is not loaded.")
end

InGameScriptRuntime.setScriptsDir(scriptsDir)

local function unloadScriptRuntime(fileName)
  return InGameScriptRuntime.unload(fileName)
end

local function executeScript(fileName)
  return InGameScriptRuntime.execute(fileName)
end

local nativeLoadedScripts = {}

local function executeRunOnLoadScript(fileName)
  local path = scriptPath(fileName)
  if not g_resources.fileExists(path) then
    return false
  end

  local ok, result = pcall(function()
    local contents = g_resources.readFileContents(path)
    assert(load(contents, fileName))()
  end)

  if not ok then
    warn("[In-Game Script Editor] Run on load error (" .. fileName .. "):\n" .. result)
    return false
  end

  nativeLoadedScripts[fileName] = true
  return true
end

local function getRuntimeEnabledScripts()
  local files = {}
  for _, fileName in ipairs(storage.ingameScripts.enabled) do
    if not isRunOnLoad(fileName) then
      table.insert(files, fileName)
    end
  end
  return files
end

local function reloadEnabledScripts()
  return InGameScriptRuntime.reloadEnabled(getRuntimeEnabledScripts())
end

local function loadRunOnLoadScripts()
  local loadedAny = false
  local existingRunOnLoad = {}

  for _, fileName in ipairs(storage.ingameScripts.runOnLoad) do
    if g_resources.fileExists(scriptPath(fileName)) then
      table.insert(existingRunOnLoad, fileName)
      enableScript(fileName)
      if executeRunOnLoadScript(fileName) then
        loadedAny = true
      end
    end
  end

  storage.ingameScripts.runOnLoad = existingRunOnLoad
  return loadedAny
end

local function listScripts()
  local files = {}
  for _, fileName in ipairs(g_resources.listDirectoryFiles(scriptsDir, false, false)) do
    if isLuaFile(fileName) then
      table.insert(files, fileName)
    end
  end
  table.sort(files)
  return files
end

g_ui.loadUIFromString([[
InGameScriptEntry < Label
  background-color: alpha
  text-offset: 2 0
  focusable: true
  height: 16
  font: verdana-11px-rounded

  $focus:
    background-color: #00000055

InGameScriptsWindow < MainWindow
  text: In-Game Script Editor
  size: 520 355
  @onEscape: self:hide()

  Label
    id: availableTitle
    anchors.left: parent.left
    anchors.top: parent.top
    width: 235
    text-align: center
    text: Available Scripts
    font: verdana-11px-rounded

  Label
    id: enabledTitle
    anchors.right: parent.right
    anchors.top: parent.top
    width: 235
    text-align: center
    text: Enabled Scripts
    font: verdana-11px-rounded

  TextList
    id: availableScripts
    anchors.left: parent.left
    anchors.top: availableTitle.bottom
    width: 235
    height: 230
    margin-top: 4
    vertical-scrollbar: availableScroll
    padding: 1

  VerticalScrollBar
    id: availableScroll
    anchors.top: availableScripts.top
    anchors.bottom: availableScripts.bottom
    anchors.right: availableScripts.right
    step: 14
    pixels-scroll: true

  TextList
    id: enabledScripts
    anchors.right: parent.right
    anchors.top: enabledTitle.bottom
    width: 235
    height: 230
    margin-top: 4
    vertical-scrollbar: enabledScroll
    padding: 1

  VerticalScrollBar
    id: enabledScroll
    anchors.top: enabledScripts.top
    anchors.bottom: enabledScripts.bottom
    anchors.right: enabledScripts.right
    step: 14
    pixels-scroll: true

  Button
    id: loadButton
    anchors.left: parent.left
    anchors.top: availableScripts.bottom
    margin-top: 8
    width: 75
    height: 22
    text: Load
    font: verdana-11px-rounded

  Button
    id: reloadButton
    anchors.left: loadButton.right
    anchors.top: loadButton.top
    margin-left: 5
    width: 75
    height: 22
    text: Reload
    font: verdana-11px-rounded

  BotSwitch
    id: runOnLoadSwitch
    anchors.right: parent.right
    anchors.top: loadButton.top
    width: 110
    height: 22
    text: Run on load
    font: verdana-11px-rounded

  Button
    id: unloadButton
    anchors.right: runOnLoadSwitch.left
    anchors.top: loadButton.top
    margin-right: 5
    width: 75
    height: 22
    text: Unload
    font: verdana-11px-rounded

  Button
    id: newButton
    anchors.left: parent.left
    anchors.top: loadButton.bottom
    margin-top: 6
    width: 75
    height: 22
    text: New
    font: verdana-11px-rounded

  Button
    id: editButton
    anchors.left: newButton.right
    anchors.top: newButton.top
    margin-left: 5
    width: 75
    height: 22
    text: Edit
    font: verdana-11px-rounded

  Button
    id: deleteButton
    anchors.left: editButton.right
    anchors.top: editButton.top
    margin-left: 5
    width: 75
    height: 22
    text: Delete
    font: verdana-11px-rounded

  Button
    id: closeButton
    anchors.right: parent.right
    anchors.top: newButton.top
    width: 75
    height: 22
    text: Close
    font: verdana-11px-rounded
]])

local rootWidget = g_ui.getRootWidget()
local managerWindow = rootWidget and UI.createWindow("InGameScriptsWindow", rootWidget)
local selectedAvailable
local selectedEnabled
local openScriptEditor
local updateRunOnLoadSwitch

local function getFocusedFile(list)
  local focused = list:getFocusedChild()
  return focused and focused.fileName
end

local function getSelectedAvailable()
  return getFocusedFile(managerWindow.availableScripts) or selectedAvailable
end

local function getSelectedEnabled()
  return getFocusedFile(managerWindow.enabledScripts) or selectedEnabled
end

local function createScriptEntry(list, fileName, onDoubleClick)
  local label = g_ui.createWidget("InGameScriptEntry", list)
  if isRunOnLoad(fileName) then
    label:setText("[load] " .. fileName)
  else
    label:setText(fileName)
  end
  label.fileName = fileName
  local selectScript = function(widget)
    widget:focus()
    if list == managerWindow.availableScripts then
      selectedAvailable = widget.fileName
      selectedEnabled = nil
    else
      selectedEnabled = widget.fileName
      selectedAvailable = nil
    end
    if updateRunOnLoadSwitch then
      updateRunOnLoadSwitch()
    end
  end
  label.onClick = selectScript
  label.onMouseRelease = function(widget)
    selectScript(widget)
  end
  label.onDoubleClick = onDoubleClick
  return label
end

local function refreshLists()
  if not managerWindow then return end
  local previousAvailable = selectedAvailable
  local previousEnabled = selectedEnabled
  selectedAvailable = nil
  selectedEnabled = nil
  managerWindow.availableScripts:destroyChildren()
  managerWindow.enabledScripts:destroyChildren()

  for _, fileName in ipairs(listScripts()) do
    if not isEnabled(fileName) then
      local entry = createScriptEntry(managerWindow.availableScripts, fileName, function(widget)
        selectedAvailable = widget.fileName
        selectedEnabled = nil
        openScriptEditor(widget.fileName)
      end)
      if fileName == previousAvailable then
        entry:focus()
        selectedAvailable = fileName
      end
    end
  end

  local existingEnabled = {}
  for _, fileName in ipairs(storage.ingameScripts.enabled) do
    if g_resources.fileExists(scriptPath(fileName)) then
      table.insert(existingEnabled, fileName)
      local entry = createScriptEntry(managerWindow.enabledScripts, fileName, function(widget)
        selectedEnabled = widget.fileName
        selectedAvailable = nil
        openScriptEditor(widget.fileName)
      end)
      if fileName == previousEnabled then
        entry:focus()
        selectedEnabled = fileName
      end
    end
  end
  storage.ingameScripts.enabled = existingEnabled

  local existingRunOnLoad = {}
  for _, fileName in ipairs(storage.ingameScripts.runOnLoad) do
    if g_resources.fileExists(scriptPath(fileName)) and isEnabled(fileName) then
      table.insert(existingRunOnLoad, fileName)
    end
  end
  storage.ingameScripts.runOnLoad = existingRunOnLoad
  if updateRunOnLoadSwitch then
    updateRunOnLoadSwitch()
  end
end

openScriptEditor = function(fileName, defaultContents)
  if not fileName then
    return warn("[In-Game Script Editor] Select a script first.")
  end

  local path = scriptPath(fileName)
  local contents = defaultContents or ""
  if g_resources.fileExists(path) then
    contents = g_resources.readFileContents(path)
  end

  UI.MultilineEditorWindow(contents, {
    title = "Edit Script: " .. fileName,
    description = path,
    width = 650,
    height = 500
  }, function(text)
    g_resources.writeFileContents(path, text)
    if isRunOnLoad(fileName) and nativeLoadedScripts[fileName] then
      warn("[In-Game Script Editor] Run on load script saved. Restart the bot/client to apply it cleanly.")
    elseif isEnabled(fileName) then
      executeScript(fileName)
    end
    refreshLists()
  end)
end

local function openNewScriptDialog()
  UI.EditorWindow("", {
    title = "New Script",
    description = "Script name",
    multiline = false,
    width = 300
  }, function(text)
    local fileName = normalizeScriptName(text)
    if not fileName then
      return warn("[In-Game Script Editor] Invalid script name.")
    end

    local path = scriptPath(fileName)
    if g_resources.fileExists(path) then
      warn("[In-Game Script Editor] Script already exists, opening it.")
    end
    openScriptEditor(fileName, "-- " .. fileName .. "\n\n")
  end)
end

if managerWindow then
  managerWindow:hide()

  updateRunOnLoadSwitch = function()
    local fileName = getSelectedEnabled()
    managerWindow.runOnLoadSwitch:setOn(fileName and isRunOnLoad(fileName) and true or false, true)
  end

  managerWindow.loadButton.onClick = function()
    local fileName = getSelectedAvailable()
    if not fileName then
      return warn("[In-Game Script Editor] Select an available script.")
    end
    enableScript(fileName)
    executeScript(fileName)
    selectedAvailable = nil
    selectedEnabled = fileName
    refreshLists()
  end

  managerWindow.reloadButton.onClick = function()
    reloadEnabledScripts()
    refreshLists()
  end

  managerWindow.unloadButton.onClick = function()
    local fileName = getSelectedEnabled()
    if not fileName then
      return warn("[In-Game Script Editor] Select an enabled script.")
    end
    local wasRunOnLoad = isRunOnLoad(fileName)
    disableScript(fileName)
    disableRunOnLoad(fileName)
    unloadScriptRuntime(fileName)
    if wasRunOnLoad and nativeLoadedScripts[fileName] then
      warn("[In-Game Script Editor] Run on load scripts unload fully after bot/client restart.")
    end
    selectedEnabled = nil
    selectedAvailable = fileName
    refreshLists()
  end

  managerWindow.runOnLoadSwitch.onClick = function(widget)
    local fileName = getSelectedEnabled()
    if not fileName then
      widget:setOn(false, true)
      return warn("[In-Game Script Editor] Select an enabled script.")
    end

    if isRunOnLoad(fileName) then
      disableRunOnLoad(fileName)
      widget:setOn(false, true)
      if nativeLoadedScripts[fileName] then
        warn("[In-Game Script Editor] Run on load disabled. Restart the bot/client to return this script to ingame runtime.")
      else
        executeScript(fileName)
      end
    else
      enableRunOnLoad(fileName)
      unloadScriptRuntime(fileName)
      if executeRunOnLoadScript(fileName) then
        widget:setOn(true, true)
      else
        disableRunOnLoad(fileName)
        executeScript(fileName)
        widget:setOn(false, true)
      end
    end

    refreshLists()
  end

  managerWindow.newButton.onClick = openNewScriptDialog

  managerWindow.editButton.onClick = function()
    openScriptEditor(getSelectedAvailable() or getSelectedEnabled())
  end

  managerWindow.deleteButton.onClick = function()
    local fileName = getSelectedAvailable() or getSelectedEnabled()
    if not fileName then
      return warn("[In-Game Script Editor] Select a script to delete.")
    end
    disableScript(fileName)
    disableRunOnLoad(fileName)
    unloadScriptRuntime(fileName)
    if g_resources.fileExists(scriptPath(fileName)) then
      local ok = deleteScriptFile(fileName)
      if not ok and g_resources.fileExists(scriptPath(fileName)) then
        return warn("[In-Game Script Editor] Unable to delete script file.")
      end
    end
    selectedAvailable = nil
    selectedEnabled = nil
    refreshLists()
  end

  managerWindow.closeButton.onClick = function()
    managerWindow:hide()
  end

  refreshLists()
end

local btIn = UI.Button("In-Game Script Editor", function()
  if not managerWindow then return end
  refreshLists()
  managerWindow:show()
  managerWindow:raise()
  managerWindow:focus()
end)
btIn:setImageColor('#2de0d7')

local loadedAny = loadRunOnLoadScripts()
loadedAny = reloadEnabledScripts() or loadedAny

if loadedAny then
  UI.Separator()
  local label = UI.Label("In-Game Scripts:")
  label:setColor('#9dd1ce')
  label:setFont('verdana-11px-rounded')
end

UI.Separator()
