-- Cavebot by otclient@otclient.ovh
-- visit http://bot.otclient.ovh/

local cavebotTab = "Cave"
local targetingTab = storage.extras.joinBot and "Cave" or "Target"
storage.cavebotCompat = storage.cavebotCompat or {}
local restoreFullFromBisect = storage.loaderCompat and storage.loaderCompat.mode == "loadedCoreCave"

if restoreFullFromBisect then
  storage.cavebotCompat.safeMode = false
  storage.cavebotCompat.stage = "full"
  storage.cavebotCompat.loadTargetBot = true
  storage.cavebotCompat.loadMainUi = true
  storage.cavebotCompat.loadMainRuntime = true
  storage.cavebotCompat.setupEditor = true
  storage.cavebotCompat.setupConfigUi = true
  storage.cavebotCompat.setupExtensions = true
  storage.cavebotCompat.bindMainConfig = true
  storage.cavebotCompat.enableSupportModules = nil
  storage.cavebotCompat.enableSensitiveModules = nil
  storage.cavebotCompat.enableTargetBotBisect = nil
  if storage._configs then
    if storage._configs.cavebot_configs then
      storage._configs.cavebot_configs.enabled = true
    end
    if storage._configs.targetbot_configs then
      storage._configs.targetbot_configs.enabled = true
    end
  end
end

if storage.cavebotCompat.safeMode == nil then
  storage.cavebotCompat.safeMode = true
end
if storage.cavebotCompat.stage == nil then
  storage.cavebotCompat.stage = "full"
end
if storage.cavebotCompat.loadTargetBot == nil then
  storage.cavebotCompat.loadTargetBot = true
end
if storage.cavebotCompat.loadMainUi == nil then
  storage.cavebotCompat.loadMainUi = true
end
if storage.cavebotCompat.loadMainRuntime == nil then
  storage.cavebotCompat.loadMainRuntime = true
end
local cavebotCompat = storage.cavebotCompat
local targetBotBisect = cavebotCompat.stage == "coreOnly"
  and cavebotCompat.loadMainUi
  and not cavebotCompat.loadMainRuntime
  and cavebotCompat.loadTargetBot == false
  and cavebotCompat.safeMode == true

if cavebotCompat.enableTargetBotBisect == nil and targetBotBisect then
  cavebotCompat.enableTargetBotBisect = true
end

local function shouldLoadCavebotModule(module)
  if cavebotCompat.stage == "coreOnly" then
    local coreModules = {
      ["/cavebot/actions.lua"] = true,
      ["/cavebot/config.lua"] = true,
      ["/cavebot/editor.lua"] = true,
      ["/cavebot/example_functions.lua"] = true,
      ["/cavebot/recorder.lua"] = true,
      ["/cavebot/walking.lua"] = true,
      ["/cavebot/cavebot.lua"] = true,
    }
    if cavebotCompat.enableSupportModules then
      coreModules["/cavebot/sell_all.lua"] = true
      coreModules["/cavebot/depositor.lua"] = true
      coreModules["/cavebot/buy_supplies.lua"] = true
      coreModules["/cavebot/d_withdraw.lua"] = true
      coreModules["/cavebot/supply_check.lua"] = true
      coreModules["/cavebot/travel.lua"] = true
      coreModules["/cavebot/doors.lua"] = true
      coreModules["/cavebot/pos_check.lua"] = true
      coreModules["/cavebot/withdraw.lua"] = true
      coreModules["/cavebot/inbox_withdraw.lua"] = true
      coreModules["/cavebot/bank.lua"] = true
      coreModules["/cavebot/clear_tile.lua"] = true
      coreModules["/cavebot/tasker.lua"] = true
      coreModules["/cavebot/imbuing.lua"] = true
    end
    return coreModules[module] == true
  elseif cavebotCompat.stage == "supportOnly" then
    local supportModules = {
      ["/cavebot/sell_all.lua"] = true,
      ["/cavebot/depositor.lua"] = true,
      ["/cavebot/buy_supplies.lua"] = true,
      ["/cavebot/d_withdraw.lua"] = true,
      ["/cavebot/supply_check.lua"] = true,
      ["/cavebot/travel.lua"] = true,
      ["/cavebot/doors.lua"] = true,
      ["/cavebot/pos_check.lua"] = true,
      ["/cavebot/withdraw.lua"] = true,
      ["/cavebot/inbox_withdraw.lua"] = true,
      ["/cavebot/bank.lua"] = true,
      ["/cavebot/clear_tile.lua"] = true,
      ["/cavebot/tasker.lua"] = true,
      ["/cavebot/imbuing.lua"] = true,
    }
    return supportModules[module] == true
  end

  return true
end

local function loadCavebotModule(module)
  if shouldLoadCavebotModule(module) then
    dofile(module)
  end
end

setDefaultTab(cavebotTab)
CaveBot.Extensions = {}
importStyle("/cavebot/cavebot.otui")
importStyle("/cavebot/config.otui")
importStyle("/cavebot/editor.otui")
loadCavebotModule("/cavebot/actions.lua")
loadCavebotModule("/cavebot/config.lua")
loadCavebotModule("/cavebot/editor.lua")
loadCavebotModule("/cavebot/example_functions.lua")
loadCavebotModule("/cavebot/recorder.lua")
loadCavebotModule("/cavebot/walking.lua")
if not cavebotCompat.safeMode or cavebotCompat.enableSensitiveModules then
  dofile("/cavebot/minimap.lua")
end
-- in this section you can add extensions, check extension_template.lua
local configName = modules.game_bot.contentsPanel.config:getCurrentOption().text

local path = "/bot/" .. configName .. "/cavebot/extensions"
if not g_resources.directoryExists(path) then
  g_resources.makeDir(path)
end

local extFiles = g_resources.listDirectoryFiles(path, false, false)
for i, file in ipairs(extFiles) do
  local ext = file:split(".")
  if ext[#ext]:lower() == "lua"  then
    dofile('/cavebot/extensions/'..file)
  end
end
--dofile("/cavebot/extension_template.lua")
loadCavebotModule("/cavebot/sell_all.lua")
loadCavebotModule("/cavebot/depositor.lua")
loadCavebotModule("/cavebot/buy_supplies.lua")
loadCavebotModule("/cavebot/d_withdraw.lua")
loadCavebotModule("/cavebot/supply_check.lua")
loadCavebotModule("/cavebot/travel.lua")
loadCavebotModule("/cavebot/doors.lua")
loadCavebotModule("/cavebot/pos_check.lua")
loadCavebotModule("/cavebot/withdraw.lua")
loadCavebotModule("/cavebot/inbox_withdraw.lua")
if not cavebotCompat.safeMode or cavebotCompat.enableSensitiveModules then
  dofile("/cavebot/lure.lua")
end
loadCavebotModule("/cavebot/bank.lua")
loadCavebotModule("/cavebot/clear_tile.lua")
loadCavebotModule("/cavebot/tasker.lua")
loadCavebotModule("/cavebot/imbuing.lua")
if not cavebotCompat.safeMode or cavebotCompat.enableSensitiveModules then
  dofile("/cavebot/stand_lure.lua")
end
-- main cavebot file, must be last
loadCavebotModule("/cavebot/cavebot.lua")

setDefaultTab(targetingTab)
if cavebotCompat.loadTargetBot or cavebotCompat.enableTargetBotBisect then
  if storage.extras.joinBot then UI.Label("-- [[ TargetBot ]] --") end
  TargetBot = {} -- global namespace
  importStyle("/targetbot/looting.otui")
  importStyle("/targetbot/target.otui")
  importStyle("/targetbot/creature_editor.otui")
  dofile("/targetbot/creature.lua")
  dofile("/targetbot/creature_attack.lua")
  dofile("/targetbot/creature_editor.lua")
  dofile("/targetbot/creature_priority.lua")
  dofile("/targetbot/looting.lua")
  dofile("/targetbot/walking.lua")
  -- main targetbot file, must be last
  dofile("/targetbot/target.lua")
end
