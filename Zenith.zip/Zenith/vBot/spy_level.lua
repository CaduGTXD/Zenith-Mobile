-- config
storage.spyLevel = storage.spyLevel or {}
if storage.spyLevel.enabled == nil then
  storage.spyLevel.enabled = false
end

local keyUp = "="
local keyDown = "-"
setDefaultTab("Tools")

-- script

local lockedLevel = pos().z

onPlayerPositionChange(function(newPos, oldPos)
    if not storage.spyLevel.enabled then return end
    lockedLevel = pos().z
    local mapPanel = modules.game_interface and modules.game_interface.getMapPanel and modules.game_interface.getMapPanel()
    if not mapPanel or not mapPanel.unlockVisibleFloor then return end
    mapPanel:unlockVisibleFloor()
end)

onKeyPress(function(keys)
    if not storage.spyLevel.enabled then return end
    local mapPanel = modules.game_interface and modules.game_interface.getMapPanel and modules.game_interface.getMapPanel()
    if not mapPanel or not mapPanel.lockVisibleFloor then return end
    if keys == keyDown then
        lockedLevel = lockedLevel + 1
        mapPanel:lockVisibleFloor(lockedLevel)
    elseif keys == keyUp then
        lockedLevel = lockedLevel - 1
        mapPanel:lockVisibleFloor(lockedLevel)
    end
end)
