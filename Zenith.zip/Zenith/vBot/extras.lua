setDefaultTab("Main")

-- securing storage namespace
local panelName = "extras"
storage[panelName] = storage[panelName] or {}
local settings = storage[panelName]

-- basic elements
extrasWindow = UI.createWindow('ExtrasWindow', rootWidget)
extrasWindow:hide()
extrasWindow.closeButton.onClick = function(widget)
  extrasWindow:hide()
end

-- available options for dest param
local rightPanel = extrasWindow.content.right
local leftPanel = extrasWindow.content.left

-- objects made by Kondrah - taken from creature editor, minor changes to adapt
local addCheckBox = function(id, title, defaultValue, dest, tooltip)
  local widget = UI.createWidget('ExtrasCheckBox', dest)
  widget.onClick = function()
    widget:setOn(not widget:isOn())
    settings[id] = widget:isOn()
    if id == "checkPlayer" then
      local label = rootWidget.newHealer.targetSettings.vocations.title
      if not widget:isOn() then
        label:setColor("#d9321f")
        label:setTooltip("! WARNING ! \nTurn on check players in extras to use this feature!")
      else
          label:setColor("#dfdfdf")
          label:setTooltip("")
      end
    end
  end
  widget:setText(title)
  widget:setTooltip(tooltip)
  if settings[id] == nil then
    widget:setOn(defaultValue)
  else
    widget:setOn(settings[id])
  end
  settings[id] = widget:isOn()
end

local addItem = function(id, title, defaultItem, dest, tooltip)
  local widget = UI.createWidget('ExtrasItem', dest)
  widget.text:setText(title)
  widget.text:setTooltip(tooltip)
  widget.item:setTooltip(tooltip)
  widget.item:setItemId(settings[id] or defaultItem)
  widget.item.onItemChange = function(widget)
    settings[id] = widget:getItemId()
  end
  settings[id] = settings[id] or defaultItem
end

local addTextEdit = function(id, title, defaultValue, dest, tooltip)
  local widget = UI.createWidget('ExtrasTextEdit', dest)
  widget.text:setText(title)
  widget.textEdit:setText(settings[id] or defaultValue or "")
  widget.text:setTooltip(tooltip)
  widget.textEdit.onTextChange = function(widget,text)
    settings[id] = text
  end
  settings[id] = settings[id] or defaultValue or ""
end

local addScrollBar = function(id, title, min, max, defaultValue, dest, tooltip)
  local widget = UI.createWidget('ExtrasScrollBar', dest)
  widget.text:setTooltip(tooltip)
  widget.scroll:setRange(min, max)
  widget.scroll.onValueChange = function(scroll, value)
    widget.text:setText(title .. ": " .. value)
    if value == 0 then
      value = 1
    end
    settings[id] = value
  end
  widget.scroll:setTooltip(tooltip)
  if max-min > 1000 then
    widget.scroll:setStep(100)
  elseif max-min > 100 then
    widget.scroll:setStep(10)
  end
  widget.scroll:setValue(settings[id] or defaultValue)
  widget.scroll.onValueChange(widget.scroll, widget.scroll:getValue())
end

local btExtras = UI.Button("Extras (Basic Scripts)", function()
  extrasWindow:show()
  extrasWindow:raise()
  extrasWindow:focus()
end)
btExtras:setImageColor("#9799a8")

addItem("rope", "Rope Item", 3003, leftPanel, "This item will be used in various bot related scripts as default rope item.")
addItem("shovel", "Shovel Item", 3457, leftPanel, "This item will be used in various bot related scripts as default shovel item.")
addItem("machete", "Machete Item", 3308, leftPanel, "This item will be used in various bot related scripts as default machete item.")
addItem("scythe", "Scythe Item", 3453, leftPanel, "This item will be used in various bot related scripts as default scythe item.")
addScrollBar("maxUseDist", "Max Distance To Use", 1, 10, 1, leftPanel, "Max distance to 'Use All' hotkey.")
addTextEdit("useAll", "Use All Hotkey", "space", leftPanel, "Set hotkey for universal actions\nrope, shovel, machete, scythe, use, open doors...")
if true then
  local useId = Global.useIds
  local shovelId = Global.shovelIds
  local ropeId = Global.ropeIds
  local macheteId = Global.macheteIds
  local scytheId = Global.scytheIds

  -- script
  if settings.useAll and settings.useAll:len() > 0 then
    hotkey(settings.useAll, function()
        if not modules.game_walking or not modules.game_walking.wsadWalking then return end
        for _, tile in pairs(g_map.getTiles(posz())) do
            if distanceFromPlayer(tile:getPosition()) <= settings.maxUseDist then
                for _, item in pairs(tile:getItems()) do
                    -- use
                    if table.find(useId, item:getId()) then
                        use(item)
                        return
                    elseif table.find(shovelId, item:getId()) then
                        useWith(settings.shovel, item)
                        return
                    elseif table.find(ropeId, item:getId()) then
                        useWith(settings.rope, item) 
                        return
                    elseif table.find(macheteId, item:getId()) then
                        useWith(settings.machete, item)
                        return
                    elseif table.find(scytheId, item:getId()) then
                        useWith(settings.scythe, item)
                        return
                    end
                end
            end
        end
    end)
  end
end

addCheckBox("title", "Custom Window Title", true, rightPanel, "Personalize OTCv8 window name according to character specific.")
if true then
  local vocText = ""

  if voc() == 1 or voc() == 11 then
      vocText = "- EK"
  elseif voc() == 2 or voc() == 12 then
      vocText = "- RP"
  elseif voc() == 3 or voc() == 13 then
      vocText = "- MS"
  elseif voc() == 4 or voc() == 14 then
      vocText = "- ED"
  end

  macro(5000, function()
    if settings.title then
      if hppercent() > 0 then
          g_window.setTitle("Tibia - " .. name() .. " - " .. lvl() .. "lvl " .. vocText)
      else
          g_window.setTitle("Tibia - " .. name() .. " - DEAD")
      end
    else
      g_window.setTitle("Tibia - " .. name())
    end
  end)
end

addCheckBox("separatePm", "Open PM's in new Window", true, rightPanel, "PM's will be automatically opened in new tab after receiving one.")
if true then
  onTalk(function(name, level, mode, text, channelId, pos)
    if mode == 4 and settings.separatePm then
        local g_console = modules.game_console
        local privateTab = g_console.getTab(name)
        if privateTab == nil then
            privateTab = g_console.addTab(name, true)
            g_console.addPrivateText(g_console.applyMessagePrefixies(name, level, text), g_console.SpeakTypesSettings['private'], name, false, name)
        end
        return
    end
  end)
end

addCheckBox("antiKick", "Anti - Kick", true, rightPanel, "Turn every 10 minutes to prevent kick.")
if true then
  macro(600*1000, function()
    if not settings.antiKick then return end
    local dir = player:getDirection()
    turn((dir + 1) % 4)
    schedule(50, function() turn(dir) end)
  end)
end

addCheckBox("oberon", "Auto Reply Oberon", true, rightPanel, "Auto reply to Grand Master Oberon talk minigame.")
if true then
  onTalk(function(name, level, mode, text, channelId, pos)
    if not settings.oberon then return end
    if mode == 34 then
        if string.find(text, "world will suffer for") then
            say("Are you ever going to fight or do you prefer talking?")
        elseif string.find(text, "feet when they see me") then
            say("Even before they smell your breath?")
        elseif string.find(text, "from this plane") then
            say("Too bad you barely exist at all!") 
        elseif string.find(text, "ESDO LO") then
            say("SEHWO ASIMO, TOLIDO ESD") 
        elseif string.find(text, "will soon rule this world") then
            say("Excuse me but I still do not get the message!") 
        elseif string.find(text, "honourable and formidable") then
            say("Then why are we fighting alone right now?") 
        elseif string.find(text, "appear like a worm") then
            say("How appropriate, you look like something worms already got the better of!") 
        elseif string.find(text, "will be the end of mortal") then
            say("Then let me show you the concept of mortality before it!") 
        elseif string.find(text, "virtues of chivalry") then
            say("Dare strike up a Minnesang and you will receive your last accolade!") 
        end
    end
  end)
end

addCheckBox("autoOpenDoors", "Auto Open Doors", true, rightPanel, "Open doors when trying to step on them.")
if true then
  local doorsIds = { 5007, 8265, 1629, 1632, 5129, 6252, 6249, 7715, 7712, 7714, 
                     7719, 6256, 1669, 1672, 5125, 5115, 5124, 17701, 17710, 1642, 
                     6260, 5107, 4912, 6251, 5291, 1683, 1696, 1692, 5006, 2179, 5116, 
                     1632, 11705, 30772, 30774, 6248, 5735, 5732, 5120, 23873, 5736,
                     6264, 5122, 30049, 30042, 7727 }

  function checkForDoors(pos)
    local tile = g_map.getTile(pos)
    if tile then
      local useThing = tile:getTopUseThing()
      if useThing and table.find(doorsIds, useThing:getId()) then
        g_game.use(useThing)
      end
    end
  end

  onKeyPress(function(keys)
    local wsadWalking = modules.game_walking and modules.game_walking.wsadWalking
    if not settings.autoOpenDoors then return end
    local pos = player:getPosition()
    if keys == 'Up' or (wsadWalking and keys == 'W') then
      pos.y = pos.y - 1
    elseif keys == 'Down' or (wsadWalking and keys == 'S') then
      pos.y = pos.y + 1
    elseif keys == 'Left' or (wsadWalking and keys == 'A') then
      pos.x = pos.x - 1
    elseif keys == 'Right' or (wsadWalking and keys == 'D') then
      pos.x = pos.x + 1
    elseif wsadWalking and keys == "Q" then
      pos.y = pos.y - 1
      pos.x = pos.x - 1
    elseif wsadWalking and keys == "E" then
      pos.y = pos.y - 1
      pos.x = pos.x + 1
    elseif wsadWalking and keys == "Z" then
      pos.y = pos.y + 1
      pos.x = pos.x - 1
    elseif wsadWalking and keys == "C" then
      pos.y = pos.y + 1
      pos.x = pos.x + 1
    end
    checkForDoors(pos)
  end)
end

addCheckBox("bless", "Buy bless at login", false, rightPanel, "Say !bless at login.")
if true then
  local blessed = false
  onTextMessage(function(mode,text) 
    if not settings.bless then return end
    
    text = text:lower()

    if text == "you already have all blessings." then
      blessed = true
    end
  end)
  if settings.bless then
    if player:getBlessings() == 0 then
      say("!bless")
      schedule(2000, function() 
          if g_game.getClientVersion() > 1000 then
            if not blessed and player:getBlessings() == 0 then
                warn("!! Blessings not bought !!")
            end
          end
      end)
    end
  end
end

addCheckBox("reUse", "Keep Crosshair", false, rightPanel, "Keep crosshair after using with item")
if true then
  local excluded = {268, 237, 238, 23373, 266, 236, 239, 7643, 23375, 7642, 23374, 5908, 5942} 

  onUseWith(function(pos, itemId, target, subType)
    if settings.reUse and not table.find(excluded, itemId) then
      schedule(50, function()
        item = findItem(itemId)
        if item then
          modules.game_interface.startUseWith(item)
        end
      end)
    end
  end)
end

addCheckBox("checkPlayer", "Check Players", true, rightPanel, "Auto look on players and mark level and vocation on character model")
if true then
  local lookedAt = {}
  local pendingLooks = {}
  local found = 0
  local activeLookName = nil
  local activeLookCreature = nil
  local activeLookTime = 0

  local function trimValue(value)
    if not value then return "" end
    return value:gsub("^%s+", ""):gsub("%s+$", "")
  end

  local function canCheckCreature(creature)
    return creature and creature:isPlayer() and creature ~= player and creature:getPosition().z == posz()
  end

  local function findPlayerByName(name)
    if not name or name == "" then return nil end

    local creature = getCreatureByName(name)
    if creature then return creature end

    local lowerName = name:lower()
    for _, spec in ipairs(getSpectators()) do
      if spec:isPlayer() and spec:getName():lower() == lowerName then
        return spec
      end
    end

    return nil
  end

  local function getCreatureExtraText(creature)
    if not creature then return "" end
    local ok, text = pcall(function() return creature:getText() end)
    if not ok or not text then return "" end
    return text
  end

  local function applyTextToCreature(creature, text)
    if not creature or not text then return end
    pcall(function() creature:setText(text) end)
    pcall(function() creature:setStaticText(text) end)
  end

  local function formatPlayerOverlay(level, voc, guild)
    local lines = {}
    local levelText = tostring(level or "")
    local vocText = trimValue(voc or "")
    local guildText = trimValue(guild or "")

    if levelText ~= "" then
      if vocText ~= "" then
        table.insert(lines, levelText .. " - [" .. vocText .. "]")
      else
        table.insert(lines, levelText)
      end
    end
    if guildText ~= "" then
      table.insert(lines, guildText)
    end

    return table.concat(lines, "\n")
  end

  local function hasPendingLook(name)
    for _, queuedName in ipairs(pendingLooks) do
      if queuedName == name then
        return true
      end
    end
    return false
  end

  local function requestPlayerLook(creature, force)
    if not settings.checkPlayer or not canCheckCreature(creature) then return end
    if getCreatureExtraText(creature) ~= "" and not force then return end

    local name = creature:getName()
    if not name or name == "" then return end
    if not force and lookedAt[name] and now - lookedAt[name] < 2000 then return end
    if activeLookName == name or hasPendingLook(name) then return end

    table.insert(pendingLooks, name)
  end

  local function checkPlayers(force)
    if not settings.checkPlayer then return end

    for _, spec in ipairs(getSpectators()) do
      if canCheckCreature(spec) then
        requestPlayerLook(spec, force)
      end
    end
  end

  local function parseLookMessage(text)
    local function matchLevel(pattern)
      local matchedName, matchedLevel = text:match(pattern)
      if matchedName and matchedLevel then
        return matchedName, matchedLevel
      end
      return nil, nil
    end

    local name, level = matchLevel("[Yy]ou see%s+(.+)%s+%([Ll]evel%s+(%d+)%)")
    if not name then
      name, level = matchLevel("[Yy]ou see%s+([^%.]+)%.+[Ll]evel[:%s]+(%d+)")
    end
    if not name then
      name, level = matchLevel("[Vv]oce ve%s+(.+)%s+%([Ll]evel%s+(%d+)%)")
    end
    if not name then
      name, level = matchLevel("[Vv]oce ve%s+([^%.]+)%.+[Ll]evel[:%s]+(%d+)")
    end
    if not name then
      name, level = matchLevel("[Vv]oc[^%s]*%s+v[^%s]*%s+(.+)%s+%([Ll]evel%s+(%d+)%)")
    end
    if not name then
      name, level = matchLevel("([%a%s%[%]%-_']+)%s+%([Ll]evel%s+(%d+)%)")
    end
    if not level then
      level = text:match("%([Ll]evel%s+(%d+)%)") or text:match("[Ll]evel[:%s]+(%d+)")
    end
    if not name and level and activeLookName then
      name = activeLookName
    end
    if not level then
      return nil
    end

    name = trimValue((name or ""):gsub("%.$", ""))
    if name == "" then
      return nil
    end

    local lowerText = text:lower()
    local voc = ""
    if lowerText:find("sorcerer") or lowerText:find("feiticeiro") then
      voc = "MS"
    elseif lowerText:find("druid") or lowerText:find("druida") then
      voc = "ED"
    elseif lowerText:find("knight") or lowerText:find("cavaleiro") then
      voc = "EK"
    elseif lowerText:find("paladin") or lowerText:find("paladino") then
      voc = "RP"
    end

    local guild = text:match(" of the ([%w%s%-_']+)[%.,]")
      or text:match(" of ([%w%s%-_']+)[%.,]")
      or text:match(" da ([%w%s%-_']+)[%.,]")
      or text:match(" do ([%w%s%-_']+)[%.,]")
      or ""
    guild = trimValue(guild)
    if guild:len() > 10 then
      guild = guild:sub(1, 10) .. "..."
    end

    return name, level, voc, guild
  end

  macro(500, function()
    checkPlayers(false)
  end)

  macro(100, function()
    if not settings.checkPlayer then return end

    if activeLookName then
      if now - activeLookTime < 1200 then
        return
      end
      activeLookName = nil
      activeLookCreature = nil
    end

    while #pendingLooks > 0 do
      local name = table.remove(pendingLooks, 1)
      local creature = findPlayerByName(name)
      if canCheckCreature(creature) then
        activeLookName = name
        activeLookCreature = creature
        activeLookTime = now
        lookedAt[name] = now
        found = now
        g_game.look(creature)
        return
      end
    end
  end)

  if settings.checkPlayer then
    schedule(500, function()
      checkPlayers(true)
    end)
  end

  onPlayerPositionChange(function(newPos, oldPos)
    if not settings.checkPlayer or not oldPos then return end

    schedule(100, function()
      checkPlayers(newPos.z ~= oldPos.z)
    end)
  end)

  onCreatureAppear(function(creature)
    requestPlayerLook(creature, true)
  end)

  onCreatureDisappear(function(creature)
    if not creature or not creature:isPlayer() then return end
    local name = creature:getName()
    if not name or name == "" then return end
    lookedAt[name] = nil
    if activeLookName == name then
      activeLookName = nil
      activeLookCreature = nil
    end
  end)

  onTextMessage(function(mode, text)
    if not settings.checkPlayer then return end

    local name, level, voc, guild = parseLookMessage(text)
    if not level then return end

    local displayText = formatPlayerOverlay(level, voc, guild)
    local creature = findPlayerByName(name) or activeLookCreature
    applyTextToCreature(creature, displayText)

    if name and activeLookName and name:lower() == activeLookName:lower() then
      activeLookName = nil
      activeLookCreature = nil
    end

    if found and now - found < 800 then
      modules.game_textmessage.clearMessages()
    end
  end)
end

addCheckBox("highlightTarget", "Highlight Current Target", true, rightPanel, "Additionaly hightlight current target with red glow")
if true then
  local function forceMarked(creature)
    if target() == creature then
        creature:setMarked("red")
        return schedule(333, function() forceMarked(creature) end)
    end
  end

  onAttackingCreatureChange(function(newCreature, oldCreature)
    if not settings.highlightTarget then return end
      if oldCreature then
          oldCreature:setMarked('')
      end
      if newCreature then
          forceMarked(newCreature)
      end
  end)
end
