-- setDefaultTab(storage.extras.joinBot and "Cave" or "Target")
setDefaultTab("Target")
-- UI.Separator()
-- locales
local panelName = "AttackBot"
local currentSettings
local showSettings = false
local showItem = false
local category = 1
local patternCategory = 1
local pattern = 1
local mainWindow

-- label library

local categories = {
  "Targeted Spell (exori hur, exori flam, etc)",
  "Area Rune (avalanche, great fireball, etc)",
  "Targeted Rune (sudden death, icycle, etc)",
  "Empowerment (utito tempo, etc)",
  "Absolute Spell (exori, hells core, etc)",
  "Challenge / Support (exeta res, exori moe, exori kor, etc)",
}


local function resolvePatternCategory(selectedCategory)
  if selectedCategory == 4 or selectedCategory == 6 then
    return 3
  elseif selectedCategory == 5 then
    return 4
  end
  return selectedCategory
end

local patterns = {
  -- targeted spells
  {
    "1 Sqm Range (exori ico)",
    "2 Sqm Range",
    "3 Sqm Range (strike spells)",
    "4 Sqm Range (exori san)",
    "5 Sqm Range (exori hur)",
    "6 Sqm Range",
    "7 Sqm Range (exori con)",
    "8 Sqm Range",
    "9 Sqm Range",
    "10 Sqm Range"
  },
  -- area runes
  {
    "Cross (explosion)",
    "Bomb (fire bomb)",
    "Ball (gfb, avalanche)"
  },
  -- empowerment/targeted rune
  {
    "1 Sqm Range",
    "2 Sqm Range",
    "3 Sqm Range",
    "4 Sqm Range",
    "5 Sqm Range",
    "6 Sqm Range",
    "7 Sqm Range",
    "8 Sqm Range",
    "9 Sqm Range",
    "10 Sqm Range",
  },
  -- absolute
  {
    "Adjacent (exori, exori gran)",
    "3x3 Wave (vis hur, tera hur)", 
    "Small Area (mas san, exori mas)",
    "Medium Area (mas flam, mas frigo)",
    "Large Area (mas vis, mas tera)",
    "Short Beam (vis lux)", 
    "Large Beam (gran vis lux)", 
    "Sweep (exori min)", -- 8
    "Small Wave (gran frigo hur)",
    "Big Wave (flam hur, frigo hur)",
    "Huge Wave (gran flam hur)",
  }
}

  -- spellPatterns[category][pattern][1 - normal, 2 - safe]
local spellPatterns = {
  {}, -- blank, wont be used
  -- Area Runes,
  { 
    {     -- cross
     [[ 
      010
      111
      010
     ]],
     -- cross SAFE
     [[
       01110
       01110
       11111
       11111
       11111
       01110
       01110
     ]]
    },
    { -- bomb
      [[
        111
        111
        111
      ]],
      -- bomb SAFE
      [[
        11111
        11111
        11111
        11111
        11111
      ]]
    },
    { -- ball
      [[
        0011100
        0111110
        1111111
        1111111
        1111111
        0111110
        0011100
      ]],
      -- ball SAFE
      [[
        000111000
        001111100
        011111110
        111111111
        111111111
        111111111
        011111110
        001111100
        000111000
      ]]
    },
  },
  {}, -- blank, wont be used
  -- Absolute
  {
    {-- adjacent
      [[
        111
        111
        111
      ]],
      -- adjacent SAFE
      [[
        11111
        11111
        11111
        11111
        11111
      ]]
    },
    { -- 3x3 Wave
      [[
        0000NNN0000
        0000NNN0000
        0000NNN0000
        00000N00000
        WWW00N00EEE
        WWWWW0EEEEE
        WWW00S00EEE
        00000S00000
        0000SSS0000
        0000SSS0000
        0000SSS0000
      ]],
      -- 3x3 Wave SAFE
      [[
        0000NNNNN0000
        0000NNNNN0000
        0000NNNNN0000
        0000NNNNN0000
        WWWW0NNN0EEEE
        WWWWWNNNEEEEE
        WWWWWW0EEEEEE
        WWWWWSSSEEEEE
        WWWW0SSS0EEEE
        0000SSSSS0000
        0000SSSSS0000
        0000SSSSS0000
        0000SSSSS0000
      ]]
    },
    { -- small area
      [[
        0011100
        0111110
        1111111
        1111111
        1111111
        0111110
        0011100
      ]],
      -- small area SAFE
      [[
        000111000
        001111100
        011111110
        111111111
        111111111
        111111111
        011111110
        001111100
        000111000
      ]]
    },
    { -- medium area
      [[
        00000100000
        00011111000
        00111111100
        01111111110
        01111111110
        11111111111
        01111111110
        01111111110
        00111111100
        00001110000
        00000100000
      ]],
      -- medium area SAFE
      [[
        0000011100000
        0000111110000
        0001111111000
        0011111111100
        0111111111110
        0111111111110
        1111111111111
        0111111111110
        0111111111110
        0011111111100
        0001111111000
        0000111110000
        0000011100000
      ]]
    },
    { -- large area
      [[
        0000001000000
        0000011100000
        0000111110000
        0001111111000
        0011111111100
        0111111111110
        1111111111111
        0111111111110
        0011111111100
        0001111111000
        0000111110000
        0000011100000
        0000001000000
      ]],
      -- large area SAFE
      [[
        000000010000000
        000000111000000
        000001111100000
        000011111110000
        000111111111000
        001111111111100
        011111111111110
        111111111111111
        011111111111110
        001111111111100
        000111111111000
        000011111110000
        000001111100000
        000000111000000
        000000010000000
      ]]
    },
    { -- short beam
      [[
        00000N00000
        00000N00000
        00000N00000
        00000N00000
        00000N00000
        WWWWW0EEEEE
        00000S00000
        00000S00000
        00000S00000
        00000S00000
        00000S00000
      ]],
      -- short beam SAFE
      [[
        00000NNN00000
        00000NNN00000
        00000NNN00000
        00000NNN00000
        00000NNN00000
        WWWWWNNNEEEEE
        WWWWWW0EEEEEE
        00000SSS00000
        00000SSS00000
        00000SSS00000
        00000SSS00000
        00000SSS00000
        00000SSS00000
      ]]
    },
    { -- large beam
      [[
        0000000N0000000
        0000000N0000000
        0000000N0000000
        0000000N0000000
        0000000N0000000
        0000000N0000000
        0000000N0000000
        WWWWWWW0EEEEEEE
        0000000S0000000
        0000000S0000000
        0000000S0000000
        0000000S0000000
        0000000S0000000
        0000000S0000000
        0000000S0000000
      ]],
      -- large beam SAFE
      [[
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        WWWWWWWNNNEEEEEEE
        WWWWWWWW0EEEEEEEE
        WWWWWWWSSSEEEEEEE
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
      ]],
    },
    {}, -- sweep, wont be used
    { -- small wave
      [[
        00NNN00
        00NNN00
        WW0N0EE
        WWW0EEE
        WW0S0EE
        00SSS00
        00SSS00
      ]],
      -- small wave SAFE
      [[
        00NNNNN00
        00NNNNN00
        WWNNNNNEE
        WWWWNEEEE
        WWWW0EEEE
        WWWWSEEEE
        WWSSSSSEE
        00SSSSS00
        00SSSSS00
      ]]
    },
    { -- large wave
      [[
        000NNNNN000
        000NNNNN000
        0000NNN0000
        WW00NNN00EE
        WWWW0N0EEEE
        WWWWW0EEEEE
        WWWW0S0EEEE
        WW00SSS00EE
        0000SSS0000
        000SSSSS000
        000SSSSS000
      ]],
      [[
        000NNNNNNN000
        000NNNNNNN000
        000NNNNNNN000
        WWWWNNNNNEEEE
        WWWWNNNNNEEEE
        WWWWWNNNEEEEE
        WWWWWW0EEEEEE
        WWWWWSSSEEEEE
        WWWWSSSSSEEEE
        WWWWSSSSSEEEE
        000SSSSSSS000
        000SSSSSSS000
        000SSSSSSS000
      ]]
    },
    { -- huge wave
      [[
        0000NNNNN0000
        0000NNNNN0000
        00000NNN00000
        00000NNN00000
        WW0000N0000EE
        WWWW00N00EEEE
        WWWWWW0EEEEEE
        WWWW00S00EEEE
        WW0000S0000EE
        00000SSS00000
        00000SSS00000
        0000SSSSS0000
        0000SSSSS0000
      ]],
      [[
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        0000000NNN0000000
        WWWWWWWNNNEEEEEEE
        WWWWWWWW0EEEEEEEE
        WWWWWWWSSSEEEEEEE
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
        0000000SSS0000000
      ]]
    }
  }
}

-- direction patterns
local ek = (voc() == 1 or voc() == 11) and true

local posN = ek and [[
  111
  000
  000
]] or [[
  00011111000
  00011111000
  00011111000
  00011111000
  00000100000
  00000000000
  00000000000
  00000000000
  00000000000
  00000000000
  00000000000
]]

local posE = ek and [[
  001
  001
  001
]] or   [[
  00000000000
  00000000000
  00000000000
  00000001111
  00000001111
  00000011111
  00000001111
  00000001111
  00000000000
  00000000000
  00000000000
]]
local posS = ek and [[
  000
  000
  111
]] or   [[
  00000000000
  00000000000
  00000000000
  00000000000
  00000000000
  00000000000
  00000100000
  00011111000
  00011111000
  00011111000
  00011111000
]]
local posW = ek and [[
  100
  100
  100
]] or   [[
  00000000000
  00000000000
  00000000000
  11110000000
  11110000000
  11111000000
  11110000000
  11110000000
  00000000000
  00000000000
  00000000000
]]

-- AttackBotConfig
-- create blank profiles 
if not AttackBotConfig[panelName] or not AttackBotConfig[panelName][1] or #AttackBotConfig[panelName] ~= 5 then
  AttackBotConfig[panelName] = {
    [1] = {
      enabled = false,
      attackTable = {},
      ignoreMana = true,
      Kills = false,
      Rotate = false,
      name = "Profile #1",
      Cooldown = true,
      Visible = true,
      OldSchool = false,
      pvpMode = false,
      KillsAmount = 1,
      PvpSafe = true,
      BlackListSafe = false,
      AntiRsRange = 5
    },
    [2] = {
      enabled = false,
      attackTable = {},
      ignoreMana = true,
      Kills = false,
      Rotate = false,
      name = "Profile #2",
      Cooldown = true,
      Visible = true,
      OldSchool = false,
      pvpMode = false,
      KillsAmount = 1,
      PvpSafe = true,
      BlackListSafe = false,
      AntiRsRange = 5
    },
    [3] = {
      enabled = false,
      attackTable = {},
      ignoreMana = true,
      Kills = false,
      Rotate = false,
      name = "Profile #3",
      Cooldown = true,
      Visible = true,
      OldSchool = false,
      pvpMode = false,
      KillsAmount = 1,
      PvpSafe = true,
      BlackListSafe = false,
      AntiRsRange = 5
    },
    [4] = {
      enabled = false,
      attackTable = {},
      ignoreMana = true,
      Kills = false,
      Rotate = false,
      name = "Profile #4",
      Cooldown = true,
      Visible = true,
      OldSchool = false,
      pvpMode = false,
      KillsAmount = 1,
      PvpSafe = true,
      BlackListSafe = false,
      AntiRsRange = 5
    },
    [5] = {
      enabled = false,
      attackTable = {},
      ignoreMana = true,
      Kills = false,
      Rotate = false,
      name = "Profile #5",
      Cooldown = true,
      Visible = true,
      OldSchool = false,
      pvpMode = false,
      KillsAmount = 1,
      PvpSafe = true,
      BlackListSafe = false,
      AntiRsRange = 5
    },
  }
end
  
if not AttackBotConfig.currentBotProfile or AttackBotConfig.currentBotProfile == 0 or AttackBotConfig.currentBotProfile > 5 then 
  AttackBotConfig.currentBotProfile = 1
end

-- create panel UI
ui = UI.createWidget("AttackBotBotPanel")

-- finding correct table, manual unfortunately
local setActiveProfile = function()
  local n = AttackBotConfig.currentBotProfile
  currentSettings = AttackBotConfig[panelName][n]
end
setActiveProfile()

if not currentSettings.AntiRsRange then
  currentSettings.AntiRsRange = 5 
end

local setProfileName = function()
  ui.name:setText(currentSettings.name)
end

-- small UI elements
ui.title.onClick = function(widget)
  currentSettings.enabled = not currentSettings.enabled
  widget:setOn(currentSettings.enabled)
  vBotConfigSave("atk")
end
  
ui.settings.onClick = function(widget)
  mainWindow:show()
  mainWindow:raise()
  mainWindow:focus()
end

  mainWindow = UI.createWindow("AttackBotWindow")
  mainWindow:hide()

  local panel = mainWindow.mainPanel
  local settingsUI = mainWindow.settingsPanel
  local editingEntry = nil

  local function syncAttackTableFromUi(saveNow)
    currentSettings.attackTable = {}
    for _, child in ipairs(panel.entryList:getChildren()) do
      table.insert(currentSettings.attackTable, child.params)
    end
    if saveNow then
      vBotConfigSave("atk")
    end
  end

  mainWindow.onVisibilityChange = function(widget, visible)
    if not visible then
      syncAttackTableFromUi(true)
    end
  end

  -- main panel

    -- functions
    function toggleSettings()
      panel:setVisible(not showSettings)
      mainWindow.shooterLabel:setVisible(not showSettings)
      settingsUI:setVisible(showSettings)
      mainWindow.settingsLabel:setVisible(showSettings)
      mainWindow.settings:setText(showSettings and "Back" or "Settings")
    end
    toggleSettings()

    mainWindow.settings.onClick = function()
      showSettings = not showSettings
      toggleSettings()
    end

    function toggleItem()
      panel.monsters:setWidth(showItem and 405 or 341)
      panel.itemId:setVisible(showItem)
      panel.spellName:setVisible(not showItem)
    end
    toggleItem()

    function setCategoryText()
      panel.category.description:setText(categories[category])
    end
    setCategoryText()

    function setPatternText()
      local categoryPatterns = patterns[patternCategory]
      local patternText = categoryPatterns and categoryPatterns[pattern]
      if not patternText then
        patternCategory = 3
        pattern = 1
        categoryPatterns = patterns[patternCategory]
        patternText = categoryPatterns and categoryPatterns[pattern] or "1 Sqm Range"
      end
      panel.range.description:setText(patternText)
    end
    setPatternText()

    local function updateEntryButtonText()
      panel.addEntry:setText(editingEntry and "Save" or "New")
    end
    updateEntryButtonText()

    -- in/de/crementation buttons
    panel.previousCategory.onClick = function()
      if category == 1 then
        category = #categories
      else
        category = category - 1
      end

      showItem = (category == 2 or category == 3) and true or false
      patternCategory = resolvePatternCategory(category)
      pattern = 1
      toggleItem()
      setPatternText()
      setCategoryText()
    end
    panel.nextCategory.onClick = function()
      if category == #categories then
        category = 1 
      else
        category = category + 1
      end

      showItem = (category == 2 or category == 3) and true or false
      patternCategory = resolvePatternCategory(category)
      pattern = 1
      toggleItem()
      setPatternText()
      setCategoryText()
    end
    panel.previousSource.onClick = function()
      warn("[AttackBot] TODO, reserved for future use.")
    end
    panel.nextSource.onClick = function()
      warn("[AttackBot] TODO, reserved for future use.")
    end
    panel.previousRange.onClick = function()
      local t = patterns[patternCategory]
      if pattern == 1 then
        pattern = #t 
      else
        pattern = pattern - 1
      end
      setPatternText()
    end
    panel.nextRange.onClick = function()
      local t = patterns[patternCategory]
      if pattern == #t then
        pattern = 1 
      else
        pattern = pattern + 1
      end
      setPatternText()
    end
    -- eo in/de/crementation

  ------- [[core table function]] -------
    function setupWidget(widget)
      local params = widget.params
      params.stationaryTime = math.max(0, tonumber(params.stationaryTime) or 0)

      widget:setText(params.description)
      if params.itemId > 0 then
        widget.spell:setVisible(false)
        widget.id:setVisible(true)
        widget.id:setItemId(params.itemId)
      end
      widget:setTooltip(params.tooltip)
      widget.remove.onClick = function()
        panel.up:setEnabled(false)
        panel.down:setEnabled(false)
        widget:destroy()
        syncAttackTableFromUi(true)
      end
      widget.enabled:setChecked(params.enabled)
      widget.enabled.onClick = function()
        params.enabled = not params.enabled
        widget.enabled:setChecked(params.enabled)
        syncAttackTableFromUi(true)
      end
      -- will serve as edit
      widget.onDoubleClick = function(widget)
        editingEntry = {
          index = panel.entryList:getChildIndex(widget),
          enabled = params.enabled
        }
        panel.monsters:setText(params.creatures)
        panel.manaPercent:setValue(params.mana)
        panel.creatures:setValue(params.count)
        panel.minHp:setValue(params.minHp)
        panel.maxHp:setValue(params.maxHp)
        panel.cooldown:setValue(params.cooldown)
        panel.stationaryTime:setValue(params.stationaryTime or 0)
        showItem = params.itemId > 100 and true or false
        panel.itemId:setItemId(params.itemId)
        panel.spellName:setText(params.spell or "")
        panel.orMore:setChecked(params.orMore)
        toggleItem()
        category = params.category
        patternCategory = params.patternCategory
        pattern = params.pattern
        setPatternText()
        setCategoryText()
        updateEntryButtonText()
        widget:destroy()
      end
      widget.onClick = function(widget)
        if #panel.entryList:getChildren() == 1 then
          panel.up:setEnabled(false)
          panel.down:setEnabled(false)
        elseif panel.entryList:getChildIndex(widget) == 1 then
          panel.up:setEnabled(false)
          panel.down:setEnabled(true)
        elseif panel.entryList:getChildIndex(widget) == panel.entryList:getChildCount() then
          panel.up:setEnabled(true)
          panel.down:setEnabled(false)
        else
          panel.up:setEnabled(true)
          panel.down:setEnabled(true)
        end
      end
    end


    -- refreshing values
    function refreshAttacks()
      if not currentSettings.attackTable then return end

      panel.entryList:destroyChildren()
      for _, entry in ipairs(currentSettings.attackTable) do
        local label = UI.createWidget("AttackEntry", panel.entryList)
        label.params = entry
        setupWidget(label)
      end
    end
    refreshAttacks()
    panel.up:setEnabled(false)
    panel.down:setEnabled(false)

    -- adding values
    panel.addEntry.onClick = function(wdiget)
      -- first variables
      local creatures = panel.monsters:getText():lower()
      local monsters = (creatures:len() == 0 or creatures == "*" or creatures == "monster names") and true or string.split(creatures, ",")
      if monsters ~= true then
        for i, monsterName in ipairs(monsters) do
          monsters[i] = monsterName:trim():lower()
        end
      end
      local mana = panel.manaPercent:getValue()
      local count = panel.creatures:getValue()
      local minHp = panel.minHp:getValue()
      local maxHp = panel.maxHp:getValue()
      local cooldown = panel.cooldown:getValue()
      local stationaryTime = panel.stationaryTime:getValue()
      local itemId = panel.itemId:getItemId()
      local spell = panel.spellName:getText()
      local tooltip = monsters ~= true and creatures
      local orMore = panel.orMore:isChecked()

      -- validation
      if showItem and itemId < 100 then
        return warn("[AttackBot]: please fill item ID!")
      elseif not showItem and (spell:lower() == "spell name" or spell:len() == 0) then
        return warn("[AttackBot]: please fill spell name!")
      end

      local regex = patternCategory ~= 1 and [[^[^\(]+]] or [[^[^R]+]]
      local type = regexMatch(patterns[patternCategory][pattern], regex)[1][1]:trim()
      regex = [[^[^ ]+]]
      local categoryName = regexMatch(categories[category], regex)[1][1]:trim():lower()
      local specificMonsters = monsters == true and "Any Creatures" or "Creatures"
      local attackType = showItem and "rune "..itemId or spell

      local countDescription = orMore and count.."+" or count
      local stationaryDescription = stationaryTime > 0 and ", still "..stationaryTime.."ms" or ""

      local params = {
        creatures = creatures,
        monsters = monsters,
        mana = mana,
        count = count,
        minHp = minHp,
        maxHp = maxHp,
        cooldown = cooldown,
        stationaryTime = stationaryTime,
        itemId = itemId,
        spell = spell,
        enabled = editingEntry and editingEntry.enabled or true,
        category = category,
        patternCategory = patternCategory,
        pattern = pattern,
        tooltip = tooltip,
        orMore = orMore,
        description = '['..type..'] '..countDescription.. ' '..specificMonsters..': '..attackType..', '..categoryName..' ('..minHp..'%-'..maxHp..'%)'..stationaryDescription
      }

      local label = UI.createWidget("AttackEntry", panel.entryList)
      label.params = params
      setupWidget(label)
      if editingEntry and editingEntry.index then
        local targetIndex = math.max(1, math.min(editingEntry.index, panel.entryList:getChildCount()))
        panel.entryList:moveChildToIndex(label, targetIndex)
        panel.entryList:focusChild(label)
        panel.entryList:ensureChildVisible(label)
      end
      syncAttackTableFromUi(true)
      resetFields()
    end

    -- moving values
    -- up
    panel.up.onClick = function(widget)
      local focused = panel.entryList:getFocusedChild()
      local n = panel.entryList:getChildIndex(focused)

      if n-1 == 1 then
        widget:setEnabled(false)
      end
      panel.down:setEnabled(true)
      panel.entryList:moveChildToIndex(focused, n-1)
      panel.entryList:ensureChildVisible(focused)
      syncAttackTableFromUi(true)
    end
    -- down
    panel.down.onClick = function(widget)
      local focused = panel.entryList:getFocusedChild()
      local n = panel.entryList:getChildIndex(focused)

      if n + 1 == panel.entryList:getChildCount() then
        widget:setEnabled(false)
      end
      panel.up:setEnabled(true)
      panel.entryList:moveChildToIndex(focused, n+1)
      panel.entryList:ensureChildVisible(focused)
      syncAttackTableFromUi(true)
    end

  -- [[settings panel]] --
  settingsUI.profileName.onTextChange = function(widget, text)
    currentSettings.name = text
    setProfileName()
  end
  settingsUI.IgnoreMana.onClick = function(widget)
    currentSettings.ignoreMana = not currentSettings.ignoreMana
    settingsUI.IgnoreMana:setChecked(currentSettings.ignoreMana)
  end
  settingsUI.Rotate.onClick = function(widget)
    currentSettings.Rotate = not currentSettings.Rotate
    settingsUI.Rotate:setChecked(currentSettings.Rotate)
  end
  settingsUI.Kills.onClick = function(widget)
    currentSettings.Kills = not currentSettings.Kills
    settingsUI.Kills:setChecked(currentSettings.Kills)
  end
  settingsUI.Cooldown.onClick = function(widget)
    currentSettings.Cooldown = not currentSettings.Cooldown
    settingsUI.Cooldown:setChecked(currentSettings.Cooldown)
  end
  settingsUI.Visible.onClick = function(widget)
    currentSettings.Visible = not currentSettings.Visible
    settingsUI.Visible:setChecked(currentSettings.Visible)
  end
  settingsUI.OldSchool.onClick = function(widget)
    currentSettings.OldSchool = not currentSettings.OldSchool
    settingsUI.OldSchool:setChecked(currentSettings.OldSchool)
  end
  settingsUI.PvpMode.onClick = function(widget)
    currentSettings.pvpMode = not currentSettings.pvpMode
    settingsUI.PvpMode:setChecked(currentSettings.pvpMode)
  end
  settingsUI.PvpSafe.onClick = function(widget)
    currentSettings.PvpSafe = not currentSettings.PvpSafe
    settingsUI.PvpSafe:setChecked(currentSettings.PvpSafe)
  end
  settingsUI.Training.onClick = function(widget)
    currentSettings.Training = not currentSettings.Training
    settingsUI.Training:setChecked(currentSettings.Training)
  end
  settingsUI.BlackListSafe.onClick = function(widget)
    currentSettings.BlackListSafe = not currentSettings.BlackListSafe
    settingsUI.BlackListSafe:setChecked(currentSettings.BlackListSafe)
  end
  settingsUI.KillsAmount.onValueChange = function(widget, value)
    currentSettings.KillsAmount = value
  end
  settingsUI.AntiRsRange.onValueChange = function(widget, value)
    currentSettings.AntiRsRange = value
  end


   -- window elements
  mainWindow.closeButton.onClick = function()
    showSettings = false
    toggleSettings()
    resetFields()
    mainWindow:hide()
  end

  -- core functions
  function resetFields()
    editingEntry = nil
    showItem = false
    toggleItem()
    pattern = 1
    patternCategory = 1
    category = 1
    setPatternText()
    setCategoryText()
    panel.manaPercent:setText(1)
    panel.creatures:setText(1)
    panel.minHp:setValue(0)
    panel.maxHp:setValue(100)
    panel.cooldown:setText(1000)
    panel.stationaryTime:setValue(0)
    panel.monsters:setText("monster names")
    panel.itemId:setItemId(0)
    panel.spellName:setText("spell name")
    panel.orMore:setChecked(false)
    updateEntryButtonText()
  end
  resetFields()

  function loadSettings()
    -- BOT panel
    ui.title:setOn(currentSettings.enabled)
    setProfileName()
    -- main panel
    refreshAttacks()
    -- settings
    settingsUI.profileName:setText(currentSettings.name)
    settingsUI.Visible:setChecked(currentSettings.Visible)
    settingsUI.OldSchool:setChecked(currentSettings.OldSchool)
    settingsUI.Cooldown:setChecked(currentSettings.Cooldown)
    settingsUI.PvpMode:setChecked(currentSettings.pvpMode)
    settingsUI.PvpSafe:setChecked(currentSettings.PvpSafe)
    settingsUI.BlackListSafe:setChecked(currentSettings.BlackListSafe)
    settingsUI.AntiRsRange:setValue(currentSettings.AntiRsRange)
    settingsUI.IgnoreMana:setChecked(currentSettings.ignoreMana)
    settingsUI.Rotate:setChecked(currentSettings.Rotate)
    settingsUI.Kills:setChecked(currentSettings.Kills)
    settingsUI.KillsAmount:setValue(currentSettings.KillsAmount)
    settingsUI.Training:setChecked(currentSettings.Training)
  end
  loadSettings()

  local activeProfileColor = function()
    for i=1,5 do
      if i == AttackBotConfig.currentBotProfile then
        ui[i]:setColor("green")
      else
        ui[i]:setColor("white")
      end
    end
  end
  activeProfileColor()

  local profileChange = function()
    setActiveProfile()
    activeProfileColor()
    loadSettings()
    resetFields()
    vBotConfigSave("atk")
  end

  for i=1,5 do
    local button = ui[i]
      button.onClick = function()
      AttackBotConfig.currentBotProfile = i
      profileChange()
    end
  end

    -- public functions
    AttackBot = {} -- global table
  
    AttackBot.isOn = function()
      return currentSettings.enabled
    end
    
    AttackBot.isOff = function()
      return not currentSettings.enabled
    end
    
    AttackBot.setOff = function()
      currentSettings.enabled = false
      ui.title:setOn(currentSettings.enabled)
      vBotConfigSave("atk")
    end
    
    AttackBot.setOn = function()
      currentSettings.enabled = true
      ui.title:setOn(currentSettings.enabled)
      vBotConfigSave("atk")
    end
    
    AttackBot.getActiveProfile = function()
      return AttackBotConfig.currentBotProfile -- returns number 1-5
    end
  
    AttackBot.setActiveProfile = function(n)
      if not n or not tonumber(n) or n < 1 or n > 5 then
        return error("[AttackBot] wrong profile parameter! should be 1 to 5 is " .. n)
      else
        AttackBotConfig.currentBotProfile = n
        profileChange()
      end
    end

    AttackBot.show = function()
      mainWindow:show()
      mainWindow:raise()
      mainWindow:focus()
    end


-- otui covered, now support functions
function getPattern(category, pattern, safe)
  safe = safe and 2 or 1

  return spellPatterns[category][pattern][safe]
end


function getMonstersInArea(category, posOrCreature, pattern, minHp, maxHp, safePattern, monsterNamesTable)
  -- monsterNamesTable can be nil
  local monsters = 0
  local t = {}
  if monsterNamesTable == true or not monsterNamesTable then
    t = {}
  else
    t = monsterNamesTable
  end

  if safePattern then
    for i, spec in pairs(getSpectators(posOrCreature, safePattern)) do
      if spec ~= player and (spec:isPlayer() and not spec:isPartyMember()) then
        return 0
      end
    end
  end 

  if category == 1 or category == 3 or category == 4 then
    if category == 1 or category == 3 then
      local name = getTarget() and getTarget():getName()
      if #t ~= 0 and not table.find(t, name, true) then
        return 0
      end
    end
    for i, spec in pairs(getSpectators()) do
      local specHp = spec:getHealthPercent()
      local name = spec:getName():lower()
      monsters = spec:isMonster() and specHp >= minHp and specHp <= maxHp and (#t == 0 or table.find(t, name, true)) and
                 (g_game.getClientVersion() < 960 or spec:getType() < 3) and monsters + 1 or monsters
    end
    return monsters
  end

  for i, spec in pairs(getSpectators(posOrCreature, pattern)) do
      if spec ~= player then
        local specHp = spec:getHealthPercent()
        local name = spec:getName():lower()
        monsters = spec:isMonster() and specHp >= minHp and specHp <= maxHp and (#t == 0 or table.find(t, name)) and
                   (g_game.getClientVersion() < 960 or spec:getType() < 3) and monsters + 1 or monsters
      end
  end

  return monsters
end

-- for area runes only
-- should return valid targets number (int) and position
function getBestTileByPattern(pattern, minHp, maxHp, safePattern, monsterNamesTable)
  local tiles = g_map.getTiles(posz())
  local targetTile = {amount=0,pos=false}

  for i, tile in pairs(tiles) do
    local tPos = tile:getPosition()
    local distance = distanceFromPlayer(tPos)
    if tile:canShoot() and tile:isWalkable() and distance < 4 then
      local amount = getMonstersInArea(2, tPos, pattern, minHp, maxHp, safePattern, monsterNamesTable)
      if amount > targetTile.amount then
        targetTile = {amount=amount,pos=tPos}
      end
    end
  end

  return targetTile.amount > 0 and targetTile or false
end

function executeAttackBotAction(categoryOrPos, idOrFormula, cooldown)
  cooldown = cooldown or 0
  if categoryOrPos == 1 or categoryOrPos == 4 or categoryOrPos == 5 or categoryOrPos == 6 then
    cast(idOrFormula, cooldown)
  elseif categoryOrPos == 3 then
    if currentSettings.OldSchool then
      local item = findItem(idOrFormula)
      if item then
        useWith(item, target())
      end
    else
      useWith(idOrFormula, target())
    end
  end
end

local function getAreaRuneTileThing(tile)
  if not tile then return nil end

  local thing = tile.getTopUseThing and tile:getTopUseThing() or nil
  if thing then return thing end

  return tile.getTopThing and tile:getTopThing() or nil
end

local function useAttackBotAreaRuneOnTile(itemId, targetPos)
  if not itemId or not targetPos then
    return false
  end

  local tile = g_map.getTile(targetPos)
  local targetThing = getAreaRuneTileThing(tile)
  if not targetThing then
    return false
  end

  schedule(5, function()
    useWith(itemId, targetThing)
  end)
  return true
end

local directionalAbsolutePatterns = {
  [2] = true,  -- 3x3 Wave
  [6] = true,  -- Short Beam
  [7] = true,  -- Large Beam
  [8] = true,  -- Sweep
  [9] = true,  -- Small Wave
  [10] = true, -- Big Wave
  [11] = true, -- Huge Wave
}
local pendingRotateCast = nil
local attackBotTurnRetryMs = 35
local attackBotTurnTimeoutMs = 500
local attackBotMovementPauseMs = 140
local directionalScanCacheMs = 25
local directionalScanCache = {
  updatedAt = 0,
  entry = nil,
  bestSide = 0,
  bestDir = nil,
}
local directionalPatternCache = {}
local directionPatternLetters = {
  [0] = "N",
  [1] = "E",
  [2] = "S",
  [3] = "W"
}

local function matchesEntryCount(entry, amount)
  if entry.orMore then
    return amount >= entry.count
  end
  return amount == entry.count
end

local supportSpellRules = {
  ["exeta res"] = {
    mode = "area"
  },
  ["exeta amp res"] = {
    mode = "ranged",
    duration = 12000,
    maxTargets = 3
  },
  ["exana amp res"] = {
    mode = "ranged",
    duration = 8000,
    maxTargets = 3
  },
  ["exori moe"] = {
    mode = "aoeDebuff",
    cast = "exori moe",
    duration = 16000,
    sharedCooldown = 12000,
    patternCategory = 2,
    pattern = 3
  },
  ["exori kor"] = {
    mode = "aoeDebuff",
    cast = "exori kor",
    duration = 16000,
    sharedCooldown = 12000,
    patternCategory = 2,
    pattern = 3
  },
}

local supportSpellAliases = {
  ["expose weakness"] = "exori moe",
  ["sap strength"] = "exori kor"
}

storage.AttackBotSupport = storage.AttackBotSupport or {}
storage.AttackBotSupport.effectIcons = storage.AttackBotSupport.effectIcons or {}
storage.AttackBotSupport.rangedNames = storage.AttackBotSupport.rangedNames or {}

-- Fallback local para clientes/servidores que não enviam os ícones de efeito.
-- Estrutura: supportEffectUntil[spell][creatureId] = timestamp.
local supportEffectUntil = {}
local cripplingSupportCooldownUntil = 0

local function supportNow()
  if type(now) == "number" then
    return now
  end

  if g_clock and g_clock.millis then
    return g_clock.millis()
  end

  return 0
end

local lastPlayerMovementAt = supportNow()

onPlayerPositionChange(function(newPos, oldPos)
  if not newPos or not oldPos
    or newPos.x ~= oldPos.x
    or newPos.y ~= oldPos.y
    or newPos.z ~= oldPos.z then
    lastPlayerMovementAt = supportNow()
  end
end)

local function isPlayerWalkingNow()
  if not player or not player.isWalking then
    return false
  end

  local ok, walking = pcall(function()
    return player:isWalking()
  end)

  return ok and walking or false
end

local function hasBeenStillLongEnough(entry)
  local requiredTime = math.max(0, tonumber(entry and entry.stationaryTime) or 0)
  if requiredTime <= 0 then
    return true
  end

  if isPlayerWalkingNow() then
    lastPlayerMovementAt = supportNow()
    return false
  end

  return supportNow() - lastPlayerMovementAt >= requiredTime
end

local function normalizeSpellName(spell)
  return tostring(spell or ""):trim():lower()
end

local function resolveSupportSpellName(spell)
  local normalized = normalizeSpellName(spell)
  return supportSpellAliases[normalized] or normalized
end

local function normalizeCreatureName(name)
  return tostring(name or ""):trim():lower()
end

local function monsterMatchesEntry(creature, entry)
  if not creature or not creature:isMonster() then return false end

  local hp = creature:getHealthPercent()
  if not hp or hp <= 0 or hp < entry.minHp or hp > entry.maxHp then
    return false
  end

  if g_game.getClientVersion() >= 960 and creature:getType() >= 3 then
    return false
  end

  local configured = entry.monsters
  if configured == true or not configured or #configured == 0 then
    return true
  end

  local creatureName = normalizeCreatureName(creature:getName())
  for _, configuredName in ipairs(configured) do
    if normalizeCreatureName(configuredName) == creatureName then
      return true
    end
  end

  return false
end

local function entryHasExplicitMonsterNames(entry)
  return entry.monsters ~= true
    and type(entry.monsters) == "table"
    and #entry.monsters > 0
end

-- OTClient não possui uma propriedade genérica creature:isRanged().
-- Para entradas com nomes específicos, esses nomes formam a lista ranged.
-- Com "*", usa distância > 1 sqm até aprender o nome pelo ícone do efeito.
local function isLikelyRangedMonster(creature, entry)
  if not creature then return false end

  local name = normalizeCreatureName(creature:getName())
  if storage.AttackBotSupport.rangedNames[name] then
    return true
  end

  if entryHasExplicitMonsterNames(entry) then
    return true
  end

  local creaturePos = creature:getPosition()
  local playerPos = player:getPosition()
  if not creaturePos or creaturePos.z ~= playerPos.z then
    return false
  end

  return distanceFromPlayer(creaturePos) > 1
end

local function getCreatureEffectIconIds(creature)
  local result = {}
  if not creature or not creature.getIcons then
    return result
  end

  pcall(function()
    local icons = creature:getIcons()
    if type(icons) ~= "table" then return end

    for _, iconEntry in pairs(icons) do
      local iconId = nil

      if type(iconEntry) == "number" then
        iconId = iconEntry
      elseif type(iconEntry) == "table" then
        iconId = tonumber(iconEntry.icon or iconEntry.id or iconEntry[1])
      end

      if iconId and iconId > 0 then
        result[iconId] = true
      end
    end
  end)

  return result
end

local function hasKnownSupportIcon(creature, spell)
  local spellIcons = storage.AttackBotSupport.effectIcons[spell]
  if type(spellIcons) ~= "table" then
    return false
  end

  local creatureIcons = getCreatureEffectIconIds(creature)
  for savedId, enabled in pairs(spellIcons) do
    if enabled and creatureIcons[tonumber(savedId)] then
      return true
    end
  end

  return false
end

local function hasLocalSupportEffect(creature, spell)
  local creatureId = creature and creature:getId()
  local spellEffects = supportEffectUntil[spell]
  if not creatureId or not spellEffects then
    return false
  end

  local expiresAt = spellEffects[creatureId]
  if not expiresAt then
    return false
  end

  if supportNow() >= expiresAt then
    spellEffects[creatureId] = nil
    return false
  end

  return true
end

local function hasSupportEffect(creature, spell)
  return hasKnownSupportIcon(creature, spell)
    or hasLocalSupportEffect(creature, spell)
end

local function hasAnyRangedChallengeEffect(creature)
  return hasSupportEffect(creature, "exeta amp res")
    or hasSupportEffect(creature, "exana amp res")
end

local function supportCreatureNeedsSpell(creature, entry, spell, rule)
  if not monsterMatchesEntry(creature, entry) then
    return false
  end

  if rule.mode == "ranged" and not isLikelyRangedMonster(creature, entry) then
    return false
  end

  if rule.mode == "ranged" then
    return not hasAnyRangedChallengeEffect(creature)
  end

  if rule.mode == "aoeDebuff" then
    return not hasSupportEffect(creature, spell)
  end

  -- exeta res: usa somente nomes, HP, alcance e quantidade.
  -- Não exige criatura ranged e não tenta detectar efeito ativo.
  return true
end

local function getSupportAoeOrigin()
  local currentTarget = target()
  local targetHp = currentTarget and currentTarget.getHealthPercent and currentTarget:getHealthPercent()
  if currentTarget and currentTarget:getPosition() and (not targetHp or targetHp > 0) then
    return currentTarget
  end

  return player
end

local function getSupportCandidates(entry, spell, rule)
  local candidates = {}

  if rule.mode == "aoeDebuff" then
    local origin = getSupportAoeOrigin()
    local patternCategory = rule.patternCategory or 2
    local patternIndex = rule.pattern or 3
    local patternData = spellPatterns[patternCategory]
      and spellPatterns[patternCategory][patternIndex]
      and spellPatterns[patternCategory][patternIndex][1]

    if not origin or not patternData then
      return candidates
    end

    for _, creature in pairs(getSpectators(origin, patternData)) do
      if creature ~= player and supportCreatureNeedsSpell(creature, entry, spell, rule) then
        table.insert(candidates, creature)
      end
    end

    table.sort(candidates, function(a, b)
      return distanceFromPlayer(a:getPosition()) < distanceFromPlayer(b:getPosition())
    end)

    return candidates
  end

  local range = tonumber(entry.pattern) or 1
  local playerPos = player:getPosition()

  for _, creature in pairs(getSpectators()) do
    if creature ~= player and supportCreatureNeedsSpell(creature, entry, spell, rule) then
      local creaturePos = creature:getPosition()

      if creaturePos
        and creaturePos.z == playerPos.z
        and distanceFromPlayer(creaturePos) <= range then
        table.insert(candidates, creature)
      end
    end
  end

  table.sort(candidates, function(a, b)
    return distanceFromPlayer(a:getPosition()) < distanceFromPlayer(b:getPosition())
  end)

  return candidates
end

local function rememberLocalSupportEffect(spell, rule, candidates)
  supportEffectUntil[spell] = supportEffectUntil[spell] or {}
  local expiresAt = supportNow() + rule.duration
  local maxTargets = math.min(#candidates, rule.maxTargets or #candidates)

  for index = 1, maxTargets do
    local creature = candidates[index]
    if creature and creature:getId() then
      supportEffectUntil[spell][creature:getId()] = expiresAt
    end
  end
end

local function learnSupportEffectIcons(spell, rule, candidates, iconsBefore)
  if not schedule then return end

  schedule(300, function()
    storage.AttackBotSupport.effectIcons[spell] = storage.AttackBotSupport.effectIcons[spell] or {}
    local savedIcons = storage.AttackBotSupport.effectIcons[spell]

    for _, creature in ipairs(candidates) do
      if creature and creature:getHealthPercent() > 0 then
        local creatureId = creature:getId()
        local before = iconsBefore[creatureId] or {}
        local after = getCreatureEffectIconIds(creature)
        local learnedEffect = false

        for iconId in pairs(after) do
          if not before[iconId] then
            savedIcons[tostring(iconId)] = true
            learnedEffect = true
          end
        end

        -- Se o servidor confirmou o efeito ranged com um ícone novo,
        -- passa a reconhecer esse nome como ranged mesmo quando estiver adjacente.
        if learnedEffect and rule.mode == "ranged" then
          storage.AttackBotSupport.rangedNames[normalizeCreatureName(creature:getName())] = true
        end
      end
    end
  end)
end

local function executeSupportEntry(entry, spell)
  spell = resolveSupportSpellName(spell)
  local rule = supportSpellRules[spell]

  if not rule then
    return false
  end

  local castSpell = rule.cast or spell
  if not canCast(castSpell, not currentSettings.ignoreMana, not currentSettings.Cooldown) then
    return false
  end

  if rule.sharedCooldown and supportNow() < cripplingSupportCooldownUntil then
    return false
  end

  local candidates = getSupportCandidates(entry, spell, rule)
  if not matchesEntryCount(entry, #candidates) then
    return false
  end

  local iconsBefore = {}
  local shouldTrackEffect = rule.mode == "ranged" or rule.mode == "aoeDebuff"
  if shouldTrackEffect then
    for _, creature in ipairs(candidates) do
      iconsBefore[creature:getId()] = getCreatureEffectIconIds(creature)
    end
  end

  executeAttackBotAction(6, castSpell, entry.cooldown)

  if rule.sharedCooldown then
    cripplingSupportCooldownUntil = supportNow() + rule.sharedCooldown
  end

  -- Somente exeta amp res / exana amp res precisam evitar criaturas
  -- que já estão sob o efeito. Exeta res pode ser recastado normalmente.
  -- Also covers aoe debuffs such as exori moe/exori kor.
  if shouldTrackEffect then
    rememberLocalSupportEffect(spell, rule, candidates)
    learnSupportEffectIcons(spell, rule, candidates, iconsBefore)
  end

  return true
end

local function directionalPatternFor(patternText, direction)
  if not patternText then return nil end

  directionalPatternCache[patternText] = directionalPatternCache[patternText] or {}
  local cached = directionalPatternCache[patternText][direction]
  if cached then return cached end

  local selectedLetter = directionPatternLetters[direction]
  local converted = patternText:gsub("[NESW]", function(letter)
    return letter == selectedLetter and "1" or "0"
  end)

  directionalPatternCache[patternText][direction] = converted
  return converted
end

local function getDirectionalEntryAmount(entry, direction)
  if not entry or direction == nil then return 0 end

  -- Sweep has no dedicated pattern in spellPatterns. Keep its historical
  -- directional masks, but still apply this entry's HP/name filters.
  if entry.pattern == 8 then
    if currentSettings.PvpSafe and getPlayers(2) > 0 then
      return 0
    end

    local sweepPatterns = {
      [0] = posN,
      [1] = posE,
      [2] = posS,
      [3] = posW
    }

    return getMonstersInArea(
      5,
      pos(),
      sweepPatterns[direction],
      entry.minHp,
      entry.maxHp,
      false,
      entry.monsters
    )
  end

  local categoryPatterns = spellPatterns[entry.patternCategory]
  local patternData = categoryPatterns and categoryPatterns[entry.pattern]
  if not patternData or not patternData[1] then return 0 end

  local attackPattern = directionalPatternFor(patternData[1], direction)
  local safePattern = false
  if currentSettings.PvpSafe and patternData[2] then
    safePattern = directionalPatternFor(patternData[2], direction)
  end

  return getMonstersInArea(
    5,
    pos(),
    attackPattern,
    entry.minHp,
    entry.maxHp,
    safePattern,
    entry.monsters
  )
end

local function getBestDirectionalSide(entry, force)
  if not force
    and directionalScanCache.entry == entry
    and now - directionalScanCache.updatedAt < directionalScanCacheMs then
    return directionalScanCache.bestSide, directionalScanCache.bestDir
  end

  local currentDirection = player:getDirection()
  local bestSide = -1
  local bestDir = currentDirection

  for direction = 0, 3 do
    local amount = getDirectionalEntryAmount(entry, direction)
    if amount > bestSide
      or (amount == bestSide and direction == currentDirection) then
      bestSide = amount
      bestDir = direction
    end
  end

  directionalScanCache.updatedAt = now
  directionalScanCache.entry = entry
  directionalScanCache.bestSide = math.max(0, bestSide)
  directionalScanCache.bestDir = bestDir
  return directionalScanCache.bestSide, directionalScanCache.bestDir
end

local function pauseMageRunForDirectionalCast(milliseconds)
  if TargetBot
    and TargetBot.isMageRunEmergencyMovement
    and TargetBot.isMageRunEmergencyMovement() then
    return
  end

  if TargetBot and TargetBot.pauseMageRunMovement then
    TargetBot.pauseMageRunMovement(milliseconds or attackBotMovementPauseMs)
  end
end

-- support function covered, now the main loop
macro(10, function()
  if not currentSettings.enabled then return end
  if #panel.entryList:getChildren() == 0 or isInPz() then return end

  local currentTarget = target()
  local attackGroupCooldownActive = modules.game_cooldown.isGroupCooldownIconActive(1)

  if currentSettings.Training and currentTarget and currentTarget:getName():lower():find("training") then return end

  if g_game.getClientVersion() < 960 or not currentSettings.Cooldown then
    delay(400)
  end

  -- A pending rotation is only a short-lived state for its own list entry.
  -- It must never monopolize the whole AttackBot queue: entries above it are
  -- always evaluated first on every loop.
  if pendingRotateCast then
    local pendingEntry = pendingRotateCast.entry
    local expired = now > (pendingRotateCast.expiresAt or 0)
    local lostTarget = not currentTarget
    local disabled = not pendingEntry or not pendingEntry.enabled
    local movedTooRecently = pendingEntry and not hasBeenStillLongEnough(pendingEntry)

    if expired or lostTarget or disabled or movedTooRecently then
      pendingRotateCast = nil
    end
  end

  local pendingEntrySeen = false

  for index, child in ipairs(panel.entryList:getChildren()) do
    local entry = child.params
    local attackData = entry.itemId > 100 and entry.itemId or entry.spell
    local isPendingEntry = pendingRotateCast and pendingRotateCast.entry == entry

    if isPendingEntry then
      pendingEntrySeen = true
    end

    if entry.enabled and manapercent() >= entry.mana and hasBeenStillLongEnough(entry) then
      local requiresTarget = entry.category ~= 6
      local blockedByAttackCooldown = entry.category ~= 6 and attackGroupCooldownActive
      local actionReady = false

      if entry.itemId > 100 then
        actionReady = not blockedByAttackCooldown
          and (not currentSettings.Visible or findItem(entry.itemId))
      else
        actionReady = (entry.category == 6 or not blockedByAttackCooldown)
          and canCast(entry.spell, not currentSettings.ignoreMana, not currentSettings.Cooldown)
      end

      if (not requiresTarget or currentTarget) and actionReady then
        -- challenge / support spells
        if entry.category == 6 then
          if executeSupportEntry(entry, attackData) then
            pendingRotateCast = nil
            return
          end

        -- first PVP scenario
        elseif currentSettings.pvpMode
          and entry.category ~= 5
          and currentTarget:getHealthPercent() >= entry.minHp
          and currentTarget:getHealthPercent() <= entry.maxHp
          and currentTarget:canShoot() then
          if entry.category == 2 then
            return warn("[AttackBot] Area Runes cannot be used in PVP situation!")
          end

          pendingRotateCast = nil
          return executeAttackBotAction(entry.category, attackData, entry.cooldown)
        end

        -- empowerment
        if entry.category == 4 and not isBuffed() then
          local monsterAmount = getMonstersInArea(entry.category, nil, nil, entry.minHp, entry.maxHp, false, entry.monsters)
          if matchesEntryCount(entry, monsterAmount)
            and distanceFromPlayer(currentTarget:getPosition()) <= entry.pattern then
            pendingRotateCast = nil
            return executeAttackBotAction(entry.category, attackData, entry.cooldown)
          end

        elseif entry.category == 1 or entry.category == 3 then
          local monsterAmount = getMonstersInArea(entry.category, nil, nil, entry.minHp, entry.maxHp, false, entry.monsters)
          if matchesEntryCount(entry, monsterAmount)
            and distanceFromPlayer(currentTarget:getPosition()) <= entry.pattern then
            pendingRotateCast = nil
            return executeAttackBotAction(entry.category, attackData, entry.cooldown)
          end

        elseif entry.category == 5 then
          local pattern = entry.pattern
          local safeToCast = (not currentSettings.BlackListSafe or not isBlackListedPlayerInRange(currentSettings.AntiRsRange))
            and (not currentSettings.Kills or killsToRs() > currentSettings.KillsAmount)

          if directionalAbsolutePatterns[pattern] then
            local currentDirection = player:getDirection()
            local amount = getDirectionalEntryAmount(entry, currentDirection)
            local castDirection = currentDirection

            if currentSettings.Rotate then
              amount, castDirection = getBestDirectionalSide(entry, true)
            end

            local ready = matchesEntryCount(entry, amount) and safeToCast

            if ready then
              if currentSettings.Rotate and castDirection ~= nil and currentDirection ~= castDirection then
                local samePending = pendingRotateCast
                  and pendingRotateCast.entry == entry
                  and pendingRotateCast.dir == castDirection

                if not samePending then
                  pendingRotateCast = {
                    spell = attackData,
                    cooldown = entry.cooldown,
                    dir = castDirection,
                    entry = entry,
                    index = index,
                    readyAt = now + attackBotTurnRetryMs,
                    expiresAt = now + attackBotTurnTimeoutMs,
                    lastTurnAt = 0
                  }
                end

                if now - (pendingRotateCast.lastTurnAt or 0) >= attackBotTurnRetryMs then
                  pauseMageRunForDirectionalCast(attackBotMovementPauseMs)
                  turn(castDirection)
                  pendingRotateCast.lastTurnAt = now
                end

                -- This is currently the highest-priority valid action. Hold the
                -- lower entries only for the brief turn, not for an arbitrary
                -- 500 ms cooldown wait.
                return
              end

              if isPendingEntry and now < (pendingRotateCast.readyAt or 0) then
                return
              end

              pendingRotateCast = nil

              -- The movement pause is needed only while turning. Send the wave
              -- first, then release Mage Run immediately and reuse its current
              -- escape/kiting destination without waiting for the old pause to
              -- expire. Packet order remains cast first, movement second.
              local result = executeAttackBotAction(entry.category, attackData, entry.cooldown)
              if TargetBot and TargetBot.resumeMageRunMovement then
                TargetBot.resumeMageRunMovement(true)
              end
              return result
            end

            if isPendingEntry then
              pendingRotateCast = nil
            end
          else
            local pCat = entry.patternCategory
            local safe = currentSettings.PvpSafe and spellPatterns[pCat][entry.pattern][2] or false
            local monsterAmount = getMonstersInArea(
              entry.category,
              pos(),
              spellPatterns[pCat][entry.pattern][1],
              entry.minHp,
              entry.maxHp,
              safe,
              entry.monsters
            )

            if matchesEntryCount(entry, monsterAmount) and safeToCast then
              pendingRotateCast = nil
              return executeAttackBotAction(entry.category, attackData, entry.cooldown)
            end
          end

        elseif entry.category == 2 then
          local pCat = entry.patternCategory
          local safe = currentSettings.PvpSafe and spellPatterns[pCat][entry.pattern][2] or false
          local data = getBestTileByPattern(spellPatterns[pCat][entry.pattern][1], entry.minHp, entry.maxHp, safe, entry.monsters)
          local monsterAmount
          local targetPos

          if data then
            monsterAmount = data.amount
            targetPos = data.pos
          end

          if monsterAmount and matchesEntryCount(entry, monsterAmount) then
            if (not currentSettings.BlackListSafe or not isBlackListedPlayerInRange(currentSettings.AntiRsRange))
              and (not currentSettings.Kills or killsToRs() > currentSettings.KillsAmount) then
              if useAttackBotAreaRuneOnTile(attackData, targetPos) then
                pendingRotateCast = nil
                return
              end
            end
          end
        end
      elseif isPendingEntry then
        -- Its spell/rune is not actually ready. Do not let a stale pending wave
        -- block lower-priority attacks that can be used right now.
        pendingRotateCast = nil
      end
    elseif isPendingEntry then
      pendingRotateCast = nil
    end
  end

  if pendingRotateCast and not pendingEntrySeen then
    pendingRotateCast = nil
  end
end)
UI.Separator()
