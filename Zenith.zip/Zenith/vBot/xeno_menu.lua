local gameRootPanel = modules.game_interface and modules.game_interface.gameRootPanel
if gameRootPanel and not gameRootPanel._vbotXenoMenuHooked then
    gameRootPanel._vbotXenoMenuHooked = true
    gameRootPanel._vbotXenoMenuOriginalOnMouseRelease = gameRootPanel.onMouseRelease

    gameRootPanel.onMouseRelease = function(widget, mousePos, mouseButton)
        local original = gameRootPanel._vbotXenoMenuOriginalOnMouseRelease

        if mouseButton == 2 then
            local child = rootWidget and rootWidget.recursiveGetChildByPos and rootWidget:recursiveGetChildByPos(mousePos)
            if child == widget then
                local ok, result = pcall(function()
                    local menu = g_ui.createWidget('PopupMenu')
                    menu:setId("blzMenu")
                    menu:setGameMenu(true)
                    menu:addOption('AttackBot', AttackBot.show, "OTCv8")
                    menu:addOption('HealBot', HealBot.show, "OTCv8")
                    menu:addOption('Conditions', Conditions.show, "OTCv8")
                    menu:addSeparator()
                    menu:addOption('CaveBot', function()
                        if CaveBot.isOn() then
                            CaveBot.setOff()
                        else
                            CaveBot.setOn()
                        end
                    end, CaveBot.isOn() and "ON " or "OFF ")
                    menu:addOption('TargetBot', function()
                        if TargetBot.isOn() then
                            TargetBot.setOff()
                        else
                            TargetBot.setOn()
                        end
                    end, TargetBot.isOn() and "ON " or "OFF ")
                    menu:display(mousePos)
                    return true
                end)

                if ok then
                    return result
                end

                warn("[vBot] xeno_menu error: " .. result)
            end
        end

        if original then
            return original(widget, mousePos, mouseButton)
        end
        return false
    end
end
