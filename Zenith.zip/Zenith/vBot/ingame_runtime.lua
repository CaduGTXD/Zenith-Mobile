InGameScriptRuntime = InGameScriptRuntime or {}

local Runtime = InGameScriptRuntime

Runtime.runtimes = Runtime.runtimes or {}
Runtime.eventProxies = Runtime.eventProxies or {}
Runtime.minMacroInterval = Runtime.minMacroInterval or 200
Runtime.slowCallbackWarningMs = Runtime.slowCallbackWarningMs or 80
Runtime.slowCallbackWarningDelay = Runtime.slowCallbackWarningDelay or 3000

local function scriptPath(fileName)
  return Runtime.scriptsDir .. "/" .. fileName
end

local function trackWidget(runtime, widget)
  local widgetType = type(widget)
  if widget and (widgetType == "table" or widgetType == "userdata") then
    table.insert(runtime.widgets, widget)
    if widgetType == "table" then
      for _, child in pairs(widget) do
        local childType = type(child)
        local ok, destroyFn = pcall(function()
          return child and child.destroy
        end)
        if ok and destroyFn and (childType == "table" or childType == "userdata") then
          table.insert(runtime.widgets, child)
        end
      end
    end
  end
  return widget
end

local function stopMacro(macroObj)
  pcall(function() if macroObj and macroObj.setOff then macroObj.setOff() end end)
  pcall(function() if macroObj and macroObj.setOn then macroObj.setOn(false) end end)
  pcall(function() if macroObj and macroObj.setOff then macroObj:setOff() end end)
  pcall(function() if macroObj and macroObj.setOn then macroObj:setOn(false) end end)
  pcall(function() if macroObj and macroObj.destroy then macroObj:destroy() end end)
end

local function getMillis()
  if g_clock and g_clock.millis then
    return g_clock.millis()
  end
  if os and os.clock then
    return math.floor(os.clock() * 1000)
  end
  return now or 0
end

local function callMacro(args)
  if args[10] ~= nil then
    return macro(args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10])
  elseif args[9] ~= nil then
    return macro(args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9])
  elseif args[8] ~= nil then
    return macro(args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8])
  elseif args[7] ~= nil then
    return macro(args[1], args[2], args[3], args[4], args[5], args[6], args[7])
  elseif args[6] ~= nil then
    return macro(args[1], args[2], args[3], args[4], args[5], args[6])
  elseif args[5] ~= nil then
    return macro(args[1], args[2], args[3], args[4], args[5])
  elseif args[4] ~= nil then
    return macro(args[1], args[2], args[3], args[4])
  elseif args[3] ~= nil then
    return macro(args[1], args[2], args[3])
  elseif args[2] ~= nil then
    return macro(args[1], args[2])
  end
  return macro(args[1])
end

local function wrapCallback(runtime, callback)
  return function(...)
    if not runtime.active then
      return
    end

    local started = getMillis()
    local result = callback(...)
    local elapsed = getMillis() - started

    if elapsed >= Runtime.slowCallbackWarningMs then
      local lastWarning = runtime.slowWarnings[callback]
      local currentTime = now or getMillis()
      if not lastWarning or currentTime - lastWarning >= Runtime.slowCallbackWarningDelay then
        runtime.slowWarnings[callback] = currentTime
        warn("Slow ingame script macro (" .. elapsed .. "ms): " .. runtime.fileName)
      end
    end

    return result
  end
end

local function addEvent(runtime, eventName, registerFn, callback)
  Runtime.eventProxies[runtime.fileName] = Runtime.eventProxies[runtime.fileName] or {}

  local proxy = Runtime.eventProxies[runtime.fileName][eventName]
  if not proxy then
    proxy = {active = false, callbacks = {}}
    Runtime.eventProxies[runtime.fileName][eventName] = proxy

    registerFn(function(...)
      if not proxy.active then return end
      for _, registeredCallback in ipairs(proxy.callbacks) do
        registeredCallback(...)
      end
    end)
  end

  proxy.active = true
  table.insert(proxy.callbacks, callback)
  runtime.eventProxies[eventName] = proxy
  runtime.stats.events = runtime.stats.events + 1
end

local function clearEventProxies(runtime)
  for _, proxy in pairs(runtime.eventProxies) do
    proxy.active = false
    proxy.callbacks = {}
  end
end

local function setWrappers(runtime)
  local previous = {
    macro = __isrMacro,
    schedule = __isrSchedule,
    setupUI = __isrSetupUI,
    UI = __isrUI,
    addSwitch = __isrAddSwitch,
    addIcon = __isrAddIcon,
    onTalk = __isrOnTalk,
    onTextMessage = __isrOnTextMessage,
    onKeyPress = __isrOnKeyPress,
    onKeyDown = __isrOnKeyDown,
    onMousePress = __isrOnMousePress,
    onMouseRelease = __isrOnMouseRelease,
    onUse = __isrOnUse,
    onAddThing = __isrOnAddThing,
    onRemoveThing = __isrOnRemoveThing,
    onCreatureAppear = __isrOnCreatureAppear,
    onCreatureDisappear = __isrOnCreatureDisappear,
    onCreaturePositionChange = __isrOnCreaturePositionChange,
    onCreatureHealthPercentChange = __isrOnCreatureHealthPercentChange,
    onAttackingCreatureChange = __isrOnAttackingCreatureChange,
    onPlayerPositionChange = __isrOnPlayerPositionChange,
    onPlayerHealthChange = __isrOnPlayerHealthChange,
    onManaChange = __isrOnManaChange,
    onContainerOpen = __isrOnContainerOpen,
    onContainerClose = __isrOnContainerClose,
    onContainerUpdateItem = __isrOnContainerUpdateItem,
    onAddItem = __isrOnAddItem,
    onSpellCooldown = __isrOnSpellCooldown,
    onGroupSpellCooldown = __isrOnGroupSpellCooldown
  }

  __isrMacro = function(...)
    local args = {...}
    if type(args[1]) == "number" and args[1] < Runtime.minMacroInterval then
      args[1] = Runtime.minMacroInterval
    end

    for i = #args, 1, -1 do
      if type(args[i]) == "function" then
        args[i] = wrapCallback(runtime, args[i])
        break
      end
    end

    local macroObj = callMacro(args)
    table.insert(runtime.macros, macroObj)
    runtime.stats.macros = runtime.stats.macros + 1

    if macroObj and macroObj.switch then
      trackWidget(runtime, macroObj.switch)
    end

    return macroObj
  end

  __isrSchedule = function(delayMs, callback)
    runtime.stats.schedules = runtime.stats.schedules + 1
    return schedule(delayMs, wrapCallback(runtime, callback))
  end

  __isrSetupUI = function(...)
    return trackWidget(runtime, setupUI(...))
  end

  __isrUI = setmetatable({}, {
    __index = function(_, key)
      local value = UI[key]
      if type(value) ~= "function" then
        return value
      end
      return function(...)
        return trackWidget(runtime, value(...))
      end
    end
  })

  __isrAddSwitch = function(...)
    return trackWidget(runtime, addSwitch(...))
  end

  __isrAddIcon = function(...)
    return trackWidget(runtime, addIcon(...))
  end

  if onTalk then __isrOnTalk = function(callback) return addEvent(runtime, "onTalk", onTalk, callback) end end
  if onTextMessage then __isrOnTextMessage = function(callback) return addEvent(runtime, "onTextMessage", onTextMessage, callback) end end
  if onKeyPress then __isrOnKeyPress = function(callback) return addEvent(runtime, "onKeyPress", onKeyPress, callback) end end
  if onKeyDown then __isrOnKeyDown = function(callback) return addEvent(runtime, "onKeyDown", onKeyDown, callback) end end
  if onMousePress then __isrOnMousePress = function(callback) return addEvent(runtime, "onMousePress", onMousePress, callback) end end
  if onMouseRelease then __isrOnMouseRelease = function(callback) return addEvent(runtime, "onMouseRelease", onMouseRelease, callback) end end
  if onUse then __isrOnUse = function(callback) return addEvent(runtime, "onUse", onUse, callback) end end
  if onAddThing then __isrOnAddThing = function(callback) return addEvent(runtime, "onAddThing", onAddThing, callback) end end
  if onRemoveThing then __isrOnRemoveThing = function(callback) return addEvent(runtime, "onRemoveThing", onRemoveThing, callback) end end
  if onCreatureAppear then __isrOnCreatureAppear = function(callback) return addEvent(runtime, "onCreatureAppear", onCreatureAppear, callback) end end
  if onCreatureDisappear then __isrOnCreatureDisappear = function(callback) return addEvent(runtime, "onCreatureDisappear", onCreatureDisappear, callback) end end
  if onCreaturePositionChange then __isrOnCreaturePositionChange = function(callback) return addEvent(runtime, "onCreaturePositionChange", onCreaturePositionChange, callback) end end
  if onCreatureHealthPercentChange then __isrOnCreatureHealthPercentChange = function(callback) return addEvent(runtime, "onCreatureHealthPercentChange", onCreatureHealthPercentChange, callback) end end
  if onAttackingCreatureChange then __isrOnAttackingCreatureChange = function(callback) return addEvent(runtime, "onAttackingCreatureChange", onAttackingCreatureChange, callback) end end
  if onPlayerPositionChange then __isrOnPlayerPositionChange = function(callback) return addEvent(runtime, "onPlayerPositionChange", onPlayerPositionChange, callback) end end
  if onPlayerHealthChange then __isrOnPlayerHealthChange = function(callback) return addEvent(runtime, "onPlayerHealthChange", onPlayerHealthChange, callback) end end
  if onManaChange then __isrOnManaChange = function(callback) return addEvent(runtime, "onManaChange", onManaChange, callback) end end
  if onContainerOpen then __isrOnContainerOpen = function(callback) return addEvent(runtime, "onContainerOpen", onContainerOpen, callback) end end
  if onContainerClose then __isrOnContainerClose = function(callback) return addEvent(runtime, "onContainerClose", onContainerClose, callback) end end
  if onContainerUpdateItem then __isrOnContainerUpdateItem = function(callback) return addEvent(runtime, "onContainerUpdateItem", onContainerUpdateItem, callback) end end
  if onAddItem then __isrOnAddItem = function(callback) return addEvent(runtime, "onAddItem", onAddItem, callback) end end
  if onSpellCooldown then __isrOnSpellCooldown = function(callback) return addEvent(runtime, "onSpellCooldown", onSpellCooldown, callback) end end
  if onGroupSpellCooldown then __isrOnGroupSpellCooldown = function(callback) return addEvent(runtime, "onGroupSpellCooldown", onGroupSpellCooldown, callback) end end

  return previous
end

local function restoreWrappers(previous)
  __isrMacro = previous.macro
  __isrSchedule = previous.schedule
  __isrSetupUI = previous.setupUI
  __isrUI = previous.UI
  __isrAddSwitch = previous.addSwitch
  __isrAddIcon = previous.addIcon
  __isrOnTalk = previous.onTalk
  __isrOnTextMessage = previous.onTextMessage
  __isrOnKeyPress = previous.onKeyPress
  __isrOnKeyDown = previous.onKeyDown
  __isrOnMousePress = previous.onMousePress
  __isrOnMouseRelease = previous.onMouseRelease
  __isrOnUse = previous.onUse
  __isrOnAddThing = previous.onAddThing
  __isrOnRemoveThing = previous.onRemoveThing
  __isrOnCreatureAppear = previous.onCreatureAppear
  __isrOnCreatureDisappear = previous.onCreatureDisappear
  __isrOnCreaturePositionChange = previous.onCreaturePositionChange
  __isrOnCreatureHealthPercentChange = previous.onCreatureHealthPercentChange
  __isrOnAttackingCreatureChange = previous.onAttackingCreatureChange
  __isrOnPlayerPositionChange = previous.onPlayerPositionChange
  __isrOnPlayerHealthChange = previous.onPlayerHealthChange
  __isrOnManaChange = previous.onManaChange
  __isrOnContainerOpen = previous.onContainerOpen
  __isrOnContainerClose = previous.onContainerClose
  __isrOnContainerUpdateItem = previous.onContainerUpdateItem
  __isrOnAddItem = previous.onAddItem
  __isrOnSpellCooldown = previous.onSpellCooldown
  __isrOnGroupSpellCooldown = previous.onGroupSpellCooldown
end

local function scriptPrefix()
  return
    "local macro = __isrMacro\n" ..
    "local schedule = __isrSchedule\n" ..
    "local setupUI = __isrSetupUI\n" ..
    "local UI = __isrUI\n" ..
    "local addSwitch = __isrAddSwitch\n" ..
    "local addIcon = __isrAddIcon\n" ..
    "local onTalk = __isrOnTalk or onTalk\n" ..
    "local onTextMessage = __isrOnTextMessage or onTextMessage\n" ..
    "local onKeyPress = __isrOnKeyPress or onKeyPress\n" ..
    "local onKeyDown = __isrOnKeyDown or onKeyDown\n" ..
    "local onMousePress = __isrOnMousePress or onMousePress\n" ..
    "local onMouseRelease = __isrOnMouseRelease or onMouseRelease\n" ..
    "local onUse = __isrOnUse or onUse\n" ..
    "local onAddThing = __isrOnAddThing or onAddThing\n" ..
    "local onRemoveThing = __isrOnRemoveThing or onRemoveThing\n" ..
    "local onCreatureAppear = __isrOnCreatureAppear or onCreatureAppear\n" ..
    "local onCreatureDisappear = __isrOnCreatureDisappear or onCreatureDisappear\n" ..
    "local onCreaturePositionChange = __isrOnCreaturePositionChange or onCreaturePositionChange\n" ..
    "local onCreatureHealthPercentChange = __isrOnCreatureHealthPercentChange or onCreatureHealthPercentChange\n" ..
    "local onAttackingCreatureChange = __isrOnAttackingCreatureChange or onAttackingCreatureChange\n" ..
    "local onPlayerPositionChange = __isrOnPlayerPositionChange or onPlayerPositionChange\n" ..
    "local onPlayerHealthChange = __isrOnPlayerHealthChange or onPlayerHealthChange\n" ..
    "local onManaChange = __isrOnManaChange or onManaChange\n" ..
    "local onContainerOpen = __isrOnContainerOpen or onContainerOpen\n" ..
    "local onContainerClose = __isrOnContainerClose or onContainerClose\n" ..
    "local onContainerUpdateItem = __isrOnContainerUpdateItem or onContainerUpdateItem\n" ..
    "local onAddItem = __isrOnAddItem or onAddItem\n" ..
    "local onSpellCooldown = __isrOnSpellCooldown or onSpellCooldown\n" ..
    "local onGroupSpellCooldown = __isrOnGroupSpellCooldown or onGroupSpellCooldown\n"
end

function Runtime.setScriptsDir(path)
  Runtime.scriptsDir = path
end

function Runtime.scriptPath(fileName)
  return scriptPath(fileName)
end

function Runtime.unload(fileName)
  local runtime = Runtime.runtimes[fileName]
  if not runtime then return false end

  runtime.active = false
  clearEventProxies(runtime)

  for _, macroObj in ipairs(runtime.macros) do
    stopMacro(macroObj)
  end

  for i = #runtime.widgets, 1, -1 do
    local widget = runtime.widgets[i]
    pcall(function()
      if widget and widget.destroy then
        widget:destroy()
      end
    end)
  end

  Runtime.runtimes[fileName] = nil
  return true
end

function Runtime.execute(fileName)
  if not Runtime.scriptsDir then
    error("Ingame runtime scriptsDir is not configured.")
  end

  local path = scriptPath(fileName)
  if not g_resources.fileExists(path) then
    return false
  end

  Runtime.unload(fileName)

  local runtime = {
    fileName = fileName,
    active = true,
    macros = {},
    widgets = {},
    eventProxies = {},
    slowWarnings = {},
    stats = {macros = 0, widgets = 0, schedules = 0, events = 0}
  }

  Runtime.runtimes[fileName] = runtime

  local previous = setWrappers(runtime)
  local contents = scriptPrefix() .. g_resources.readFileContents(path)
  local status, result = pcall(function()
    assert(load(contents, fileName))()
  end)
  restoreWrappers(previous)

  runtime.stats.widgets = #runtime.widgets

  if not status then
    Runtime.unload(fileName)
    error("Ingame script error (" .. fileName .. "):\n" .. result)
  end

  return true
end

function Runtime.reloadEnabled(enabledScripts)
  local loadedScripts = {}
  for fileName in pairs(Runtime.runtimes) do
    table.insert(loadedScripts, fileName)
  end

  for _, fileName in ipairs(loadedScripts) do
    Runtime.unload(fileName)
  end

  local loadedAny = false
  for _, fileName in ipairs(enabledScripts) do
    if Runtime.execute(fileName) then
      loadedAny = true
    end
  end

  return loadedAny
end

function Runtime.getStats(fileName)
  local runtime = Runtime.runtimes[fileName]
  return runtime and runtime.stats
end
