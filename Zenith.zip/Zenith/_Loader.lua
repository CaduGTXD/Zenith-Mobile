-- load all otui files, order doesn't matter
local configName = modules.game_bot.contentsPanel.config:getCurrentOption().text

local configFiles = g_resources.listDirectoryFiles("/bot/" .. configName .. "/vBot", true, false)
for i, file in ipairs(configFiles) do
  local ext = file:split(".")
  if ext[#ext]:lower() == "ui" or ext[#ext]:lower() == "otui" then
    g_ui.importStyle(file)
  end
end

local function loadScript(name)
  return dofile("/" .. name .. ".lua")
end

storage.loaderCompat = storage.loaderCompat or {}
if storage.loaderCompat.mode == nil then
  storage.loaderCompat.mode = "full"
end

local skippedInSafeMode = {
  ["vBot/extrasPvp"] = true,
  ["vBot/cave_target_settings"] = true,
  ["vBot/analyzer"] = true,
  ["vBot/spy_level"] = true,
  ["vBot/xeno_menu"] = true,
  ["zFreeScripts/Misc/SkillsHUD"] = true,
  ["vBot/ingame_runtime"] = true,
  ["vBot/ingame_editor"] = true,
}

local bisectAModeScripts = {
  ["vBot/main"] = true,
  ["vBot/items"] = true,
  ["vBot/vlib"] = true,
  ["vBot/new_cavebot_lib"] = true,
  ["vBot/configs"] = true,
  ["vBot/extras"] = true,
  ["vBot/playerlist"] = true,
  ["vBot/alarms"] = true,
  ["vBot/AttackBot"] = true,
  ["vBot/Conditions"] = true,
  ["vBot/Equipper"] = true,
  ["vBot/friend_healer"] = true,
  ["zFreeScripts/Spells/zAutoBuff"] = true,
  ["vBot/HealBot"] = true,
  ["vBot/mana_train"] = true,
  ["vBot/Dropper"] = true,
  ["zFreeScripts/Party/z_Auto-Party"] = true,
  ["vBot/tools"] = true,
  ["vBot/antiRs"] = true,
  ["vBot/eat_food"] = true,
  ["vBot/equip"] = true,
  ["vBot/exeta"] = true,
  ["vBot/npc_talk"] = true,
}

local bisectBModeScripts = {
  ["vBot/main"] = true,
  ["vBot/items"] = true,
  ["vBot/vlib"] = true,
  ["vBot/new_cavebot_lib"] = true,
  ["vBot/configs"] = true,
  ["vBot/extrasPvp"] = true,
  ["vBot/cave_target_settings"] = true,
  ["vBot/cavebot"] = true,
  ["vBot/analyzer"] = true,
  ["vBot/spy_level"] = true,
  ["vBot/supplies"] = true,
  ["vBot/depositer_config"] = true,
  ["vBot/xeno_menu"] = true,
  ["zFreeScripts/Misc/SkillsHUD"] = true,
  ["vBot/ingame_runtime"] = true,
  ["vBot/ingame_editor"] = true,
  ["vBot/ContainerManager"] = true,
  ["vBot/quiver_manager"] = true,
  ["vBot/depot_withdraw"] = true,
}

local loadedBisectAModeScripts = {
  ["vBot/main"] = true,
  ["vBot/items"] = true,
  ["vBot/vlib"] = true,
  ["vBot/new_cavebot_lib"] = true,
  ["vBot/configs"] = true,
  ["vBot/extras"] = true,
  ["vBot/cavebot"] = true,
  ["vBot/playerlist"] = true,
  ["vBot/alarms"] = true,
  ["vBot/AttackBot"] = true,
  ["vBot/Conditions"] = true,
  ["vBot/friend_healer"] = true,
  ["vBot/HealBot"] = true,
  ["vBot/mana_train"] = true,
  ["vBot/eat_food"] = true,
  ["vBot/exeta"] = true,
}

local loadedBisectBModeScripts = {
  ["vBot/main"] = true,
  ["vBot/items"] = true,
  ["vBot/vlib"] = true,
  ["vBot/new_cavebot_lib"] = true,
  ["vBot/configs"] = true,
  ["vBot/Equipper"] = true,
  ["zFreeScripts/Spells/zAutoBuff"] = true,
  ["vBot/Dropper"] = true,
  ["zFreeScripts/Party/z_Auto-Party"] = true,
  ["vBot/ContainerManager"] = true,
  ["vBot/quiver_manager"] = true,
  ["vBot/tools"] = true,
  ["vBot/antiRs"] = true,
  ["vBot/depot_withdraw"] = true,
  ["vBot/equip"] = true,
  ["vBot/supplies"] = true,
  ["vBot/depositer_config"] = true,
  ["vBot/npc_talk"] = true,
}

local loadedCoreBotModeScripts = {
  ["vBot/main"] = true,
  ["vBot/items"] = true,
  ["vBot/vlib"] = true,
  ["vBot/new_cavebot_lib"] = true,
  ["vBot/configs"] = true,
  ["vBot/extras"] = true,
  ["vBot/cavebot"] = true,
  ["vBot/AttackBot"] = true,
}

local loadedSupportAModeScripts = {
  ["vBot/main"] = true,
  ["vBot/items"] = true,
  ["vBot/vlib"] = true,
  ["vBot/new_cavebot_lib"] = true,
  ["vBot/configs"] = true,
  ["vBot/playerlist"] = true,
  ["vBot/alarms"] = true,
  ["vBot/Conditions"] = true,
  ["vBot/friend_healer"] = true,
  ["vBot/HealBot"] = true,
  ["vBot/mana_train"] = true,
  ["vBot/eat_food"] = true,
  ["vBot/exeta"] = true,
}

local loadedCoreCaveModeScripts = {
  ["vBot/main"] = true,
  ["vBot/items"] = true,
  ["vBot/vlib"] = true,
  ["vBot/new_cavebot_lib"] = true,
  ["vBot/configs"] = true,
  ["vBot/cavebot"] = true,
}

local loadedCoreCavePlusModeScripts = {
  ["vBot/main"] = true,
  ["vBot/items"] = true,
  ["vBot/vlib"] = true,
  ["vBot/new_cavebot_lib"] = true,
  ["vBot/configs"] = true,
  ["vBot/extras"] = true,
  ["vBot/cavebot"] = true,
  ["vBot/AttackBot"] = true,
}

local loadedFinalSuspectsModeScripts = {
  ["vBot/main"] = true,
  ["vBot/items"] = true,
  ["vBot/vlib"] = true,
  ["vBot/new_cavebot_lib"] = true,
  ["vBot/configs"] = true,
  ["vBot/extras"] = true,
  ["vBot/cavebot"] = true,
  ["vBot/AttackBot"] = true,
  ["vBot/extrasPvp"] = true,
  ["vBot/cave_target_settings"] = true,
  ["vBot/analyzer"] = true,
  ["vBot/spy_level"] = true,
  ["vBot/xeno_menu"] = true,
  ["zFreeScripts/Misc/SkillsHUD"] = true,
  ["vBot/ingame_runtime"] = true,
  ["vBot/ingame_editor"] = true,
}

local loadedCoreMiscModeScripts = {
  ["vBot/main"] = true,
  ["vBot/items"] = true,
  ["vBot/vlib"] = true,
  ["vBot/new_cavebot_lib"] = true,
  ["vBot/configs"] = true,
  ["vBot/extras"] = true,
  ["vBot/AttackBot"] = true,
}

-- here you can set manually order of scripts
-- libraries should be loaded first
local luaFiles = {
  "vBot/main",
  "vBot/items",
  "vBot/vlib",
  "vBot/new_cavebot_lib",
  "vBot/configs", -- do not change this and above
  "vBot/extras",
  "vBot/extrasPvp",
  "vBot/cave_target_settings",
  "vBot/cavebot",
  "vBot/playerlist",
  "vBot/alarms",
  "vBot/AttackBot", -- last of major modules
  -- "vBot/BotServer",
  -- "vBot/combo",
  "vBot/Conditions",
  "vBot/Equipper",
  "vBot/friend_healer",
  "zFreeScripts/Spells/zAutoBuff",
  "vBot/HealBot",
  -- "vBot/Heal-Old",
  "vBot/mana_train",
  "vBot/Dropper",
  "zFreeScripts/Party/z_Auto-Party",
  "vBot/ContainerManager",
  "vBot/quiver_manager",
  "vBot/tools",
  "vBot/antiRs",
  "vBot/depot_withdraw",
  "vBot/eat_food",
  "vBot/equip",
  "vBot/exeta",
  "vBot/analyzer",
  "vBot/spy_level",
  "vBot/supplies",
  "vBot/depositer_config",
  "vBot/npc_talk",
  "vBot/xeno_menu",
  "vBot/cavebot_control_panel",
  "zFreeScripts/Misc/SkillsHUD",
  "vBot/ingame_runtime",
  "vBot/ingame_editor",
}

local activeMode = storage.loaderCompat.mode

for i, file in ipairs(luaFiles) do
  if activeMode == "safe" then
    if not skippedInSafeMode[file] then
      loadScript(file)
    end
  elseif activeMode == "loadedCoreCave" then
    if loadedCoreCaveModeScripts[file] then
      loadScript(file)
    end
  elseif activeMode == "loadedCoreCavePlus" then
    if loadedCoreCavePlusModeScripts[file] then
      loadScript(file)
    end
  elseif activeMode == "loadedFinalSuspects" then
    if loadedFinalSuspectsModeScripts[file] then
      loadScript(file)
    end
  elseif activeMode == "loadedCoreMisc" then
    if loadedCoreMiscModeScripts[file] then
      loadScript(file)
    end
  elseif activeMode == "loadedCoreBot" then
    if loadedCoreBotModeScripts[file] then
      loadScript(file)
    end
  elseif activeMode == "loadedSupportA" then
    if loadedSupportAModeScripts[file] then
      loadScript(file)
    end
  elseif activeMode == "loadedBisectA" then
    if loadedBisectAModeScripts[file] then
      loadScript(file)
    end
  elseif activeMode == "loadedBisectB" then
    if loadedBisectBModeScripts[file] then
      loadScript(file)
    end
  elseif activeMode == "bisectA" then
    if bisectAModeScripts[file] then
      loadScript(file)
    end
  elseif activeMode == "bisectB" then
    if bisectBModeScripts[file] then
      loadScript(file)
    end
  else
    loadScript(file)
  end
end

setDefaultTab("Main")
local label = UI.Label("Custom Scripts:")
label:setColor('#9dd1ce')
label:setFont('verdana-11px-rounded')
UI.Separator()

if modules.game_interface and modules.game_interface.registerMobileBotControls then
  modules.game_interface.registerMobileBotControls({
    toggleCaster = function()
      if not AttackBot or not AttackBot.isOn then return false end
      if AttackBot.isOn() then AttackBot.setOff() else AttackBot.setOn() end
      return AttackBot.isOn()
    end,
    toggleTargeting = function()
      if not TargetBot or not TargetBot.isOn then return false end
      if TargetBot.isOn() then TargetBot.setOff() else TargetBot.setOn() end
      return TargetBot.isOn()
    end,
    isCasterEnabled = function()
      return AttackBot and AttackBot.isOn and AttackBot.isOn() or false
    end,
    isTargetingEnabled = function()
      return TargetBot and TargetBot.isOn and TargetBot.isOn() or false
    end
  })
end
