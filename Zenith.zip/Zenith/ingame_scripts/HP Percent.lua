-- Enemy HP Percent v3
-- Modo limpo:
-- Todos da tela OFF = mostra HP% do target em uma caixa na tela
-- Todos da tela ON  = mostra HP% curto em todos os monstros visiveis + marca por cor

setDefaultTab("Tools")

UI.Separator()

if type(storage.enemyHpPercent) ~= "table" then
  storage.enemyHpPercent = {
    enabled = false,
    showAll = false,
    onlyMonsters = true,
    showTargetBox = true,
    markCreatures = true,
    updateDelay = 100,
    posX = 50,
    posY = 18,
    massAlertEnabled = false,
    massAlertMinCreatures = 4,
    massAlertHpPercent = 40,
    massAlertSpellIndex = 1,
    massAlertVocation = "auto",
    massAlertCooldowns = {},
    massAlertDefaultCooldown = 40000
  }
end

if storage.enemyHpPercent.showAll == nil then storage.enemyHpPercent.showAll = false end
if storage.enemyHpPercent.onlyMonsters == nil then storage.enemyHpPercent.onlyMonsters = true end
if storage.enemyHpPercent.showTargetBox == nil then storage.enemyHpPercent.showTargetBox = true end
if storage.enemyHpPercent.markCreatures == nil then storage.enemyHpPercent.markCreatures = true end
if storage.enemyHpPercent.updateDelay == nil then storage.enemyHpPercent.updateDelay = 100 end
if storage.enemyHpPercent.posX == nil then storage.enemyHpPercent.posX = 50 end
if storage.enemyHpPercent.posY == nil then storage.enemyHpPercent.posY = 18 end
if storage.enemyHpPercent.massAlertEnabled == nil then storage.enemyHpPercent.massAlertEnabled = false end
if storage.enemyHpPercent.massAlertMinCreatures == nil then storage.enemyHpPercent.massAlertMinCreatures = 4 end
if storage.enemyHpPercent.massAlertHpPercent == nil then storage.enemyHpPercent.massAlertHpPercent = 40 end
if storage.enemyHpPercent.massAlertSpellIndex == nil then storage.enemyHpPercent.massAlertSpellIndex = 1 end
if storage.enemyHpPercent.massAlertVocation == nil then storage.enemyHpPercent.massAlertVocation = "auto" end
if type(storage.enemyHpPercent.massAlertCooldowns) ~= "table" then storage.enemyHpPercent.massAlertCooldowns = {} end
storage.enemyHpPercent.massAlertDefaultCooldown = 40000

local mainPanel = setupUI([[
Panel
  height: 22

  BotSwitch
    id: enabled
    anchors.top: parent.top
    anchors.left: parent.left
    width: 125
    height: 20
    text-align: center
    text: Enemy HP%

  Button
    id: setup
    anchors.top: parent.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Setup
]])

mainPanel.enabled:setOn(storage.enemyHpPercent.enabled)

mainPanel.enabled.onClick = function(widget)
  storage.enemyHpPercent.enabled = not storage.enemyHpPercent.enabled
  widget:setOn(storage.enemyHpPercent.enabled)
end

local setupPanel = setupUI([[
Panel
  height: 386

  BotSwitch
    id: showAll
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    height: 20
    text-align: center
    text: Todos da tela

  BotSwitch
    id: onlyMonsters
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 20
    text-align: center
    text: Somente monstros

  BotSwitch
    id: showTargetBox
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 20
    text-align: center
    text: Caixa do Target

  BotSwitch
    id: markCreatures
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 20
    text-align: center
    text: Marcar por cor

  Label
    id: xLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: X: 50%

  HorizontalScrollBar
    id: xSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: yLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Y: 18%

  HorizontalScrollBar
    id: ySlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  BotSwitch
    id: massAlertEnabled
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 8
    height: 20
    text-align: center
    text: Alert Mas Spell

  Label
    id: massVocationLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Vocacao: Auto

  Button
    id: massVocationButton
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 3
    height: 20
    text: Voc: Auto

  Label
    id: massSpellLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Spell: detectando vocacao

  Button
    id: massSpellButton
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 3
    height: 20
    text: Alternar spell

  Label
    id: massCountLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Criaturas: 4

  HorizontalScrollBar
    id: massCountSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: massHpLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: HP abaixo de: 40%

  HorizontalScrollBar
    id: massHpSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: massCooldownLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: CD: aguardando primeira magia
]])

setupPanel:hide()

mainPanel.setup.onClick = function(widget)
  if setupPanel:isVisible() then
    setupPanel:hide()
    widget:setText("Setup")
  else
    setupPanel:show()
    widget:setText("Close")
  end
end

setupPanel.showAll:setOn(storage.enemyHpPercent.showAll)
setupPanel.showAll.onClick = function(widget)
  storage.enemyHpPercent.showAll = not storage.enemyHpPercent.showAll
  widget:setOn(storage.enemyHpPercent.showAll)
end

setupPanel.onlyMonsters:setOn(storage.enemyHpPercent.onlyMonsters)
setupPanel.onlyMonsters.onClick = function(widget)
  storage.enemyHpPercent.onlyMonsters = not storage.enemyHpPercent.onlyMonsters
  widget:setOn(storage.enemyHpPercent.onlyMonsters)
end

setupPanel.showTargetBox:setOn(storage.enemyHpPercent.showTargetBox)
setupPanel.showTargetBox.onClick = function(widget)
  storage.enemyHpPercent.showTargetBox = not storage.enemyHpPercent.showTargetBox
  widget:setOn(storage.enemyHpPercent.showTargetBox)
end

setupPanel.markCreatures:setOn(storage.enemyHpPercent.markCreatures)
setupPanel.markCreatures.onClick = function(widget)
  storage.enemyHpPercent.markCreatures = not storage.enemyHpPercent.markCreatures
  widget:setOn(storage.enemyHpPercent.markCreatures)
end

setupPanel.massAlertEnabled:setOn(storage.enemyHpPercent.massAlertEnabled)
setupPanel.massAlertEnabled.onClick = function(widget)
  storage.enemyHpPercent.massAlertEnabled = not storage.enemyHpPercent.massAlertEnabled
  widget:setOn(storage.enemyHpPercent.massAlertEnabled)
end

local function clamp(value, minValue, maxValue)
  value = tonumber(value) or minValue

  if value < minValue then return minValue end
  if value > maxValue then return maxValue end

  return value
end

local function setupSlider(slider, label, storageKey, labelText, minValue, maxValue, suffix)
  minValue = minValue or 0
  maxValue = maxValue or 100
  suffix = suffix or "%"

  local value = clamp(storage.enemyHpPercent[storageKey], minValue, maxValue)

  pcall(function()
    slider:setMinimum(minValue)
    slider:setMaximum(maxValue)
    slider:setValue(value)
  end)

  label:setText(labelText .. ": " .. value .. suffix)

  slider.onValueChange = function(widget, newValue)
    newValue = clamp(newValue, minValue, maxValue)
    storage.enemyHpPercent[storageKey] = newValue
    label:setText(labelText .. ": " .. newValue .. suffix)
  end
end

local MASS_SPELLS = {
  sorcerer = { "exevo gran mas vis", "exevo gran mas flam" },
  druid = { "exevo gran mas frigo", "exevo gran mas tera" }
}

local VOCATION_NAMES = {
  sorcerer = "Sorcerer",
  druid = "Druid"
}

local VOCATION_OPTION_LABELS = {
  auto = "Auto",
  sorcerer = "Sorcerer",
  druid = "Druid"
}

local VOCATION_OPTION_ORDER = { "auto", "sorcerer", "druid" }

local DEFAULT_MASS_COOLDOWN = 40000
local MIN_LEARNED_COOLDOWN = 3000
local MAX_LEARNED_COOLDOWN = 120000

-- Corrige valores antigos gravados no storage por vers�es anteriores.
-- Estas magias t�m cooldown fixo de 40s neste servidor.
storage.enemyHpPercent.massAlertDefaultCooldown = DEFAULT_MASS_COOLDOWN
if type(storage.enemyHpPercent.massAlertCooldowns) ~= "table" then
  storage.enemyHpPercent.massAlertCooldowns = {}
end
for _, spells in pairs(MASS_SPELLS) do
  for _, spell in ipairs(spells) do
    if type(storage.enemyHpPercent.massAlertCooldowns[spell]) == "table" then
      storage.enemyHpPercent.massAlertCooldowns[spell].cooldownMs = DEFAULT_MASS_COOLDOWN
      storage.enemyHpPercent.massAlertCooldowns[spell].learned = true
    end
  end
end

local function getMillis()
  if now then return now end

  if g_clock and g_clock.millis then
    local ok, millis = pcall(function()
      return g_clock.millis()
    end)

    if ok and millis then return millis end
  end

  return os.time() * 1000
end

local function normalizeText(text)
  text = tostring(text or ""):lower()
  text = text:gsub("^%s+", "")
  text = text:gsub("%s+$", "")
  text = text:gsub("%s+", " ")
  return text
end

local function getLocalPlayer()
  if player then
    local ok, localPlayer = pcall(function()
      return player
    end)

    if ok and localPlayer then return localPlayer end
  end

  if g_game and g_game.getLocalPlayer then
    local ok, localPlayer = pcall(function()
      return g_game.getLocalPlayer()
    end)

    if ok and localPlayer then return localPlayer end
  end

  return nil
end

local function getLocalPlayerName()
  local localPlayer = getLocalPlayer()

  if localPlayer and localPlayer.getName then
    local ok, name = pcall(function()
      return localPlayer:getName()
    end)

    if ok and name then return normalizeText(name) end
  end

  return ""
end

local function readVocationFromValue(vocation)
  if vocation == nil then return nil end

  if type(vocation) == "number" then
    -- 1/5 = Sorcerer/Master Sorcerer, 2/6 = Druid/Elder Druid
    -- Alguns servidores custom podem usar 9/10, mas normalmente mantem o par 1/5 e 2/6.
    if vocation == 1 or vocation == 5 or vocation == 9 then return "sorcerer" end
    if vocation == 2 or vocation == 6 or vocation == 10 then return "druid" end
    return nil
  end

  vocation = normalizeText(vocation)

  if vocation:find("sorcerer", 1, true) or vocation:find("master sorcerer", 1, true) then return "sorcerer" end
  if vocation:find("druid", 1, true) or vocation:find("elder druid", 1, true) then return "druid" end
  if vocation == "ms" or vocation == "sorc" or vocation == "sorcerer" then return "sorcerer" end
  if vocation == "ed" or vocation == "druid" then return "druid" end

  return nil
end

local function getStoredVocationOverride()
  local override = normalizeText(storage.enemyHpPercent.massAlertVocation or "auto")

  if override == "sorcerer" or override == "druid" then
    return override
  end

  storage.enemyHpPercent.massAlertVocation = "auto"
  return nil
end

local function getVocationKey()
  -- No OTC Redemption nem sempre a vocacao vem exposta no Lua.
  -- Por isso o modo manual tem prioridade quando voce escolhe Sorcerer/Druid na UI.
  local override = getStoredVocationOverride()
  if override then return override, false end

  local localPlayer = getLocalPlayer()

  if localPlayer then
    local methodNames = {
      "getVocation",
      "getVocationId",
      "getVocationID",
      "getProfession",
      "getProfessionId",
      "getProfessionID"
    }

    for _, methodName in ipairs(methodNames) do
      if localPlayer[methodName] then
        local ok, vocation = pcall(function()
          return localPlayer[methodName](localPlayer)
        end)

        local parsed = ok and readVocationFromValue(vocation) or nil
        if parsed then return parsed, true end
      end
    end
  end

  -- Fallback para bases que criam funcao global.
  local globalMethods = { "getVocation", "getVocationId", "getPlayerVocation", "vocation" }

  for _, methodName in ipairs(globalMethods) do
    local fn = _G and _G[methodName] or nil

    if type(fn) == "function" then
      local ok, vocation = pcall(function()
        return fn()
      end)

      local parsed = ok and readVocationFromValue(vocation) or nil
      if parsed then return parsed, true end
    end
  end

  return nil, true
end

local function getSelectedMassSpell()
  local vocationKey = getVocationKey()
  local spells = MASS_SPELLS[vocationKey]

  if not spells then return nil, vocationKey end

  local index = clamp(storage.enemyHpPercent.massAlertSpellIndex, 1, 2)
  storage.enemyHpPercent.massAlertSpellIndex = index

  return spells[index], vocationKey
end

local function getCooldownData(spell)
  if type(storage.enemyHpPercent.massAlertCooldowns) ~= "table" then
    storage.enemyHpPercent.massAlertCooldowns = {}
  end

  if type(storage.enemyHpPercent.massAlertCooldowns[spell]) ~= "table" then
    storage.enemyHpPercent.massAlertCooldowns[spell] = {
      lastCast = 0,
      cooldownMs = storage.enemyHpPercent.massAlertDefaultCooldown or DEFAULT_MASS_COOLDOWN,
      learned = false
    }
  end

  return storage.enemyHpPercent.massAlertCooldowns[spell]
end

local function getLearnedCooldownInfo(spell)
  local data = getCooldownData(spell)
  data.cooldownMs = DEFAULT_MASS_COOLDOWN
  data.learned = true

  local lastCast = tonumber(data.lastCast) or 0
  local cooldownMs = DEFAULT_MASS_COOLDOWN

  if lastCast <= 0 then
    return true, 0, true, cooldownMs
  end

  local remaining = (lastCast + cooldownMs) - getMillis()

  if remaining <= 0 then
    return true, 0, true, cooldownMs
  end

  return false, remaining, true, cooldownMs
end

local function isMassSpellReady(spell)
  if not spell then return false, 0, true, DEFAULT_MASS_COOLDOWN end

  local timerReady, remaining, learned, cooldownMs = getLearnedCooldownInfo(spell)

  -- Se o client/vBot tiver canCast, respeita ele tamb�m.
  -- Mas nunca libera antes dos 40s do timer local depois que voc� usar a magia.
  if canCast then
    local ok, result = pcall(function()
      return canCast(spell)
    end)

    if ok and type(result) == "boolean" then
      if result and timerReady then
        return true, 0, true, cooldownMs
      end

      if remaining <= 0 then remaining = 1000 end
      return false, remaining, true, cooldownMs
    end
  end

  return timerReady, remaining, true, cooldownMs
end

local function learnMassSpellCooldown(spell)
  if not spell then return end

  local data = getCooldownData(spell)

  -- Cooldown das magias exevo gran mas configurado como fixo de 40 segundos.
  -- O "aprendizado" aqui s� marca o momento em que voc� falou a magia,
  -- para o alerta contar os 40s certinho a partir do cast.
  data.lastCast = getMillis()
  data.cooldownMs = DEFAULT_MASS_COOLDOWN
  data.learned = true
end

local function updateVocationButton()
  if not setupPanel or not setupPanel.massVocationButton or not setupPanel.massVocationLabel then return end

  local override = normalizeText(storage.enemyHpPercent.massAlertVocation or "auto")
  if override ~= "sorcerer" and override ~= "druid" then
    override = "auto"
  end

  local vocationKey, detected = getVocationKey()
  local modeLabel = VOCATION_OPTION_LABELS[override] or "Auto"

  if override == "auto" then
    if vocationKey then
      setupPanel.massVocationLabel:setText("Vocacao Auto: " .. (VOCATION_NAMES[vocationKey] or vocationKey))
    else
      setupPanel.massVocationLabel:setText("Vocacao Auto: nao detectada")
    end
  else
    setupPanel.massVocationLabel:setText("Vocacao Manual: " .. modeLabel)
  end

  setupPanel.massVocationButton:setText("Voc: " .. modeLabel)
end

local function updateMassSpellButton()
  if not setupPanel or not setupPanel.massSpellButton or not setupPanel.massSpellLabel then return end

  updateVocationButton()

  local spell, vocationKey = getSelectedMassSpell()
  local vocName = VOCATION_NAMES[vocationKey] or "Vocacao nao detectada"

  if spell then
    setupPanel.massSpellLabel:setText(vocName .. ": " .. spell)
    setupPanel.massSpellButton:setText("Usar: " .. spell)
  else
    setupPanel.massSpellLabel:setText(vocName)
    setupPanel.massSpellButton:setText("Spell indisponivel")
  end
end

setupPanel.massVocationButton.onClick = function()
  local current = normalizeText(storage.enemyHpPercent.massAlertVocation or "auto")
  local nextIndex = 1

  for index, value in ipairs(VOCATION_OPTION_ORDER) do
    if value == current then
      nextIndex = index + 1
      break
    end
  end

  if nextIndex > #VOCATION_OPTION_ORDER then
    nextIndex = 1
  end

  storage.enemyHpPercent.massAlertVocation = VOCATION_OPTION_ORDER[nextIndex]
  storage.enemyHpPercent.massAlertSpellIndex = 1
  updateMassSpellButton()
end

setupPanel.massSpellButton.onClick = function()
  storage.enemyHpPercent.massAlertSpellIndex = clamp((storage.enemyHpPercent.massAlertSpellIndex or 1) + 1, 1, 3)

  if storage.enemyHpPercent.massAlertSpellIndex > 2 then
    storage.enemyHpPercent.massAlertSpellIndex = 1
  end

  updateMassSpellButton()
end

setupSlider(setupPanel.xSlider, setupPanel.xLabel, "posX", "Box X")
setupSlider(setupPanel.ySlider, setupPanel.yLabel, "posY", "Box Y")
setupSlider(setupPanel.massCountSlider, setupPanel.massCountLabel, "massAlertMinCreatures", "Criaturas", 1, 15, "")
setupSlider(setupPanel.massHpSlider, setupPanel.massHpLabel, "massAlertHpPercent", "HP abaixo de", 1, 100, "%")
updateMassSpellButton()

local markedCreatures = {}
local lastUpdate = 0
local targetBox = nil
local massAlertBox = nil

local function getRootSize(root)
  local width = 1000
  local height = 700

  pcall(function()
    if root and root.getWidth then
      width = root:getWidth()
    end
  end)

  pcall(function()
    if root and root.getHeight then
      height = root:getHeight()
    end
  end)

  return width, height
end

local function createTargetBox()
  local root = g_ui.getRootWidget()
  if not root then return nil end

  if targetBox then return targetBox end

  targetBox = setupUI([[
Label
  anchors.left: parent.left
  anchors.top: parent.top
  width: 300
  height: 48
  text-align: center
  color: white
  background: #000000cc
  font: verdana-11px-rounded
]], root)

  return targetBox
end

local function hideTargetBox()
  if targetBox then
    targetBox:hide()
  end
end

local function positionTargetBox()
  local root = g_ui.getRootWidget()
  local box = createTargetBox()

  if not root or not box then return end

  local boxWidth = 300
  local boxHeight = 48

  local rootWidth, rootHeight = getRootSize(root)

  local xPercent = clamp(storage.enemyHpPercent.posX, 0, 100)
  local yPercent = clamp(storage.enemyHpPercent.posY, 0, 100)

  local left = math.floor((rootWidth - boxWidth) * (xPercent / 100))
  local top = math.floor((rootHeight - boxHeight) * (yPercent / 100))

  if left < 0 then left = 0 end
  if top < 0 then top = 0 end

  pcall(function()
    box:setMarginLeft(left)
    box:setMarginTop(top)
  end)
end

local function createMassAlertBox()
  local root = g_ui.getRootWidget()
  if not root then return nil end

  if massAlertBox then return massAlertBox end

  massAlertBox = setupUI([[
Label
  anchors.left: parent.left
  anchors.top: parent.top
  width: 360
  height: 58
  text-align: center
  color: #ffff00
  background: #000000dd
  font: verdana-11px-rounded
]], root)

  return massAlertBox
end

local function hideMassAlertBox()
  if massAlertBox then
    massAlertBox:hide()
  end
end

local function positionMassAlertBox()
  local root = g_ui.getRootWidget()
  local box = createMassAlertBox()

  if not root or not box then return end

  local boxWidth = 360
  local boxHeight = 58
  local targetBoxHeight = 48
  local rootWidth, rootHeight = getRootSize(root)

  local xPercent = clamp(storage.enemyHpPercent.posX, 0, 100)
  local yPercent = clamp(storage.enemyHpPercent.posY, 0, 100)

  local left = math.floor((rootWidth - boxWidth) * (xPercent / 100))
  local top = math.floor((rootHeight - boxHeight) * (yPercent / 100)) + targetBoxHeight + 6

  if left < 0 then left = 0 end
  if top < 0 then top = 0 end
  if top > rootHeight - boxHeight then top = rootHeight - boxHeight end

  pcall(function()
    box:setMarginLeft(left)
    box:setMarginTop(top)
  end)
end

local function getHpPercent(creature)
  if not creature then return nil end

  if creature.getHealthPercent then
    local ok, hp = pcall(function()
      return creature:getHealthPercent()
    end)

    if ok and hp then
      hp = tonumber(hp) or 0
      hp = math.floor(hp + 0.5)

      if hp < 0 then hp = 0 end
      if hp > 100 then hp = 100 end

      return hp
    end
  end

  return nil
end

local function getHpColor(hp)
  hp = tonumber(hp) or 100

  if hp <= 25 then
    return "#ff3030"
  elseif hp <= 50 then
    return "#ff9900"
  elseif hp <= 75 then
    return "#ffff00"
  end

  return "#00ff00"
end

local function getMarkColor(hp)
  hp = tonumber(hp) or 100

  if hp <= 25 then
    return "#ff0000"
  elseif hp <= 50 then
    return "#ff8800"
  elseif hp <= 75 then
    return "#ffff00"
  end

  return "#00ff00"
end

local function getCreatureName(creature)
  if creature and creature.getName then
    local ok, name = pcall(function()
      return creature:getName()
    end)

    if ok and name then
      return tostring(name)
    end
  end

  return "Target"
end

local function getCreatureKey(creature)
  if not creature then return nil end

  if creature.getId then
    local ok, id = pcall(function()
      return creature:getId()
    end)

    if ok and id then
      return tostring(id)
    end
  end

  if creature.getName and creature.getPosition then
    local okName, name = pcall(function()
      return creature:getName()
    end)

    local okPos, pos = pcall(function()
      return creature:getPosition()
    end)

    if okName and okPos and name and pos then
      return tostring(name) .. ":" .. pos.x .. ":" .. pos.y .. ":" .. pos.z
    end
  end

  return tostring(creature)
end

local function setCreatureText(creature, text, color)
  if not creature or not creature.setText then
    return false
  end

  local ok = pcall(function()
    creature:setText(text, color)
  end)

  if ok then return true end

  ok = pcall(function()
    creature:setText(text)
  end)

  return ok == true
end

local function clearCreatureText(creature)
  if creature then
    setCreatureText(creature, "")
  end

  if creature and creature.setMarked then
    pcall(function()
      creature:setMarked("")
    end)
  end
end

local function clearOldTexts(activeKeys)
  for key, creature in pairs(markedCreatures) do
    if not activeKeys[key] then
      clearCreatureText(creature)
      markedCreatures[key] = nil
    end
  end
end

local function clearAllTexts()
  for key, creature in pairs(markedCreatures) do
    clearCreatureText(creature)
    markedCreatures[key] = nil
  end

  hideTargetBox()
  hideMassAlertBox()
end

local function isValidEnemy(creature)
  if not creature then return false end

  if creature.isLocalPlayer then
    local ok, result = pcall(function()
      return creature:isLocalPlayer()
    end)

    if ok and result then return false end
  end

  if storage.enemyHpPercent.onlyMonsters then
    if creature.isMonster then
      local ok, result = pcall(function()
        return creature:isMonster()
      end)

      if ok then
        return result == true
      end
    end

    return false
  end

  return true
end

local function getTargetCreature()
  if g_game and g_game.getAttackingCreature then
    local ok, target = pcall(function()
      return g_game.getAttackingCreature()
    end)

    if ok and target then return target end
  end

  if target then
    local ok, t = pcall(function()
      return target()
    end)

    if ok and t then return t end
  end

  return nil
end

local function getSpectatorCreatures()
  local creatures = {}

  if getSpectators then
    local ok, spectators = pcall(function()
      return getSpectators()
    end)

    if ok and spectators then
      for _, creature in ipairs(spectators) do
        table.insert(creatures, creature)
      end

      return creatures
    end
  end

  if g_map and g_map.getSpectators and player and player.getPosition then
    local ok, spectators = pcall(function()
      return g_map.getSpectators(player:getPosition(), false)
    end)

    if ok and spectators then
      for _, creature in ipairs(spectators) do
        table.insert(creatures, creature)
      end
    end
  end

  return creatures
end

local function countLowHpEnemies(spectators)
  local minHp = clamp(storage.enemyHpPercent.massAlertHpPercent, 1, 100)
  local count = 0
  local seen = {}

  spectators = spectators or getSpectatorCreatures()

  for _, creature in ipairs(spectators) do
    if isValidEnemy(creature) then
      local key = getCreatureKey(creature) or tostring(creature)

      if not seen[key] then
        seen[key] = true

        local hp = getHpPercent(creature)

        if hp and hp <= minHp then
          count = count + 1
        end
      end
    end
  end

  return count
end

local function updateCooldownSetupLabel(spell, ready, remaining, learned, cooldownMs)
  if not setupPanel or not setupPanel.massCooldownLabel then return end

  if not spell then
    setupPanel.massCooldownLabel:setText("CD: vocacao nao detectada")
    return
  end

  cooldownMs = DEFAULT_MASS_COOLDOWN

  if ready then
    setupPanel.massCooldownLabel:setText("CD: livre | fixo 40s")
    return
  end

  local seconds = math.ceil((remaining or 0) / 1000)
  if seconds < 1 then seconds = 1 end
  if seconds > 40 then seconds = 40 end

  setupPanel.massCooldownLabel:setText("CD: " .. seconds .. "s | fixo 40s")
end

local function updateMassSpellAlert(spectators)
  if not storage.enemyHpPercent.massAlertEnabled then
    hideMassAlertBox()
    return
  end

  local spell = getSelectedMassSpell()

  if not spell then
    hideMassAlertBox()
    updateCooldownSetupLabel(nil)
    updateMassSpellButton()
    return
  end

  local ready, remaining, learned, cooldownMs = isMassSpellReady(spell)
  updateCooldownSetupLabel(spell, ready, remaining, learned, cooldownMs)
  updateMassSpellButton()

  if not ready then
    hideMassAlertBox()
    return
  end

  local needed = clamp(storage.enemyHpPercent.massAlertMinCreatures, 1, 15)
  local hpLimit = clamp(storage.enemyHpPercent.massAlertHpPercent, 1, 100)
  local count = countLowHpEnemies(spectators)

  if count < needed then
    hideMassAlertBox()
    return
  end

  local box = createMassAlertBox()
  if not box then return end

  positionMassAlertBox()

  box:setText("USE " .. spell:upper() .. "\n" .. count .. " criaturas com HP <= " .. hpLimit .. "% | CD LIVRE")
  box:show()
end

if onTalk then
  onTalk(function(name, level, mode, text, channelId, pos)
    local said = normalizeText(text)
    local myName = getLocalPlayerName()
    local speaker = normalizeText(name)

    if myName ~= "" and speaker ~= "" and speaker ~= myName then
      return
    end

    for _, spells in pairs(MASS_SPELLS) do
      for _, spell in ipairs(spells) do
        if said == spell then
          learnMassSpellCooldown(spell)
          return
        end
      end
    end
  end)
end

local function updateTargetBox(creature)
  if not storage.enemyHpPercent.showTargetBox then
    hideTargetBox()
    return
  end

  if not creature or not isValidEnemy(creature) then
    hideTargetBox()
    return
  end

  local hp = getHpPercent(creature)
  if not hp then
    hideTargetBox()
    return
  end

  local name = getCreatureName(creature)
  local box = createTargetBox()

  if not box then return end

  positionTargetBox()

  local hpColor = getHpColor(hp)

  pcall(function()
    box:setColor(hpColor)
  end)

  box:setText(name .. "\nHP: " .. hp .. "%")
  box:show()
end

local function drawHpOnCreature(creature, activeKeys)
  if not isValidEnemy(creature) then return end

  local hp = getHpPercent(creature)
  if not hp then return end

  local key = getCreatureKey(creature)
  if not key then return end

  local color = getHpColor(hp)

  -- Texto bem curto para n�o poluir tanto
  setCreatureText(creature, hp .. "%", color)

  if storage.enemyHpPercent.markCreatures and creature.setMarked then
    pcall(function()
      creature:setMarked(getMarkColor(hp))
    end)
  end

  markedCreatures[key] = creature
  activeKeys[key] = true
end

macro(50, function()
  if not storage.enemyHpPercent.enabled then
    clearAllTexts()
    return
  end

  local delayMs = clamp(storage.enemyHpPercent.updateDelay, 50, 1000)

  if now - lastUpdate < delayMs then
    return
  end

  lastUpdate = now

  local activeKeys = {}
  local targetCreature = getTargetCreature()
  local spectators = nil

  if storage.enemyHpPercent.showAll or storage.enemyHpPercent.massAlertEnabled then
    spectators = getSpectatorCreatures()
  end

  -- Caixa limpa do target sempre que existir target
  updateTargetBox(targetCreature)

  if storage.enemyHpPercent.showAll then
    for _, creature in ipairs(spectators or {}) do
      drawHpOnCreature(creature, activeKeys)
    end
  else
    if targetCreature then
      drawHpOnCreature(targetCreature, activeKeys)
    end
  end

  updateMassSpellAlert(spectators)
  clearOldTexts(activeKeys)
end)