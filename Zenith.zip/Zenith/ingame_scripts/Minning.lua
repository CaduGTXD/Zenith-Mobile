-- Minning.lua

setDefaultTab("Tools")

UI.Separator()
UI.Label("Mining Bot")

if type(storage.miningBot) ~= "table" then
  storage.miningBot = {
    enabled = false,
    toolId = 3456,
    targetId = 1841,
    range = 7,
    delay = 500
  }
end

local miningSwitch = addSwitch("miningBotSwitch", "Mining ON/OFF", function(widget)
  storage.miningBot.enabled = not storage.miningBot.enabled
  widget:setOn(storage.miningBot.enabled)
end)

miningSwitch:setOn(storage.miningBot.enabled)

UI.Label("Tool ID:")
UI.TextEdit(tostring(storage.miningBot.toolId), function(widget, text)
  local value = tonumber(text)
  if value then
    storage.miningBot.toolId = value
  end
end)

UI.Label("Target ID:")
UI.TextEdit(tostring(storage.miningBot.targetId), function(widget, text)
  local value = tonumber(text)
  if value then
    storage.miningBot.targetId = value
  end
end)

UI.Label("Range:")
UI.TextEdit(tostring(storage.miningBot.range), function(widget, text)
  local value = tonumber(text)
  if value then
    storage.miningBot.range = value
  end
end)

UI.Label("Delay ms:")
UI.TextEdit(tostring(storage.miningBot.delay), function(widget, text)
  local value = tonumber(text)
  if value then
    storage.miningBot.delay = value
  end
end)

local function getDistance(pos1, pos2)
  if not pos1 or not pos2 then return 999 end
  if pos1.z ~= pos2.z then return 999 end

  return math.max(math.abs(pos1.x - pos2.x), math.abs(pos1.y - pos2.y))
end

local function findClosestMiningTarget()
  local playerPos = player:getPosition()
  if not playerPos then return nil end

  local closestThing = nil
  local closestDistance = 999

  local range = tonumber(storage.miningBot.range) or 7
  local targetId = tonumber(storage.miningBot.targetId) or 1841

  for x = -range, range do
    for y = -range, range do
      local checkPos = {
        x = playerPos.x + x,
        y = playerPos.y + y,
        z = playerPos.z
      }

      local tile = g_map.getTile(checkPos)

      if tile then
        local dist = getDistance(playerPos, checkPos)

        if dist <= range then
          for _, thing in ipairs(tile:getThings()) do
            if thing and thing:getId() == targetId then
              if dist < closestDistance then
                closestDistance = dist
                closestThing = thing
              end
            end
          end
        end
      end
    end
  end

  return closestThing, closestDistance
end

macro(500, "Mining Bot", function()
  if not storage.miningBot.enabled then return end

  local toolId = tonumber(storage.miningBot.toolId) or 3456
  local delayMs = tonumber(storage.miningBot.delay) or 500

  local target = findClosestMiningTarget()
  if not target then return end

  g_game.useInventoryItemWith(toolId, target)
  delay(delayMs)
end)
