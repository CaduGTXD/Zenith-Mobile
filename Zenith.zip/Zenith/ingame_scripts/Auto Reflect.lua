-- PK Reflect.lua
-- Quando um player/PK atacar:
-- fecha a m�ozinha
-- salva estado do TargetBot e CaveBot
-- desliga TargetBot e CaveBot
-- opcionalmente liga follow attack
-- ataca o player
--
-- Se o player sumir da tela pelo tempo configurado:
-- abre a m�ozinha
-- religa TargetBot/CaveBot somente se estavam ligados antes

setDefaultTab("Tools")

UI.Separator()

if type(storage.pkReflectBot) ~= "table" then
  storage.pkReflectBot = {
    enabled = false,
    followAttack = true,
    lostDelay = 5000,
    posX = 50,
    posY = 20
  }
end

if storage.pkReflectBot.enabled == nil then storage.pkReflectBot.enabled = false end
if storage.pkReflectBot.followAttack == nil then storage.pkReflectBot.followAttack = true end
if storage.pkReflectBot.lostDelay == nil then storage.pkReflectBot.lostDelay = 5000 end
if storage.pkReflectBot.posX == nil then storage.pkReflectBot.posX = 50 end
if storage.pkReflectBot.posY == nil then storage.pkReflectBot.posY = 20 end

local RETRY_DELAY = 300
local ATTACK_TIME = 60000

local mainPanel = setupUI([[
Panel
  height: 22

  BotSwitch
    id: enabled
    anchors.top: parent.top
    anchors.left: parent.left
    width: 125
    height: 20
    text-align: center
    text: PK Reflect

  Button
    id: setup
    anchors.top: parent.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Setup
]])

mainPanel.enabled:setOn(storage.pkReflectBot.enabled)

mainPanel.enabled.onClick = function(widget)
  storage.pkReflectBot.enabled = not storage.pkReflectBot.enabled
  widget:setOn(storage.pkReflectBot.enabled)
end

local setupPanel = setupUI([[
Panel
  height: 174

  BotSwitch
    id: followAttack
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    height: 20
    text-align: center
    text: Follow Attack

  Label
    id: lostDelayLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Fora da tela: 5000ms

  HorizontalScrollBar
    id: lostDelaySlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: xLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: X: 50%

  HorizontalScrollBar
    id: xSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: yLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Y: 20%

  HorizontalScrollBar
    id: ySlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Button
    id: testAlert
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 20
    text: Simular Alerta
]])

setupPanel:hide()

mainPanel.setup.onClick = function(widget)
  if setupPanel:isVisible() then
    setupPanel:hide()
    widget:setText("Setup")
  else
    setupPanel:show()
    widget:setText("Close")
  end
end

local function clamp(value, minValue, maxValue)
  value = tonumber(value) or minValue

  if value < minValue then return minValue end
  if value > maxValue then return maxValue end

  return value
end

setupPanel.followAttack:setOn(storage.pkReflectBot.followAttack)

setupPanel.followAttack.onClick = function(widget)
  storage.pkReflectBot.followAttack = not storage.pkReflectBot.followAttack
  widget:setOn(storage.pkReflectBot.followAttack)
end

local function setupPercentSlider(slider, label, key, labelText)
  local value = clamp(storage.pkReflectBot[key], 0, 100)
  storage.pkReflectBot[key] = value

  pcall(function()
    slider:setMinimum(0)
    slider:setMaximum(100)
    slider:setValue(value)
  end)

  label:setText(labelText .. ": " .. value .. "%")

  slider.onValueChange = function(widget, newValue)
    newValue = clamp(newValue, 0, 100)
    storage.pkReflectBot[key] = newValue
    label:setText(labelText .. ": " .. newValue .. "%")
  end
end

local function updateLostDelayLabel()
  storage.pkReflectBot.lostDelay = clamp(storage.pkReflectBot.lostDelay, 1000, 15000)
  setupPanel.lostDelayLabel:setText("Fora da tela: " .. storage.pkReflectBot.lostDelay .. "ms")
end

pcall(function()
  setupPanel.lostDelaySlider:setMinimum(1000)
  setupPanel.lostDelaySlider:setMaximum(15000)
  setupPanel.lostDelaySlider:setValue(clamp(storage.pkReflectBot.lostDelay, 1000, 15000))
end)

setupPanel.lostDelaySlider.onValueChange = function(widget, value)
  storage.pkReflectBot.lostDelay = clamp(value, 1000, 15000)
  updateLostDelayLabel()
end

updateLostDelayLabel()

setupPercentSlider(setupPanel.xSlider, setupPanel.xLabel, "posX", "X")
setupPercentSlider(setupPanel.ySlider, setupPanel.yLabel, "posY", "Y")

local reflectTargetName = nil
local reflectUntil = 0
local lastAttackTry = 0
local lastSeenAt = 0
local reflecting = false

local targetWasOn = false
local caveWasOn = false

local alertBox = nil

local function normalizeName(name)
  if not name then return "" end
  return tostring(name):lower():gsub("^%s+", ""):gsub("%s+$", "")
end

local function getTextWidth(text)
  text = tostring(text or "")
  return (#text * 7) + 16
end

local function getRootSize(root)
  local width = 1000
  local height = 700

  pcall(function()
    if root and root.getWidth then
      width = root:getWidth()
    end
  end)

  pcall(function()
    if root and root.getHeight then
      height = root:getHeight()
    end
  end)

  return width, height
end

local function createAlertBox()
  local root = g_ui.getRootWidget()
  if not root then return nil end

  if alertBox then return alertBox end

  alertBox = setupUI([[
Label
  anchors.left: parent.left
  anchors.top: parent.top
  height: 20
  text-align: center
  color: red
  background: #000000cc
  font: verdana-11px-rounded
]], root)

  return alertBox
end

local function setAlertSize(box, width, height)
  pcall(function()
    box:setWidth(width)
  end)

  pcall(function()
    box:setHeight(height)
  end)

  pcall(function()
    box:setSize({width = width, height = height})
  end)
end

local function setAlertPosition(box, width, height)
  local root = g_ui.getRootWidget()
  if not root or not box then return end

  local rootWidth, rootHeight = getRootSize(root)

  local xPercent = clamp(storage.pkReflectBot.posX, 0, 100)
  local yPercent = clamp(storage.pkReflectBot.posY, 0, 100)

  local left = math.floor((rootWidth - width) * (xPercent / 100))
  local top = math.floor((rootHeight - height) * (yPercent / 100))

  if left < 0 then left = 0 end
  if top < 0 then top = 0 end

  pcall(function()
    box:setMarginLeft(left)
    box:setMarginTop(top)
  end)

  pcall(function()
    box:setPosition({x = left, y = top})
  end)
end

local function showPkAlert(name)
  local text = "PK: " .. tostring(name or "?")
  local width = getTextWidth(text)
  local height = 20

  local box = createAlertBox()
  if not box then return end

  setAlertSize(box, width, height)
  setAlertPosition(box, width, height)

  box:setText(text)
  box:show()
end

local function hidePkAlert()
  if alertBox then
    alertBox:hide()
  end
end

setupPanel.testAlert.onClick = function()
  showPkAlert("Player")

  schedule(5000, function()
    if not reflecting then
      hidePkAlert()
    end
  end)
end

local function isTargetBotOn()
  if not TargetBot then return false end

  if TargetBot.isOn then
    local ok, result = pcall(function()
      return TargetBot.isOn()
    end)

    if ok then return result == true end
  end

  if TargetBot.isOff then
    local ok, result = pcall(function()
      return TargetBot.isOff()
    end)

    if ok then return result ~= true end
  end

  return false
end

local function isCaveBotOn()
  if not CaveBot then return false end

  if CaveBot.isOn then
    local ok, result = pcall(function()
      return CaveBot.isOn()
    end)

    if ok then return result == true end
  end

  if CaveBot.isOff then
    local ok, result = pcall(function()
      return CaveBot.isOff()
    end)

    if ok then return result ~= true end
  end

  return false
end

local function setTargetBotOff()
  if not TargetBot then return end

  if TargetBot.setOff then
    pcall(function()
      TargetBot.setOff()
    end)
    return
  end

  if TargetBot.isOn and TargetBot.toggle then
    local ok, result = pcall(function()
      return TargetBot.isOn()
    end)

    if ok and result then
      pcall(function()
        TargetBot.toggle()
      end)
    end
  end
end

local function setTargetBotOn()
  if not TargetBot then return end

  if TargetBot.setOn then
    pcall(function()
      TargetBot.setOn()
    end)
    return
  end

  if TargetBot.isOff and TargetBot.toggle then
    local ok, result = pcall(function()
      return TargetBot.isOff()
    end)

    if ok and result then
      pcall(function()
        TargetBot.toggle()
      end)
    end
  end
end

local function setCaveBotOff()
  if not CaveBot then return end

  if CaveBot.setOff then
    pcall(function()
      CaveBot.setOff()
    end)
    return
  end

  if CaveBot.isOn and CaveBot.toggle then
    local ok, result = pcall(function()
      return CaveBot.isOn()
    end)

    if ok and result then
      pcall(function()
        CaveBot.toggle()
      end)
    end
  end
end

local function setCaveBotOn()
  if not CaveBot then return end

  if CaveBot.setOn then
    pcall(function()
      CaveBot.setOn()
    end)
    return
  end

  if CaveBot.isOff and CaveBot.toggle then
    local ok, result = pcall(function()
      return CaveBot.isOff()
    end)

    if ok and result then
      pcall(function()
        CaveBot.toggle()
      end)
    end
  end
end

local function closeHand()
  -- Fechar m�ozinha = safe fight OFF, permite atacar player.
  pcall(function()
    if g_game and g_game.setSafeFight then
      g_game.setSafeFight(false)
    end
  end)

  pcall(function()
    if g_game and g_game.setSafeFightMode then
      g_game.setSafeFightMode(false)
    end
  end)

  pcall(function()
    if setSafeFight then
      setSafeFight(false)
    end
  end)
end

local function openHand()
  -- Abrir m�ozinha = safe fight ON.
  pcall(function()
    if g_game and g_game.setSafeFight then
      g_game.setSafeFight(true)
    end
  end)

  pcall(function()
    if g_game and g_game.setSafeFightMode then
      g_game.setSafeFightMode(true)
    end
  end)

  pcall(function()
    if setSafeFight then
      setSafeFight(true)
    end
  end)
end

local function setFollowAttack()
  if not storage.pkReflectBot.followAttack then return end

  pcall(function()
    if g_game and g_game.setChaseMode then
      g_game.setChaseMode(ChaseOpponent or 1)
    end
  end)

  pcall(function()
    if g_game and g_game.setFightMode then
      g_game.setFightMode(FightOffensive or 1)
    end
  end)
end

local function isValidPlayer(creature)
  if not creature then return false end

  if creature.isLocalPlayer then
    local ok, result = pcall(function()
      return creature:isLocalPlayer()
    end)

    if ok and result then return false end
  end

  if creature.isPlayer then
    local ok, result = pcall(function()
      return creature:isPlayer()
    end)

    if ok then return result == true end
  end

  return false
end

local function getCreatureName(creature)
  if not creature or not creature.getName then return nil end

  local ok, name = pcall(function()
    return creature:getName()
  end)

  if ok and name then
    return tostring(name)
  end

  return nil
end

local function getSpectatorsList()
  local list = {}

  if getSpectators then
    local ok, spectators = pcall(function()
      return getSpectators()
    end)

    if ok and spectators then
      for _, creature in ipairs(spectators) do
        table.insert(list, creature)
      end

      return list
    end
  end

  if g_map and g_map.getSpectators and player and player.getPosition then
    local ok, spectators = pcall(function()
      return g_map.getSpectators(player:getPosition(), false)
    end)

    if ok and spectators then
      for _, creature in ipairs(spectators) do
        table.insert(list, creature)
      end
    end
  end

  return list
end

local function findPlayerByName(name)
  local wanted = normalizeName(name)

  if wanted == "" then
    return nil
  end

  for _, creature in ipairs(getSpectatorsList()) do
    if isValidPlayer(creature) then
      local creatureName = getCreatureName(creature)

      if normalizeName(creatureName) == wanted then
        return creature
      end
    end
  end

  return nil
end

local function prepareReflect()
  closeHand()
  setFollowAttack()
  setTargetBotOff()
  setCaveBotOff()
end

local function attackCreature(creature)
  if not creature then return false end

  prepareReflect()

  local ok = pcall(function()
    g_game.attack(creature)
  end)

  return ok == true
end

local function restoreBots()
  if targetWasOn then
    setTargetBotOn()
  end

  if caveWasOn then
    setCaveBotOn()
  end
end

local function stopReflect()
  reflectTargetName = nil
  reflectUntil = 0
  lastAttackTry = 0
  lastSeenAt = 0
  reflecting = false

  openHand()
  restoreBots()
  hidePkAlert()
end

local function startReflect(name)
  if not name or name == "" then return end

  if not reflecting then
    targetWasOn = isTargetBotOn()
    caveWasOn = isCaveBotOn()
  end

  reflectTargetName = name
  reflectUntil = now + ATTACK_TIME
  lastAttackTry = 0
  lastSeenAt = now
  reflecting = true

  showPkAlert(name)
  prepareReflect()

  local creature = findPlayerByName(name)

  if creature then
    lastSeenAt = now
    attackCreature(creature)
  end
end

local function parseAttackerFromText(text)
  if not text then return nil end

  local raw = tostring(text)

  local name =
    raw:match("[Yy]ou lose.-due to an attack by ([%a%s%-_'%[%]%.]+)%.?") or
    raw:match("[Yy]ou lose.-due to a hit by ([%a%s%-_'%[%]%.]+)%.?") or
    raw:match("[Yy]ou lose.-by ([%a%s%-_'%[%]%.]+)%.?")

  if not name then
    name =
      raw:match("[Vv]oc[e�].-[Aa]taque de ([%a%s%-_'%[%]%.]+)%.?") or
      raw:match("[Vv]oc[e�].-[Pp]or ([%a%s%-_'%[%]%.]+)%.?") or
      raw:match("[Vv]oc[e�].-[Dd]e ([%a%s%-_'%[%]%.]+)%.?")
  end

  if not name then return nil end

  name = name:gsub("^%s+", ""):gsub("%s+$", "")
  name = name:gsub("%.$", "")

  local lower = name:lower()

  local invalid = {
    ["fire"] = true,
    ["energy"] = true,
    ["earth"] = true,
    ["ice"] = true,
    ["death"] = true,
    ["poison"] = true,
    ["drown"] = true,
    ["bleeding"] = true,
    ["physical"] = true,
    ["field"] = true
  }

  if invalid[lower] then
    return nil
  end

  return name
end

onTextMessage(function(mode, text)
  if not storage.pkReflectBot.enabled then
    return
  end

  local attackerName = parseAttackerFromText(text)

  if not attackerName then
    return
  end

  local creature = findPlayerByName(attackerName)

  -- S� reage se o player estiver na tela.
  if not creature then
    return
  end

  startReflect(attackerName)
end)

macro(100, function()
  if not storage.pkReflectBot.enabled then
    if reflecting then
      stopReflect()
    end

    return
  end

  if not reflecting or not reflectTargetName then
    return
  end

  showPkAlert(reflectTargetName)

  if now > reflectUntil then
    stopReflect()
    return
  end

  local creature = findPlayerByName(reflectTargetName)

  if creature then
    lastSeenAt = now

    if now - lastAttackTry >= RETRY_DELAY then
      lastAttackTry = now

      local currentTarget = nil

      pcall(function()
        if g_game and g_game.getAttackingCreature then
          currentTarget = g_game.getAttackingCreature()
        end
      end)

      if currentTarget ~= creature then
        attackCreature(creature)
      else
        prepareReflect()
      end
    end

    return
  end

  local lostDelay = clamp(storage.pkReflectBot.lostDelay, 1000, 15000)

  if now - lastSeenAt >= lostDelay then
    stopReflect()
    return
  end
end)