-- Exp Boost.lua


setDefaultTab("Tools")

UI.Separator()

if type(storage.expBoostBot) ~= "table" then
  storage.expBoostBot = {
    enabled = false,
    useWith = false,
    boostItems = {},
    lastUseAt = 0
  }
end

if type(storage.expBoostBot.boostItems) ~= "table" then
  storage.expBoostBot.boostItems = {}
end

if storage.expBoostBot.useWith == nil then
  storage.expBoostBot.useWith = false
end

if storage.expBoostBot.lastUseAt == nil then
  storage.expBoostBot.lastUseAt = 0
end

local BOOST_INTERVAL = 30 * 60 -- 30 minutos em segundos
local USE_DELAY = 700 -- delay entre um item e outro

local mainPanel = setupUI([[
Panel
  height: 22

  BotSwitch
    id: enabled
    anchors.top: parent.top
    anchors.left: parent.left
    width: 125
    height: 20
    text-align: center
    text: EXP Boosts

  Button
    id: setup
    anchors.top: parent.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Setup
]])

mainPanel.enabled:setOn(storage.expBoostBot.enabled)

mainPanel.enabled.onClick = function(widget)
  storage.expBoostBot.enabled = not storage.expBoostBot.enabled
  widget:setOn(storage.expBoostBot.enabled)
end

local setupPanel = setupUI([[
Panel
  height: 74

  Label
    id: info
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    height: 18
    text-align: center
    text: Arraste os boosts abaixo

  BotSwitch
    id: useWith
    anchors.top: prev.bottom
    anchors.left: parent.left
    width: 125
    height: 20
    text-align: center
    text: Use With Player

  Button
    id: useNow
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Use Now

  Label
    id: status
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 18
    text-align: center
    text: Status: parado
]])

setupPanel:hide()

local boostContainer = UI.Container(function(widget, items)
  storage.expBoostBot.boostItems = items
end, true)

boostContainer:setHeight(35)
boostContainer:setItems(storage.expBoostBot.boostItems)
boostContainer:hide()

mainPanel.setup.onClick = function(widget)
  if setupPanel:isVisible() then
    setupPanel:hide()
    boostContainer:hide()
    widget:setText("Setup")
  else
    setupPanel:show()
    boostContainer:show()
    widget:setText("Close")
  end
end

setupPanel.useWith:setOn(storage.expBoostBot.useWith)

setupPanel.useWith.onClick = function(widget)
  storage.expBoostBot.useWith = not storage.expBoostBot.useWith
  widget:setOn(storage.expBoostBot.useWith)
end

local function getItemIdFromEntry(entry)
  if not entry then return 0 end

  if type(entry) == "table" then
    return tonumber(entry.id or entry.itemId or entry[1]) or 0
  end

  return tonumber(entry) or 0
end

local function getBoostIds()
  local ids = {}
  local added = {}

  for _, entry in ipairs(storage.expBoostBot.boostItems or {}) do
    local id = getItemIdFromEntry(entry)

    if id > 0 and not added[id] then
      table.insert(ids, id)
      added[id] = true
    end
  end

  return ids
end

local function useBoostById(id)
  if not id or id <= 0 then return false end

  local item = findItem(id)

  -- MODO USE WITH PLAYER
  if storage.expBoostBot.useWith then
    if item then
      if useWith then
        useWith(item, player)
      elseif g_game.useWith then
        g_game.useWith(item, player)
      elseif g_game.useInventoryItemWith then
        g_game.useInventoryItemWith(id, player)
      else
        return false
      end

      return true
    end

    if g_game.useInventoryItemWith then
      g_game.useInventoryItemWith(id, player)
      return true
    end

    return false
  end

  -- MODO USE NORMAL
  if item then
    g_game.use(item)
    return true
  end

  if g_game.useInventoryItem then
    g_game.useInventoryItem(id)
    return true
  end

  return false
end

local function useAllBoosts()
  local ids = getBoostIds()

  if #ids == 0 then
    setupPanel.status:setText("Status: arraste os itens")
    return false
  end

  for i, id in ipairs(ids) do
    schedule((i - 1) * USE_DELAY, function()
      useBoostById(id)
    end)
  end

  storage.expBoostBot.lastUseAt = os.time()

  setupPanel.status:setText("Status: boosts usados")
  return true
end

setupPanel.useNow.onClick = function()
  useAllBoosts()
end

local function formatTime(seconds)
  seconds = math.max(0, tonumber(seconds) or 0)

  local minutes = math.floor(seconds / 60)
  local secs = seconds % 60

  if minutes > 0 then
    return minutes .. "m " .. secs .. "s"
  end

  return secs .. "s"
end

macro(1000, function()
  if not storage.expBoostBot.enabled then
    setupPanel.status:setText("Status: desligado")
    return
  end

  local ids = getBoostIds()

  if #ids == 0 then
    setupPanel.status:setText("Status: arraste os boosts")
    return
  end

  local nowTime = os.time()
  local lastUse = tonumber(storage.expBoostBot.lastUseAt) or 0
  local elapsed = nowTime - lastUse
  local remaining = BOOST_INTERVAL - elapsed

  if lastUse <= 0 or elapsed >= BOOST_INTERVAL then
    setupPanel.status:setText("Status: usando boosts...")
    useAllBoosts()
    return
  end

  setupPanel.status:setText("Status: proximo em " .. formatTime(remaining))
end)