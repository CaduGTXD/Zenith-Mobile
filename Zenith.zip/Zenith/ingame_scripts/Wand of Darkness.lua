-- Auto Wand of Darkness - Cooldown Inteligente.lua
-- OTClientV8 / vBot
--
-- Magia: exevo gran mort
--
-- FUNCIONAMENTO:
-- 1. Procura a magia na SpellInfo assim que o script inicia.
-- 2. Pega automaticamente o ID usado pelo cooldown.
-- 3. Reconhece cooldown que JA ESTAVA ATIVO antes do script ligar.
-- 4. Verifica o cooldown real do client.
-- 5. Nao usa cronometro de 30 minutos.
-- 6. Se tentar conjurar e falhar, tenta novamente.
-- 7. Se o cooldown aparecer, para completamente de tentar.

setDefaultTab("Tools")

UI.Separator()

if type(storage.autoWandDarkness) ~= "table" then
  storage.autoWandDarkness = {
    enabled = false,

    spell = "exevo gran mort",

    retryDelay = 1000,

    -- Preenchido automaticamente atrav�s da SpellInfo.
    cooldownIconId = 0,

    -- Nome detectado da magia.
    detectedSpellName = ""
  }
end

local config = storage.autoWandDarkness

if config.enabled == nil then
  config.enabled = false
end

if config.spell == nil or config.spell == "" then
  config.spell = "exevo gran mort"
end

if config.retryDelay == nil then
  config.retryDelay = 1000
end

if config.cooldownIconId == nil then
  config.cooldownIconId = 0
end

if config.detectedSpellName == nil then
  config.detectedSpellName = ""
end

-- Usado apenas como fallback para reconhecer o evento.
-- Nao controla o tempo de espera.
local EXPECTED_COOLDOWN_MS = 1800 * 1000
local COOLDOWN_TOLERANCE_MS = 20000

local mainPanel = setupUI([[
Panel
  height: 22

  BotSwitch
    id: enabled
    anchors.top: parent.top
    anchors.left: parent.left
    width: 145
    height: 20
    text-align: center
    text: Auto Wand

  Button
    id: setup
    anchors.top: parent.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Setup
]])

local setupPanel = setupUI([[
Panel
  height: 238

  Label
    id: spellLabel
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    height: 18
    text-align: center
    text: Magia

  BotTextEdit
    id: spell
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 22
    text: exevo gran mort

  Label
    id: retryLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 18
    text-align: center
    text: Nova tentativa: 1000ms

  HorizontalScrollBar
    id: retrySlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: cooldownIdLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 18
    text-align: center
    text: Cooldown Icon ID

  BotTextEdit
    id: cooldownId
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 22
    text: 0

  Label
    id: detectedSpell
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 18
    text-align: center
    text: Magia detectada: procurando...

  Label
    id: status
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Status: aguardando

  Button
    id: resolveId
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 7
    height: 20
    text: Detectar Cooldown Agora

  Button
    id: castNow
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 20
    text: Verificar e Conjurar
]])

setupPanel:hide()

local function currentMillis()
  local botNow = tonumber(now)

  if botNow then
    return botNow
  end

  if g_clock and g_clock.millis then
    local ok, value = pcall(function()
      return g_clock.millis()
    end)

    if ok and value then
      return tonumber(value) or 0
    end
  end

  return os.time() * 1000
end

local function clamp(value, minimum, maximum)
  value = tonumber(value) or minimum

  if value < minimum then
    return minimum
  end

  if value > maximum then
    return maximum
  end

  return value
end

local function normalizeText(text)
  text = tostring(text or "")
  text = text:lower()
  text = text:gsub("^%s+", "")
  text = text:gsub("%s+$", "")
  text = text:gsub("%s+", " ")

  return text
end

local function isOnline()
  if not g_game or not g_game.isOnline then
    return false
  end

  local ok, result = pcall(function()
    return g_game.isOnline()
  end)

  return ok and result == true
end

local function normalizeCooldownDuration(duration)
  duration = tonumber(duration) or 0

  -- Compatibilidade com clients que possam enviar em segundos.
  if duration > 0 and duration < 10000 then
    return duration * 1000
  end

  return duration
end

local function durationMatchesWand(duration)
  local durationMs = normalizeCooldownDuration(duration)

  if durationMs <= 0 then
    return false
  end

  return math.abs(durationMs - EXPECTED_COOLDOWN_MS)
    <= COOLDOWN_TOLERANCE_MS
end

local function getSpellInfoSources()
  local sources = {}
  local alreadyAdded = {}

  local function addSource(source)
    if type(source) ~= "table" then
      return
    end

    if alreadyAdded[source] then
      return
    end

    alreadyAdded[source] = true
    table.insert(sources, source)
  end

  addSource(SpellInfo)

  if modules and modules.gamelib then
    addSource(modules.gamelib.SpellInfo)
  end

  if modules and modules.game_spelllist then
    addSource(modules.game_spelllist.SpellInfo)
  end

  return sources
end

local function getIconIdFromSpellInfo(info)
  if type(info) ~= "table" then
    return 0
  end

  -- Este e o ID usado pela action bar para comparar
  -- com o iconId recebido no evento de cooldown.
  local spellId = tonumber(info.id)

  if spellId and spellId > 0 then
    return spellId
  end

  -- Fallback para outros formatos de SpellInfo.
  local icon = tonumber(info.icon)

  if icon and icon > 0 then
    return icon
  end

  if SpellIcons and info.icon and SpellIcons[info.icon] then
    local iconData = SpellIcons[info.icon]

    if type(iconData) == "table" then
      local iconId = tonumber(iconData[1])

      if iconId and iconId > 0 then
        return iconId
      end
    end
  end

  return 0
end

local function findSpellByWords(words)
  words = normalizeText(words)

  if words == "" then
    return nil
  end

  for _, source in ipairs(getSpellInfoSources()) do
    -- Estrutura:
    -- SpellInfo["Default"]["Nome da Magia"] = info
    for profileName, profileData in pairs(source) do
      if type(profileData) == "table" then
        for spellName, info in pairs(profileData) do
          if type(info) == "table" then
            local spellWords = normalizeText(info.words)

            if spellWords == words then
              return {
                name = tostring(spellName),
                profile = tostring(profileName),
                info = info,
                id = getIconIdFromSpellInfo(info)
              }
            end
          end
        end
      end
    end
  end

  return nil
end

local function getCooldownTable()
  if modules
    and modules.game_cooldown
    and type(modules.game_cooldown.cooldown) == "table" then

    return modules.game_cooldown.cooldown
  end

  if type(cooldown) == "table" then
    return cooldown
  end

  return nil
end

local function isCooldownActiveByTable(iconId)
  iconId = tonumber(iconId) or 0

  if iconId <= 0 then
    return nil
  end

  local cooldownTable = getCooldownTable()

  if not cooldownTable then
    return nil
  end

  return cooldownTable[iconId] == true
end

local function getSpellNameByIcon(iconId)
  iconId = tonumber(iconId) or 0

  if iconId <= 0 then
    return ""
  end

  if not Spells or not Spells.getSpellByIcon then
    return ""
  end

  local ok, spell, profile, spellName = pcall(function()
    return Spells.getSpellByIcon(iconId)
  end)

  if not ok then
    return ""
  end

  if spellName then
    return tostring(spellName)
  end

  if type(spell) == "string" then
    return spell
  end

  return ""
end

local function findActiveCooldownBySpellName()
  local cooldownTable = getCooldownTable()

  if not cooldownTable then
    return 0, ""
  end

  local wantedWords = normalizeText(config.spell)
  local wantedName = normalizeText(config.detectedSpellName)

  for iconId, active in pairs(cooldownTable) do
    if active == true then
      local spellName = getSpellNameByIcon(iconId)
      local normalizedName = normalizeText(spellName)

      if normalizedName ~= "" then
        if wantedName ~= "" and normalizedName == wantedName then
          return tonumber(iconId) or 0, spellName
        end

        if normalizedName:find("wand of darkness", 1, true) then
          return tonumber(iconId) or 0, spellName
        end

        if wantedWords ~= ""
          and normalizedName:find(wantedWords, 1, true) then

          return tonumber(iconId) or 0, spellName
        end
      end
    end
  end

  return 0, ""
end

local function updateCooldownIdField()
  local iconId = tonumber(config.cooldownIconId) or 0

  setupPanel.cooldownId:setText(tostring(iconId))
end

local function updateDetectedSpellLabel()
  local spellName = tostring(config.detectedSpellName or "")

  if spellName == "" then
    setupPanel.detectedSpell:setText(
      "Magia detectada: procurando..."
    )
  else
    setupPanel.detectedSpell:setText(
      "Magia detectada: " .. spellName
    )
  end
end

local resolvingId = false

local function resolveCooldownId(force)
  if resolvingId then
    return tonumber(config.cooldownIconId) or 0
  end

  resolvingId = true

  local configuredId = tonumber(config.cooldownIconId) or 0

  if configuredId > 0 and not force then
    resolvingId = false
    return configuredId
  end

  -- Forma principal:
  -- procura "exevo gran mort" diretamente na SpellInfo.
  local spellData = findSpellByWords(config.spell)

  if spellData and spellData.id and spellData.id > 0 then
    config.cooldownIconId = spellData.id
    config.detectedSpellName = spellData.name

    updateCooldownIdField()
    updateDetectedSpellLabel()

    resolvingId = false
    return spellData.id
  end

  -- Fallback:
  -- procura entre cooldowns que ja estao ativos.
  -- Resolve inclusive quando o script liga no meio do cooldown.
  local activeId, activeName = findActiveCooldownBySpellName()

  if activeId > 0 then
    config.cooldownIconId = activeId

    if activeName ~= "" then
      config.detectedSpellName = activeName
    end

    updateCooldownIdField()
    updateDetectedSpellLabel()

    resolvingId = false
    return activeId
  end

  resolvingId = false

  return configuredId
end

-- Retorna:
-- true  = cooldown ativo
-- false = cooldown livre
-- nil   = nao foi possivel verificar
local function getRealCooldownState()
  local iconId = tonumber(config.cooldownIconId) or 0

  if iconId <= 0 then
    iconId = resolveCooldownId(false)
  end

  if iconId <= 0 then
    return nil, "idNotFound"
  end

  if modules
    and modules.game_cooldown
    and modules.game_cooldown.isCooldownIconActive then

    local ok, active = pcall(function()
      return modules.game_cooldown.isCooldownIconActive(iconId)
    end)

    if ok then
      -- Pode retornar nil quando nunca houve cooldown.
      -- Com o ID conhecido, nil significa que nao esta ativo.
      return active == true, "api"
    end
  end

  local tableState = isCooldownActiveByTable(iconId)

  if tableState ~= nil then
    return tableState, "table"
  end

  return nil, "apiUnavailable"
end

local lastStatusText = ""

local function setStatus(text)
  text = tostring(text or "")

  if text == lastStatusText then
    return
  end

  lastStatusText = text
  setupPanel.status:setText("Status: " .. text)
end

local lastAttemptAt = 0
local nextAttemptAt = 0
local confirmationUntil = 0

local function updateStatus()
  if not config.enabled then
    setStatus("desligado")
    return
  end

  if not isOnline() then
    setStatus("offline")
    return
  end

  local iconId = resolveCooldownId(false)

  if iconId <= 0 then
    setStatus("nao encontrou o ID da magia")
    return
  end

  local active, reason = getRealCooldownState()

  if active == true then
    setStatus("cooldown ativo | ID " .. iconId)
    return
  end

  if active == false then
    if currentMillis() < confirmationUntil then
      setStatus("aguardando confirmar conjuracao")
    else
      setStatus("cooldown livre | ID " .. iconId)
    end

    return
  end

  if reason == "apiUnavailable" then
    setStatus("API de cooldown indisponivel")
  else
    setStatus("nao foi possivel verificar")
  end
end

mainPanel.enabled:setOn(config.enabled)

mainPanel.enabled.onClick = function(widget)
  config.enabled = not config.enabled
  widget:setOn(config.enabled)

  if config.enabled then
    -- Resolve o ID imediatamente ao ligar.
    resolveCooldownId(true)

    nextAttemptAt = 0
    confirmationUntil = 0
  end

  updateStatus()
end

mainPanel.setup.onClick = function(widget)
  if setupPanel:isVisible() then
    setupPanel:hide()
    widget:setText("Setup")
  else
    setupPanel:show()
    widget:setText("Close")

    resolveCooldownId(false)
    updateStatus()
  end
end

setupPanel.spell:setText(config.spell)

setupPanel.spell.onTextChange = function(widget, text)
  local spell = normalizeText(text)

  if spell == "" then
    return
  end

  if normalizeText(config.spell) ~= spell then
    config.spell = spell

    config.cooldownIconId = 0
    config.detectedSpellName = ""

    nextAttemptAt = 0
    confirmationUntil = 0

    updateCooldownIdField()
    updateDetectedSpellLabel()

    schedule(100, function()
      resolveCooldownId(true)
      updateStatus()
    end)
  end
end

local function updateRetryLabel()
  config.retryDelay = clamp(config.retryDelay, 500, 10000)

  setupPanel.retryLabel:setText(
    "Nova tentativa: " .. config.retryDelay .. "ms"
  )
end

pcall(function()
  setupPanel.retrySlider:setMinimum(500)
  setupPanel.retrySlider:setMaximum(10000)
  setupPanel.retrySlider:setValue(
    clamp(config.retryDelay, 500, 10000)
  )
end)

setupPanel.retrySlider.onValueChange = function(widget, value)
  config.retryDelay = clamp(value, 500, 10000)
  updateRetryLabel()
end

updateRetryLabel()

updateCooldownIdField()
updateDetectedSpellLabel()

local changingIdText = false

setupPanel.cooldownId.onTextChange = function(widget, text)
  if changingIdText then
    return
  end

  local iconId = tonumber(text) or 0

  if iconId < 0 then
    iconId = 0
  end

  config.cooldownIconId = math.floor(iconId)

  nextAttemptAt = 0
  confirmationUntil = 0

  if config.cooldownIconId > 0 then
    local spellName = getSpellNameByIcon(config.cooldownIconId)

    if spellName ~= "" then
      config.detectedSpellName = spellName
      updateDetectedSpellLabel()
    end
  end

  updateStatus()
end

local function sendSpell()
  if not isOnline() then
    return false
  end

  local spell = normalizeText(config.spell)

  if spell == "" then
    spell = "exevo gran mort"

    config.spell = spell
    setupPanel.spell:setText(spell)
  end

  local time = currentMillis()

  lastAttemptAt = time

  -- Espera curta apenas para o servidor enviar o cooldown.
  -- Nao e o cooldown de 30 minutos.
  confirmationUntil = time + 2000

  if say then
    local ok = pcall(function()
      say(spell)
    end)

    if ok then
      return true
    end
  end

  if g_game and g_game.talk then
    local ok = pcall(function()
      g_game.talk(spell)
    end)

    if ok then
      return true
    end
  end

  confirmationUntil = 0

  return false
end

local function checkAndCast()
  if not config.enabled then
    return false
  end

  if not isOnline() then
    return false
  end

  local time = currentMillis()
  local iconId = resolveCooldownId(false)

  -- Por seguranca, nao conjura sem conhecer o ID.
  -- Como a magia existe na action bar, ele deve encontrar automaticamente.
  if iconId <= 0 then
    setStatus("nao encontrou o ID da magia")
    return false
  end

  local active = getRealCooldownState()

  -- Reconhece inclusive cooldown que ja estava em andamento.
  if active == true then
    confirmationUntil = 0
    setStatus("cooldown ativo | ID " .. iconId)

    return false
  end

  if active == nil then
    setStatus("nao conseguiu consultar o cooldown")
    return false
  end

  if time < confirmationUntil then
    return false
  end

  if time < nextAttemptAt then
    return false
  end

  local sent = sendSpell()

  nextAttemptAt =
    time + clamp(config.retryDelay, 500, 10000)

  updateStatus()

  return sent
end

-- Atualiza quando o servidor enviar um cooldown.
if onSpellCooldown then
  onSpellCooldown(function(iconId, duration)
    iconId = tonumber(iconId) or 0

    if iconId <= 0 then
      return
    end

    local configuredId =
      tonumber(config.cooldownIconId) or 0

    local time = currentMillis()

    -- Evento da magia que ja detectamos.
    if configuredId > 0 and iconId == configuredId then
      confirmationUntil = 0

      local spellName = getSpellNameByIcon(iconId)

      if spellName ~= "" then
        config.detectedSpellName = spellName
        updateDetectedSpellLabel()
      end

      updateStatus()
      return
    end

    -- Fallback caso a SpellInfo customizada nao forneca o ID.
    if configuredId <= 0 then
      local recentAttempt =
        lastAttemptAt > 0
        and time >= lastAttemptAt
        and time - lastAttemptAt <= 5000

      if recentAttempt and durationMatchesWand(duration) then
        config.cooldownIconId = iconId

        local spellName = getSpellNameByIcon(iconId)

        if spellName ~= "" then
          config.detectedSpellName = spellName
        end

        confirmationUntil = 0

        updateCooldownIdField()
        updateDetectedSpellLabel()
        updateStatus()
      end
    end
  end)
end

setupPanel.resolveId.onClick = function()
  config.cooldownIconId = 0
  config.detectedSpellName = ""

  updateCooldownIdField()
  updateDetectedSpellLabel()

  local iconId = resolveCooldownId(true)

  if iconId > 0 then
    setStatus("ID detectado: " .. iconId)
  else
    setStatus("nao encontrou a magia na SpellInfo")
  end
end

setupPanel.castNow.onClick = function()
  nextAttemptAt = 0
  confirmationUntil = 0

  checkAndCast()
end

-- Resolve assim que o script for carregado.
schedule(300, function()
  resolveCooldownId(true)
  updateStatus()
end)

-- Verifica continuamente o cooldown real.
macro(250, function()
  if not config.enabled then
    return
  end

  if not isOnline() then
    return
  end

  local iconId = resolveCooldownId(false)

  if iconId <= 0 then
    updateStatus()
    return
  end

  local active = getRealCooldownState()

  if active == true then
    confirmationUntil = 0
    return
  end

  checkAndCast()
end)

macro(500, function()
  if setupPanel:isVisible() then
    updateStatus()
  end
end)