-- MageBot-like Diagonal Keys + Dodge
-- Numpad:
-- 7 NW | 8 N | 9 NE
-- 4 W  |     | 6 E
-- 1 SW | 2 S | 3 SE
--
-- Tamb�m suporta:
-- Q = NW
-- E = NE
-- Z = SW
-- C = SE
--
-- N�o funciona com chat aberto/ativo.
-- N�o funciona segurando CTRL.

setDefaultTab("Tools")

UI.Separator()

if type(storage.diagonalDashDodge) ~= "table" then
  storage.diagonalDashDodge = {
    enabled = false,
    useNumpad = true,
    useQEZC = true,
    useWASD = false,
    dodge = true,
    delay = 110
  }
end

if storage.diagonalDashDodge.useNumpad == nil then
  storage.diagonalDashDodge.useNumpad = true
end

if storage.diagonalDashDodge.useQEZC == nil then
  storage.diagonalDashDodge.useQEZC = true
end

if storage.diagonalDashDodge.useWASD == nil then
  storage.diagonalDashDodge.useWASD = false
end

if storage.diagonalDashDodge.dodge == nil then
  storage.diagonalDashDodge.dodge = true
end

if storage.diagonalDashDodge.delay == nil then
  storage.diagonalDashDodge.delay = 110
end

-- Valores antigos abaixo de 80ms geravam muitos comandos de movimento.
if tonumber(storage.diagonalDashDodge.delay) and tonumber(storage.diagonalDashDodge.delay) < 80 then
  storage.diagonalDashDodge.delay = 110
end

local mainPanel = setupUI([[
Panel
  height: 22

  BotSwitch
    id: enabled
    anchors.top: parent.top
    anchors.left: parent.left
    width: 125
    height: 20
    text-align: center
    text: Diagonal Keys

  Button
    id: setup
    anchors.top: parent.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Setup
]])

mainPanel.enabled:setOn(storage.diagonalDashDodge.enabled)

mainPanel.enabled.onClick = function(widget)
  storage.diagonalDashDodge.enabled = not storage.diagonalDashDodge.enabled
  widget:setOn(storage.diagonalDashDodge.enabled)
end

local setupPanel = setupUI([[
Panel
  height: 152

  BotSwitch
    id: useNumpad
    anchors.top: parent.top
    anchors.left: parent.left
    width: 125
    height: 20
    text-align: center
    text: Numpad

  BotSwitch
    id: useQEZC
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text-align: center
    text: Q/E/Z/C

  BotSwitch
    id: useWASD
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 20
    text-align: center
    text: WASD Combo

  BotSwitch
    id: dodge
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 20
    text-align: center
    text: Dodge

  Label
    id: delayLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Delay: 110ms

  HorizontalScrollBar
    id: delaySlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: info
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 36
    text-align: center
    text: Ignora chat e CTRL
]])

setupPanel:hide()

mainPanel.setup.onClick = function(widget)
  if setupPanel:isVisible() then
    setupPanel:hide()
    widget:setText("Setup")
  else
    setupPanel:show()
    widget:setText("Close")
  end
end

setupPanel.useNumpad:setOn(storage.diagonalDashDodge.useNumpad)

setupPanel.useNumpad.onClick = function(widget)
  storage.diagonalDashDodge.useNumpad = not storage.diagonalDashDodge.useNumpad
  widget:setOn(storage.diagonalDashDodge.useNumpad)
end

setupPanel.useQEZC:setOn(storage.diagonalDashDodge.useQEZC)

setupPanel.useQEZC.onClick = function(widget)
  storage.diagonalDashDodge.useQEZC = not storage.diagonalDashDodge.useQEZC
  widget:setOn(storage.diagonalDashDodge.useQEZC)
end

setupPanel.useWASD:setOn(storage.diagonalDashDodge.useWASD)

setupPanel.useWASD.onClick = function(widget)
  storage.diagonalDashDodge.useWASD = not storage.diagonalDashDodge.useWASD
  widget:setOn(storage.diagonalDashDodge.useWASD)
end

setupPanel.dodge:setOn(storage.diagonalDashDodge.dodge)

setupPanel.dodge.onClick = function(widget)
  storage.diagonalDashDodge.dodge = not storage.diagonalDashDodge.dodge
  widget:setOn(storage.diagonalDashDodge.dodge)
end

local function clamp(value, minValue, maxValue)
  value = tonumber(value) or minValue

  if value < minValue then
    return minValue
  end

  if value > maxValue then
    return maxValue
  end

  return value
end

local function updateDelayLabel()
  local delayValue = clamp(storage.diagonalDashDodge.delay, 80, 250)
  setupPanel.delayLabel:setText("Delay: " .. delayValue .. "ms")
end

pcall(function()
  setupPanel.delaySlider:setMinimum(80)
  setupPanel.delaySlider:setMaximum(250)
  setupPanel.delaySlider:setValue(clamp(storage.diagonalDashDodge.delay, 80, 250))
end)

setupPanel.delaySlider.onValueChange = function(widget, value)
  storage.diagonalDashDodge.delay = clamp(value, 80, 250)
  updateDelayLabel()
end

updateDelayLabel()

local lastDash = 0
local lastRequestedDirection = nil
local lastCommandPosition = nil
local repeatReadyAt = 0

-- A leitura das teclas pode ser r�pida, mas comandos de movimento n�o devem ser
-- enviados antes do passo anterior avan�ar. Isso evita backlog/fake ping.
local INITIAL_HOLD_DELAY = 150
local STUCK_RETRY_DELAY = 350

local function samePosition(a, b)
  return a and b and a.x == b.x and a.y == b.y and a.z == b.z
end

local function copyPosition(pos)
  if not pos then return nil end
  return {x = pos.x, y = pos.y, z = pos.z}
end

local DIR_NORTH = North or 0
local DIR_EAST = East or 1
local DIR_SOUTH = South or 2
local DIR_WEST = West or 3
local DIR_NORTH_EAST = NorthEast or 4
local DIR_SOUTH_EAST = SouthEast or 5
local DIR_SOUTH_WEST = SouthWest or 6
local DIR_NORTH_WEST = NorthWest or 7

local directionOffset = {
  [DIR_NORTH] = {x = 0, y = -1},
  [DIR_EAST] = {x = 1, y = 0},
  [DIR_SOUTH] = {x = 0, y = 1},
  [DIR_WEST] = {x = -1, y = 0},

  [DIR_NORTH_EAST] = {x = 1, y = -1},
  [DIR_SOUTH_EAST] = {x = 1, y = 1},
  [DIR_SOUTH_WEST] = {x = -1, y = 1},
  [DIR_NORTH_WEST] = {x = -1, y = -1}
}

local dodgeFallbacks = {
  [DIR_NORTH] = {
    DIR_NORTH,
    DIR_NORTH_EAST,
    DIR_NORTH_WEST,
    DIR_EAST,
    DIR_WEST
  },

  [DIR_SOUTH] = {
    DIR_SOUTH,
    DIR_SOUTH_EAST,
    DIR_SOUTH_WEST,
    DIR_EAST,
    DIR_WEST
  },

  [DIR_EAST] = {
    DIR_EAST,
    DIR_NORTH_EAST,
    DIR_SOUTH_EAST,
    DIR_NORTH,
    DIR_SOUTH
  },

  [DIR_WEST] = {
    DIR_WEST,
    DIR_NORTH_WEST,
    DIR_SOUTH_WEST,
    DIR_NORTH,
    DIR_SOUTH
  },

  [DIR_NORTH_EAST] = {
    DIR_NORTH_EAST,
    DIR_NORTH,
    DIR_EAST,
    DIR_SOUTH_EAST,
    DIR_NORTH_WEST
  },

  [DIR_NORTH_WEST] = {
    DIR_NORTH_WEST,
    DIR_NORTH,
    DIR_WEST,
    DIR_SOUTH_WEST,
    DIR_NORTH_EAST
  },

  [DIR_SOUTH_EAST] = {
    DIR_SOUTH_EAST,
    DIR_SOUTH,
    DIR_EAST,
    DIR_NORTH_EAST,
    DIR_SOUTH_WEST
  },

  [DIR_SOUTH_WEST] = {
    DIR_SOUTH_WEST,
    DIR_SOUTH,
    DIR_WEST,
    DIR_NORTH_WEST,
    DIR_SOUTH_EAST
  }
}

local function keyDown(...)
  if not g_keyboard or not g_keyboard.isKeyPressed then
    return false
  end

  local keys = {...}

  for _, key in ipairs(keys) do
    local ok, pressed = pcall(function()
      return g_keyboard.isKeyPressed(key)
    end)

    if ok and pressed then
      return true
    end
  end

  return false
end

local function isCtrlDown()
  if g_keyboard and g_keyboard.isCtrlPressed then
    local ok, result = pcall(function()
      return g_keyboard.isCtrlPressed()
    end)

    if ok and result then
      return true
    end
  end

  if keyDown(
    "Ctrl",
    "Control",
    "LeftCtrl",
    "RightCtrl",
    "LCtrl",
    "RCtrl",
    "CtrlLeft",
    "CtrlRight"
  ) then
    return true
  end

  return false
end

local function isChatOpen()
  if modules and modules.game_console and modules.game_console.isChatEnabled then
    local ok, result = pcall(function()
      return modules.game_console.isChatEnabled()
    end)

    if ok then
      return result == true
    end
  end

  if g_game and g_game.isChatEnabled then
    local ok, result = pcall(function()
      return g_game.isChatEnabled()
    end)

    if ok then
      return result == true
    end
  end

  if isChatEnabled then
    local ok, result = pcall(function()
      return isChatEnabled()
    end)

    if ok then
      return result == true
    end
  end

  if g_ui and g_ui.getFocusedWidget then
    local ok, widget = pcall(function()
      return g_ui.getFocusedWidget()
    end)

    if ok and widget then
      local className = ""

      pcall(function()
        if widget.getClassName then
          className = tostring(widget:getClassName())
        end
      end)

      className = className:lower()

      if className:find("text") or className:find("edit") or className:find("multiline") then
        return true
      end
    end
  end

  return false
end

local function getPlayerPos()
  if player and player.getPosition then
    return player:getPosition()
  end

  local p = g_game.getLocalPlayer()

  if p and p.getPosition then
    return p:getPosition()
  end

  return nil
end

local function getPosByDirection(pos, direction)
  local offset = directionOffset[direction]

  if not pos or not offset then
    return nil
  end

  return {
    x = pos.x + offset.x,
    y = pos.y + offset.y,
    z = pos.z
  }
end

local function hasCreature(tile)
  if not tile then
    return true
  end

  if tile.getTopCreature then
    local creature = tile:getTopCreature()

    if creature then
      return true
    end
  end

  if tile.getCreatures then
    local creatures = tile:getCreatures()

    if creatures and #creatures > 0 then
      return true
    end
  end

  return false
end

local function isTileWalkable(tile)
  if not tile then
    return false
  end

  if tile.isWalkable then
    local ok, result = pcall(function()
      return tile:isWalkable()
    end)

    if ok then
      return result == true
    end
  end

  if tile.isPathable then
    local ok, result = pcall(function()
      return tile:isPathable()
    end)

    if ok then
      return result == true
    end
  end

  return true
end

local function canStep(direction)
  local pos = getPlayerPos()

  if not pos then
    return false
  end

  local checkPos = getPosByDirection(pos, direction)

  if not checkPos then
    return false
  end

  local tile = g_map.getTile(checkPos)

  if not tile then
    return false
  end

  if hasCreature(tile) then
    return false
  end

  if not isTileWalkable(tile) then
    return false
  end

  return true
end

local function getDodgeDirection(direction)
  if not storage.diagonalDashDodge.dodge then
    return direction
  end

  if canStep(direction) then
    return direction
  end

  local list = dodgeFallbacks[direction]

  if not list then
    return direction
  end

  for _, dir in ipairs(list) do
    if canStep(dir) then
      return dir
    end
  end

  return nil
end

local function getNumpadDirection()
  if not storage.diagonalDashDodge.useNumpad then
    return nil
  end

  if keyDown("Numpad8", "Num8", "KP8") then return DIR_NORTH end
  if keyDown("Numpad2", "Num2", "KP2") then return DIR_SOUTH end
  if keyDown("Numpad4", "Num4", "KP4") then return DIR_WEST end
  if keyDown("Numpad6", "Num6", "KP6") then return DIR_EAST end

  if keyDown("Numpad7", "Num7", "KP7") then return DIR_NORTH_WEST end
  if keyDown("Numpad9", "Num9", "KP9") then return DIR_NORTH_EAST end
  if keyDown("Numpad1", "Num1", "KP1") then return DIR_SOUTH_WEST end
  if keyDown("Numpad3", "Num3", "KP3") then return DIR_SOUTH_EAST end

  return nil
end

local function getQEZCDirection()
  if not storage.diagonalDashDodge.useQEZC then
    return nil
  end

  if keyDown("Q", "q") then return DIR_NORTH_WEST end
  if keyDown("E", "e") then return DIR_NORTH_EAST end
  if keyDown("Z", "z") then return DIR_SOUTH_WEST end
  if keyDown("C", "c") then return DIR_SOUTH_EAST end

  return nil
end

local function getWASDDirection()
  if not storage.diagonalDashDodge.useWASD then
    return nil
  end

  local up = keyDown("W", "w", "Up")
  local down = keyDown("S", "s", "Down")
  local left = keyDown("A", "a", "Left")
  local right = keyDown("D", "d", "Right")

  if up and left then return DIR_NORTH_WEST end
  if up and right then return DIR_NORTH_EAST end
  if down and left then return DIR_SOUTH_WEST end
  if down and right then return DIR_SOUTH_EAST end

  if up then return DIR_NORTH end
  if down then return DIR_SOUTH end
  if left then return DIR_WEST end
  if right then return DIR_EAST end

  return nil
end

local function resetHeldKeyState()
  lastRequestedDirection = nil
  lastCommandPosition = nil
  repeatReadyAt = 0
end

local function dash(direction, directionChanged)
  if not direction then return false end

  local delayMs = clamp(storage.diagonalDashDodge.delay, 80, 250)
  local currentPos = getPlayerPos()
  if not currentPos then return false end

  local movedSinceCommand = lastCommandPosition and not samePosition(currentPos, lastCommandPosition)

  -- Ao trocar de dire��o, permite resposta imediata, mas nunca dispara dois
  -- pacotes quase juntos. Segurando a tecla, aguarda o passo realmente avan�ar.
  if not directionChanged then
    if now < repeatReadyAt then return false end

    if lastCommandPosition and not movedSinceCommand then
      -- N�o cria fila enquanto o passo anterior ainda n�o alterou a posi��o.
      -- Se o servidor rejeitar o passo, permite uma nova tentativa ap�s 350ms.
      if now - lastDash < STUCK_RETRY_DELAY then
        return false
      end
    end
  elseif now - lastDash < math.min(delayMs, 90) then
    return false
  end

  local finalDirection = getDodgeDirection(direction)
  if not finalDirection then return false end

  lastDash = now
  lastCommandPosition = copyPosition(currentPos)
  repeatReadyAt = now + (directionChanged and INITIAL_HOLD_DELAY or delayMs)
  g_game.walk(finalDirection)
  return true
end

macro(20, function()
  if not storage.diagonalDashDodge.enabled or isChatOpen() or isCtrlDown() then
    resetHeldKeyState()
    return
  end

  local direction = getNumpadDirection()
    or getQEZCDirection()
    or getWASDDirection()

  if not direction then
    resetHeldKeyState()
    return
  end

  local directionChanged = direction ~= lastRequestedDirection
  if directionChanged then
    lastRequestedDirection = direction
    repeatReadyAt = 0
  end

  dash(direction, directionChanged)
end)
