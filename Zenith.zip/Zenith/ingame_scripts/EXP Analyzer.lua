-- Exp Tracker v2.lua
-- OTClientV8 / vBot
-- Mostra:
-- EXP/h
-- EXP ganha na sess�o
-- EXP faltando, quando conseguir calcular
-- tempo estimado para upar pelo % do level, quando dispon�vel

setDefaultTab("Tools")

UI.Separator()

if type(storage.expTrackerBot) ~= "table" then
  storage.expTrackerBot = {
    enabled = false,
    showOnScreen = true,
    posX = 50,
    posY = 85,
    updateDelay = 1000
  }
end

if storage.expTrackerBot.enabled == nil then storage.expTrackerBot.enabled = false end
if storage.expTrackerBot.showOnScreen == nil then storage.expTrackerBot.showOnScreen = true end
if storage.expTrackerBot.posX == nil then storage.expTrackerBot.posX = 50 end
if storage.expTrackerBot.posY == nil then storage.expTrackerBot.posY = 85 end
if storage.expTrackerBot.updateDelay == nil then storage.expTrackerBot.updateDelay = 1000 end

local mainPanel = setupUI([[
Panel
  height: 22

  BotSwitch
    id: enabled
    anchors.top: parent.top
    anchors.left: parent.left
    width: 84
    height: 20
    text-align: center
    text: Exp Tracker

  Button
    id: resetMain
    anchors.top: parent.top
    anchors.left: prev.right
    margin-left: 4
    width: 45
    height: 20
    text: Reset

  Button
    id: setup
    anchors.top: parent.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Setup
]])
mainPanel.enabled:setOn(storage.expTrackerBot.enabled)

mainPanel.enabled.onClick = function(widget)
  storage.expTrackerBot.enabled = not storage.expTrackerBot.enabled
  widget:setOn(storage.expTrackerBot.enabled)
end

local setupPanel = setupUI([[
Panel
  height: 138

  BotSwitch
    id: showOnScreen
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    height: 20
    text-align: center
    text: Mostrar na Tela

  Button
    id: reset
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 20
    text: Reset Session

  Label
    id: xLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: X: 50%

  HorizontalScrollBar
    id: xSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: yLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Y: 85%

  HorizontalScrollBar
    id: ySlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16
]])

setupPanel:hide()

mainPanel.setup.onClick = function(widget)
  if setupPanel:isVisible() then
    setupPanel:hide()
    widget:setText("Setup")
  else
    setupPanel:show()
    widget:setText("Close")
  end
end

setupPanel.showOnScreen:setOn(storage.expTrackerBot.showOnScreen)

setupPanel.showOnScreen.onClick = function(widget)
  storage.expTrackerBot.showOnScreen = not storage.expTrackerBot.showOnScreen
  widget:setOn(storage.expTrackerBot.showOnScreen)
end

local function clamp(value, minValue, maxValue)
  value = tonumber(value) or minValue

  if value < minValue then return minValue end
  if value > maxValue then return maxValue end

  return value
end

local function setupSlider(slider, label, storageKey, labelText)
  local value = clamp(storage.expTrackerBot[storageKey], 0, 100)

  pcall(function()
    slider:setMinimum(0)
    slider:setMaximum(100)
    slider:setValue(value)
  end)

  label:setText(labelText .. ": " .. value .. "%")

  slider.onValueChange = function(widget, newValue)
    newValue = clamp(newValue, 0, 100)
    storage.expTrackerBot[storageKey] = newValue
    label:setText(labelText .. ": " .. newValue .. "%")
  end
end

setupSlider(setupPanel.xSlider, setupPanel.xLabel, "posX", "X")
setupSlider(setupPanel.ySlider, setupPanel.yLabel, "posY", "Y")

local overlay = nil
local lastUpdate = 0
local lastStatusText = nil
local lastOverlayText = nil
local lastOverlayLeft = nil
local lastOverlayTop = nil
local textCacheAt = nil
local textCache = nil

local sessionStartExp = nil
local sessionStartLevel = nil
local sessionStartPercent = nil
local sessionStartTime = nil
local sessionLastExp = nil
local sessionLastPercentExp = nil
local sessionObservedExpGained = 0
local sessionLastGainTime = nil
local recentExpGainTexts = {}
local expRateSamples = {}
local expRateWindowMs = 15 * 60 * 1000
local levelExpRequiredEstimate = nil
local levelEstimateLevel = nil
local percentBaselineLevel = nil
local percentBaselinePercent = nil
local percentBaselineGain = nil
local lastSeenLevel = nil
local levelChangedAt = nil

local percentSamples = {}

local function setMainStatus(text)
  if mainPanel.status and lastStatusText ~= text then
    mainPanel.status:setText(text)
    lastStatusText = text
  end
end

local function trim(text)
  if not text then return "" end
  return text:match("^%s*(.-)%s*$") or ""
end

local function safeGetText(widget)
  local ok, text = pcall(function()
    if widget and widget.getText then
      return widget:getText()
    end
  end)

  if ok and text then
    return tostring(text)
  end

  return ""
end

local function safeGetChildren(widget)
  local ok, children = pcall(function()
    if widget and widget.getChildren then
      return widget:getChildren()
    end
  end)

  if ok and children then
    return children
  end

  return {}
end

local function findWidgetText(widget, list)
  if not widget then return end

  local text = trim(safeGetText(widget))

  if text ~= "" then
    table.insert(list, {
      widget = widget,
      text = text
    })
  end

  for _, child in ipairs(safeGetChildren(widget)) do
    findWidgetText(child, list)
  end
end

local function getAllTexts()
  local stamp = now or 0
  if textCacheAt == stamp and textCache then
    return textCache
  end

  local root = g_ui.getRootWidget()
  local texts = {}

  if not root then
    textCacheAt = stamp
    textCache = texts
    return texts
  end

  findWidgetText(root, texts)
  textCacheAt = stamp
  textCache = texts
  return texts
end

local function parseNumber(text)
  if not text then return nil end

  local raw = tostring(text):lower()
  raw = raw:gsub("%s", "")

  local multiplier = 1
  local hasShortSuffix = raw:find("k") ~= nil

  if raw:find("kk") then
    multiplier = 1000000
  elseif raw:find("k") then
    multiplier = 1000
  end

  raw = raw:gsub("experience", "")
  raw = raw:gsub("exp", "")
  raw = raw:gsub("kk", "")
  raw = raw:gsub("k", "")

  local clean = raw:match("(%d+[,%d%.]*)")

  if not clean then return nil end

  local commaCount = 0
  for _ in clean:gmatch(",") do commaCount = commaCount + 1 end

  local dotCount = 0
  for _ in clean:gmatch("%.") do dotCount = dotCount + 1 end

  if hasShortSuffix and commaCount <= 1 and dotCount <= 1 then
    clean = clean:gsub(",", ".")
  elseif commaCount > 1 then
    clean = clean:gsub(",", "")
  elseif dotCount > 1 then
    clean = clean:gsub("%.", "")
  else
    clean = clean:gsub("%.", "")
    clean = clean:gsub(",", ".")
  end

  local value = tonumber(clean)

  if not value then return nil end

  return value * multiplier
end
local function parseExpGainText(text)
  if not text then return nil end

  local raw = tostring(text)
  local lower = raw:lower()

  if not lower:find("exp") then
    return nil
  end

  local amount = raw:match("%+%s*([%d%.,]+%s*[kK]*[kK]*)%s*[Ee][Xx][Pp]")

  if not amount and lower:find("gain") then
    amount = raw:match("([%d%.,]+%s*[kK]*[kK]*)%s*[Ee][Xx][Pp]")
  end

  if not amount then
    return nil
  end

  return parseNumber(amount .. " exp")
end

local function parsePercentToGoText(text)
  if not text then return nil end

  local lower = tostring(text):lower()
  local toGo = lower:match("(%d+)%s*percent%s*to%s*go") or lower:match("(%d+)%%%s*to%s*go")

  if not toGo then
    return nil
  end

  return clamp(100 - tonumber(toGo), 0, 100)
end

local function getExpLeftFromTexts(texts)
  for _, data in ipairs(texts or {}) do
    local text = tostring(data.text)
    local lower = text:lower()

    if lower:find("experience") and lower:find("left") then
      local amount = text:match("[Yy]ou%s+[Nn]eed%s+([%d%.,]+%s*[kK]*[kK]*)") or
        text:match("([%d%.,]+%s*[kK]*[kK]*)%s+of%s+[Ee]xperience%s+[Ll]eft")
      local value = amount and parseNumber(amount .. " experience") or nil

      if value and value > 0 then
        return value, "text"
      end
    end
  end

  return nil, "none"
end

local function addObservedExpGain(value, key)
  if not storage.expTrackerBot.enabled or not sessionStartTime then return 0 end

  value = tonumber(value)
  if not value or value <= 0 then return 0 end

  key = tostring(key or value)
  local lastSeen = recentExpGainTexts[key]

  if lastSeen and now - lastSeen < 1200 then
    return 0
  end

  recentExpGainTexts[key] = now
  sessionObservedExpGained = sessionObservedExpGained + value
  sessionLastGainTime = now
  return value
end

local function scanTextExpGains(texts)
  local added = 0

  for _, data in ipairs(texts or {}) do
    local value = parseExpGainText(data.text)
    if value then
      added = added + addObservedExpGain(value, tostring(data.text):lower())
    end
  end

  for key, seenAt in pairs(recentExpGainTexts) do
    if now - seenAt > 5000 then
      recentExpGainTexts[key] = nil
    end
  end

  return added
end

onTextMessage(function(mode, text)
  local value = parseExpGainText(text)
  if value then
    addObservedExpGain(value, tostring(text):lower())
  end
end)

local function parseLevelNumber(text)
  if not text then return nil end

  local raw = tostring(text):lower()
  raw = raw:gsub("%s", "")

  local clean = raw:match("level(%d+[,%d%.]*)") or raw:match("(%d+[,%d%.]*)")

  if not clean then return nil end

  clean = clean:gsub("%.", "")
  clean = clean:gsub(",", ".")

  return tonumber(clean)
end

local function getSkillValueByLabel(labelName, texts)
  texts = texts or getAllTexts()
  labelName = labelName:lower()

  for i, data in ipairs(texts) do
    local text = trim(data.text):lower()

    if text == labelName then
      for j = i + 1, math.min(i + 8, #texts) do
        local value = parseNumber(texts[j].text)

        if value and value >= 0 then
          return value
        end
      end
    end
  end

  for _, data in ipairs(texts) do
    local text = trim(data.text):lower()
    local skipText = labelName == "experience" and (text:find("left") or text:find("to go"))

    if text:find(labelName) and not skipText then
      local value = parseNumber(text)

      if value and value >= 0 then
        return value
      end
    end
  end

  return nil
end

local function getPlayer()
  if player then return player end

  if g_game and g_game.getLocalPlayer then
    return g_game.getLocalPlayer()
  end

  return nil
end

local function getCurrentExp(texts)
  local p = getPlayer()

  if p and p.getExperience then
    local ok, value = pcall(function()
      return p:getExperience()
    end)

    if ok and value and tonumber(value) and tonumber(value) > 0 then
      return tonumber(value), "player"
    end
  end

  if exp then
    local ok, value = pcall(function()
      return exp()
    end)

    if ok and value and tonumber(value) and tonumber(value) > 0 then
      return tonumber(value), "exp()"
    end
  end

  local skillExp = getSkillValueByLabel("experience", texts)

  if skillExp and skillExp > 0 then
    return skillExp, "skills"
  end

  return nil, "none"
end

local function getCurrentLevel(texts)
  -- Primeiro tenta texto visual com porcentagem, porque em OT custom costuma ser mais confi�vel.
  texts = texts or getAllTexts()

  for _, data in ipairs(texts) do
    local text = tostring(data.text)
    local lower = text:lower()

    if lower:find("level") then
      local lvl = text:match("[Ll]evel%s*(%d+[,%d%.]*)")

      if lvl then
        lvl = parseLevelNumber(lvl)

        if lvl then
          return lvl, "text"
        end
      end
    end
  end

  local skillLevel = getSkillValueByLabel("level", texts)

  if skillLevel and skillLevel > 0 then
    return skillLevel, "skills"
  end

  local p = getPlayer()

  if p and p.getLevel then
    local ok, value = pcall(function()
      return p:getLevel()
    end)

    if ok and value and tonumber(value) then
      return tonumber(value), "player"
    end
  end

  if lvl then
    local ok, value = pcall(function()
      return lvl()
    end)

    if ok and value and tonumber(value) then
      return tonumber(value), "lvl()"
    end
  end

  return nil, "none"
end

local function getCurrentLevelPercent(texts)
  texts = texts or getAllTexts()

  local p = getPlayer()

  if p and p.getLevelPercent then
    local ok, value = pcall(function()
      return p:getLevelPercent()
    end)

    if ok and value and tonumber(value) then
      return clamp(tonumber(value), 0, 100), "player"
    end
  end

  if levelpercent then
    local ok, value = pcall(function()
      return levelpercent()
    end)

    if ok and value and tonumber(value) then
      return clamp(tonumber(value), 0, 100), "levelpercent()"
    end
  end

  for _, data in ipairs(texts) do
    local text = tostring(data.text)

    if text:lower():find("level") then
      local percent = text:match("%((%d+)%%%)")

      if percent then
        return clamp(tonumber(percent), 0, 100), "text"
      end
    end
  end

  for _, data in ipairs(texts) do
    local percent = parsePercentToGoText(data.text)

    if percent then
      return percent, "text-to-go"
    end
  end

  return nil, "none"
end
local function expForLevel(level)
  level = math.floor(tonumber(level) or 0)

  if level <= 1 then
    return 0
  end

  return ((50 * level * level * level) - (150 * level * level) + (400 * level)) / 3
end
local function expAtLevelPercent(level, percent)
  if not level or not percent then return nil end

  local levelInt = math.floor(tonumber(level) or 0)
  local percentNumber = clamp(tonumber(percent) or 0, 0, 100)

  if levelInt <= 0 then return nil end

  local currentLevelExp = expForLevel(levelInt)
  local nextLevelExp = expForLevel(levelInt + 1)

  return currentLevelExp + ((nextLevelExp - currentLevelExp) * (percentNumber / 100))
end

local function formatExp(value)
  value = tonumber(value) or 0

  if value < 0 then value = 0 end

  if value >= 1000000000 then
    return string.format("%.2fb", value / 1000000000)
  elseif value >= 1000000 then
    return string.format("%.2fkk", value / 1000000)
  elseif value >= 1000 then
    return string.format("%.1fk", value / 1000)
  end

  return tostring(math.floor(value))
end

local function formatPercent(value)
  if not value then return "--" end
  return tostring(math.floor(value + 0.5)) .. "%"
end

local function formatTime(seconds)
  seconds = tonumber(seconds) or 0

  if seconds <= 0 then
    return "--"
  end

  local days = math.floor(seconds / 86400)
  seconds = seconds % 86400

  local hours = math.floor(seconds / 3600)
  seconds = seconds % 3600

  local minutes = math.floor(seconds / 60)
  local secs = math.floor(seconds % 60)

  if days > 0 then
    return days .. "d " .. hours .. "h"
  end

  if hours > 0 then
    return hours .. "h " .. minutes .. "m"
  end

  if minutes > 0 then
    return minutes .. "m " .. secs .. "s"
  end

  return secs .. "s"
end

local function getSessionSeconds()
  if not sessionStartTime then return 0 end
  local elapsedMs = (now or 0) - sessionStartTime
  if elapsedMs < 0 then elapsedMs = 0 end
  return elapsedMs / 1000
end

local function getRootSize(root)
  local width = 1000
  local height = 700

  pcall(function()
    if root and root.getWidth then
      width = root:getWidth()
    end
  end)

  pcall(function()
    if root and root.getHeight then
      height = root:getHeight()
    end
  end)

  return width, height
end

local function createOverlay()
  local root = g_ui.getRootWidget()

  if not root then return nil end

  if overlay then return overlay end

  overlay = setupUI([[
Label
  anchors.left: parent.left
  anchors.top: parent.top
  width: 300
  height: 90
  text-align: center
  color: yellow
  background: #000000cc
  font: verdana-11px-rounded
]], root)

  return overlay
end

local function hideOverlay()
  if overlay then
    overlay:hide()
  end
end

local function updateOverlay(text)
  if not storage.expTrackerBot.showOnScreen then
    hideOverlay()
    return
  end

  local root = g_ui.getRootWidget()
  local box = createOverlay()

  if not root or not box then return end

  local boxWidth = 300
  local boxHeight = 90

  local rootWidth, rootHeight = getRootSize(root)

  local xPercent = clamp(storage.expTrackerBot.posX, 0, 100)
  local yPercent = clamp(storage.expTrackerBot.posY, 0, 100)

  local left = math.floor((rootWidth - boxWidth) * (xPercent / 100))
  local top = math.floor((rootHeight - boxHeight) * (yPercent / 100))

  if left < 0 then left = 0 end
  if top < 0 then top = 0 end

  if left ~= lastOverlayLeft or top ~= lastOverlayTop then
    pcall(function()
      box:setMarginLeft(left)
      box:setMarginTop(top)
    end)
    lastOverlayLeft = left
    lastOverlayTop = top
  end

  if text ~= lastOverlayText then
    box:setText(text)
    lastOverlayText = text
  end

  box:show()
end

local function addDeltaExpGain(value)
  value = tonumber(value)
  if not value or value <= 0 or not sessionStartTime then return 0 end

  sessionObservedExpGained = sessionObservedExpGained + value
  sessionLastGainTime = now
  return value
end

local function calculateExpPerHour(gainedExp)
  gainedExp = tonumber(gainedExp)

  if not gainedExp or gainedExp < 0 or not sessionStartTime then
    return nil
  end

  if #expRateSamples == 0 then
    table.insert(expRateSamples, { time = sessionStartTime, gain = 0 })
  end

  local lastSample = expRateSamples[#expRateSamples]
  if not lastSample or now - lastSample.time >= 1000 or gainedExp ~= lastSample.gain then
    table.insert(expRateSamples, { time = now, gain = gainedExp })
  end

  local cutoff = now - expRateWindowMs

  while #expRateSamples > 2 and expRateSamples[2].time <= cutoff do
    table.remove(expRateSamples, 1)
  end

  while #expRateSamples > 1200 do
    table.remove(expRateSamples, 1)
  end

  local firstSample = expRateSamples[1]
  local last = expRateSamples[#expRateSamples]

  if not firstSample or not last then
    return nil
  end

  if firstSample.time < cutoff and #expRateSamples > 1 then
    local secondSample = expRateSamples[2]

    if secondSample and secondSample.time > firstSample.time and secondSample.gain >= firstSample.gain then
      local ratio = (cutoff - firstSample.time) / (secondSample.time - firstSample.time)
      firstSample = {
        time = cutoff,
        gain = firstSample.gain + ((secondSample.gain - firstSample.gain) * ratio)
      }
    end
  end

  local deltaGain = last.gain - firstSample.gain
  local deltaTime = last.time - firstSample.time

  if deltaGain < 0 then
    return nil
  end

  if deltaTime < 1000 then
    local elapsedMs = now - sessionStartTime

    if elapsedMs <= 0 then
      return 0
    end

    deltaGain = gainedExp
    deltaTime = elapsedMs
  end

  return deltaGain / (deltaTime / 3600000)
end

local function resetSession()
  local currentExp = getCurrentExp()
  local texts = getAllTexts()
  local currentLevel = getCurrentLevel(texts)
  local currentPercent = getCurrentLevelPercent(texts)

  sessionStartExp = currentExp
  sessionStartLevel = currentLevel
  sessionStartPercent = currentPercent
  sessionStartTime = now
  sessionLastExp = currentExp
  sessionLastPercentExp = expAtLevelPercent(currentLevel, currentPercent)
  sessionObservedExpGained = 0
  sessionLastGainTime = nil
  recentExpGainTexts = {}
  expRateSamples = {{ time = now, gain = 0 }}
  percentSamples = {}
  percentBaselineLevel = currentLevel
  percentBaselinePercent = currentPercent
  percentBaselineGain = 0
  lastSeenLevel = currentLevel
  levelChangedAt = nil

  setMainStatus("Status: sess�o resetada")
end

setupPanel.reset.onClick = function()
  resetSession()
end

mainPanel.resetMain.onClick = function()
  resetSession()
end

local function ensureSession()
  if sessionStartTime == nil then
    resetSession()
  end
end

local function addPercentSample(level, percent)
  if not percent then return end

  local levelKey = tonumber(level) or 0
  local percentValue = clamp(tonumber(percent), 0, 100)
  local lastSample = percentSamples[#percentSamples]

  if lastSample and lastSample.level == levelKey and percentValue < lastSample.percent then
    percentSamples = {}
  end

  table.insert(percentSamples, {
    time = now,
    level = levelKey,
    percent = percentValue
  })

  while #percentSamples > 120 do
    table.remove(percentSamples, 1)
  end
end
local function calculatePercentPerHour(currentLevel, currentPercent)
  if not currentPercent then
    return nil
  end

  if #percentSamples < 2 then
    return nil
  end

  local levelKey = tonumber(currentLevel) or 0
  local cutoff = now - 90000
  local first = nil
  local last = nil

  for i = 1, #percentSamples do
    local sample = percentSamples[i]

    if sample.level == levelKey and sample.time >= cutoff then
      if not first then first = sample end
      last = sample
    end
  end

  if not first or not last or first == last then
    for i = 1, #percentSamples do
      local sample = percentSamples[i]

      if sample.level == levelKey then
        if not first then first = sample end
        last = sample
      end
    end
  end

  if not first or not last or first == last then
    return nil
  end

  local deltaPercent = last.percent - first.percent
  local deltaTimeMs = last.time - first.time

  if deltaPercent <= 0 or deltaTimeMs < 5000 then
    return nil
  end

  local hours = deltaTimeMs / 3600000
  return deltaPercent / hours
end
local function updateLevelExpEstimate(level, percent, gainedExp)
  level = tonumber(level)
  percent = tonumber(percent)
  gainedExp = tonumber(gainedExp)

  if not level or not percent or not gainedExp then
    return
  end

  if lastSeenLevel and level > lastSeenLevel then
    levelChangedAt = now
    percentBaselineLevel = level
    percentBaselinePercent = percent
    percentBaselineGain = gainedExp
    lastSeenLevel = level
    return
  end

  if not percentBaselineLevel or percentBaselineLevel ~= level or percent < (percentBaselinePercent or 0) then
    percentBaselineLevel = level
    percentBaselinePercent = percent
    percentBaselineGain = gainedExp
    lastSeenLevel = level
    return
  end

  local deltaPercent = percent - (percentBaselinePercent or percent)
  local deltaGain = gainedExp - (percentBaselineGain or gainedExp)

  if deltaPercent >= 1 and deltaGain > 0 then
    local estimate = deltaGain * 100 / deltaPercent

    if estimate > 0 then
      if levelExpRequiredEstimate and levelEstimateLevel == level then
        levelExpRequiredEstimate = (levelExpRequiredEstimate * 0.7) + (estimate * 0.3)
      else
        levelExpRequiredEstimate = estimate
      end

      levelEstimateLevel = level
    end
  end

  lastSeenLevel = level
end

local function calculateCalibratedExpLeft(level, percent)
  level = tonumber(level)
  percent = tonumber(percent)

  if not level or not percent or not levelExpRequiredEstimate then
    return nil
  end

  if levelEstimateLevel and level < levelEstimateLevel then
    return nil
  end

  local missingPercent = 100 - clamp(percent, 0, 100)

  if missingPercent <= 0 then
    return 0
  end

  return levelExpRequiredEstimate * (missingPercent / 100)
end

local function applyExactExpLeftEstimate(level, percent, expLeft)
  level = tonumber(level)
  percent = tonumber(percent)
  expLeft = tonumber(expLeft)

  if not level or not percent or not expLeft or expLeft <= 0 then
    return
  end

  local missingPercent = 100 - clamp(percent, 0, 100)

  if missingPercent <= 0 then
    return
  end

  levelExpRequiredEstimate = expLeft * 100 / missingPercent
  levelEstimateLevel = level
end

local function calculateExpLeftByFormula(currentExp, currentLevel)
  if not currentExp or not currentLevel then
    return nil
  end

  local levelInt = math.floor(currentLevel)

  if levelInt <= 0 then
    return nil
  end

  local currentLevelExp = expForLevel(levelInt)
  local nextLevelExp = expForLevel(levelInt + 1)

  if currentExp >= currentLevelExp and currentExp < nextLevelExp then
    return nextLevelExp - currentExp
  end

  return nil
end

macro(500, function()
  if not storage.expTrackerBot.enabled then
    setMainStatus("Status: desligado")
    hideOverlay()
    return
  end

  local delayMs = clamp(storage.expTrackerBot.updateDelay, 500, 5000)

  if now - lastUpdate < delayMs then
    return
  end

  lastUpdate = now

  ensureSession()

  local currentExp, expSource = getCurrentExp()
  local texts = getAllTexts()
  local textGain = scanTextExpGains(texts)
  local currentLevel, levelSource = getCurrentLevel(texts)
  local currentPercent, percentSource = getCurrentLevelPercent(texts)
  local exactExpLeft, exactExpLeftSource = getExpLeftFromTexts(texts)

  if currentPercent then
    addPercentSample(currentLevel, currentPercent)
  end

  local expPerHour = nil
  local gainedExp = nil

  if sessionStartTime then
    local totalGain = nil

    if currentExp and sessionStartExp then
      if currentExp < sessionStartExp then
        resetSession()
        return
      end

      totalGain = currentExp - sessionStartExp

      if sessionLastExp and currentExp > sessionLastExp and textGain == 0 then
        addDeltaExpGain(currentExp - sessionLastExp)
      end

      sessionLastExp = currentExp
    end

    local measuredGain = math.max(totalGain or 0, sessionObservedExpGained or 0)
    gainedExp = measuredGain
    expPerHour = calculateExpPerHour(gainedExp)
  end

  local expLeft = exactExpLeft
  if not expLeft and not currentPercent then
    expLeft = calculateExpLeftByFormula(currentExp, currentLevel)
  end

  local percentPerHour = calculatePercentPerHour(currentLevel, currentPercent)
  local timeLeftText = "--"

  if currentPercent and percentPerHour and percentPerHour > 0 then
    local missingPercent = 100 - currentPercent

    if missingPercent > 0 then
      timeLeftText = formatTime((missingPercent / percentPerHour) * 3600)
    end
  elseif not exactExpLeft and expLeft and expPerHour and expPerHour > 0 then
    local timeLeftSeconds = (expLeft / expPerHour) * 3600

    if sessionLastGainTime then
      local secondsWithoutGain = (now - sessionLastGainTime) / 1000

      if timeLeftSeconds < 60 and secondsWithoutGain > timeLeftSeconds then
        timeLeftSeconds = secondsWithoutGain
      end
    end

    timeLeftText = formatTime(timeLeftSeconds)
  end

  local expHourText = expPerHour and formatExp(expPerHour) or "--"
  local gainedText = gainedExp and formatExp(gainedExp) or "--"
  local expLeftText = expLeft and formatExp(expLeft) or "--"
  local percentText = formatPercent(currentPercent)
  local sessionText = formatTime(getSessionSeconds())

  local statusText =
    "EXP/h " ..
    expHourText ..
    " | S " ..
    sessionText

  local overlayText =
    "EXP/h: " ..
    expHourText ..
    "\nSessao: " ..
    sessionText ..
    " | Ganho: " ..
    gainedText ..
    "\nFalta: " ..
    expLeftText ..
    " | Level: " ..
    percentText ..
    " | UP: " ..
    timeLeftText

  if not currentExp then
    statusText = "Sem EXP | abre Skills"
    overlayText =
      "EXP/h: --\n" ..
      "Sessao: " .. sessionText .. "\n" ..
      "Nao li Experience\n" ..
      "Abre Skills"
  elseif not currentPercent then
    overlayText =
      "EXP/h: " ..
      expHourText ..
      "\nSessao: " ..
      sessionText ..
      " | Ganho: " ..
      gainedText ..
      "\nUP: sem % do level"
  end

  setMainStatus(statusText)
  updateOverlay(overlayText)
end)