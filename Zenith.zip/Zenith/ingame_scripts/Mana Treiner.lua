-- Mana Treiner.lua


-- Mana Trainer OTClientV8 / vBot
-- Clica nos campos para abrir popup de edi��o
-- Casta a spell a cada 1 segundo se mana % >= porcentagem configurada

local panelName = "manaTrainerPopup"

if not storage[panelName] then
  storage[panelName] = {
    spell = "utevo lux",
    manaPercent = "90"
  }
end

local config = storage[panelName]

local ui = setupUI([[
Panel
  height: 92

  Label
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 2
    text-align: center
    text: Mana Trainer
    color: #ff7777
    font: verdana-11px-rounded

  Label
    id: spellLabel
    anchors.top: title.bottom
    anchors.left: parent.left
    margin-left: 4
    margin-top: 8
    text: Spell:
    font: verdana-11px-rounded

  BotTextEdit
    id: spell
    anchors.top: spellLabel.top
    anchors.left: spellLabel.right
    anchors.right: parent.right
    margin-left: 6
    margin-right: 4
    text: utevo lux

  Label
    id: manaLabel
    anchors.top: spell.bottom
    anchors.left: parent.left
    margin-left: 4
    margin-top: 8
    text: Mana %:
    font: verdana-11px-rounded

  BotTextEdit
    id: manaPercent
    anchors.top: manaLabel.top
    anchors.left: manaLabel.right
    margin-left: 6
    width: 45
    text: 90

  Label
    id: hint
    anchors.top: manaPercent.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 8
    text-align: center
    text: Clique no campo para editar
    color: #aaaaaa
    font: verdana-11px-rounded
]], parent)

ui.spell:setText(config.spell or "utevo lux")
ui.manaPercent:setText(tostring(config.manaPercent or "90"))

ui.spell.onTextChange = function(widget, text)
  config.spell = text
end

ui.manaPercent.onTextChange = function(widget, text)
  local value = tonumber(text)

  if not value then
    value = 90
  end

  if value < 1 then value = 1 end
  if value > 100 then value = 100 end

  config.manaPercent = tostring(value)
  widget:setText(config.manaPercent)
end

macro(1000, "Mana Trainer", function()
  if not g_game.isOnline() then
    return
  end

  local spell = config.spell or "utevo lux"
  local minManaPercent = tonumber(config.manaPercent) or 90

  if spell == "" then
    return
  end

  local currentManaPercent

  if manapercent then
    currentManaPercent = manapercent()
  else
    local player = g_game.getLocalPlayer()
    if not player then return end

    local mana = player:getMana()
    local maxMana = player:getMaxMana()

    if not mana or not maxMana or maxMana <= 0 then
      return
    end

    currentManaPercent = math.floor((mana / maxMana) * 100)
  end

  if currentManaPercent >= minManaPercent then
    say(spell)
  end
end)
