-- Auto Fishing.lua
-- OTClientV8 / vBot
-- Arraste a fishing rod no Setup.
-- Configure os IDs da �gua conforme o seu OT.
-- Default comum 8.6: 4597 at� 4620.

setDefaultTab("Tools")

UI.Separator()

if type(storage.autoFishingBot) ~= "table" then
  storage.autoFishingBot = {
    enabled = false,
    rodId = 0,
    waterIds = "4597,4598,4599,4600,4601,4602,4603,4604,4605,4606,4607,4608,4609,4610,4611,4612,4613,4614,4615,4616,4617,4618,4619,4620",
    wormId = 3976,
    requireWorm = false,
    randomTile = true,
    radius = 5,
    delay = 1200
  }
end

if storage.autoFishingBot.enabled == nil then storage.autoFishingBot.enabled = false end
if storage.autoFishingBot.rodId == nil then storage.autoFishingBot.rodId = 0 end
if storage.autoFishingBot.waterIds == nil then
  storage.autoFishingBot.waterIds = "4597,4598,4599,4600,4601,4602,4603,4604,4605,4606,4607,4608,4609,4610,4611,4612,4613,4614,4615,4616,4617,4618,4619,4620"
end
if storage.autoFishingBot.wormId == nil then storage.autoFishingBot.wormId = 3976 end
if storage.autoFishingBot.requireWorm == nil then storage.autoFishingBot.requireWorm = false end
if storage.autoFishingBot.randomTile == nil then storage.autoFishingBot.randomTile = true end
if storage.autoFishingBot.radius == nil then storage.autoFishingBot.radius = 5 end
if storage.autoFishingBot.delay == nil then storage.autoFishingBot.delay = 1200 end

local mainPanel = setupUI([[
Panel
  height: 22

  BotSwitch
    id: enabled
    anchors.top: parent.top
    anchors.left: parent.left
    width: 125
    height: 20
    text-align: center
    text: Auto Fishing

  Button
    id: setup
    anchors.top: parent.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Setup
]])

mainPanel.enabled:setOn(storage.autoFishingBot.enabled)

mainPanel.enabled.onClick = function(widget)
  storage.autoFishingBot.enabled = not storage.autoFishingBot.enabled
  widget:setOn(storage.autoFishingBot.enabled)
end

local setupPanel = setupUI([[
Panel
  height: 252

  Label
    id: rodLabel
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    height: 18
    text-align: center
    text: Arraste a fishing rod

  BotItem
    id: rodItem
    anchors.top: prev.bottom
    anchors.horizontalCenter: parent.horizontalCenter
    margin-top: 2
    size: 32 32
    tooltip: Arraste a vara de pesca aqui

  BotSwitch
    id: requireWorm
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 20
    text-align: center
    text: Exigir Worm

  BotSwitch
    id: randomTile
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 20
    text-align: center
    text: Randomizar Agua

  Label
    id: radiusLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Raio: 5 sqm

  HorizontalScrollBar
    id: radiusSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: delayLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Delay: 1200ms

  HorizontalScrollBar
    id: delaySlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: waterLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: IDs da Agua:

  BotTextEdit
    id: waterIds
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 22
    text: 4597,4598,4599

  Button
    id: fishNow
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 20
    text: Pescar Agora
]])

setupPanel:hide()

mainPanel.setup.onClick = function(widget)
  if setupPanel:isVisible() then
    setupPanel:hide()
    widget:setText("Setup")
  else
    setupPanel:show()
    widget:setText("Close")
  end
end

local function clamp(value, minValue, maxValue)
  value = tonumber(value) or minValue

  if value < minValue then return minValue end
  if value > maxValue then return maxValue end

  return value
end

setupPanel.rodItem:setItemId(tonumber(storage.autoFishingBot.rodId) or 0)

setupPanel.rodItem.onItemChange = function(widget)
  storage.autoFishingBot.rodId = widget:getItemId()
end

setupPanel.requireWorm:setOn(storage.autoFishingBot.requireWorm)

setupPanel.requireWorm.onClick = function(widget)
  storage.autoFishingBot.requireWorm = not storage.autoFishingBot.requireWorm
  widget:setOn(storage.autoFishingBot.requireWorm)
end

setupPanel.randomTile:setOn(storage.autoFishingBot.randomTile)

setupPanel.randomTile.onClick = function(widget)
  storage.autoFishingBot.randomTile = not storage.autoFishingBot.randomTile
  widget:setOn(storage.autoFishingBot.randomTile)
end

setupPanel.waterIds:setText(storage.autoFishingBot.waterIds or "")

setupPanel.waterIds.onTextChange = function(widget, text)
  storage.autoFishingBot.waterIds = text
end

local function updateRadiusLabel()
  storage.autoFishingBot.radius = clamp(storage.autoFishingBot.radius, 1, 10)
  setupPanel.radiusLabel:setText("Raio: " .. storage.autoFishingBot.radius .. " sqm")
end

pcall(function()
  setupPanel.radiusSlider:setMinimum(1)
  setupPanel.radiusSlider:setMaximum(10)
  setupPanel.radiusSlider:setValue(clamp(storage.autoFishingBot.radius, 1, 10))
end)

setupPanel.radiusSlider.onValueChange = function(widget, value)
  storage.autoFishingBot.radius = clamp(value, 1, 10)
  updateRadiusLabel()
end

updateRadiusLabel()

local function updateDelayLabel()
  storage.autoFishingBot.delay = clamp(storage.autoFishingBot.delay, 300, 5000)
  setupPanel.delayLabel:setText("Delay: " .. storage.autoFishingBot.delay .. "ms")
end

pcall(function()
  setupPanel.delaySlider:setMinimum(300)
  setupPanel.delaySlider:setMaximum(5000)
  setupPanel.delaySlider:setValue(clamp(storage.autoFishingBot.delay, 300, 5000))
end)

setupPanel.delaySlider.onValueChange = function(widget, value)
  storage.autoFishingBot.delay = clamp(value, 300, 5000)
  updateDelayLabel()
end

updateDelayLabel()

local lastFishAt = 0
local lastTileIndex = 1

local function parseIdList(text)
  local ids = {}
  text = tostring(text or "")

  for number in text:gmatch("%d+") do
    ids[tonumber(number)] = true
  end

  return ids
end

local function getLocalPlayer()
  if player then return player end

  if g_game and g_game.getLocalPlayer then
    return g_game.getLocalPlayer()
  end

  return nil
end

local function getPlayerPos()
  local p = getLocalPlayer()

  if p and p.getPosition then
    local ok, pos = pcall(function()
      return p:getPosition()
    end)

    if ok and pos then
      return pos
    end
  end

  return nil
end

local function getThingId(thing)
  if not thing then return 0 end

  if thing.getId then
    local ok, id = pcall(function()
      return thing:getId()
    end)

    if ok and id then
      return tonumber(id) or 0
    end
  end

  return 0
end

local function getTileUseThing(tile)
  if not tile then return nil end

  if tile.getTopUseThing then
    local ok, thing = pcall(function()
      return tile:getTopUseThing()
    end)

    if ok and thing then
      return thing
    end
  end

  if tile.getTopThing then
    local ok, thing = pcall(function()
      return tile:getTopThing()
    end)

    if ok and thing then
      return thing
    end
  end

  if tile.getGround then
    local ok, thing = pcall(function()
      return tile:getGround()
    end)

    if ok and thing then
      return thing
    end
  end

  return nil
end

local function isWaterTile(tile, waterIds)
  if not tile then return false end

  local thing = getTileUseThing(tile)
  local id = getThingId(thing)

  if id > 0 and waterIds[id] then
    return true
  end

  if tile.getGround then
    local ok, ground = pcall(function()
      return tile:getGround()
    end)

    if ok and ground then
      local groundId = getThingId(ground)

      if groundId > 0 and waterIds[groundId] then
        return true
      end
    end
  end

  return false
end

local function findRodItem()
  local rodId = tonumber(storage.autoFishingBot.rodId) or 0

  if rodId <= 0 then
    return nil, rodId
  end

  local item = findItem(rodId)

  return item, rodId
end

local function hasWorm()
  local wormId = tonumber(storage.autoFishingBot.wormId) or 3976

  if wormId <= 0 then
    return true
  end

  return findItem(wormId) ~= nil
end

local function getWaterTiles()
  local pos = getPlayerPos()
  local tiles = {}

  if not pos then
    return tiles
  end

  local waterIds = parseIdList(storage.autoFishingBot.waterIds)
  local radius = clamp(storage.autoFishingBot.radius, 1, 10)

  for dx = -radius, radius do
    for dy = -radius, radius do
      if not (dx == 0 and dy == 0) then
        local checkPos = {
          x = pos.x + dx,
          y = pos.y + dy,
          z = pos.z
        }

        local tile = g_map.getTile(checkPos)

        if tile and isWaterTile(tile, waterIds) then
          table.insert(tiles, {
            tile = tile,
            pos = checkPos,
            distance = math.max(math.abs(dx), math.abs(dy))
          })
        end
      end
    end
  end

  table.sort(tiles, function(a, b)
    return a.distance < b.distance
  end)

  return tiles
end

local function chooseWaterTile(tiles)
  if #tiles == 0 then
    return nil
  end

  if storage.autoFishingBot.randomTile then
    return tiles[math.random(1, #tiles)]
  end

  if lastTileIndex > #tiles then
    lastTileIndex = 1
  end

  local chosen = tiles[lastTileIndex]
  lastTileIndex = lastTileIndex + 1

  return chosen
end

local function useRodOnThing(rodItem, rodId, thing)
  if not thing then
    return false
  end

  if rodItem and useWith then
    local ok = pcall(function()
      useWith(rodItem, thing)
    end)

    if ok then return true end
  end

  if rodItem and g_game and g_game.useWith then
    local ok = pcall(function()
      g_game.useWith(rodItem, thing)
    end)

    if ok then return true end
  end

  if g_game and g_game.useInventoryItemWith then
    local ok = pcall(function()
      g_game.useInventoryItemWith(rodId, thing)
    end)

    if ok then return true end
  end

  return false
end

local function fishOnce()
  if not g_game.isOnline() then
    return false
  end

  local rodItem, rodId = findRodItem()

  if rodId <= 0 then
    return false
  end

  if not rodItem and not g_game.useInventoryItemWith then
    return false
  end

  if storage.autoFishingBot.requireWorm and not hasWorm() then
    return false
  end

  local tiles = getWaterTiles()

  if #tiles == 0 then
    return false
  end

  local chosen = chooseWaterTile(tiles)

  if not chosen or not chosen.tile then
    return false
  end

  local thing = getTileUseThing(chosen.tile)

  if not thing then
    return false
  end

  return useRodOnThing(rodItem, rodId, thing)
end

setupPanel.fishNow.onClick = function()
  fishOnce()
end

macro(100, function()
  if not storage.autoFishingBot.enabled then
    return
  end

  local delay = clamp(storage.autoFishingBot.delay, 300, 5000)

  if now - lastFishAt < delay then
    return
  end

  lastFishAt = now
  fishOnce()
end)