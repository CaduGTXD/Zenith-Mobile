-- Auto Werewolf Amulet
-- Remove o amuleto descarregado, encanta e equipa novamente.
-- IDs:
--   22060 = Werewolf Amulet descarregado
--   22061 = Werewolf Amulet encantado
--   22083 = Moonlight Crystal

local WEREWOLF_AMULET = 22060
local ENCHANTED_WEREWOLF_AMULET = 22061
local MOONLIGHT_CRYSTAL = 22083

local ACTION_DELAY = 650
local busyUntil = 0
local lastWarningAt = 0

local function warnOnce(message)
  if now - lastWarningAt < 5000 then
    return
  end

  lastWarningAt = now
  warn("[Werewolf Amulet] " .. message)
end

local function waitAction(extraDelay)
  busyUntil = now + ACTION_DELAY + (extraDelay or 0)
end

local function findItemInOpenContainers(itemId)
  for _, container in pairs(getContainers()) do
    for _, item in ipairs(container:getItems()) do
      if item:getId() == itemId then
        return item
      end
    end
  end

  return nil
end

local function findFreeContainerPosition()
  for _, container in pairs(getContainers()) do
    local items = container:getItems()
    local capacity = container:getCapacity()

    if #items < capacity then
      return container:getSlotPosition(#items)
    end
  end

  return nil
end

macro(200, "Auto Werewolf Amulet", function()
  if now < busyUntil then
    return
  end

  local neck = getNeck()

  -- J� est� encantado e equipado.
  if neck and neck:getId() == ENCHANTED_WEREWOLF_AMULET then
    return
  end

  -- O amuleto acabou: remove para uma backpack aberta.
  if neck and neck:getId() == WEREWOLF_AMULET then
    local destination = findFreeContainerPosition()

    if not destination then
      warnOnce("Nenhum espa�o livre nas backpacks abertas.")
      waitAction(1000)
      return
    end

    g_game.move(neck, destination, 1)
    waitAction()
    return
  end

  -- N�o substitui outro colar/amuleto que o jogador tenha equipado.
  if neck then
    return
  end

  -- Se j� foi encantado, equipa.
  local enchantedAmulet = findItemInOpenContainers(ENCHANTED_WEREWOLF_AMULET)
  if enchantedAmulet then
    moveToSlot(enchantedAmulet, SlotNeck)
    waitAction()
    return
  end

  -- Se est� descarregado na backpack, encanta.
  local plainAmulet = findItemInOpenContainers(WEREWOLF_AMULET)
  if not plainAmulet then
    return
  end

  local moonlight = findItemInOpenContainers(MOONLIGHT_CRYSTAL)
  if not moonlight then
    warnOnce("Moonlight Crystal n�o encontrado nas backpacks abertas.")
    waitAction(1000)
    return
  end

  useWith(moonlight, plainAmulet)
  waitAction(250)
end)
