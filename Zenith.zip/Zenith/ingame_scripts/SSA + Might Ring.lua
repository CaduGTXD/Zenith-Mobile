-- SSA + Might Ring Fast.lua
-- OTClientV8 / vBot
-- Equipa SSA + Might Ring no HP baixo.
-- Prioriza usar os itens da MAIN BP configurada.
-- Move o item equipado atual para a MAIN BP antes de equipar.
-- A MAIN BP configurada NAO minimiza.
-- Auto abre BPs internas com limite.
--
-- Main BP exemplo: Basic Paladin Backpack
-- IDs comuns:
-- SSA = 3081
-- Might Ring = 3048

setDefaultTab("Tools")

UI.Separator()

if type(storage.ssaMightBot) ~= "table" then
  storage.ssaMightBot = {
    enabled = false,

    hpEquip = 55,
    hpRemove = 85,

    useAmuletSlot = true,
    useRingSlot = true,
    equipDefaults = true,

    ssaId = 3081,
    mightId = 3048,

    defaultAmulet = 0,
    defaultRing = 0,

    autoOpenBps = true,
    minimizeSubBps = true,
    moveEquippedToMain = true,

    mainBpName = "Basic Paladin",
    mainBpFallbackIndex = 1,

    openDelay = 250,
    equipDelay = 100,
    moveDelay = 70
  }
end

local config = storage.ssaMightBot

if config.enabled == nil then config.enabled = false end
if config.hpEquip == nil then config.hpEquip = 55 end
if config.hpRemove == nil then config.hpRemove = 85 end

if config.useAmuletSlot == nil then
  if config.useSSA ~= nil then
    config.useAmuletSlot = config.useSSA
  else
    config.useAmuletSlot = true
  end
end

if config.useRingSlot == nil then
  if config.useMight ~= nil then
    config.useRingSlot = config.useMight
  else
    config.useRingSlot = true
  end
end

if config.equipDefaults == nil then config.equipDefaults = true end

if config.ssaId == nil then config.ssaId = 3081 end
if config.mightId == nil then config.mightId = 3048 end

if config.defaultAmulet == nil then config.defaultAmulet = 0 end
if config.defaultRing == nil then config.defaultRing = 0 end

if config.autoOpenBps == nil then config.autoOpenBps = true end
if config.minimizeSubBps == nil then config.minimizeSubBps = true end
if config.moveEquippedToMain == nil then config.moveEquippedToMain = true end

if config.mainBpName == nil then config.mainBpName = "Basic Paladin" end
if config.mainBpFallbackIndex == nil then config.mainBpFallbackIndex = 1 end

if config.openDelay == nil then config.openDelay = 250 end
if config.equipDelay == nil then config.equipDelay = 100 end
if config.moveDelay == nil then config.moveDelay = 70 end

local EMPTY_SLOT = 0

local SLOT_NECK = SlotNeck or SlotAmulet or SlotNecklace or 2
local SLOT_FINGER = SlotFinger or 9

local MAX_OPEN_PER_SCAN = 8
local RESCAN_DELAY = 30000

local mainPanel = setupUI([[
Panel
  height: 22

  BotSwitch
    id: enabled
    anchors.top: parent.top
    anchors.left: parent.left
    width: 125
    height: 20
    text-align: center
    text: SSA + Might

  Button
    id: setup
    anchors.top: parent.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Setup
]])

mainPanel.enabled:setOn(config.enabled)

mainPanel.enabled.onClick = function(widget)
  config.enabled = not config.enabled
  widget:setOn(config.enabled)
end

local setupPanel = setupUI([[
Panel
  height: 572

  Label
    id: hpEquipLabel
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    height: 18
    text-align: center
    text: Equipar HP <= 55%

  HorizontalScrollBar
    id: hpEquipSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: hpRemoveLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 18
    text-align: center
    text: Remover HP >= 85%

  HorizontalScrollBar
    id: hpRemoveSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  BotSwitch
    id: useAmuletSlot
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 20
    text-align: center
    text: Ativar Amulet

  BotSwitch
    id: useRingSlot
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 20
    text-align: center
    text: Ativar Ring

  BotSwitch
    id: equipDefaults
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 20
    text-align: center
    text: Voltar Itens Padrao

  BotSwitch
    id: moveEquippedToMain
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 20
    text-align: center
    text: Mover Equipado p/ Main BP

  BotSwitch
    id: autoOpenBps
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 20
    text-align: center
    text: Auto Abrir BPs

  BotSwitch
    id: minimizeSubBps
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 20
    text-align: center
    text: Minimizar BPs Internas

  Label
    id: mainBpNameLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Nome Main BP:

  BotTextEdit
    id: mainBpName
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 22
    text: Basic Paladin

  Label
    id: fallbackLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Fallback Index: 1

  HorizontalScrollBar
    id: fallbackSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: openDelayLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Delay abrir BP: 250ms

  HorizontalScrollBar
    id: openDelaySlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: equipDelayLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Delay equipar set: 100ms

  HorizontalScrollBar
    id: equipDelaySlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: moveDelayLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Delay apos mover: 70ms

  HorizontalScrollBar
    id: moveDelaySlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: dangerLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 18
    text-align: center
    text: Itens de emergencia

  BotItem
    id: ssaItem
    anchors.top: prev.bottom
    anchors.left: parent.left
    margin-left: 64
    margin-top: 2
    size: 32 32
    tooltip: Arraste a SSA aqui

  BotItem
    id: mightItem
    anchors.top: ssaItem.top
    anchors.left: ssaItem.right
    margin-left: 14
    size: 32 32
    tooltip: Arraste o Might Ring aqui

  Label
    id: defaultLabel
    anchors.top: ssaItem.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 18
    text-align: center
    text: Itens padrao

  BotItem
    id: defaultAmulet
    anchors.top: prev.bottom
    anchors.left: parent.left
    margin-left: 64
    margin-top: 2
    size: 32 32
    tooltip: Arraste o amuleto padrao aqui

  BotItem
    id: defaultRing
    anchors.top: defaultAmulet.top
    anchors.left: defaultAmulet.right
    margin-left: 14
    size: 32 32
    tooltip: Arraste o ring padrao aqui

  Button
    id: testDanger
    anchors.top: defaultAmulet.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 8
    height: 20
    text: Testar Emergencia

  Button
    id: testDefault
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 20
    text: Testar Padrao
]])

setupPanel:hide()

mainPanel.setup.onClick = function(widget)
  if setupPanel:isVisible() then
    setupPanel:hide()
    widget:setText("Setup")
  else
    setupPanel:show()
    widget:setText("Close")
  end
end

local function clamp(value, minValue, maxValue)
  value = tonumber(value) or minValue

  if value < minValue then return minValue end
  if value > maxValue then return maxValue end

  return value
end

local function lowerText(text)
  return tostring(text or ""):lower()
end

local function setupPercentSlider(slider, label, key, labelText)
  local value = clamp(config[key], 0, 100)
  config[key] = value

  pcall(function()
    slider:setMinimum(0)
    slider:setMaximum(100)
    slider:setValue(value)
  end)

  label:setText(labelText .. " " .. value .. "%")

  slider.onValueChange = function(widget, newValue)
    newValue = clamp(newValue, 0, 100)
    config[key] = newValue
    label:setText(labelText .. " " .. newValue .. "%")
  end
end

setupPercentSlider(setupPanel.hpEquipSlider, setupPanel.hpEquipLabel, "hpEquip", "Equipar HP <=")
setupPercentSlider(setupPanel.hpRemoveSlider, setupPanel.hpRemoveLabel, "hpRemove", "Remover HP >=")

setupPanel.useAmuletSlot:setOn(config.useAmuletSlot)
setupPanel.useAmuletSlot.onClick = function(widget)
  config.useAmuletSlot = not config.useAmuletSlot
  widget:setOn(config.useAmuletSlot)
end

setupPanel.useRingSlot:setOn(config.useRingSlot)
setupPanel.useRingSlot.onClick = function(widget)
  config.useRingSlot = not config.useRingSlot
  widget:setOn(config.useRingSlot)
end

setupPanel.equipDefaults:setOn(config.equipDefaults)
setupPanel.equipDefaults.onClick = function(widget)
  config.equipDefaults = not config.equipDefaults
  widget:setOn(config.equipDefaults)
end

setupPanel.moveEquippedToMain:setOn(config.moveEquippedToMain)
setupPanel.moveEquippedToMain.onClick = function(widget)
  config.moveEquippedToMain = not config.moveEquippedToMain
  widget:setOn(config.moveEquippedToMain)
end

setupPanel.autoOpenBps:setOn(config.autoOpenBps)
setupPanel.autoOpenBps.onClick = function(widget)
  config.autoOpenBps = not config.autoOpenBps
  widget:setOn(config.autoOpenBps)
end

setupPanel.minimizeSubBps:setOn(config.minimizeSubBps)
setupPanel.minimizeSubBps.onClick = function(widget)
  config.minimizeSubBps = not config.minimizeSubBps
  widget:setOn(config.minimizeSubBps)
end

setupPanel.mainBpName:setText(config.mainBpName or "Basic Paladin")
setupPanel.mainBpName.onTextChange = function(widget, text)
  config.mainBpName = text
end

local function updateFallbackLabel()
  config.mainBpFallbackIndex = clamp(config.mainBpFallbackIndex, 0, 15)
  setupPanel.fallbackLabel:setText("Fallback Index: " .. config.mainBpFallbackIndex)
end

pcall(function()
  setupPanel.fallbackSlider:setMinimum(0)
  setupPanel.fallbackSlider:setMaximum(15)
  setupPanel.fallbackSlider:setValue(clamp(config.mainBpFallbackIndex, 0, 15))
end)

setupPanel.fallbackSlider.onValueChange = function(widget, value)
  config.mainBpFallbackIndex = clamp(value, 0, 15)
  updateFallbackLabel()
end

updateFallbackLabel()

local function updateOpenDelayLabel()
  config.openDelay = clamp(config.openDelay, 100, 1500)
  setupPanel.openDelayLabel:setText("Delay abrir BP: " .. config.openDelay .. "ms")
end

pcall(function()
  setupPanel.openDelaySlider:setMinimum(100)
  setupPanel.openDelaySlider:setMaximum(1500)
  setupPanel.openDelaySlider:setValue(clamp(config.openDelay, 100, 1500))
end)

setupPanel.openDelaySlider.onValueChange = function(widget, value)
  config.openDelay = clamp(value, 100, 1500)
  updateOpenDelayLabel()
end

updateOpenDelayLabel()

local function updateEquipDelayLabel()
  config.equipDelay = clamp(config.equipDelay, 50, 500)
  setupPanel.equipDelayLabel:setText("Delay equipar set: " .. config.equipDelay .. "ms")
end

pcall(function()
  setupPanel.equipDelaySlider:setMinimum(50)
  setupPanel.equipDelaySlider:setMaximum(500)
  setupPanel.equipDelaySlider:setValue(clamp(config.equipDelay, 50, 500))
end)

setupPanel.equipDelaySlider.onValueChange = function(widget, value)
  config.equipDelay = clamp(value, 50, 500)
  updateEquipDelayLabel()
end

updateEquipDelayLabel()

local function updateMoveDelayLabel()
  config.moveDelay = clamp(config.moveDelay, 30, 300)
  setupPanel.moveDelayLabel:setText("Delay apos mover: " .. config.moveDelay .. "ms")
end

pcall(function()
  setupPanel.moveDelaySlider:setMinimum(30)
  setupPanel.moveDelaySlider:setMaximum(300)
  setupPanel.moveDelaySlider:setValue(clamp(config.moveDelay, 30, 300))
end)

setupPanel.moveDelaySlider.onValueChange = function(widget, value)
  config.moveDelay = clamp(value, 30, 300)
  updateMoveDelayLabel()
end

updateMoveDelayLabel()

setupPanel.ssaItem:setItemId(tonumber(config.ssaId) or 3081)
setupPanel.ssaItem.onItemChange = function(widget)
  config.ssaId = widget:getItemId()
end

setupPanel.mightItem:setItemId(tonumber(config.mightId) or 3048)
setupPanel.mightItem.onItemChange = function(widget)
  config.mightId = widget:getItemId()
end

setupPanel.defaultAmulet:setItemId(tonumber(config.defaultAmulet) or 0)
setupPanel.defaultAmulet.onItemChange = function(widget)
  config.defaultAmulet = widget:getItemId()
end

setupPanel.defaultRing:setItemId(tonumber(config.defaultRing) or 0)
setupPanel.defaultRing.onItemChange = function(widget)
  config.defaultRing = widget:getItemId()
end

local function getItemId(item)
  if item and item.getId then
    local ok, id = pcall(function()
      return item:getId()
    end)

    if ok and id then
      return tonumber(id) or 0
    end
  end

  return EMPTY_SLOT
end

local function getItemCount(item)
  if item and item.getCount then
    local ok, count = pcall(function()
      return item:getCount()
    end)

    if ok and count and count > 0 then
      return count
    end
  end

  return 1
end

local function getSlotItem(slot)
  if getSlot then
    local ok, item = pcall(function()
      return getSlot(slot)
    end)

    if ok then return item end
  end

  return nil
end

local function getNeckItem()
  if getNeck then
    local ok, item = pcall(function()
      return getNeck()
    end)

    if ok then return item end
  end

  return getSlotItem(SLOT_NECK)
end

local function getFingerItem()
  if getFinger then
    local ok, item = pcall(function()
      return getFinger()
    end)

    if ok then return item end
  end

  return getSlotItem(SLOT_FINGER)
end

local function getNeckId()
  return getItemId(getNeckItem())
end

local function getFingerId()
  return getItemId(getFingerItem())
end

local function getHpPercent()
  if hppercent then
    local ok, value = pcall(function()
      return hppercent()
    end)

    if ok and value then
      return clamp(value, 0, 100)
    end
  end

  local p = nil

  if player then
    p = player
  elseif g_game and g_game.getLocalPlayer then
    p = g_game.getLocalPlayer()
  end

  if p and p.getHealthPercent then
    local ok, value = pcall(function()
      return p:getHealthPercent()
    end)

    if ok and value then
      return clamp(value, 0, 100)
    end
  end

  return 100
end

-- CONTAINERS

local openedBpKeys = {}
local failedBpKeys = {}
local lastOpenAt = 0
local lastMinimizeAt = 0
local scanFinishedAt = 0
local openedThisScan = 0

local function getContainersList()
  if getContainers then
    local ok, containers = pcall(function()
      return getContainers()
    end)

    if ok and containers then return containers end
  end

  if modules and modules.game_containers and modules.game_containers.getContainers then
    local ok, containers = pcall(function()
      return modules.game_containers.getContainers()
    end)

    if ok and containers then return containers end
  end

  return {}
end

local function getContainerIndex(container)
  if not container then return nil end

  if container.getIndex then
    local ok, index = pcall(function()
      return container:getIndex()
    end)

    if ok and index ~= nil then return tonumber(index) end
  end

  if container.getId then
    local ok, id = pcall(function()
      return container:getId()
    end)

    if ok and id ~= nil then return tonumber(id) end
  end

  return nil
end

local function getContainerKey(container)
  local index = getContainerIndex(container)

  if index ~= nil then
    return tostring(index)
  end

  return tostring(container)
end

local function containerGetItems(container)
  if not container then return {} end

  if container.getItems then
    local ok, items = pcall(function()
      return container:getItems()
    end)

    if ok and items then return items end
  end

  return {}
end

local function getContainerCapacity(container)
  if not container then return 0 end

  if container.getCapacity then
    local ok, capacity = pcall(function()
      return container:getCapacity()
    end)

    if ok and capacity then return tonumber(capacity) or 0 end
  end

  if container.getSize then
    local ok, size = pcall(function()
      return container:getSize()
    end)

    if ok and size then return tonumber(size) or 0 end
  end

  return 20
end

local function getWidgetText(widget)
  if not widget then return "" end

  if widget.getText then
    local ok, text = pcall(function()
      return widget:getText()
    end)

    if ok and text then
      return tostring(text)
    end
  end

  return ""
end

local function getItemName(item)
  if not item then return "" end

  if item.getName then
    local ok, name = pcall(function()
      return item:getName()
    end)

    if ok and name then
      return tostring(name)
    end
  end

  return ""
end

local function getContainerName(container)
  if not container then return "" end

  local candidates = {}

  if container.getName then
    local ok, name = pcall(function()
      return container:getName()
    end)

    if ok and name then
      table.insert(candidates, tostring(name))
    end
  end

  if container.getText then
    local ok, text = pcall(function()
      return container:getText()
    end)

    if ok and text then
      table.insert(candidates, tostring(text))
    end
  end

  if container.window then
    table.insert(candidates, getWidgetText(container.window))
  end

  pcall(function()
    local parentWidget = container:getParent()
    if parentWidget then
      table.insert(candidates, getWidgetText(parentWidget))
    end
  end)

  if container.getContainerItem then
    local ok, item = pcall(function()
      return container:getContainerItem()
    end)

    if ok and item then
      table.insert(candidates, getItemName(item))
    end
  end

  for _, text in ipairs(candidates) do
    if tostring(text or "") ~= "" then
      return tostring(text)
    end
  end

  return ""
end

local function getMainContainer()
  local containers = getContainersList()
  local wanted = lowerText(config.mainBpName or "")

  if wanted ~= "" then
    for _, container in pairs(containers) do
      local name = lowerText(getContainerName(container))

      if name ~= "" and name:find(wanted, 1, true) then
        return container
      end
    end
  end

  local fallbackIndex = tonumber(config.mainBpFallbackIndex)

  if fallbackIndex ~= nil then
    for _, container in pairs(containers) do
      local index = getContainerIndex(container)

      if index ~= nil and index == fallbackIndex then
        return container
      end
    end
  end

  for _, container in pairs(containers) do
    local name = lowerText(getContainerName(container))

    if name ~= "main" then
      return container
    end
  end

  for _, container in pairs(containers) do
    return container
  end

  return nil
end

local function getMainContainerKey()
  local mainContainer = getMainContainer()

  if not mainContainer then
    return nil
  end

  return getContainerKey(mainContainer)
end

local function getFreeContainerPosition(container)
  if not container then return nil end

  local items = containerGetItems(container)
  local count = #items
  local capacity = getContainerCapacity(container)

  if capacity > 0 and count >= capacity then
    return nil
  end

  if container.getSlotPosition then
    local ok, pos = pcall(function()
      return container:getSlotPosition(count)
    end)

    if ok and pos then
      return pos
    end
  end

  local index = getContainerIndex(container)

  if index ~= nil then
    return {
      x = 65535,
      y = index,
      z = count
    }
  end

  return nil
end

local function moveItemToMainContainer(item)
  if not item then return false end

  local mainContainer = getMainContainer()

  if not mainContainer then
    return false
  end

  local dest = getFreeContainerPosition(mainContainer)

  if not dest then
    return false
  end

  if g_game and g_game.move then
    local ok = pcall(function()
      g_game.move(item, dest, 1)
    end)

    if ok then
      return true
    end

    ok = pcall(function()
      g_game.move(item, dest, getItemCount(item))
    end)

    if ok then
      return true
    end
  end

  return false
end

local function findItemInContainer(container, itemId)
  if not container then return nil end

  itemId = tonumber(itemId) or 0
  if itemId <= 0 then return nil end

  local items = containerGetItems(container)

  for _, item in ipairs(items) do
    if getItemId(item) == itemId then
      return item
    end
  end

  return nil
end

local function findItemFast(itemId)
  itemId = tonumber(itemId) or 0

  if itemId <= 0 then return nil end

  -- Prioridade m�xima: pegar da Main BP.
  -- Isso evita puxar SSA/Might das BPs internas e ficar lotando a Main.
  local mainContainer = getMainContainer()
  local itemInMain = findItemInContainer(mainContainer, itemId)

  if itemInMain then
    return itemInMain
  end

  -- Fallback: se n�o tiver na Main, pega de qualquer BP aberta.
  local item = findItem(itemId)

  if item then
    return item
  end

  return nil
end

-- EQUIP

local pendingEquip = {}

local function rawMoveItemToSlot(item, slot)
  if not item then return false end

  if moveToSlot then
    local ok = pcall(function()
      moveToSlot(item, slot)
    end)

    if ok then return true end
  end

  if g_game and g_game.move then
    local ok = pcall(function()
      g_game.move(item, {x = 65535, y = slot, z = 0}, 1)
    end)

    if ok then return true end

    ok = pcall(function()
      g_game.move(item, {x = 65535, y = slot, z = 0}, getItemCount(item))
    end)

    if ok then return true end
  end

  return false
end

local function rawEquipItemById(itemId, slot)
  local item = findItemFast(itemId)

  if not item then
    return false
  end

  return rawMoveItemToSlot(item, slot)
end

local function getEquippedIdBySlot(slot)
  if slot == SLOT_NECK then
    return getNeckId()
  end

  if slot == SLOT_FINGER then
    return getFingerId()
  end

  return getItemId(getSlotItem(slot))
end

local function getEquippedItemBySlot(slot)
  if slot == SLOT_NECK then
    return getNeckItem()
  end

  if slot == SLOT_FINGER then
    return getFingerItem()
  end

  return getSlotItem(slot)
end

local function equipItemById(itemId, slot)
  itemId = tonumber(itemId) or 0

  if itemId <= 0 then
    return false
  end

  if getEquippedIdBySlot(slot) == itemId then
    return true
  end

  if pendingEquip[slot] and now < pendingEquip[slot] then
    return false
  end

  local equippedItem = getEquippedItemBySlot(slot)
  local equippedId = getItemId(equippedItem)

  -- Antes de equipar, move o item atual para a Main BP correta.
  if config.moveEquippedToMain and equippedId > 0 and equippedId ~= itemId then
    local moved = moveItemToMainContainer(equippedItem)

    if moved then
      local delay = clamp(config.moveDelay, 30, 300)
      pendingEquip[slot] = now + delay + 80

      schedule(delay, function()
        rawEquipItemById(itemId, slot)
      end)

      return true
    end
  end

  pendingEquip[slot] = now + 150
  return rawEquipItemById(itemId, slot)
end

local function equipSSA()
  if not config.useAmuletSlot then return false end

  local ssaId = tonumber(config.ssaId) or 0
  if ssaId <= 0 then return false end

  return equipItemById(ssaId, SLOT_NECK)
end

local function equipMight()
  if not config.useRingSlot then return false end

  local mightId = tonumber(config.mightId) or 0
  if mightId <= 0 then return false end

  return equipItemById(mightId, SLOT_FINGER)
end

local function equipDefaultAmulet()
  if not config.useAmuletSlot then return false end
  if not config.equipDefaults then return false end

  local defaultId = tonumber(config.defaultAmulet) or 0
  if defaultId <= 0 then return false end

  return equipItemById(defaultId, SLOT_NECK)
end

local function equipDefaultRing()
  if not config.useRingSlot then return false end
  if not config.equipDefaults then return false end

  local defaultId = tonumber(config.defaultRing) or 0
  if defaultId <= 0 then return false end

  return equipItemById(defaultId, SLOT_FINGER)
end

local function isDangerItemEquipped()
  local neckId = getNeckId()
  local fingerId = getFingerId()

  local ssaId = tonumber(config.ssaId) or 0
  local mightId = tonumber(config.mightId) or 0

  local amuletDanger = config.useAmuletSlot and neckId == ssaId
  local ringDanger = config.useRingSlot and fingerId == mightId

  return amuletDanger or ringDanger
end

local function equipDangerSet()
  if config.useAmuletSlot then
    equipSSA()
  end

  if config.useRingSlot then
    schedule(clamp(config.equipDelay, 50, 500), function()
      if config.enabled then
        equipMight()
      end
    end)
  end
end

local function equipDefaultSet()
  if config.useAmuletSlot then
    equipDefaultAmulet()
  end

  if config.useRingSlot then
    schedule(clamp(config.equipDelay, 50, 500), function()
      if config.enabled then
        equipDefaultRing()
      end
    end)
  end
end

setupPanel.testDanger.onClick = function()
  equipDangerSet()
end

setupPanel.testDefault.onClick = function()
  equipDefaultSet()
end

-- AUTO OPEN BPS SEM LOOP

local function itemIsContainer(item)
  if not item then return false end

  if item.isContainer then
    local ok, result = pcall(function()
      return item:isContainer()
    end)

    if ok then return result == true end
  end

  return false
end

local function getItemPositionKey(item)
  if not item then return "nopos" end

  if item.getPosition then
    local ok, pos = pcall(function()
      return item:getPosition()
    end)

    if ok and pos then
      return tostring(pos.x) .. ":" .. tostring(pos.y) .. ":" .. tostring(pos.z)
    end
  end

  return "nopos"
end

local function getStableBpKey(parentContainer, item, index)
  local parentKey = getContainerKey(parentContainer)
  local itemId = getItemId(item)
  local posKey = getItemPositionKey(item)

  return "parent=" .. parentKey .. "|slot=" .. tostring(index or "?") .. "|id=" .. tostring(itemId) .. "|pos=" .. posKey
end

local function tryMinimizeContainer(container, mainKey)
  if not container then return end
  if not config.minimizeSubBps then return end

  local key = getContainerKey(container)

  -- Nunca minimiza a Main BP configurada.
  if mainKey and key == mainKey then
    return
  end

  pcall(function()
    if container.window and container.window.minimize then
      container.window:minimize()
    end
  end)

  pcall(function()
    if container.minimize then
      container:minimize()
    end
  end)

  pcall(function()
    local parentWidget = container:getParent()
    if parentWidget and parentWidget.minimize then
      parentWidget:minimize()
    end
  end)
end

local function minimizeSubContainers()
  if now - lastMinimizeAt < 1000 then
    return
  end

  lastMinimizeAt = now

  local mainKey = getMainContainerKey()

  for _, container in pairs(getContainersList()) do
    tryMinimizeContainer(container, mainKey)
  end
end

local function openContainerItem(item, parentContainer)
  if not item then return false end

  if g_game and g_game.open then
    local ok = pcall(function()
      g_game.open(item, parentContainer)
    end)

    if ok then return true end

    ok = pcall(function()
      g_game.open(item)
    end)

    if ok then return true end
  end

  if use then
    local ok = pcall(function()
      use(item)
    end)

    if ok then return true end
  end

  if g_game and g_game.use then
    local ok = pcall(function()
      g_game.use(item)
    end)

    if ok then return true end
  end

  return false
end

local function missingNeededItems()
  local mainContainer = getMainContainer()

  if config.useAmuletSlot then
    local ssaId = tonumber(config.ssaId) or 0

    if ssaId > 0 then
      local hasInMain = findItemInContainer(mainContainer, ssaId) ~= nil
      local hasAnywhere = findItem(ssaId) ~= nil
      local equipped = getNeckId() == ssaId

      if not equipped and not hasInMain and not hasAnywhere then
        return true
      end
    end
  end

  if config.useRingSlot then
    local mightId = tonumber(config.mightId) or 0

    if mightId > 0 then
      local hasInMain = findItemInContainer(mainContainer, mightId) ~= nil
      local hasAnywhere = findItem(mightId) ~= nil
      local equipped = getFingerId() == mightId

      if not equipped and not hasInMain and not hasAnywhere then
        return true
      end
    end
  end

  return false
end

local function scanOpenBps()
  if not config.enabled then return end
  if not config.autoOpenBps then return end
  if not g_game.isOnline() then return end

  -- Se j� achou SSA/Might, n�o abre mais nada.
  if not missingNeededItems() then
    minimizeSubContainers()
    openedThisScan = 0
    scanFinishedAt = 0
    return
  end

  -- Se j� tentou abrir v�rias BPs e n�o achou, d� pausa.
  if openedThisScan >= MAX_OPEN_PER_SCAN then
    if scanFinishedAt == 0 then
      scanFinishedAt = now
    end

    if now - scanFinishedAt < RESCAN_DELAY then
      return
    end

    scanFinishedAt = 0
    openedThisScan = 0
    openedBpKeys = {}
    failedBpKeys = {}
  end

  local delay = clamp(config.openDelay, 100, 1500)

  if now - lastOpenAt < delay then
    return
  end

  lastOpenAt = now

  for _, container in pairs(getContainersList()) do
    local items = containerGetItems(container)

    for index, item in ipairs(items) do
      if itemIsContainer(item) then
        local key = getStableBpKey(container, item, index)

        if not openedBpKeys[key] and not failedBpKeys[key] then
          openedBpKeys[key] = now
          openedThisScan = openedThisScan + 1

          local opened = openContainerItem(item, container)

          if not opened then
            failedBpKeys[key] = now
          else
            schedule(250, function()
              minimizeSubContainers()
            end)
          end

          return
        end
      end
    end
  end

  scanFinishedAt = now
  minimizeSubContainers()
end

macro(100, function()
  scanOpenBps()
end)

macro(50, function()
  if not config.enabled then
    return
  end

  if not g_game.isOnline() then
    return
  end

  local hp = getHpPercent()
  local hpEquip = clamp(config.hpEquip, 0, 100)
  local hpRemove = clamp(config.hpRemove, 0, 100)

  if hp <= hpEquip then
    equipDangerSet()
    return
  end

  if hp >= hpRemove then
    if isDangerItemEquipped() then
      equipDefaultSet()
      return
    end
  end

  if hp > hpEquip and config.equipDefaults then
    if config.useAmuletSlot and getNeckId() == EMPTY_SLOT then
      equipDefaultAmulet()
    end

    if config.useRingSlot and getFingerId() == EMPTY_SLOT then
      equipDefaultRing()
    end
  end
end)