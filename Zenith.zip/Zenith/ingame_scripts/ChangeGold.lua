-- ChangeGold.lua

-- Change Gold - Use With.lua
-- OTClientV8 / vBot
--
-- Neste OT, para transformar a moeda � necess�rio:
-- usar a moeda nela mesma.
--
-- Exemplo:
-- Gold Coin -> useWith(goldCoin, goldCoin)
--
-- Procura as moedas em todas as backpacks abertas.
-- Faz apenas uma transforma��o por vez para evitar exhaust.

setDefaultTab("Tools")

UI.Separator()

if type(storage.changeGoldUseWith) ~= "table" then
  storage.changeGoldUseWith = {
    enabled = false,

    -- IDs comuns do Tibia 8.6
    coin1 = 2148, -- Gold Coin
    coin2 = 2152, -- Platinum Coin
    coin3 = 0,    -- Opcional

    minCount = 100,
    delay = 500
  }
end

local config = storage.changeGoldUseWith

if config.enabled == nil then config.enabled = false end
if config.coin1 == nil then config.coin1 = 2148 end
if config.coin2 == nil then config.coin2 = 2152 end
if config.coin3 == nil then config.coin3 = 0 end
if config.minCount == nil then config.minCount = 100 end
if config.delay == nil then config.delay = 500 end

local mainPanel = setupUI([[
Panel
  height: 22

  BotSwitch
    id: enabled
    anchors.top: parent.top
    anchors.left: parent.left
    width: 125
    height: 20
    text-align: center
    text: Change Gold

  Button
    id: setup
    anchors.top: parent.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Setup
]])

mainPanel.enabled:setOn(config.enabled)

mainPanel.enabled.onClick = function(widget)
  config.enabled = not config.enabled
  widget:setOn(config.enabled)
end

local setupPanel = setupUI([[
Panel
  height: 192

  Label
    id: coinsLabel
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    height: 18
    text-align: center
    text: Moedas para transformar

  BotItem
    id: coin1
    anchors.top: prev.bottom
    anchors.left: parent.left
    margin-left: 45
    margin-top: 3
    size: 32 32
    tooltip: Arraste a primeira moeda aqui

  BotItem
    id: coin2
    anchors.top: coin1.top
    anchors.left: coin1.right
    margin-left: 12
    size: 32 32
    tooltip: Arraste a segunda moeda aqui

  BotItem
    id: coin3
    anchors.top: coin1.top
    anchors.left: coin2.right
    margin-left: 12
    size: 32 32
    tooltip: Arraste uma terceira moeda opcional

  Label
    id: minCountLabel
    anchors.top: coin1.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 7
    height: 18
    text-align: center
    text: Quantidade minima: 100

  HorizontalScrollBar
    id: minCountSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: delayLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 18
    text-align: center
    text: Delay: 500ms

  HorizontalScrollBar
    id: delaySlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Button
    id: changeNow
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 8
    height: 20
    text: Transformar Agora
]])

setupPanel:hide()

mainPanel.setup.onClick = function(widget)
  if setupPanel:isVisible() then
    setupPanel:hide()
    widget:setText("Setup")
  else
    setupPanel:show()
    widget:setText("Close")
  end
end

local function clamp(value, minValue, maxValue)
  value = tonumber(value) or minValue

  if value < minValue then
    return minValue
  end

  if value > maxValue then
    return maxValue
  end

  return value
end

-- Itens configur�veis

setupPanel.coin1:setItemId(tonumber(config.coin1) or 2148)

setupPanel.coin1.onItemChange = function(widget)
  config.coin1 = widget:getItemId()
end

setupPanel.coin2:setItemId(tonumber(config.coin2) or 2152)

setupPanel.coin2.onItemChange = function(widget)
  config.coin2 = widget:getItemId()
end

setupPanel.coin3:setItemId(tonumber(config.coin3) or 0)

setupPanel.coin3.onItemChange = function(widget)
  config.coin3 = widget:getItemId()
end

-- Quantidade m�nima

local function updateMinCountLabel()
  config.minCount = clamp(config.minCount, 1, 100)

  setupPanel.minCountLabel:setText(
    "Quantidade minima: " .. config.minCount
  )
end

pcall(function()
  setupPanel.minCountSlider:setMinimum(1)
  setupPanel.minCountSlider:setMaximum(100)
  setupPanel.minCountSlider:setValue(
    clamp(config.minCount, 1, 100)
  )
end)

setupPanel.minCountSlider.onValueChange = function(widget, value)
  config.minCount = clamp(value, 1, 100)
  updateMinCountLabel()
end

updateMinCountLabel()

-- Delay

local function updateDelayLabel()
  config.delay = clamp(config.delay, 100, 3000)

  setupPanel.delayLabel:setText(
    "Delay: " .. config.delay .. "ms"
  )
end

pcall(function()
  setupPanel.delaySlider:setMinimum(100)
  setupPanel.delaySlider:setMaximum(3000)
  setupPanel.delaySlider:setValue(
    clamp(config.delay, 100, 3000)
  )
end)

setupPanel.delaySlider.onValueChange = function(widget, value)
  config.delay = clamp(value, 100, 3000)
  updateDelayLabel()
end

updateDelayLabel()

local function getItemId(item)
  if not item or not item.getId then
    return 0
  end

  local ok, id = pcall(function()
    return item:getId()
  end)

  if ok and id then
    return tonumber(id) or 0
  end

  return 0
end

local function getItemCount(item)
  if not item then
    return 0
  end

  if item.getCount then
    local ok, count = pcall(function()
      return item:getCount()
    end)

    if ok and count then
      return tonumber(count) or 0
    end
  end

  if item.getSubType then
    local ok, count = pcall(function()
      return item:getSubType()
    end)

    if ok and count then
      return tonumber(count) or 0
    end
  end

  return 1
end

local function getContainersList()
  if getContainers then
    local ok, containers = pcall(function()
      return getContainers()
    end)

    if ok and containers then
      return containers
    end
  end

  if modules
    and modules.game_containers
    and modules.game_containers.getContainers then

    local ok, containers = pcall(function()
      return modules.game_containers.getContainers()
    end)

    if ok and containers then
      return containers
    end
  end

  return {}
end

local function getContainerItems(container)
  if not container or not container.getItems then
    return {}
  end

  local ok, items = pcall(function()
    return container:getItems()
  end)

  if ok and items then
    return items
  end

  return {}
end

local function getConfiguredCoinIds()
  local ids = {}

  local coin1 = tonumber(config.coin1) or 0
  local coin2 = tonumber(config.coin2) or 0
  local coin3 = tonumber(config.coin3) or 0

  if coin1 > 0 then
    ids[coin1] = 1
  end

  if coin2 > 0 then
    ids[coin2] = 2
  end

  if coin3 > 0 then
    ids[coin3] = 3
  end

  return ids
end

local function findCoinStack()
  local coinIds = getConfiguredCoinIds()
  local minCount = clamp(config.minCount, 1, 100)

  local candidates = {}

  for _, container in pairs(getContainersList()) do
    for _, item in ipairs(getContainerItems(container)) do
      local itemId = getItemId(item)
      local priority = coinIds[itemId]

      if priority then
        local count = getItemCount(item)

        if count >= minCount then
          table.insert(candidates, {
            item = item,
            id = itemId,
            count = count,
            priority = priority
          })
        end
      end
    end
  end

  if #candidates == 0 then
    return nil
  end

  -- Prioriza a moeda mais alta configurada.
  -- Exemplo: primeiro Platinum e depois Gold.
  table.sort(candidates, function(a, b)
    if a.priority ~= b.priority then
      return a.priority > b.priority
    end

    return a.count > b.count
  end)

  return candidates[1].item
end

local function useCoinOnItself(item)
  if not item then
    return false
  end

  -- M�todo padr�o do vBot.
  if useWith then
    local ok = pcall(function()
      useWith(item, item)
    end)

    if ok then
      return true
    end
  end

  -- M�todo direto do OTClient.
  if g_game and g_game.useWith then
    local ok = pcall(function()
      g_game.useWith(item, item)
    end)

    if ok then
      return true
    end
  end

  -- Fallback usando o ID do item.
  if g_game and g_game.useInventoryItemWith then
    local itemId = getItemId(item)

    if itemId > 0 then
      local ok = pcall(function()
        g_game.useInventoryItemWith(itemId, item)
      end)

      if ok then
        return true
      end
    end
  end

  return false
end

local function changeGoldOnce()
  if not g_game.isOnline() then
    return false
  end

  local coin = findCoinStack()

  if not coin then
    return false
  end

  return useCoinOnItself(coin)
end

setupPanel.changeNow.onClick = function()
  changeGoldOnce()
end

local lastChangeAt = 0

macro(50, function()
  if not config.enabled then
    return
  end

  if not g_game.isOnline() then
    return
  end

  local delay = clamp(config.delay, 100, 3000)

  if now - lastChangeAt < delay then
    return
  end

  local changed = changeGoldOnce()

  if changed then
    lastChangeAt = now
  else
    -- Evita ficar escaneando todas as BPs a cada 50ms
    -- quando n�o h� pilha suficiente.
    lastChangeAt = now - delay + 250
  end
end)