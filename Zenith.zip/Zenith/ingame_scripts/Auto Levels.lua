-- Auto Levels.lua


setDefaultTab("Tools")

UI.Separator()
UI.Label("Auto Vale Levels")

if type(storage.autoValeLevels) ~= "table" then
  storage.autoValeLevels = {
    enabled = false,
    useWith = false,
    valeItems = {},
    delay = 1500,
    usedForReset = -1,
    lastResets = 0,
    lastSkillLevel = 0
  }
end

if type(storage.autoValeLevels.valeItems) ~= "table" then
  storage.autoValeLevels.valeItems = {}
end

if storage.autoValeLevels.useWith == nil then
  storage.autoValeLevels.useWith = false
end

local statusLabel = UI.Label("Status: parado")

local valeSwitch = addSwitch("autoValeLevelsSwitch", "Auto Vale Levels", function(widget)
  storage.autoValeLevels.enabled = not storage.autoValeLevels.enabled
  widget:setOn(storage.autoValeLevels.enabled)
end)

valeSwitch:setOn(storage.autoValeLevels.enabled)

local useWithSwitch = addSwitch("autoValeUseWithSwitch", "Use With Player", function(widget)
  storage.autoValeLevels.useWith = not storage.autoValeLevels.useWith
  widget:setOn(storage.autoValeLevels.useWith)
end)

useWithSwitch:setOn(storage.autoValeLevels.useWith)

UI.Label("Arraste o Vale Levels:")

local valeContainer = UI.Container(function(widget, items)
  storage.autoValeLevels.valeItems = items
end, true)

valeContainer:setHeight(35)
valeContainer:setItems(storage.autoValeLevels.valeItems)

UI.Label("Delay ms:")
UI.TextEdit(tostring(storage.autoValeLevels.delay), function(widget, text)
  local value = tonumber(text)
  if value then
    storage.autoValeLevels.delay = value
  end
end)

local lastAction = 0

local function trim(text)
  if not text then return "" end
  return text:match("^%s*(.-)%s*$") or ""
end

local function parseSkillNumber(text)
  if not text then return nil end

  local clean = tostring(text)
  clean = clean:gsub("%s", "")
  clean = clean:match("(%d+[,%d%.]*)")

  if not clean then return nil end

  -- Exemplo:
  -- "128,138" -> 128.138
  -- "141,001" -> 141.001
  clean = clean:gsub("%.", "")
  clean = clean:gsub(",", ".")

  return tonumber(clean)
end

local function formatLevel(value)
  if not value then return "0,000" end
  return string.format("%.3f", value):gsub("%.", ",")
end

local function safeGetText(widget)
  local ok, text = pcall(function()
    if widget and widget.getText then
      return widget:getText()
    end
  end)

  if ok and text then
    return tostring(text)
  end

  return ""
end

local function safeGetChildren(widget)
  local ok, children = pcall(function()
    if widget and widget.getChildren then
      return widget:getChildren()
    end
  end)

  if ok and children then
    return children
  end

  return {}
end

local function findWidgetText(widget, list)
  if not widget then return end

  local text = trim(safeGetText(widget))

  if text ~= "" then
    table.insert(list, {
      widget = widget,
      text = text
    })
  end

  for _, child in ipairs(safeGetChildren(widget)) do
    findWidgetText(child, list)
  end
end

local function getSkillValueByLabel(labelName)
  local root = g_ui.getRootWidget()
  if not root then return nil end

  local texts = {}
  findWidgetText(root, texts)

  labelName = labelName:lower()

  for i, data in ipairs(texts) do
    local text = trim(data.text):lower()

    if text == labelName then
      for j = i + 1, math.min(i + 8, #texts) do
        local value = parseSkillNumber(texts[j].text)

        if value and value >= 0 then
          return value
        end
      end
    end
  end

  return nil
end

local function getResets()
  local resets = getSkillValueByLabel("resets")

  if resets and resets >= 0 then
    storage.autoValeLevels.lastResets = math.floor(resets)
    return math.floor(resets)
  end

  if storage.autoValeLevels.lastResets and storage.autoValeLevels.lastResets > 0 then
    return storage.autoValeLevels.lastResets
  end

  return nil
end

local function getSkillLevel()
  local level = getSkillValueByLabel("level")

  if level and level >= 0 then
    storage.autoValeLevels.lastSkillLevel = level
    return level
  end

  if storage.autoValeLevels.lastSkillLevel and storage.autoValeLevels.lastSkillLevel > 0 then
    return storage.autoValeLevels.lastSkillLevel
  end

  return nil
end

local function getValeId()
  if not storage.autoValeLevels.valeItems then return 0 end

  local item = storage.autoValeLevels.valeItems[1]
  if not item then return 0 end

  if type(item) == "table" then
    return tonumber(item.id or item.itemId or item[1]) or 0
  end

  return tonumber(item) or 0
end

local function useValeLevel()
  local valeId = getValeId()

  if valeId <= 0 then
    statusLabel:setText("Status: arraste o Vale Levels")
    return false
  end

  local item = findItem(valeId)

  -- USE WITH PLAYER
  if storage.autoValeLevels.useWith then
    if useWith then
      if item then
        useWith(item, player)
      else
        useWith(valeId, player)
      end
      return true
    end

    if g_game.useInventoryItemWith then
      g_game.useInventoryItemWith(valeId, player)
      return true
    end

    statusLabel:setText("Status: use with indisponivel")
    return false
  end

  -- USE NORMAL
  if item then
    g_game.use(item)
    return true
  end

  if g_game.useInventoryItem then
    g_game.useInventoryItem(valeId)
    return true
  end

  statusLabel:setText("Status: Vale nao encontrado")
  return false
end

macro(1000, function()
  if not storage.autoValeLevels.enabled then
    statusLabel:setText("Status: desligado")
    return
  end

  local level = getSkillLevel()
  local resets = getResets()

  if not level then
    statusLabel:setText("Status: abra Skills para ler Level")
    return
  end

  if not resets then
    statusLabel:setText("Status: abra Skills para ler Resets")
    return
  end

  -- Regra do seu server:
  -- Com 140 resets, precisa chegar em 141,001.
  -- Ent�o alvo = resets + 1,001.
  local targetLevel = resets + 1.001

  -- Vale d� 2.000 levels.
  -- Na escala do painel: 2.000 = 2.000.
  local valeGain = 2.000

  -- Usa 2k antes do alvo.
  -- Exemplo: alvo 141,001 -> usa em 139,001.
  local useAt = targetLevel - valeGain

  local delayMs = tonumber(storage.autoValeLevels.delay) or 1500

  -- J� chegou no level necess�rio para resetar.
  if level >= targetLevel then
    statusLabel:setText(
      "Status: pronto p/ reset | Lv " ..
      formatLevel(level) ..
      " | alvo " ..
      formatLevel(targetLevel) ..
      " | Resets " ..
      resets
    )
    return
  end

  -- Usa o vale quando faltar 2.000 levels para o alvo.
  if level >= useAt and level < targetLevel then
    if storage.autoValeLevels.usedForReset == resets then
      statusLabel:setText(
        "Status: vale ja usado | Lv " ..
        formatLevel(level) ..
        " | alvo " ..
        formatLevel(targetLevel)
      )
      return
    end

    if now - lastAction < delayMs then return end

    local mode = storage.autoValeLevels.useWith and "use with" or "use normal"

    statusLabel:setText(
      "Status: usando vale (" ..
      mode ..
      ") | Lv " ..
      formatLevel(level) ..
      " -> " ..
      formatLevel(targetLevel)
    )

    if useValeLevel() then
      storage.autoValeLevels.usedForReset = resets
      lastAction = now
      delay(delayMs)
    end

    return
  end

  statusLabel:setText(
    "Status: Lv " ..
    formatLevel(level) ..
    " | Resets " ..
    resets ..
    " | usar em " ..
    formatLevel(useAt) ..
    " | alvo " ..
    formatLevel(targetLevel)
  )
end)