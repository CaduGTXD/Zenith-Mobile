setDefaultTab("Tools")

UI.Separator()

if type(storage.questLevelAlert) ~= "table" then
  storage.questLevelAlert = {
    enabled = false,
    posX = 50,
    posY = 50,
    lastResets = 0,
    lastSkillLevel = 0
  }
end

if storage.questLevelAlert.posX == nil then storage.questLevelAlert.posX = 50 end
if storage.questLevelAlert.posY == nil then storage.questLevelAlert.posY = 50 end

local mainPanel = setupUI([[
Panel
  height: 22

  BotSwitch
    id: enabled
    anchors.top: parent.top
    anchors.left: parent.left
    width: 125
    height: 20
    text-align: center
    text: Aviso Quest 30k

  Button
    id: setup
    anchors.top: parent.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Setup
]])

mainPanel.enabled:setOn(storage.questLevelAlert.enabled)

mainPanel.enabled.onClick = function(widget)
  storage.questLevelAlert.enabled = not storage.questLevelAlert.enabled
  widget:setOn(storage.questLevelAlert.enabled)
end

local setupPanel = setupUI([[
Panel
  height: 106

  Label
    id: xLabel
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    height: 18
    text-align: center
    text: X: 50%

  HorizontalScrollBar
    id: xSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: yLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    height: 18
    text-align: center
    text: Y: 50%

  HorizontalScrollBar
    id: ySlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Button
    id: test
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 20
    text: Test Alert
]])

setupPanel:hide()

mainPanel.setup.onClick = function(widget)
  if setupPanel:isVisible() then
    setupPanel:hide()
    widget:setText("Setup")
  else
    setupPanel:show()
    widget:setText("Close")
  end
end

local function clamp(value, minValue, maxValue)
  value = tonumber(value) or minValue

  if value < minValue then return minValue end
  if value > maxValue then return maxValue end

  return value
end

local function setupSlider(slider, label, storageKey, labelText)
  local value = clamp(storage.questLevelAlert[storageKey], 0, 100)

  pcall(function()
    slider:setMinimum(0)
    slider:setMaximum(100)
    slider:setValue(value)
  end)

  label:setText(labelText .. ": " .. value .. "%")

  slider.onValueChange = function(widget, newValue)
    newValue = clamp(newValue, 0, 100)
    storage.questLevelAlert[storageKey] = newValue
    label:setText(labelText .. ": " .. newValue .. "%")
  end
end

setupSlider(setupPanel.xSlider, setupPanel.xLabel, "posX", "X")
setupSlider(setupPanel.ySlider, setupPanel.yLabel, "posY", "Y")

local screenAlert = nil
local lastAlertTime = 0

local function trim(text)
  if not text then return "" end
  return text:match("^%s*(.-)%s*$") or ""
end

local function parseSkillNumber(text)
  if not text then return nil end

  local clean = tostring(text)
  clean = clean:gsub("%s", "")
  clean = clean:match("(%d+[,%d%.]*)")

  if not clean then return nil end

  -- Exemplo:
  -- "117,809" -> 117.809
  -- "142,001" -> 142.001
  clean = clean:gsub("%.", "")
  clean = clean:gsub(",", ".")

  return tonumber(clean)
end

local function formatLevel(value)
  if not value then return "0,000" end
  return string.format("%.3f", value):gsub("%.", ",")
end

local function formatShortK(value)
  if not value then return "0k" end
  return tostring(math.floor(value)) .. "k"
end

local function safeGetText(widget)
  local ok, text = pcall(function()
    if widget and widget.getText then
      return widget:getText()
    end
  end)

  if ok and text then
    return tostring(text)
  end

  return ""
end

local function safeGetChildren(widget)
  local ok, children = pcall(function()
    if widget and widget.getChildren then
      return widget:getChildren()
    end
  end)

  if ok and children then
    return children
  end

  return {}
end

local function findWidgetText(widget, list)
  if not widget then return end

  local text = trim(safeGetText(widget))

  if text ~= "" then
    table.insert(list, {
      widget = widget,
      text = text
    })
  end

  for _, child in ipairs(safeGetChildren(widget)) do
    findWidgetText(child, list)
  end
end

local function getSkillValueByLabel(labelName)
  local root = g_ui.getRootWidget()
  if not root then return nil end

  local texts = {}
  findWidgetText(root, texts)

  labelName = labelName:lower()

  for i, data in ipairs(texts) do
    local text = trim(data.text):lower()

    if text == labelName then
      for j = i + 1, math.min(i + 8, #texts) do
        local value = parseSkillNumber(texts[j].text)

        if value and value >= 0 then
          return value
        end
      end
    end
  end

  return nil
end

local function getResets()
  local resets = getSkillValueByLabel("resets")

  if resets and resets >= 0 then
    storage.questLevelAlert.lastResets = math.floor(resets)
    return math.floor(resets)
  end

  if storage.questLevelAlert.lastResets and storage.questLevelAlert.lastResets > 0 then
    return storage.questLevelAlert.lastResets
  end

  return nil
end

local function getSkillLevel()
  local level = getSkillValueByLabel("level")

  if level and level >= 0 then
    storage.questLevelAlert.lastSkillLevel = level
    return level
  end

  if storage.questLevelAlert.lastSkillLevel and storage.questLevelAlert.lastSkillLevel > 0 then
    return storage.questLevelAlert.lastSkillLevel
  end

  return nil
end

local function getRootSize(root)
  local width = 1000
  local height = 700

  pcall(function()
    if root and root.getWidth then
      width = root:getWidth()
    end
  end)

  pcall(function()
    if root and root.getHeight then
      height = root:getHeight()
    end
  end)

  return width, height
end

local function showScreenAlert(text)
  local root = g_ui.getRootWidget()
  if not root then return end

  if screenAlert then
    screenAlert:destroy()
    screenAlert = nil
  end

  local alertWidth = 420
  local alertHeight = 72

  screenAlert = setupUI([[
Label
  anchors.left: parent.left
  anchors.top: parent.top
  width: 420
  height: 72
  text-align: center
  color: yellow
  background: #000000cc
  font: verdana-11px-rounded
]], root)

  screenAlert:setText(text)

  local rootWidth, rootHeight = getRootSize(root)

  local xPercent = clamp(storage.questLevelAlert.posX, 0, 100)
  local yPercent = clamp(storage.questLevelAlert.posY, 0, 100)

  local left = math.floor((rootWidth - alertWidth) * (xPercent / 100))
  local top = math.floor((rootHeight - alertHeight) * (yPercent / 100))

  if left < 0 then left = 0 end
  if top < 0 then top = 0 end

  pcall(function()
    screenAlert:setMarginLeft(left)
    screenAlert:setMarginTop(top)
  end)

  schedule(5000, function()
    if screenAlert then
      screenAlert:destroy()
      screenAlert = nil
    end
  end)
end

setupPanel.test.onClick = function()
  showScreenAlert("QUEST 30K LIBERADA!\nLv 117k -> Alvo 142k\nResets 141")
end

local function notifyQuestReady(level, resets, targetLevel)
  local msg =
    "QUEST 30K LIBERADA!\n" ..
    "Lv " .. formatShortK(level) .. " -> Alvo " .. formatShortK(targetLevel) .. "\n" ..
    "Resets " .. resets

  showScreenAlert(msg)
end

macro(500, function()
  if not storage.questLevelAlert.enabled then
    return
  end

  local level = getSkillLevel()
  local resets = getResets()

  if not level or not resets then
    return
  end

  -- Regra do server:
  -- 141 resets -> alvo 142,001
  local targetLevel = resets + 1.001

  -- Quest d� 30.000 levels
  local questGain = 30.000

  -- Exemplo:
  -- alvo 142,001 -> pode fazer a quest em 112,001
  local questAt = targetLevel - questGain

  if level >= targetLevel then
    return
  end

  if level >= questAt then
    -- repete a cada 10 segundos
    if now - lastAlertTime >= 10000 then
      notifyQuestReady(level, resets, targetLevel)
      lastAlertTime = now
    end
  end
end)