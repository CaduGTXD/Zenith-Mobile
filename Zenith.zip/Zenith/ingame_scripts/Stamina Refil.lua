-- Stamina Refill.lua

setDefaultTab("Tools")

UI.Separator()

if type(storage.staminaRefillBot) ~= "table" then
  storage.staminaRefillBot = {
    enabled = false,
    useWith = false,
    refillItems = {},
    useDelay = 30000,
    limitHour = 40,
    limitMinute = 0,
    lastStamina = 0
  }
end

if type(storage.staminaRefillBot.refillItems) ~= "table" then
  storage.staminaRefillBot.refillItems = {}
end

if storage.staminaRefillBot.useWith == nil then
  storage.staminaRefillBot.useWith = false
end

if storage.staminaRefillBot.useDelay == nil then
  storage.staminaRefillBot.useDelay = 30000
end

if storage.staminaRefillBot.limitHour == nil then
  storage.staminaRefillBot.limitHour = 40
end

if storage.staminaRefillBot.limitMinute == nil then
  storage.staminaRefillBot.limitMinute = 0
end

-- cooldown s� da sess�o atual, n�o salva no storage
local lastUseAt = 0

local mainPanel = setupUI([[
Panel
  height: 22

  BotSwitch
    id: enabled
    anchors.top: parent.top
    anchors.left: parent.left
    width: 125
    height: 20
    text-align: center
    text: Stamina Refill

  Button
    id: setup
    anchors.top: parent.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Setup
]])

mainPanel.enabled:setOn(storage.staminaRefillBot.enabled)

mainPanel.enabled.onClick = function(widget)
  storage.staminaRefillBot.enabled = not storage.staminaRefillBot.enabled
  widget:setOn(storage.staminaRefillBot.enabled)
end

local setupPanel = setupUI([[
Panel
  height: 178

  BotSwitch
    id: useWith
    anchors.top: parent.top
    anchors.left: parent.left
    width: 125
    height: 20
    text-align: center
    text: Use With Player

  Button
    id: useNow
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Use Now

  Label
    id: hourLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 18
    text-align: center
    text: Hora: 40

  HorizontalScrollBar
    id: hourSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: minuteLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 18
    text-align: center
    text: Minuto: 00

  HorizontalScrollBar
    id: minuteSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: info
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 18
    text-align: center
    text: Arraste refill abaixo

  Label
    id: status
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 18
    text-align: center
    text: Status: parado
]])

setupPanel:hide()

local function setStatus(text)
  if setupPanel and setupPanel.status then
    setupPanel.status:setText(text)
  end
end


local refillContainer = UI.Container(function(widget, items)
  storage.staminaRefillBot.refillItems = items
end, true)

refillContainer:setHeight(35)
refillContainer:setItems(storage.staminaRefillBot.refillItems)
refillContainer:hide()

mainPanel.setup.onClick = function(widget)
  if setupPanel:isVisible() then
    setupPanel:hide()
    refillContainer:hide()
    widget:setText("Setup")
  else
    setupPanel:show()
    refillContainer:show()
    widget:setText("Close")
  end
end

setupPanel.useWith:setOn(storage.staminaRefillBot.useWith)

setupPanel.useWith.onClick = function(widget)
  storage.staminaRefillBot.useWith = not storage.staminaRefillBot.useWith
  widget:setOn(storage.staminaRefillBot.useWith)
end

local function clamp(value, minValue, maxValue)
  value = tonumber(value) or minValue

  if value < minValue then return minValue end
  if value > maxValue then return maxValue end

  return value
end

local function twoDigits(value)
  value = tonumber(value) or 0

  if value < 10 then
    return "0" .. value
  end

  return tostring(value)
end

local function formatStamina(minutes)
  minutes = tonumber(minutes) or 0

  local h = math.floor(minutes / 60)
  local m = minutes % 60

  return h .. ":" .. twoDigits(m)
end

local function getLimitMinutes()
  local h = clamp(storage.staminaRefillBot.limitHour, 0, 42)
  local m = clamp(storage.staminaRefillBot.limitMinute, 0, 59)

  return (h * 60) + m
end

local function updateLimitLabels()
  local h = clamp(storage.staminaRefillBot.limitHour, 0, 42)
  local m = clamp(storage.staminaRefillBot.limitMinute, 0, 59)

  setupPanel.hourLabel:setText("Hora: " .. h)
  setupPanel.minuteLabel:setText("Minuto: " .. twoDigits(m))
end

local function setupSlider(slider, minValue, maxValue, value, callback)
  value = clamp(value, minValue, maxValue)

  pcall(function()
    slider:setMinimum(minValue)
    slider:setMaximum(maxValue)
    slider:setValue(value)
  end)

  slider.onValueChange = function(widget, newValue)
    newValue = clamp(newValue, minValue, maxValue)
    callback(newValue)
  end
end

setupSlider(setupPanel.hourSlider, 0, 42, storage.staminaRefillBot.limitHour, function(value)
  storage.staminaRefillBot.limitHour = value
  updateLimitLabels()
end)

setupSlider(setupPanel.minuteSlider, 0, 59, storage.staminaRefillBot.limitMinute, function(value)
  storage.staminaRefillBot.limitMinute = value
  updateLimitLabels()
end)

updateLimitLabels()

local function trim(text)
  if not text then return "" end
  return text:match("^%s*(.-)%s*$") or ""
end

local function safeGetText(widget)
  local ok, text = pcall(function()
    if widget and widget.getText then
      return widget:getText()
    end
  end)

  if ok and text then
    return tostring(text)
  end

  return ""
end

local function safeGetChildren(widget)
  local ok, children = pcall(function()
    if widget and widget.getChildren then
      return widget:getChildren()
    end
  end)

  if ok and children then
    return children
  end

  return {}
end

local function findWidgetText(widget, list)
  if not widget then return end

  local text = trim(safeGetText(widget))

  if text ~= "" then
    table.insert(list, {
      widget = widget,
      text = text
    })
  end

  for _, child in ipairs(safeGetChildren(widget)) do
    findWidgetText(child, list)
  end
end

local function parseStaminaMinutes(text)
  if not text then return nil end

  local h, m = tostring(text):match("(%d+)%s*:%s*(%d+)")

  if not h or not m then
    return nil
  end

  h = tonumber(h)
  m = tonumber(m)

  if not h or not m then
    return nil
  end

  return (h * 60) + m
end

local function getStaminaFromSkills()
  local root = g_ui.getRootWidget()
  if not root then return nil end

  local texts = {}
  findWidgetText(root, texts)

  -- Caso esteja separado:
  -- Stamina
  -- 32:03
  for i, data in ipairs(texts) do
    local text = trim(data.text):lower()

    if text == "stamina" then
      for j = i + 1, math.min(i + 8, #texts) do
        local value = parseStaminaMinutes(texts[j].text)

        if value then
          storage.staminaRefillBot.lastStamina = value
          return value
        end
      end
    end
  end

  -- Caso venha junto:
  -- Stamina 32:03
  for _, data in ipairs(texts) do
    local text = trim(data.text):lower()

    if text:find("stamina") then
      local value = parseStaminaMinutes(text)

      if value then
        storage.staminaRefillBot.lastStamina = value
        return value
      end
    end
  end

  if storage.staminaRefillBot.lastStamina and storage.staminaRefillBot.lastStamina > 0 then
    return storage.staminaRefillBot.lastStamina
  end

  return nil
end

local function getItemIdFromEntry(entry)
  if not entry then return 0 end

  if type(entry) == "table" then
    return tonumber(entry.id or entry.itemId or entry[1]) or 0
  end

  return tonumber(entry) or 0
end

local function getRefillIds()
  local ids = {}
  local added = {}

  for _, entry in ipairs(storage.staminaRefillBot.refillItems or {}) do
    local id = getItemIdFromEntry(entry)

    if id > 0 and not added[id] then
      table.insert(ids, id)
      added[id] = true
    end
  end

  return ids
end

local function tryUseNormal(id)
  local item = findItem(id)

  if item then
    g_game.use(item)
    return true
  end

  if g_game.useInventoryItem then
    g_game.useInventoryItem(id)
    return true
  end

  return false
end

local function tryUseWithPlayer(id)
  local item = findItem(id)

  if item and useWith then
    useWith(item, player)
    return true
  end

  if item and g_game.useWith then
    g_game.useWith(item, player)
    return true
  end

  if g_game.useInventoryItemWith then
    g_game.useInventoryItemWith(id, player)
    return true
  end

  return false
end

local function useStaminaRefill()
  local ids = getRefillIds()

  if #ids == 0 then
    if setupPanel:isVisible() then
      setStatus("Arraste o item")
    end
    return false
  end

  for _, id in ipairs(ids) do
    local used = false

    if storage.staminaRefillBot.useWith then
      used = tryUseWithPlayer(id)
    else
      used = tryUseNormal(id)
    end

    if used then
      if setupPanel:isVisible() then
        setStatus("Usando item " .. id)
      end

      return true
    end
  end

  if setupPanel:isVisible() then
    setStatus("Item nao encontrado")
  end

  return false
end

setupPanel.useNow.onClick = function()
  if useStaminaRefill() then
    lastUseAt = now
  end
end

macro(1000, function()
  local stamina = getStaminaFromSkills()
  local limit = getLimitMinutes()

  if setupPanel:isVisible() then
    if stamina then
      setStatus("Stam " .. formatStamina(stamina) .. " | < " .. formatStamina(limit))
    else
      setStatus("Abra Skills")
    end
  end

  if not storage.staminaRefillBot.enabled then
    return
  end

  if not stamina then
    return
  end

  -- usa somente quando estiver abaixo do hor�rio escolhido
  if stamina >= limit then
    return
  end

  local delayMs = tonumber(storage.staminaRefillBot.useDelay) or 30000

  if now - lastUseAt < delayMs then
    return
  end

  if useStaminaRefill() then
    lastUseAt = now

    if setupPanel:isVisible() then
      setStatus("Usou em " .. formatStamina(stamina))
    end
  end
end)