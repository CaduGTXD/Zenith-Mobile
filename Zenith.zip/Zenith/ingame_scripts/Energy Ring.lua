-- Energy Ring.lua
-- OTClientV8 / vBot
-- 3051 = Energy Ring na backpack
-- 3088 = Energy Ring equipado
-- Arraste o ring padrÃ£o no Setup
-- Deixe aberta a BP com Energy Ring e com o ring padrÃ£o

setDefaultTab("Tools")

UI.Separator()

local ENERGY_RING = 3051
local ENERGY_RING_EQUIPPED = 3088
local EMPTY_RING = 0

local panelName = "energyRingSwitchUI"

if type(storage[panelName]) ~= "table" then
  storage[panelName] = {
    enabled = false,
    hpEquip = 50,
    hpRemove = 80,
    manaRemove = 25,
    defaultRing = 0,
    equipDefault = true,
    useUtamoVita = false,
    useExanaVita = false
  }
end

local config = storage[panelName]

if config.enabled == nil then config.enabled = false end
if config.hpEquip == nil then config.hpEquip = 50 end
if config.hpRemove == nil then config.hpRemove = 80 end
if config.manaRemove == nil then config.manaRemove = 25 end
if config.defaultRing == nil then config.defaultRing = 0 end
if config.equipDefault == nil then config.equipDefault = true end
if config.useUtamoVita == nil then config.useUtamoVita = false end
if config.useExanaVita == nil then config.useExanaVita = false end

local function clamp(value, minValue, maxValue)
  value = tonumber(value) or minValue

  if value < minValue then
    return minValue
  end

  if value > maxValue then
    return maxValue
  end

  return value
end

config.hpEquip = clamp(config.hpEquip, 0, 100)
config.hpRemove = clamp(config.hpRemove, 0, 100)
config.manaRemove = clamp(config.manaRemove, 0, 100)

local mainPanel = setupUI([[
Panel
  height: 22

  BotSwitch
    id: enabled
    anchors.top: parent.top
    anchors.left: parent.left
    width: 125
    height: 20
    text-align: center
    text: Energy Ring

  Button
    id: setup
    anchors.top: parent.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Setup
]])

mainPanel.enabled:setOn(config.enabled)

mainPanel.enabled.onClick = function(widget)
  config.enabled = not config.enabled
  widget:setOn(config.enabled)
end

local setupPanel = setupUI([[
Panel
  height: 250

  Label
    id: hpEquipLabel
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    height: 18
    text-align: center
    text: Equipar HP <= 50%

  HorizontalScrollBar
    id: hpEquipSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: hpRemoveLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 18
    text-align: center
    text: Remover HP >= 80%

  HorizontalScrollBar
    id: hpRemoveSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: manaRemoveLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 18
    text-align: center
    text: Remover Mana <= 25%

  HorizontalScrollBar
    id: manaRemoveSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  BotSwitch
    id: equipDefault
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 20
    text-align: center
    text: Equipar Ring Padrao

  BotSwitch
    id: useUtamoVita
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 20
    text-align: center
    text: Usar Utamo Vita

  BotSwitch
    id: useExanaVita
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 20
    text-align: center
    text: Exana Vita com HP seguro

  Label
    id: defaultRingLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Arraste o ring padrao

  BotItem
    id: defaultRing
    anchors.top: prev.bottom
    anchors.horizontalCenter: parent.horizontalCenter
    margin-top: 2
    size: 32 32
    tooltip: Arraste o ring padrao aqui

  Label
    id: status
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 18
    text-align: center
    text: Status: aguardando
    color: #aaaaaa
]])

setupPanel:hide()

mainPanel.setup.onClick = function(widget)
  if setupPanel:isVisible() then
    setupPanel:hide()
    widget:setText("Setup")
  else
    setupPanel:show()
    widget:setText("Close")
  end
end

local function setStatus(text)
  if setupPanel and setupPanel.status then
    setupPanel.status:setText("Status: " .. text)
  end
end

local function setupPercentSlider(slider, label, key, labelText)
  local value = clamp(config[key], 0, 100)
  config[key] = value

  pcall(function()
    slider:setMinimum(0)
    slider:setMaximum(100)
    slider:setValue(value)
  end)

  label:setText(labelText .. " " .. value .. "%")

  slider.onValueChange = function(widget, newValue)
    newValue = clamp(newValue, 0, 100)
    config[key] = newValue
    label:setText(labelText .. " " .. newValue .. "%")
  end
end

setupPercentSlider(
  setupPanel.hpEquipSlider,
  setupPanel.hpEquipLabel,
  "hpEquip",
  "Equipar HP <="
)

setupPercentSlider(
  setupPanel.hpRemoveSlider,
  setupPanel.hpRemoveLabel,
  "hpRemove",
  "Remover HP >="
)

setupPercentSlider(
  setupPanel.manaRemoveSlider,
  setupPanel.manaRemoveLabel,
  "manaRemove",
  "Remover Mana <="
)

setupPanel.equipDefault:setOn(config.equipDefault)

setupPanel.equipDefault.onClick = function(widget)
  config.equipDefault = not config.equipDefault
  widget:setOn(config.equipDefault)
end

setupPanel.useUtamoVita:setOn(config.useUtamoVita)
setupPanel.useUtamoVita.onClick = function(widget)
  config.useUtamoVita = not config.useUtamoVita
  widget:setOn(config.useUtamoVita)
end

setupPanel.useExanaVita:setOn(config.useExanaVita)
setupPanel.useExanaVita.onClick = function(widget)
  config.useExanaVita = not config.useExanaVita
  widget:setOn(config.useExanaVita)
end

setupPanel.defaultRing:setItemId(tonumber(config.defaultRing) or 0)

setupPanel.defaultRing.onItemChange = function(widget)
  config.defaultRing = widget:getItemId()
end

local function getFingerItem()
  if getFinger then
    local ok, item = pcall(function()
      return getFinger()
    end)

    if ok then
      return item
    end
  end

  if getSlot then
    local ok, item = pcall(function()
      return getSlot(SlotFinger)
    end)

    if ok then
      return item
    end
  end

  return nil
end

local function getFingerId()
  local finger = getFingerItem()

  if finger and finger.getId then
    return finger:getId()
  end

  return EMPTY_RING
end

local function hasPlayerState(state)
  if not state then return false end

  local localPlayer = player or (g_game and g_game.getLocalPlayer and g_game.getLocalPlayer())
  if not localPlayer then return false end

  local ok, result = pcall(function()
    return localPlayer:hasState(state)
  end)
  return ok and result == true
end

local function callConditionFunction(fn)
  if type(fn) ~= "function" then return false end
  local ok, result = pcall(fn)
  return ok and result == true
end

local function getManaShieldState()
  local legacyShield = callConditionFunction(hasManaShield)
  local newShield = callConditionFunction(hasNewManaShield)

  -- Fallback for clients where the helper was not exported into this script
  -- context yet. This mirrors player_conditions.lua: hasCondition(state).
  if PlayerStates then
    legacyShield = legacyShield or hasPlayerState(PlayerStates.ManaShield)
    newShield = newShield or hasPlayerState(PlayerStates.NewManaShield)
  end

  return legacyShield or newShield, legacyShield, newShield
end

local function hasManaShieldActive()
  local active = getManaShieldState()
  return active
end

local lastSpellCast = 0
local managedUtamoActive = false
local lastUtamoCast = 0
local lastExanaCast = 0

local function saySpell(text, statusText)
  if now - lastSpellCast < 1200 then
    return false
  end

  if say then
    say(text)
    lastSpellCast = now
    setStatus(statusText or text)

    if TargetBot and TargetBot.resumeMageRunMovement then
      schedule(30, function()
        if TargetBot and TargetBot.resumeMageRunMovement then
          TargetBot.resumeMageRunMovement(true)
        end
      end)
    end

    return true
  end

  return false
end

local function rememberManaShield(manaShield)
  -- Alguns clientes/servidores mostram o icone de Utamo, mas hasManaShield()
  -- retorna false. Por isso tambem lembramos o Utamo ativado por este script.
  if manaShield and now - lastExanaCast >= 1800 then
    managedUtamoActive = true
  end

  return manaShield or managedUtamoActive
end

local function castUtamoVita()
  if saySpell("utamo vita", "usando utamo vita") then
    managedUtamoActive = true
    lastUtamoCast = now
    return true
  end

  return false
end

local function tryRemoveUtamo(hp, hpRemove, manaShield)
  if not config.useExanaVita or hp < hpRemove then
    return false
  end

  local utamoActive = rememberManaShield(manaShield)
  if not utamoActive then
    return false
  end

  -- Evita repetir enquanto o cliente ainda nao removeu o icone/estado.
  if now - lastExanaCast < 1800 then
    setStatus("HP seguro | exana vita enviado")
    return true
  end

  if saySpell("exana vita", "removendo utamo | HP seguro") then
    managedUtamoActive = false
    lastExanaCast = now
    return true
  end

  setStatus("HP seguro | aguardando cooldown do exana")
  return true
end

local function equipItemById(itemId, name)
  itemId = tonumber(itemId) or 0

  if itemId <= 0 then
    setStatus(name .. " nao configurado")
    return false
  end

  local item = findItem(itemId)

  if not item then
    setStatus(name .. " nao encontrado")
    return false
  end

  if moveToSlot then
    moveToSlot(item, SlotFinger)
    setStatus("equipando " .. name)
    return true
  end

  if g_game and g_game.move then
    g_game.move(item, {x = 65535, y = SlotFinger, z = 0}, item:getCount())
    setStatus("equipando " .. name)
    return true
  end

  setStatus("nao consegui mover " .. name)
  return false
end

local function equipEnergyRing()
  return equipItemById(ENERGY_RING, "Energy Ring")
end

local function equipDefaultRing()
  if not config.equipDefault then
    return false
  end

  local defaultRingId = tonumber(config.defaultRing) or 0

  if defaultRingId <= 0 then
    setStatus("sem ring padrao")
    return false
  end

  if getFingerId() == defaultRingId then
    return true
  end

  return equipItemById(defaultRingId, "Ring padrao")
end

local function getHpPercent()
  if hppercent then
    local ok, value = pcall(function()
      return hppercent()
    end)

    if ok and value then
      return clamp(value, 0, 100)
    end
  end

  local p = g_game.getLocalPlayer()

  if p and p.getHealthPercent then
    local ok, value = pcall(function()
      return p:getHealthPercent()
    end)

    if ok and value then
      return clamp(value, 0, 100)
    end
  end

  return 100
end

local function getManaPercent()
  if manapercent then
    local ok, value = pcall(function()
      return manapercent()
    end)

    if ok and value then
      return clamp(value, 0, 100)
    end
  end

  local p = g_game.getLocalPlayer()

  if p and p.getMana and p.getMaxMana then
    local okMana, manaValue = pcall(function()
      return p:getMana()
    end)

    local okMax, maxManaValue = pcall(function()
      return p:getMaxMana()
    end)

    if okMana and okMax and maxManaValue and maxManaValue > 0 then
      return clamp(math.floor((manaValue / maxManaValue) * 100), 0, 100)
    end
  end

  return 100
end

macro(200, function()
  if not config.enabled then
    return
  end

  if not g_game.isOnline() then
    managedUtamoActive = false
    lastUtamoCast = 0
    lastExanaCast = 0
    return
  end

  local hpEquip = clamp(config.hpEquip, 0, 100)
  local hpRemove = clamp(config.hpRemove, 0, 100)
  local manaRemove = clamp(config.manaRemove, 0, 100)

  local hp = getHpPercent()
  local mana = getManaPercent()
  local fingerId = getFingerId()
  local manaShield = hasManaShieldActive()
  local useUtamoMode = config.useUtamoVita == true
  local utamoActive = rememberManaShield(manaShield)
  local protectedByShield = utamoActive or (not useUtamoMode and fingerId == ENERGY_RING_EQUIPPED)

  -- Mana baixa: tira Energy Ring e tenta voltar ring padrÃ£o
  if mana <= manaRemove then
    if fingerId == ENERGY_RING_EQUIPPED then
      equipDefaultRing()
      return
    end

    -- Mana baixa nunca remove Utamo com a vida insegura.
    -- Ao atingir o HP seguro, remove mesmo se hasManaShield() falhar,
    -- usando o estado interno do Utamo ativado pelo proprio script.
    if utamoActive and config.useExanaVita then
      if hp >= hpRemove then
        if tryRemoveUtamo(hp, hpRemove, manaShield) then
          return
        end
      else
        setStatus("mana baixa | mantendo utamo ate HP seguro")
        return
      end
    end

    if fingerId == EMPTY_RING then
      equipDefaultRing()
      return
    end

    setStatus("mana baixa | ring ok")
    return
  end

  -- HP baixo: equipa Energy Ring
  if hp <= hpEquip then
    if not protectedByShield then
      if useUtamoMode then
        if castUtamoVita() then
          return
        end

        setStatus("aguardando utamo vita")
        return
      end

      equipEnergyRing()
      return
    end

    if utamoActive then
      if manaShield then
        local _, legacyShield, newShield = getManaShieldState()
        if newShield then
          setStatus("utamo ativo | NewManaShield")
        elseif legacyShield then
          setStatus("utamo ativo | ManaShield")
        else
          setStatus("utamo vita ativo")
        end
      else
        setStatus("utamo vita ativo | memoria interna")
      end
    else
      setStatus("Energy Ring ativo")
    end
    return
  end

  -- HP seguro: se estiver de Energy Ring, volta pro ring padrÃ£o
  if hp >= hpRemove then
    if fingerId == ENERGY_RING_EQUIPPED then
      equipDefaultRing()
      return
    end

    if tryRemoveUtamo(hp, hpRemove, manaShield) then
      return
    end
  end

  -- Se nÃ£o tiver nada no dedo, equipa ring padrÃ£o
  if fingerId == EMPTY_RING then
    equipDefaultRing()
    return
  end

  if utamoActive and hp >= hpRemove and not config.useExanaVita then
    setStatus("HP seguro | Exana Vita desligado")
    return
  end

  setStatus("ok | HP " .. hp .. "% MP " .. mana .. "%")
end)
