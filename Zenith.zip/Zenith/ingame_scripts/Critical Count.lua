-- Critical Tracker - Magic Effect Version
-- Conta criticals por efeito visual/magic effect.
-- Use Debug Effects 10s para descobrir o ID da anima��o do critical.

setDefaultTab("Tools")

UI.Separator()

if type(storage.criticalTrackerBot) ~= "table" then
  storage.criticalTrackerBot = {
    enabled = false,
    showOnScreen = true,
    onlyNearTarget = true,
    critEffectIds = "",
    effectRadius = 2,
    posX = 50,
    posY = 78
  }
end

if storage.criticalTrackerBot.enabled == nil then storage.criticalTrackerBot.enabled = false end
if storage.criticalTrackerBot.showOnScreen == nil then storage.criticalTrackerBot.showOnScreen = true end
if storage.criticalTrackerBot.onlyNearTarget == nil then storage.criticalTrackerBot.onlyNearTarget = true end
if storage.criticalTrackerBot.critEffectIds == nil then storage.criticalTrackerBot.critEffectIds = "" end
if storage.criticalTrackerBot.effectRadius == nil then storage.criticalTrackerBot.effectRadius = 2 end
if storage.criticalTrackerBot.posX == nil then storage.criticalTrackerBot.posX = 50 end
if storage.criticalTrackerBot.posY == nil then storage.criticalTrackerBot.posY = 78 end

local mainPanel = setupUI([[
Panel
  height: 22

  BotSwitch
    id: enabled
    anchors.top: parent.top
    anchors.left: parent.left
    width: 125
    height: 20
    text-align: center
    text: Critical Tracker

  Button
    id: setup
    anchors.top: parent.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Setup
]])
mainPanel.enabled:setOn(storage.criticalTrackerBot.enabled)

mainPanel.enabled.onClick = function(widget)
  storage.criticalTrackerBot.enabled = not storage.criticalTrackerBot.enabled
  widget:setOn(storage.criticalTrackerBot.enabled)
end

local setupPanel = setupUI([[
Panel
  height: 258

  BotSwitch
    id: onlyNearTarget
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    height: 20
    text-align: center
    text: So Perto do Target

  Label
    id: effectLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Crit Effect IDs:

  BotTextEdit
    id: effectIds
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 22
    text: 

  Label
    id: radiusLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Raio Target: 2 sqm

  HorizontalScrollBar
    id: radiusSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Button
    id: debug
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 20
    text: Debug Effects 10s

  Button
    id: reset
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 20
    text: Reset Session

  Button
    id: simulate
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 20
    text: Simular Crit

  Label
    id: xLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: X: 50%

  HorizontalScrollBar
    id: xSlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16

  Label
    id: yLabel
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
    height: 18
    text-align: center
    text: Y: 78%

  HorizontalScrollBar
    id: ySlider
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 4
    margin-right: 4
    height: 16
]])
setupPanel:hide()

mainPanel.setup.onClick = function(widget)
  if setupPanel:isVisible() then
    setupPanel:hide()
    widget:setText("Setup")
  else
    setupPanel:show()
    widget:setText("Close")
  end
end

setupPanel.onlyNearTarget:setOn(storage.criticalTrackerBot.onlyNearTarget)
setupPanel.onlyNearTarget.onClick = function(widget)
  storage.criticalTrackerBot.onlyNearTarget = not storage.criticalTrackerBot.onlyNearTarget
  widget:setOn(storage.criticalTrackerBot.onlyNearTarget)
end

setupPanel.effectIds:setText(storage.criticalTrackerBot.critEffectIds or "")
setupPanel.effectIds.onTextChange = function(widget, text)
  storage.criticalTrackerBot.critEffectIds = text
end

local function clamp(value, minValue, maxValue)
  value = tonumber(value) or minValue

  if value < minValue then return minValue end
  if value > maxValue then return maxValue end

  return value
end

local function setupPercentSlider(slider, label, key, labelText)
  local value = clamp(storage.criticalTrackerBot[key], 0, 100)
  storage.criticalTrackerBot[key] = value

  pcall(function()
    slider:setMinimum(0)
    slider:setMaximum(100)
    slider:setValue(value)
  end)

  label:setText(labelText .. ": " .. value .. "%")

  slider.onValueChange = function(widget, newValue)
    newValue = clamp(newValue, 0, 100)
    storage.criticalTrackerBot[key] = newValue
    label:setText(labelText .. ": " .. newValue .. "%")
  end
end

setupPercentSlider(setupPanel.xSlider, setupPanel.xLabel, "posX", "X")
setupPercentSlider(setupPanel.ySlider, setupPanel.yLabel, "posY", "Y")

local function updateRadiusLabel()
  storage.criticalTrackerBot.effectRadius = clamp(storage.criticalTrackerBot.effectRadius, 0, 8)
  setupPanel.radiusLabel:setText("Raio Target: " .. storage.criticalTrackerBot.effectRadius .. " sqm")
end

pcall(function()
  setupPanel.radiusSlider:setMinimum(0)
  setupPanel.radiusSlider:setMaximum(8)
  setupPanel.radiusSlider:setValue(clamp(storage.criticalTrackerBot.effectRadius, 0, 8))
end)

setupPanel.radiusSlider.onValueChange = function(widget, value)
  storage.criticalTrackerBot.effectRadius = clamp(value, 0, 8)
  updateRadiusLabel()
end

updateRadiusLabel()

local overlay = nil
local critCount = 0
local sessionStart = now
local lastCritAt = 0
local lastCritKey = ""
local lastUpdate = 0
local debugUntil = 0

local recentEffects = {}
local recentDebug = {}

local function parseEffectIds(text)
  local ids = {}
  text = tostring(text or "")

  for number in text:gmatch("%d+") do
    ids[tonumber(number)] = true
  end

  return ids
end

local function getTargetCreature()
  if g_game and g_game.getAttackingCreature then
    local ok, creature = pcall(function()
      return g_game.getAttackingCreature()
    end)

    if ok and creature then
      return creature
    end
  end

  if target then
    local ok, creature = pcall(function()
      return target()
    end)

    if ok and creature then
      return creature
    end
  end

  return nil
end

local function getCreaturePos(creature)
  if not creature or not creature.getPosition then return nil end

  local ok, pos = pcall(function()
    return creature:getPosition()
  end)

  if ok and pos then return pos end

  return nil
end

local function distance(pos1, pos2)
  if not pos1 or not pos2 then return 999 end
  if pos1.z ~= pos2.z then return 999 end

  return math.max(math.abs(pos1.x - pos2.x), math.abs(pos1.y - pos2.y))
end

local function isNearTarget(pos)
  if not storage.criticalTrackerBot.onlyNearTarget then
    return true
  end

  local targetCreature = getTargetCreature()
  local targetPos = getCreaturePos(targetCreature)

  if not targetPos then
    return true
  end

  if not pos then
    return true
  end

  local radius = clamp(storage.criticalTrackerBot.effectRadius, 0, 8)

  return distance(pos, targetPos) <= radius
end

local function getCritsPerHour()
  local elapsed = now - sessionStart

  if elapsed <= 0 then
    return 0
  end

  local hours = elapsed / 3600000
  return critCount / hours
end

local function formatNumber(value)
  value = tonumber(value) or 0

  if value >= 1000000 then
    return string.format("%.2fkk", value / 1000000)
  elseif value >= 1000 then
    return string.format("%.1fk", value / 1000)
  end

  return tostring(math.floor(value + 0.5))
end

local function getTextWidth(text)
  text = tostring(text or "")

  local maxLen = 0

  for line in text:gmatch("[^\n]+") do
    if #line > maxLen then
      maxLen = #line
    end
  end

  return (maxLen * 7) + 18
end

local function getRootSize(root)
  local width = 1000
  local height = 700

  pcall(function()
    if root and root.getWidth then
      width = root:getWidth()
    end
  end)

  pcall(function()
    if root and root.getHeight then
      height = root:getHeight()
    end
  end)

  return width, height
end

local function createOverlay()
  local root = g_ui.getRootWidget()

  if not root then return nil end

  if overlay then return overlay end

  overlay = setupUI([[
Label
  anchors.left: parent.left
  anchors.top: parent.top
  text-align: center
  color: yellow
  background: #000000cc
  font: verdana-11px-rounded
]], root)

  return overlay
end

local function setOverlaySize(box, width, height)
  pcall(function()
    box:setWidth(width)
  end)

  pcall(function()
    box:setHeight(height)
  end)

  pcall(function()
    box:setSize({width = width, height = height})
  end)
end

local function setOverlayPosition(box, width, height)
  local root = g_ui.getRootWidget()

  if not root or not box then return end

  local rootWidth, rootHeight = getRootSize(root)

  local xPercent = clamp(storage.criticalTrackerBot.posX, 0, 100)
  local yPercent = clamp(storage.criticalTrackerBot.posY, 0, 100)

  local left = math.floor((rootWidth - width) * (xPercent / 100))
  local top = math.floor((rootHeight - height) * (yPercent / 100))

  if left < 0 then left = 0 end
  if top < 0 then top = 0 end

  pcall(function()
    box:setMarginLeft(left)
    box:setMarginTop(top)
  end)

  pcall(function()
    box:setPosition({x = left, y = top})
  end)
end

local function hideOverlay()
  if overlay then
    overlay:hide()
  end
end

local function updateOverlay()
  local critsPerHour = getCritsPerHour()

  local box = createOverlay()
  if not box then return end

  local text =
    "Crits: " ..
    critCount ..
    "\nCrit/h: " ..
    formatNumber(critsPerHour)

  local width = getTextWidth(text)
  local height = 38

  setOverlaySize(box, width, height)
  setOverlayPosition(box, width, height)

  box:setText(text)
  box:show()
end

local function addCritical(effectId, pos)
  if not storage.criticalTrackerBot.enabled then
    return
  end

  local key = tostring(effectId)

  if pos then
    key = key .. ":" .. tostring(pos.x) .. ":" .. tostring(pos.y) .. ":" .. tostring(pos.z)
  end

  -- evita contar v�rios efeitos do mesmo critical
  if now - lastCritAt <= 350 and lastCritKey == key then
    return
  end

  -- evita contar spam de m�ltiplos callbacks
  if now - lastCritAt <= 180 then
    return
  end

  critCount = critCount + 1
  lastCritAt = now
  lastCritKey = key

  updateOverlay()
end

local function resetSession()
  critCount = 0
  sessionStart = now
  lastCritAt = 0
  lastCritKey = ""
  updateOverlay()
end

setupPanel.reset.onClick = function()
  resetSession()
end

setupPanel.simulate.onClick = function()
  addCritical("simulado", nil)
end

setupPanel.debug.onClick = function()
  debugUntil = now + 10000
  warn("Critical Tracker: Debug Effects ON por 10 segundos.")
  warn("Bata no monstro e veja os Effect IDs perto do target.")
end

local function debugEffect(effectId, pos)
  if now > debugUntil then
    return
  end

  if not isNearTarget(pos) then
    return
  end

  local key =
    tostring(effectId) ..
    ":" ..
    tostring(pos and pos.x or "?") ..
    ":" ..
    tostring(pos and pos.y or "?") ..
    ":" ..
    tostring(pos and pos.z or "?")

  if recentDebug[key] and now - recentDebug[key] < 500 then
    return
  end

  recentDebug[key] = now

  local dist = "--"

  local targetCreature = getTargetCreature()
  local targetPos = getCreaturePos(targetCreature)

  if pos and targetPos then
    dist = tostring(distance(pos, targetPos))
  end

  warn(
    "Effect ID: " ..
    tostring(effectId) ..
    " | dist target: " ..
    dist ..
    " | pos: " ..
    tostring(pos and pos.x or "?") ..
    "," ..
    tostring(pos and pos.y or "?") ..
    "," ..
    tostring(pos and pos.z or "?")
  )
end

local function handleEffect(effectId, pos)
  if not storage.criticalTrackerBot.enabled then
    return
  end

  effectId = tonumber(effectId)

  if not effectId then
    return
  end

  if not isNearTarget(pos) then
    return
  end

  local effectKey =
    tostring(effectId) ..
    ":" ..
    tostring(pos and pos.x or "?") ..
    ":" ..
    tostring(pos and pos.y or "?") ..
    ":" ..
    tostring(pos and pos.z or "?")

  if recentEffects[effectKey] and now - recentEffects[effectKey] < 200 then
    return
  end

  recentEffects[effectKey] = now

  debugEffect(effectId, pos)

  local ids = parseEffectIds(storage.criticalTrackerBot.critEffectIds)

  if ids[effectId] then
    addCritical(effectId, pos)
  end
end

local function extractEffectId(thing)
  if not thing then return nil end

  if thing.getId then
    local ok, id = pcall(function()
      return thing:getId()
    end)

    if ok and id then
      return tonumber(id)
    end
  end

  if thing.getEffectId then
    local ok, id = pcall(function()
      return thing:getEffectId()
    end)

    if ok and id then
      return tonumber(id)
    end
  end

  return nil
end

local function isEffectThing(thing)
  if not thing then return false end

  if thing.isEffect then
    local ok, result = pcall(function()
      return thing:isEffect()
    end)

    if ok then
      return result == true
    end
  end

  if thing.getEffectId then
    return true
  end

  -- alguns clients representam magic effect como Thing com getId,
  -- ent�o deixa passar se tiver getId e n�o for criatura/item comum
  if thing.getId and not thing.isCreature then
    return true
  end

  return false
end

local function getTilePos(tile)
  if not tile then return nil end

  if tile.getPosition then
    local ok, pos = pcall(function()
      return tile:getPosition()
    end)

    if ok and pos then
      return pos
    end
  end

  return nil
end

local function handleThing(tile, thing)
  if not storage.criticalTrackerBot.enabled then
    return
  end

  if not thing then
    return
  end

  if not isEffectThing(thing) then
    return
  end

  local effectId = extractEffectId(thing)

  if not effectId then
    return
  end

  local pos = getTilePos(tile)

  if not pos and thing.getPosition then
    local ok, thingPos = pcall(function()
      return thing:getPosition()
    end)

    if ok and thingPos then
      pos = thingPos
    end
  end

  handleEffect(effectId, pos)
end

-- vBot comum
if onAddThing then
  onAddThing(function(tile, thing)
    handleThing(tile, thing)
  end)
end

-- alguns OTC exp�em por connect no g_map
pcall(function()
  if g_map and connect then
    connect(g_map, {
      onAddThing = function(...)
        local args = {...}
        local tile = nil
        local thing = nil

        -- poss�veis formatos:
        -- tile, thing
        -- map, tile, thing
        if #args >= 3 then
          tile = args[2]
          thing = args[3]
        else
          tile = args[1]
          thing = args[2]
        end

        handleThing(tile, thing)
      end
    })
  end
end)

-- alguns clients t�m callback direto de magic effect
if onAddEffect then
  onAddEffect(function(...)
    local args = {...}
    local effectId = nil
    local pos = nil

    for _, value in ipairs(args) do
      if type(value) == "number" then
        effectId = value
      elseif type(value) == "table" and value.x and value.y and value.z then
        pos = value
      elseif type(value) == "userdata" then
        local maybeId = extractEffectId(value)

        if maybeId then
          effectId = maybeId
        end

        if value.getPosition then
          local ok, p = pcall(function()
            return value:getPosition()
          end)

          if ok and p then
            pos = p
          end
        end
      end
    end

    if effectId then
      handleEffect(effectId, pos)
    end
  end)
end

macro(500, function()
  if not storage.criticalTrackerBot.enabled then
    hideOverlay()
    return
  end

  if now - lastUpdate < 500 then
    return
  end

  lastUpdate = now

  for key, time in pairs(recentEffects) do
    if now - time > 3000 then
      recentEffects[key] = nil
    end
  end

  for key, time in pairs(recentDebug) do
    if now - time > 3000 then
      recentDebug[key] = nil
    end
  end

  if debugUntil > 0 and now > debugUntil then
    debugUntil = 0
    warn("Critical Tracker: Debug Effects OFF.")
  end

  updateOverlay()
end)