CaveBot.Extensions.SupplyCheck = {}

local supplyRetries = 0
local missedChecks = 0
local maxMissedChecks = 6
local rawRound = 0
local time = now
vBot.CaveBotData =
  vBot.CaveBotData or
  {
    refills = 0,
    rounds = 0,
    time = {},
    lastRefill = os.time(),
    refillTime = {}
  }

local function setCaveBotData(hunting)
  if hunting then
    supplyRetries = supplyRetries + 1
  else
    supplyRetries = 0
    table.insert(vBot.CaveBotData.refillTime, os.difftime(os.time() - vBot.CaveBotData.lastRefill))
    vBot.CaveBotData.lastRefill = os.time()
    vBot.CaveBotData.refills = vBot.CaveBotData.refills + 1
  end

  table.insert(vBot.CaveBotData.time, rawRound)
  vBot.CaveBotData.rounds = vBot.CaveBotData.rounds + 1
  missedChecks = 0
end

CaveBot.Extensions.SupplyCheck.setup = function()
  CaveBot.registerAction(
    "supplyCheck",
    "#db5a5a",
    function(value)
      local data = string.split(value, ",")
      local round = 0
      rawRound = 0
      local label = data[1]:trim()
      local pos = nil
      if #data == 4 then
        pos = {x = tonumber(data[2]), y = tonumber(data[3]), z = tonumber(data[4])}
      end

      local function goToHuntLabel(reason)
        if reason then
          print(reason)
        end
        if not CaveBot.gotoLabel(label) then
          warn("CaveBot[SupplyCheck]: label not found: " .. label)
          return false
        end
        return true
      end

      if pos then
        if missedChecks >= maxMissedChecks then
          missedChecks = 0
          supplyRetries = 0
          print("CaveBot[SupplyCheck]: Missed " .. (maxMissedChecks + 1) .. " supply checks, proceeding with waypoints")
          return true
        end
        local currentPos = player:getPosition()
        local checkDistance = getDistanceBetween(currentPos, pos)
        if checkDistance > 12 then
          missedChecks = missedChecks + 1
          return goToHuntLabel(
            "CaveBot[SupplyCheck]: Missed supply check at distance " .. checkDistance ..
            " from expected position (" .. pos.x .. "," .. pos.y .. "," .. pos.z .. "). " ..
            ((maxMissedChecks + 1) - missedChecks) .. " tries left before skipping."
          )
        end
      end

      if time then
        rawRound = math.ceil((now - time) / 1000)
        round = rawRound .. "s"
      else
        round = ""
      end
      time = now

      local softCount = itemAmount(6529) + itemAmount(3549)
      local supplyData = Supplies.hasEnough()
      local supplyInfo = Supplies.getAdditionalData()
      local huntRoutesLimit = tonumber(storage.extras.huntRoutes) or 50

      if storage.caveBot.forceRefill then
        print("CaveBot[SupplyCheck]: User forced, going back on refill. Last round took: " .. round)
        storage.caveBot.forceRefill = false
        supplyRetries = 0
        missedChecks = 0
        return false
      elseif storage.caveBot.backStop then
        print("CaveBot[SupplyCheck]: User forced, going back to city and turning off CaveBot. Last round took: " .. round)
        supplyRetries = 0
        missedChecks = 0
        return false
      elseif storage.caveBot.backTrainers then
        print("CaveBot[SupplyCheck]: User forced, going back to city, then on trainers. Last round took: " .. round)
        supplyRetries = 0
        missedChecks = 0
        return false
      elseif storage.caveBot.backOffline then
        print("CaveBot[SupplyCheck]: User forced, going back to city, then on offline training. Last round took: " .. round)
        supplyRetries = 0
        missedChecks = 0
        return false
      elseif huntRoutesLimit > 0 and supplyRetries > huntRoutesLimit then
        print("CaveBot[SupplyCheck]: Round limit reached (" .. supplyRetries .. "/" .. huntRoutesLimit .. "), going back on refill. Last round took: " .. round)
        setCaveBotData()
        return false
      elseif (supplyInfo.imbues.enabled and player:getSkillLevel(11) == 0) then
        print("CaveBot[SupplyCheck]: Imbues ran out. Going on refill. Last round took: " .. round)
        setCaveBotData()
        return false
      elseif (supplyInfo.stamina.enabled and stamina() < tonumber(supplyInfo.stamina.value)) then
        print("CaveBot[SupplyCheck]: Stamina ran out. Going on refill. Last round took: " .. round)
        setCaveBotData()
        return false
      elseif (supplyInfo.softBoots.enabled and softCount < 1) then
        print("CaveBot[SupplyCheck]: No soft boots left. Going on refill. Last round took: " .. round)
        setCaveBotData()
        return false
      elseif type(supplyData) == "table" then
        print("CaveBot[SupplyCheck]: Not enough item: " .. supplyData.id .. "(only " .. supplyData.amount .. " left). Going on refill. Last round took: " .. round)
        setCaveBotData()
        return false
      elseif (supplyInfo.capacity.enabled and freecap() < tonumber(supplyInfo.capacity.value)) then
        print("CaveBot[SupplyCheck]: Not enough capacity. Going on refill. Last round took: " .. round)
        setCaveBotData()
        return false
      else
        local roundsText = huntRoutesLimit > 0 and (supplyRetries .. "/" .. huntRoutesLimit) or (supplyRetries .. "/off")
        print("CaveBot[SupplyCheck]: Enough supplies. Hunting. Round (" .. roundsText .. "). Last round took: " .. round)
        setCaveBotData(true)
        return goToHuntLabel()
      end
    end
  )

  CaveBot.Editor.registerAction(
    "supplycheck",
    "supply check",
    {
      value = function()
        return "startHunt," .. posx() .. "," .. posy() .. "," .. posz()
      end,
      title = "Supply check label",
      description = "Insert here hunting start label",
      validation = [[[^,]+,\d{1,5},\d{1,5},\d{1,2}$]]
    }
  )
end
