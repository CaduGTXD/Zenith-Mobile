CaveBot.Extensions.BuySupplies = {}

local BUY = 1

local MAX_RETRIES = 180
local MAX_TRADE_ATTEMPTS = 8
local MAX_NO_PROGRESS = 6
local TRADE_RETRY_INTERVAL = 300

local state = {
  key = nil,
  lastTalkAt = 0,
  tradeAttempts = 0,
  waitTradeDataTries = 0,
  noProgress = {},
  lastCount = {},
  skipped = {}
}

local function resetState(key)
  state.key = key
  state.lastTalkAt = 0
  state.tradeAttempts = 0
  state.waitTradeDataTries = 0
  state.noProgress = {}
  state.lastCount = {}
  state.skipped = {}
end

local function trim(str)
  return tostring(str or ""):gsub("^%s+", ""):gsub("%s+$", "")
end

local function nowMs()
  if type(now) == "number" then
    return now
  end

  if g_clock and g_clock.millis then
    local ok, result = pcall(function()
      return g_clock.millis()
    end)

    if ok and result then
      return result
    end
  end

  return os.time() * 1000
end

local function hasAnyEntry(tbl)
  if type(tbl) ~= "table" then
    return false
  end

  for _, _ in pairs(tbl) do
    return true
  end

  return false
end

local function getTalkDelay(default)
  default = default or 1000
  local delay = default

  if storage and storage.extras and storage.extras.talkDelay then
    delay = tonumber(storage.extras.talkDelay) or default
  end

  return math.max(delay, 300)
end

local function getItemCount(id)
  id = tonumber(id)
  if not id then
    return 0
  end

  if type(itemAmount) == "function" then
    local ok, result = pcall(function()
      return itemAmount(id)
    end)

    if ok and result then
      return result
    end
  end

  if player and player.getItemsCount then
    local ok, result = pcall(function()
      return player:getItemsCount(id)
    end)

    if ok and result then
      return result
    end
  end

  return 0
end

local function stopMoving()
  pcall(function()
    player:stopAutoWalk()
  end)

  pcall(function()
    g_game.stop()
  end)
end

local function sayNpc(text)
  if NPC and NPC.say then
    local ok = pcall(function()
      NPC.say(text)
    end)

    if ok then
      return true
    end
  end

  if g_game and g_game.talkChannel then
    local ok = pcall(function()
      g_game.talkChannel(11, 0, text)
    end)

    if ok then
      return true
    end
  end

  if type(say) == "function" then
    local ok = pcall(function()
      say(text)
    end)

    if ok then
      return true
    end
  end

  return false
end

local function widgetVisible(widget)
  if not widget or not widget.isVisible then
    return false
  end

  local ok, visible = pcall(function()
    return widget:isVisible()
  end)

  return ok and visible
end

local function findNpcTradeWindow()
  local tradeModule = modules and modules.game_npctrade

  if tradeModule and tradeModule.npcWindow then
    return tradeModule.npcWindow
  end

  local roots = {}

  if rootWidget then
    table.insert(roots, rootWidget)
  end

  if g_ui and g_ui.getRootWidget then
    local ok, root = pcall(function()
      return g_ui.getRootWidget()
    end)

    if ok and root then
      table.insert(roots, root)
    end
  end

  if modules and modules.game_interface then
    if modules.game_interface.getRootPanel then
      local ok, root = pcall(function()
        return modules.game_interface.getRootPanel()
      end)

      if ok and root then
        table.insert(roots, root)
      end
    end

    if modules.game_interface.getMapPanel then
      local ok, root = pcall(function()
        return modules.game_interface.getMapPanel()
      end)

      if ok and root then
        table.insert(roots, root)
      end
    end
  end

  for _, root in ipairs(roots) do
    if root and root.recursiveGetChildById then
      local ok, widget = pcall(function()
        return root:recursiveGetChildById("npcWindow")
      end)

      if ok and widget then
        return widget
      end
    end
  end

  return nil
end

local function getBuyTradeList()
  local tradeModule = modules and modules.game_npctrade
  if not tradeModule or type(tradeModule.tradeItems) ~= "table" then
    return nil
  end

  local buyIndex = tradeModule.BUY or BUY
  local list = tradeModule.tradeItems[buyIndex]

  if type(list) == "table" then
    return list
  end

  return nil
end

local function getBuyTradeItem(id)
  id = tonumber(id)
  if not id then
    return nil
  end

  local list = getBuyTradeList()
  if type(list) ~= "table" then
    return nil
  end

  for _, item in pairs(list) do
    if item and item.ptr and item.ptr.getId then
      local ok, itemId = pcall(function()
        return item.ptr:getId()
      end)

      if ok and itemId == id then
        return item
      end
    end
  end

  return nil
end

local function hasBuyTradeData()
  local list = getBuyTradeList()
  return hasAnyEntry(list)
end

local function isTradeOpen()
  if NPC and NPC.isTrading then
    local ok, result = pcall(function()
      return NPC.isTrading()
    end)

    if ok and result then
      return true
    end
  end

  local window = findNpcTradeWindow()
  if widgetVisible(window) then
    return true
  end

  return false
end

local function closeTrade()
  if NPC and NPC.closeTrade then
    pcall(function()
      NPC.closeTrade()
    end)
    return
  end

  if modules and modules.game_npctrade and modules.game_npctrade.closeNpcTrade then
    pcall(function()
      modules.game_npctrade.closeNpcTrade()
    end)
    return
  end

  if g_game and g_game.closeNpcTrade then
    pcall(function()
      g_game.closeNpcTrade()
    end)
  end
end

local function buyItem(id, count)
  id = tonumber(id)
  count = tonumber(count)

  if not id or not count or count <= 0 then
    return false
  end

  local tradeItem = getBuyTradeItem(id)
  local item = tradeItem and tradeItem.ptr or nil

  if not item and Item and Item.create then
    local ok, createdItem = pcall(function()
      return Item.create(id)
    end)

    if ok and createdItem then
      item = createdItem
    end
  end

  if item and g_game and g_game.buyItem then
    local ok = pcall(function()
      -- args: item, count, ignoreCapacity, buyWithBackpack
      g_game.buyItem(item, count, false, false)
    end)

    if ok then
      return true
    end
  end

  if NPC and NPC.buy then
    local ok = pcall(function()
      NPC.buy(id, count, false, false)
    end)

    if ok then
      return true
    end
  end

  return false
end

local function getSuppliesData()
  if not Supplies or not Supplies.getItemsData then
    return {}
  end

  local ok, data = pcall(function()
    return Supplies.getItemsData()
  end)

  if ok and type(data) == "table" then
    return data
  end

  return {}
end

CaveBot.Extensions.BuySupplies.setup = function()
  CaveBot.registerAction("BuySupplies", "#C300FF", function(value, retries)
    local rawValue = tostring(value or "")
    local val = string.split(rawValue, ",")

    if not val or #val == 0 or #val > 2 then
      warn("CaveBot[BuySupplies]: incorrect BuySupplies value")
      return false
    end

    local npcName = trim(val[1])
    if npcName == "" then
      warn("CaveBot[BuySupplies]: NPC name is empty")
      return false
    end

    local waitVal = nil
    if #val == 2 then
      waitVal = tonumber(trim(val[2]))
      if not waitVal then
        warn("CaveBot[BuySupplies]: incorrect delay value")
      end
    end

    local key = npcName .. "|" .. rawValue
    if state.key ~= key then
      resetState(key)
    end

    if retries > MAX_RETRIES then
      print("CaveBot[BuySupplies]: too many tries, stopping")
      resetState(nil)
      return false
    end

    local itemsData = getSuppliesData()
    if not hasAnyEntry(itemsData) then
      print("CaveBot[BuySupplies]: no supplies configured for current profile, proceeding")
      resetState(nil)
      return true
    end

    local npc = getCreatureByName(npcName)
    if not npc then
      if retries < 15 then
        CaveBot.delay(400)
        return "retry"
      end

      print("CaveBot[BuySupplies]: NPC not found: " .. npcName)
      resetState(nil)
      return false
    end

    local npcPos = npc:getPosition()
    if getDistanceBetween(pos(), npcPos) > 3 then
      CaveBot.GoTo(npcPos, 3)
      CaveBot.delay(300)
      return "retry"
    end

    if not isTradeOpen() then
      local talkDelay = getTalkDelay(1000)
      local currentTime = nowMs()
      local canTalkAgain = state.lastTalkAt == 0 or currentTime - state.lastTalkAt >= math.max(talkDelay * 3, 2500)

      if canTalkAgain then
        state.tradeAttempts = state.tradeAttempts + 1
        state.lastTalkAt = currentTime

        if state.tradeAttempts > MAX_TRADE_ATTEMPTS then
          print("CaveBot[BuySupplies]: trade window did not open after " .. MAX_TRADE_ATTEMPTS .. " attempts")
          resetState(nil)
          return false
        end

        stopMoving()
        print("CaveBot[BuySupplies]: opening trade with " .. npcName .. " attempt " .. state.tradeAttempts)

        sayNpc("hi")

        schedule(talkDelay, function()
          sayNpc("trade")
        end)
      end

      CaveBot.delay(TRADE_RETRY_INTERVAL)
      return "retry"
    end

    state.tradeAttempts = 0

    if waitVal and state.waitTradeDataTries == 0 then
      CaveBot.delay(waitVal)
      state.waitTradeDataTries = state.waitTradeDataTries + 1
      return "retry"
    end

    if not hasBuyTradeData() then
      state.waitTradeDataTries = state.waitTradeDataTries + 1

      if state.waitTradeDataTries <= 10 then
        CaveBot.delay(300)
        return "retry"
      end

      print("CaveBot[BuySupplies]: trade is open, but buy list is empty/unavailable; trying direct buy mode")
    end

    for id, values in pairs(itemsData) do
      id = tonumber(id)

      if id and not state.skipped[id] then
        local max = 0

        if type(values) == "table" then
          max = tonumber(values.max) or 0
        else
          max = tonumber(values) or 0
        end

        if max > 0 then
          local current = getItemCount(id)
          local toBuy = max - current

          if toBuy > 0 then
            local list = getBuyTradeList()
            local tradeHasList = hasAnyEntry(list)
            local tradeItem = getBuyTradeItem(id)

            if tradeHasList and not tradeItem then
              print("CaveBot[BuySupplies]: NPC does not sell item " .. id .. ", skipping")
              state.skipped[id] = true
              CaveBot.delay(100)
              return "retry"
            end

            if state.lastCount[id] == nil or current > state.lastCount[id] then
              state.noProgress[id] = 0
            else
              state.noProgress[id] = (state.noProgress[id] or 0) + 1
            end

            state.lastCount[id] = current

            if state.noProgress[id] > MAX_NO_PROGRESS then
              print("CaveBot[BuySupplies]: item " .. id .. " is not increasing after several tries, skipping")
              state.skipped[id] = true
              CaveBot.delay(100)
              return "retry"
            end

            toBuy = math.min(100, toBuy)

            print(
              "CaveBot[BuySupplies]: buying item " ..
              id ..
              " | have " ..
              current ..
              " | target " ..
              max ..
              " | amount " ..
              toBuy
            )

            local sent = buyItem(id, toBuy)

            if not sent then
              print("CaveBot[BuySupplies]: failed to send buy packet for item " .. id)
              state.noProgress[id] = (state.noProgress[id] or 0) + 1
            end

            CaveBot.delay(getTalkDelay(300))
            return "retry"
          end
        end
      end
    end

    closeTrade()

    if hasAnyEntry(state.skipped) then
      print("CaveBot[BuySupplies]: finished with some skipped items, proceeding")
    else
      print("CaveBot[BuySupplies]: bought everything, proceeding")
    end

    resetState(nil)
    return true
  end)

  CaveBot.Editor.registerAction("buysupplies", "buy supplies", {
    value = "NPC name",
    title = "Buy Supplies",
    description = "NPC Name, delay(in ms, optional)",
  })
end