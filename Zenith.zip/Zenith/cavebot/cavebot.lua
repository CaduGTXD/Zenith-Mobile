local cavebotMacro = nil
local config = nil

local cavebotCompat = storage.cavebotCompat or {}
local ui = nil
local configWidget = nil
local panelOnlyBisect = cavebotCompat.stage == "coreOnly"
  and cavebotCompat.loadMainUi
  and not cavebotCompat.loadMainRuntime
  and cavebotCompat.loadTargetBot == false
  and cavebotCompat.safeMode == true
local runtimeBisect = panelOnlyBisect

if cavebotCompat.enableSupportModules == nil and runtimeBisect then
  cavebotCompat.enableSupportModules = true
end

if cavebotCompat.enableSensitiveModules == nil and runtimeBisect then
  cavebotCompat.enableSensitiveModules = true
end

if cavebotCompat.setupEditor == nil then
  cavebotCompat.setupEditor = true
end

if cavebotCompat.setupConfigUi == nil then
  cavebotCompat.setupConfigUi = true
end

if cavebotCompat.setupExtensions == nil then
  cavebotCompat.setupExtensions = true
end

if cavebotCompat.bindMainConfig == nil then
  cavebotCompat.bindMainConfig = true
end

if not panelOnlyBisect then
  cavebotCompat.setupEditor = true
  cavebotCompat.setupConfigUi = true
  cavebotCompat.setupExtensions = true
  cavebotCompat.bindMainConfig = true
end

if cavebotCompat.loadMainUi then
  configWidget = UI.Config()
  ui = UI.createWidget("CaveBotPanel")

  ui.list = ui.listPanel.list -- shortcut
  CaveBot.actionList = ui.list

  if cavebotCompat.setupEditor and CaveBot.Editor then
    CaveBot.Editor.setup()
  end
  if cavebotCompat.setupConfigUi and CaveBot.Config then
    CaveBot.Config.setup()
  end
  if cavebotCompat.setupExtensions then
    for extension, callbacks in pairs(CaveBot.Extensions) do
      if callbacks.setup then
        callbacks.setup()
      end
    end
  end
end

-- main loop, controlled by config
local actionRetries = 0
local prevActionResult = true
cavebotMacro = macro(20, function()
  if not (cavebotCompat.loadMainRuntime or runtimeBisect) or not ui then return end
  if CaveBot.isFloorTransitionGuardActive and CaveBot.isFloorTransitionGuardActive() then
    CaveBot.resetWalking()
    return
  end
  if TargetBot and TargetBot.isActive() and not TargetBot.isCaveBotActionAllowed() then
    CaveBot.resetWalking()
    return -- target bot or looting is working, wait
  end
  
  if CaveBot.doWalking() then
    return -- executing walking3
  end
  
  local actions = ui.list:getChildCount()
  if actions == 0 then return end
  local currentAction = ui.list:getFocusedChild()
  if not currentAction then
    currentAction = ui.list:getFirstChild()
  end
  local action = CaveBot.Actions[currentAction.action]  
  local value = currentAction.value
  local retry = false
  if action then
    local status, result = pcall(function()
      CaveBot.resetWalking()
      return action.callback(value, actionRetries, prevActionResult)
    end)
    if status then
      if result == "retry" then
        actionRetries = actionRetries + 1
        retry = true
      elseif type(result) == 'boolean' then
        actionRetries = 0
        prevActionResult = result
      else
        warn("Invalid return from cavebot action (" .. currentAction.action .. "), should be \"retry\", false or true, is: " .. tostring(result))
      end
    else
      warn("warn while executing cavebot action (" .. currentAction.action .. "):\n" .. result)
    end    
  else
    warn("Invalid cavebot action: " .. currentAction.action)
  end
  
  if retry then
    return
  end
  
  if currentAction ~= ui.list:getFocusedChild() then
    -- focused child can change durring action, get it again and reset state
    currentAction = ui.list:getFocusedChild() or ui.list:getFirstChild()
    actionRetries = 0
    prevActionResult = true
  end
  local nextAction = ui.list:getChildIndex(currentAction) + 1
  if nextAction > actions then
    nextAction = 1
  end
  ui.list:focusChild(ui.list:getChildByIndex(nextAction))
end)

-- config, its callback is called immediately, data can be nil
local lastConfig = ""
if configWidget and cavebotCompat.bindMainConfig then
  config = Config.setup("cavebot_configs", configWidget, "cfg", function(name, enabled, data)
    if enabled and CaveBot.Recorder.isOn() then
      CaveBot.Recorder.disable()
      CaveBot.setOff()
      return    
    end

    local currentActionIndex = ui.list:getChildIndex(ui.list:getFocusedChild())
    ui.list:destroyChildren()
    if not data then return cavebotMacro.setOff() end
    
    local cavebotConfig = nil
    for k,v in ipairs(data) do
      if type(v) == "table" and #v == 2 then
        if v[1] == "config" then
          local status, result = pcall(function()
            return json.decode(v[2])
          end)
          if not status then
            warn("warn while parsing CaveBot extensions from config:\n" .. result)
          else
            cavebotConfig = result
          end
        elseif v[1] == "extensions" then
          local status, result = pcall(function()
            return json.decode(v[2])
          end)
          if not status then
            warn("warn while parsing CaveBot extensions from config:\n" .. result)
          else
            for extension, callbacks in pairs(CaveBot.Extensions) do
              if callbacks.onConfigChange then
                callbacks.onConfigChange(name, enabled, result[extension])
              end
            end
          end
        else
          CaveBot.addAction(v[1], v[2])
        end
      end
    end

    CaveBot.Config.onConfigChange(name, enabled, cavebotConfig)
    
    actionRetries = 0
    CaveBot.resetWalking()
    prevActionResult = true
    cavebotMacro.setOn(enabled)
    cavebotMacro.delay = nil
    if lastConfig == name then 
      -- restore focused child on the action list
      ui.list:focusChild(ui.list:getChildByIndex(currentActionIndex))
    end
    lastConfig = name  
  end)
end

local waypointMarkColor = "#00CCFF"
local shownMapWaypoints = {}

local function waypointKey(pos)
  return pos.x .. "," .. pos.y .. "," .. pos.z
end

local function parseMapWaypoint(action, value)
  action = action:lower()

  if action == "goto" or action == "stand" or action == "startlure" or action == "endlure" or action == "use" or action == "opendoors" or action == "cleartile" or action == "drop item" then
    local match = regexMatch(value, [[^\s*([0-9]+)\s*,\s*([0-9]+)\s*,\s*([0-9]+)]])
    if match[1] then
      return {x=tonumber(match[1][2]), y=tonumber(match[1][3]), z=tonumber(match[1][4])}
    end
  elseif action == "usewith" then
    local match = regexMatch(value, [[^\s*[0-9]+\s*,\s*([0-9]+)\s*,\s*([0-9]+)\s*,\s*([0-9]+)]])
    if match[1] then
      return {x=tonumber(match[1][2]), y=tonumber(match[1][3]), z=tonumber(match[1][4])}
    end
  elseif action == "supplycheck" then
    local match = regexMatch(value, [[^[^,]+,\s*([0-9]+)\s*,\s*([0-9]+)\s*,\s*([0-9]+)]])
    if match[1] then
      return {x=tonumber(match[1][2]), y=tonumber(match[1][3]), z=tonumber(match[1][4])}
    end
  end
end

CaveBot.clearMapWaypoints = function()
  for key, data in pairs(shownMapWaypoints) do
    local tile = g_map.getTile(data.pos)
    if tile then
      if tile:getText() == data.text then
        tile:setText("")
      end

      local thing = tile:getTopUseThing() or tile:getTopThing()
      if thing then
        thing:setMarked("")
      end
    end
  end
  shownMapWaypoints = {}
end

CaveBot.refreshMapWaypoints = function()
  CaveBot.clearMapWaypoints()

  if not storage.caveBotShowMapWaypoints then
    return
  end

  local mapWaypoints = {}
  for index, child in ipairs(ui.list:getChildren()) do
    local pos = parseMapWaypoint(child.action, child.value)
    if pos and pos.z == posz() then
      local key = waypointKey(pos)
      if not mapWaypoints[key] then
        mapWaypoints[key] = {pos=pos, labels={}}
      end
      table.insert(mapWaypoints[key].labels, "#" .. index .. " " .. child.action)
    end
  end

  for key, data in pairs(mapWaypoints) do
    local tile = g_map.getTile(data.pos)
    if tile then
      local text = table.concat(data.labels, "\n")
      tile:setText(text)

      local thing = tile:getTopUseThing() or tile:getTopThing()
      if thing then
        thing:setMarked(waypointMarkColor)
      end

      shownMapWaypoints[key] = {pos=data.pos, text=text}
    end
  end
end

storage.caveBotShowMapWaypoints = storage.caveBotShowMapWaypoints or false
if ui then
  ui.showMapWaypoints:setOn(storage.caveBotShowMapWaypoints)
  ui.showMapWaypoints.onClick = function(widget)
    storage.caveBotShowMapWaypoints = not storage.caveBotShowMapWaypoints
    widget:setOn(storage.caveBotShowMapWaypoints)
    CaveBot.refreshMapWaypoints()
  end

  macro(1000, function()
    if storage.caveBotShowMapWaypoints then
      CaveBot.refreshMapWaypoints()
    end
  end)

  -- ui callbacks
  ui.showEditor.onClick = function()
    if not CaveBot.Editor then return end
    if ui.showEditor:isOn() then
      CaveBot.Editor.hide()
      ui.showEditor:setOn(false)
    else
      CaveBot.Editor.show()
      ui.showEditor:setOn(true)
    end
  end

  ui.showConfig.onClick = function()
    if not CaveBot.Config then return end
    if ui.showConfig:isOn() then
      CaveBot.Config.hide()
      ui.showConfig:setOn(false)
    else
      CaveBot.Config.show()
      ui.showConfig:setOn(true)
    end
  end

  ui.autoRecording.onClick = function()
    if ui.autoRecording:isOn() then
      CaveBot.Recorder.disable()
      ui.autoRecording:setOn(false)
    else
      CaveBot.Recorder.enable()
      ui.autoRecording:setOn(true)
    end
  end
end

-- public function, you can use them in your scripts
CaveBot.isOn = function()
  if not config then return false end
  return config.isOn()
end

CaveBot.isOff = function()
  if not config then return true end
  return config.isOff()
end

CaveBot.setOn = function(val)
  if not config then return end
  if val == false then  
    return CaveBot.setOff(true)
  end
  config.setOn()
end

CaveBot.setOff = function(val)
  if not config then return end
  if val == false then  
    return CaveBot.setOn(true)
  end
  config.setOff()
end

CaveBot.getCurrentProfile = function()
  return storage._configs.cavebot_configs.selected
end

CaveBot.lastReachedLabel = function()
  return vBot.lastLabel
end

local function getWaypointPositionFromAction(action, value)
  if action ~= "goto" and action ~= "stand" and action ~= "startlure" and action ~= "endlure" then
    return nil
  end

  local re = regexMatch(value, [[([^,]+),([^,]+),([^,]+)]])
  if not re[1] then
    return nil
  end

  return {x = tonumber(re[1][2]), y = tonumber(re[1][3]), z = tonumber(re[1][4])}
end

CaveBot.gotoNextWaypointInRange = function()
  local currentAction = ui.list:getFocusedChild()
  local index = ui.list:getChildIndex(currentAction)
  local actions = ui.list:getChildren()

  -- start searching from current index
  for i, child in ipairs(actions) do
    if i > index then
      local pos = getWaypointPositionFromAction(child.action, child.value)
      if pos then
        if posz() == pos.z then
          local maxDist = storage.extras.gotoMaxDistance
          if distanceFromPlayer(pos) <= maxDist then
            if findPath(player:getPosition(), pos, maxDist, { ignoreNonPathable = true }) then
              ui.list:focusChild(ui.list:getChildByIndex(i-1))
              return true
            end
          end
        end
      end
    end
  end

  -- if not found then damn go from start
  for i, child in ipairs(actions) do
    if i <= index then
      local pos = getWaypointPositionFromAction(child.action, child.value)
      if pos then
        if posz() == pos.z then
          local maxDist = storage.extras.gotoMaxDistance
          if distanceFromPlayer(pos) <= maxDist then
            if findPath(player:getPosition(), pos, maxDist, { ignoreNonPathable = true }) then
              ui.list:focusChild(ui.list:getChildByIndex(i-1))
              return true
            end
          end
        end
      end
    end
  end

  -- not found
  return false
end

local function reverseTable(t, max)
  local reversedTable = {}
  local itemCount = max or #t
  for i, v in ipairs(t) do
      reversedTable[itemCount + 1 - i] = v
  end
  return reversedTable
end

function rpairs(t)
  test()
	return function(t, i)
		i = i - 1
		if i ~= 0 then
			return i, t[i]
		end
	end, t, #t + 1
end

CaveBot.gotoFirstPreviousReachableWaypoint = function()
  local currentAction = ui.list:getFocusedChild()
  local currentIndex = ui.list:getChildIndex(currentAction)
  local index = ui.list:getChildIndex(currentAction)

  -- check up to 100 childs
  for i=0,100 do
    index = index - i
    if index <= 0 or index > currentIndex or math.abs(index-currentIndex) > 100 then
      break
    end

    local child = ui.list:getChildByIndex(index)

    if child then
      local pos = getWaypointPositionFromAction(child.action, child.value)
      if pos then
        if posz() == pos.z then
          if distanceFromPlayer(pos) <= storage.extras.gotoMaxDistance/2 then
            print("found pos, going back "..currentIndex-index.. " waypoints.")
            return ui.list:focusChild(child)
          end
        end
      end
    end
  end

  -- not found
  print("previous pos not found, proceeding")
  return false
end

CaveBot.getFirstWaypointBeforeLabel = function(label)
  label = label:lower()
  local actions = ui.list:getChildren()
  local index

  -- find index of label
  for i, child in pairs(actions) do
    if child.action == "label" and child.value:lower() == label then
      index = i
      break
    end
  end

  -- if there's no index then label was not found
  if not index then return false end

  for i=1,#actions do
    if index - 1 < 1 then
      -- did not found any waypoint in range before label 
      return false
    end

    local child = ui.list:getChildByIndex(index-i)
    if child then
      local pos = getWaypointPositionFromAction(child.action, child.value)
      if pos then
        if posz() == pos.z then
          if distanceFromPlayer(pos) <= storage.extras.gotoMaxDistance/2 then
            return ui.list:focusChild(child)
          end
        end
      end
    end
  end
end

CaveBot.getPreviousLabel = function()
  local actions = ui.list:getChildren()
  -- check if config is empty
  if #actions == 0 then return false end

  local currentAction = ui.list:getFocusedChild()
  --check we made any progress in waypoints, if no focused or first then no point checking
  if not currentAction or currentAction == ui.list:getFirstChild() then return false end

  local index = ui.list:getChildIndex(currentAction)

  -- if not index then something went wrong and there's no selected child
  if not index then return false end

  for i=1,#actions do
    if index - i < 1 then
      -- did not found any waypoint in range before label 
      return false
    end

    local child = ui.list:getChildByIndex(index-i)
    if child then
      if child.action == "label" then
        return child.value
      end
    end
  end
end

CaveBot.getNextLabel = function()
  local actions = ui.list:getChildren()
  -- check if config is empty
  if #actions == 0 then return false end

  local currentAction = ui.list:getFocusedChild() or ui.list:getFirstChild()
  local index = ui.list:getChildIndex(currentAction)

  -- if not index then something went wrong
  if not index then return false end

  for i=1,#actions do
    if index + i > #actions then
      -- did not found any waypoint in range before label 
      return false
    end

    local child = ui.list:getChildByIndex(index+i)
    if child then
      if child.action == "label" then
        return child.value
      end
    end
  end
end

local botConfigName = modules.game_bot.contentsPanel.config:getCurrentOption().text
CaveBot.setCurrentProfile = function(name)
  if not g_resources.fileExists("/bot/"..botConfigName.."/cavebot_configs/"..name..".cfg") then
    return warn("there is no cavebot profile with that name!")
  end
  CaveBot.setOff()
  storage._configs.cavebot_configs.selected = name
  CaveBot.setOn()
end

CaveBot.delay = function(value)
  cavebotMacro.delay = math.max(cavebotMacro.delay or 0, now + value)
end

CaveBot.gotoLabel = function(label)
  label = label:lower()
  for index, child in ipairs(ui.list:getChildren()) do
    if child.action == "label" and child.value:lower() == label then    
      ui.list:focusChild(child)
      return true
    end
  end
  return false
end

CaveBot.save = function()
  local data = {}
  for index, child in ipairs(ui.list:getChildren()) do
    table.insert(data, {child.action, child.value})
  end
  
  if CaveBot.Config then
    table.insert(data, {"config", json.encode(CaveBot.Config.save())})
  end
  
  local extension_data = {}
  for extension, callbacks in pairs(CaveBot.Extensions) do
    if callbacks.onSave then
      local ext_data = callbacks.onSave()
      if type(ext_data) == "table" then
        extension_data[extension] = ext_data
      end
    end
  end
  table.insert(data, {"extensions", json.encode(extension_data, 2)})
  config.save(data)
end

CaveBotList = function()
  return ui.list
end
