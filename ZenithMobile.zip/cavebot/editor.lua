CaveBot.Editor = {}
CaveBot.Editor.Actions = {}
CaveBot.Editor.walkDirectionWindow = nil

local function ensureWalkDirectionWindow()
  if CaveBot.Editor.walkDirectionWindow then
    return CaveBot.Editor.walkDirectionWindow
  end

  local window = UI.createWindow("CaveBotWalkDirectionWindow", g_ui.getRootWidget())
  window:hide()
  window._callback = nil

  local function choose(direction)
    local callback = window._callback
    window._callback = nil
    window:hide()
    if callback then
      callback(direction)
    end
  end

  local buttonDirections = {
    nw = "nw",
    n = "n",
    ne = "ne",
    w = "w",
    c = "c",
    e = "e",
    sw = "sw",
    s = "s",
    se = "se"
  }

  for id, direction in pairs(buttonDirections) do
    local button = window.content[id]
    if button then
      button.onClick = function()
        choose(direction)
      end
    end
  end

  window.closeButton.onClick = function()
    window._callback = nil
    window:hide()
  end

  CaveBot.Editor.walkDirectionWindow = window
  return window
end

local function ensureExaniHurWindow()
  if CaveBot.Editor.exaniHurWindow then
    return CaveBot.Editor.exaniHurWindow
  end

  local window = UI.createWindow("CaveBotExaniHurWindow", g_ui.getRootWidget())
  window:hide()
  window._callback = nil
  window._mode = "up"
  window._direction = "n"

  local function refresh()
    local modeIds = {"up", "down"}
    for _, id in ipairs(modeIds) do
      local button = window.modePanel[id]
      if button then
        button:setColor(window._mode == id and "#66FF99" or "#FFFFFF")
      end
    end

    local directionIds = {"n", "e", "s", "w"}
    for _, id in ipairs(directionIds) do
      local button = window.directionPanel[id]
      if button then
        button:setColor(window._direction == id and "#66FF99" or "#FFFFFF")
      end
    end

    window.summary:setText('exani hur "' .. window._mode .. '" facing ' .. window._direction:upper())
  end

  window.modePanel.up.onClick = function()
    window._mode = "up"
    refresh()
  end

  window.modePanel.down.onClick = function()
    window._mode = "down"
    refresh()
  end

  for _, id in ipairs({"n", "e", "s", "w"}) do
    local directionId = id
    window.directionPanel[directionId].onClick = function()
      window._direction = directionId
      refresh()
    end
  end

  window.saveButton.onClick = function()
    local callback = window._callback
    local value = window._mode .. "," .. window._direction
    window._callback = nil
    window:hide()
    if callback then
      callback(value)
    end
  end

  window.cancelButton.onClick = function()
    window._callback = nil
    window:hide()
  end

  window.refresh = refresh
  CaveBot.Editor.exaniHurWindow = window
  return window
end

local function openExaniHurEditor(currentValue, callback)
  local window = ensureExaniHurWindow()
  local parts = string.split(tostring(currentValue or "up,n"), ",")
  local mode = parts[1] and parts[1]:lower():trim() or "up"
  local direction = parts[2] and parts[2]:lower():trim() or "n"

  if mode ~= "up" and mode ~= "down" then mode = "up" end
  if direction ~= "n" and direction ~= "e" and direction ~= "s" and direction ~= "w" then
    direction = "n"
  end

  window._mode = mode
  window._direction = direction
  window._callback = callback
  window.refresh()
  window:show()
  window:raise()
  window:focus()
end

local function ensureStowAllWindow()
  if CaveBot.Editor.stowAllWindow then
    return CaveBot.Editor.stowAllWindow
  end

  local window = UI.createWindow("CaveBotStowAllWindow", g_ui.getRootWidget())
  window:hide()
  window._callback = nil
  window._mode = "guardar"

  local function refresh()
    for _, id in ipairs({"guardar", "remover"}) do
      local button = window.modePanel[id]
      if button then
        button:setColor(window._mode == id and "#66FF99" or "#FFFFFF")
      end
    end
    window.summary:setText("stow all: " .. window._mode)
  end

  window.modePanel.guardar.onClick = function()
    window._mode = "guardar"
    refresh()
  end

  window.modePanel.remover.onClick = function()
    window._mode = "remover"
    refresh()
  end

  window.saveButton.onClick = function()
    local callback = window._callback
    local value = window._mode
    window._callback = nil
    window:hide()
    if callback then
      callback(value)
    end
  end

  window.cancelButton.onClick = function()
    window._callback = nil
    window:hide()
  end

  window.refresh = refresh
  CaveBot.Editor.stowAllWindow = window
  return window
end

local function openStowAllEditor(currentValue, callback)
  local window = ensureStowAllWindow()
  local mode = tostring(currentValue or "guardar"):lower():trim()
  if mode ~= "guardar" and mode ~= "remover" then
    mode = "guardar"
  end

  window._mode = mode
  window._callback = callback
  window.refresh()
  window:show()
  window:raise()
  window:focus()
end
CaveBot.Editor.openStowAllEditor = openStowAllEditor

local function openWalkDirectionPicker(currentValue, callback)
  local window = ensureWalkDirectionWindow()
  window._callback = callback
  window:show()
  window:raise()
  window:focus()
end

-- also works as registerAction(action, params), then text == action
-- params are options for text editor or function to be executed when clicked
-- you have many examples how to use it bellow
CaveBot.Editor.registerAction = function(action, text, params)
  if type(text) ~= 'string' then
    params = text
    text = action
  end

  local color = nil
  if type(params) ~= 'function' then
    local raction = CaveBot.Actions[action]
    if not raction then
      return warn("CaveBot editor warn: action " .. action .. " doesn't exist")
    end
    CaveBot.Editor.Actions[action] = params
    color = raction.color
  end
  
  local button = UI.createWidget('CaveBotEditorButton', CaveBot.Editor.ui.buttons)
  button:setText(text)
  if color then
    button:setColor(color)
  end
  button:setFont('verdana-11px-rounded')
  button.onClick = function()    
    if type(params) == 'function' then
      params()
      return
    end
    CaveBot.Editor.edit(action, nil, function(action, value)
      local focusedAction = CaveBot.actionList:getFocusedChild()
      local index = CaveBot.actionList:getChildCount()
      if focusedAction then
        index = CaveBot.actionList:getChildIndex(focusedAction)
      end
      local widget = CaveBot.addAction(action, value)
      CaveBot.actionList:moveChildToIndex(widget, index + 1)
      CaveBot.actionList:focusChild(widget)
      CaveBot.refreshActionListNumbers()
      CaveBot.save()
    end)
  end
  return button
end

CaveBot.Editor.setup = function()
  CaveBot.Editor.ui = UI.createWidget("CaveBotEditorPanel")
  local ui = CaveBot.Editor.ui
  local registerAction = CaveBot.Editor.registerAction

  registerAction("move up", function()
    local action = CaveBot.actionList:getFocusedChild()
    if not action then return end
    local index = CaveBot.actionList:getChildIndex(action)
    if index < 2 then return end
    CaveBot.actionList:moveChildToIndex(action, index - 1)
    CaveBot.actionList:ensureChildVisible(action)
    CaveBot.refreshActionListNumbers()
    CaveBot.save()
  end)
  registerAction("edit", function()
    local action = CaveBot.actionList:getFocusedChild()
    if not action or not action.onDoubleClick then return end
    action.onDoubleClick(action)
  end)
  registerAction("move down", function()
    local action = CaveBot.actionList:getFocusedChild()
    if not action then return end
    local index = CaveBot.actionList:getChildIndex(action)
    if index >= CaveBot.actionList:getChildCount() then return end
    CaveBot.actionList:moveChildToIndex(action, index + 1)
    CaveBot.actionList:ensureChildVisible(action)
    CaveBot.refreshActionListNumbers()
    CaveBot.save()
  end)
  registerAction("remove", function()
    local action = CaveBot.actionList:getFocusedChild()
    if not action then return end
    action:destroy()
    CaveBot.refreshActionListNumbers()
    CaveBot.save()
  end)
    
  registerAction("label", {
    value="labelName",
    title="Label",
    description="Add label",
    multiline=false   
  })
  registerAction("delay", {
    value="500",
    title="Delay",
    description="Delay next action (in milliseconds),randomness (in percent-optional)",
    multiline=false,
    validation="^[0-9]{1,10}$|^[0-9]{1,10},[0-9]{1,4}$"
  })
  registerAction("gotolabel", "go to label", {
    value="labelName",
    title="Go to label",
    description="Go to label",
    multiline=false   
  })
  registerAction("goto", "go to", {
    value=function() return posx() .. "," .. posy() .. "," .. posz() end,
    title="Go to position",
    description="Go to position (x,y,z)",
    multiline=false,
    validation="^\\s*([0-9]+)\\s*,\\s*([0-9]+)\\s*,\\s*([0-9]+),?\\s*([0-9]?)$"
  })
  registerAction("walk", {
    value="n",
    title="Walk",
    description="Walk one tile in a chosen direction",
    multiline=false,
    customEditor=function(currentValue, callback)
      openWalkDirectionPicker(currentValue, callback)
    end
  })
  registerAction("exani hur", "Exani Hur", {
    value="up,n",
    title="Exani Hur",
    description="Use Levitate persistently until the character changes floor",
    multiline=false,
    customEditor=function(currentValue, callback)
      openExaniHurEditor(currentValue, callback)
    end
  })
  registerAction("stand", {
    value=function() return posx() .. "," .. posy() .. "," .. posz() end,
    title="Stand",
    description="Stand exactly on position (x,y,z)",
    multiline=false,
    validation="^\\s*([0-9]+)\\s*,\\s*([0-9]+)\\s*,\\s*([0-9]+)$"
  })
  registerAction("checkcontainers", "check containers", {
    value="refill",
    title="Check Containers",
    description="Go to label if all carried containers are full",
    multiline=false,
    validation="^[^,]+$"
  })
  registerAction("use", {
    value=function() return posx() .. "," .. posy() .. "," .. posz() end,
    title="Use",
    description="Use item from position (x,y,z) or from inventory (itemId)",
    multiline=false   
  }) 
  registerAction("usewith", "use with", {
    value=function() return "itemId," .. posx() .. "," .. posy() .. "," .. posz() end,
    title="Use with",
    description="Use item at position (itemid,x,y,z)",
    multiline=false,
    validation="^\\s*([0-9]+)\\s*,\\s*([0-9]+)\\s*,\\s*([0-9]+)\\s*,\\s*([0-9]+)$"
  })
  registerAction("say", {
    value="text",
    title="Say",
    description="Enter text to say",
    multiline=false   
  }) 
  registerAction("follow", {
    value="NPC name",
    title="Follow Creature",
    description="insert creature name to follow",
    multiline=false   
  })
  registerAction("npcsay", {
    value="text",
    title="NPC Say",
    description="Enter text to NPC say",
    multiline=false   
  }) 
  registerAction("function", {
    title="Edit bot function",
    multiline=true,
    value=CaveBot.Editor.ExampleFunctions[1][2],
    examples=CaveBot.Editor.ExampleFunctions,
    width=650
  })
  
  -- ui.autoRecording.onClick = function()
  --   if ui.autoRecording:isOn() then
  --     CaveBot.Recorder.disable()
  --   else
  --     CaveBot.Recorder.enable()
  --   end
  -- end
  
  -- callbacks
  onPlayerPositionChange(function(pos)
    ui.pos:setText("Position: " .. pos.x .. ", " .. pos.y .. ", " .. pos.z) 
  end)
  ui.pos:setText("Position: " .. posx() .. ", " .. posy() .. ", " .. posz()) 
end

CaveBot.Editor.show = function()
  CaveBot.Editor.ui:show()
end


CaveBot.Editor.hide = function()
  CaveBot.Editor.ui:hide()
end

CaveBot.Editor.edit = function(action, value, callback) -- callback = function(action, value)
  local params = CaveBot.Editor.Actions[action]
  if not params then return end
  if not value then
    if type(params.value) == 'function' then
      value = params.value()
    elseif type(params.value) == 'string' then
      value = params.value
    end
  end

  if params.customEditor then
    return params.customEditor(value, function(newText)
      callback(action, newText)
    end)
  end

  UI.EditorWindow(value, params, function(newText)
    callback(action, newText)
  end)   
end
