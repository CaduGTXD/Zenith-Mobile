-- config for bot
CaveBot.Config = {}
CaveBot.Config.values = {}
CaveBot.Config.default_values = {}
CaveBot.Config.value_setters = {}
CaveBot.Config.widgets = {}
CaveBot.Config.lureWindow = nil
CaveBot.Config.lureMageRunWidgets = {}

local function setSliderLabel(panel, title, value)
  panel.title:setText(tostring(title or "") .. ": " .. value)
end

CaveBot.Config.registerVirtualSlider = function(id, title, defaultValue)
  if CaveBot.Config.default_values[id] ~= nil then
    return warn("Duplicated config key: " .. id)
  end

  CaveBot.Config.values[id] = defaultValue
  CaveBot.Config.default_values[id] = defaultValue
  CaveBot.Config.value_setters[id] = function(value)
    value = tonumber(value) or defaultValue
    CaveBot.Config.values[id] = value

    local panel = CaveBot.Config.widgets[id]
    if panel and panel.scroll then
      panel.scroll:setValue(value)
      setSliderLabel(panel, title, value)
    end
  end
end

CaveBot.Config.registerVirtualBoolean = function(id, title, defaultValue)
  if CaveBot.Config.default_values[id] ~= nil then
    return warn("Duplicated config key: " .. id)
  end

  defaultValue = defaultValue and true or false
  CaveBot.Config.values[id] = defaultValue
  CaveBot.Config.default_values[id] = defaultValue
  CaveBot.Config.value_setters[id] = function(value)
    value = value and true or false
    CaveBot.Config.values[id] = value

    local panel = CaveBot.Config.widgets[id]
    if panel and panel.value then
      panel.value:setOn(value, true)
    end
  end
end

CaveBot.Config.ensureLureWindow = function()
  if CaveBot.Config.lureWindow then
    return CaveBot.Config.lureWindow
  end

  CaveBot.Config.lureWindow = UI.createWindow("CaveBotLureConfigWindow", g_ui.getRootWidget())
  CaveBot.Config.lureWindow:hide()

  local function addSection(text, tooltip)
    local separator = UI.createWidget("CaveBotConfigSectionSeparator", CaveBot.Config.lureWindow.content)
    if tooltip then separator:setTooltip(tooltip) end
    local section = UI.createWidget("CaveBotConfigSection", CaveBot.Config.lureWindow.content)
    section:setText(text)
    if tooltip then section:setTooltip(tooltip) end
  end

  addSection("Minimum creatures", "Rules for how many configured creatures are required before stopping at End Lure.")
  CaveBot.Config.addSlider("lureMinCreature", "Min creature", 0, 30, 1, CaveBot.Config.lureWindow.content, "Minimum configured creatures required at End Lure to stop and kill.")
  CaveBot.Config.addSlider("lureCreatureRange", "Creature range", 1, 15, 8, CaveBot.Config.lureWindow.content, "Shared Mage Run detection radius: Start/End Lure counts, Ignore remaining, lure walking, TargetBot scanning and target path search.")

  addSection("Lure walk", "Controls when the bot should walk using the Lure walk delay while pulling creatures.")
  CaveBot.Config.addSlider("minLure", "Min lure (walk)", 0, 30, 1, CaveBot.Config.lureWindow.content, "Minimum configured creatures on screen to use Lure walk delay.")
  CaveBot.Config.addSlider("lureMaxToWalk", "Max lure (walk)", 0, 30, 8, CaveBot.Config.lureWindow.content, "Maximum configured creatures to keep using Lure walk delay. Above this value, the bot keeps walking normally without the lure walk delay.")
  CaveBot.Config.addSlider("lureWalkDelay", "Lure walk delay", 0, 5000, 100, CaveBot.Config.lureWindow.content, "Extra walking delay used only between Min lure (walk) and Max lure (walk).")

  local mageRunSeparator = UI.createWidget("CaveBotConfigSectionSeparator", CaveBot.Config.lureWindow.content)
  mageRunSeparator:setTooltip("Extra lure safety settings used only while TargetBot attack style is Mage run.")
  local mageRunSection = UI.createWidget("CaveBotConfigSection", CaveBot.Config.lureWindow.content)
  mageRunSection:setText("Mage run")
  mageRunSection:setTooltip("Extra lure safety settings used only while TargetBot attack style is Mage run.")
  local adjacentPanel = CaveBot.Config.addSlider("lureAdjacentMax", "Adjacent lure", 0, 8, 1, CaveBot.Config.lureWindow.content, "Maximum adjacent monsters allowed while luring before switching to fast sequential movement toward End Lure.")
  local minRangePanel = CaveBot.Config.addSlider("lureMageRunMinRange", "Safe distance", 1, 6, 3, CaveBot.Config.lureWindow.content, "Minimum preferred distance from the nearest configured monster while kiting.")
  local maxRangePanel = CaveBot.Config.addSlider("lureMageRunMaxRange", "Kiting max distance", 2, 8, 6, CaveBot.Config.lureWindow.content, "Maximum normal kiting distance from the nearest configured monster. Creature range controls detection and target scanning for the entire Mage Run stack.")
  local arenaPanel = CaveBot.Config.addSlider("lureMageRunArenaRadius", "Arena radius", 3, 15, 5, CaveBot.Config.lureWindow.content, "Maximum normal distance from the End Lure point. Emergency movement may temporarily use Arena radius + 2.")
  local decisionPanel = CaveBot.Config.addSlider("lureMageRunDecisionDelay", "Decision hold", 200, 1500, 650, CaveBot.Config.lureWindow.content, "Milliseconds to keep a safe destination before choosing another one. Higher values reduce direction changes.")
  local carryPanel = CaveBot.Config.addCheckBox("lureMageRunCarryRemaining", "Carry remaining", false, CaveBot.Config.lureWindow.content, "Mage Run only: when at most two configured creatures remain above Ignore remaining, leave End Lure and pull them with Lure walk delay until the next waypoint. Adjacent lure still switches the walk to fast movement when needed.")
  local debugPanel = CaveBot.Config.addCheckBox("lureMageRunDebugPath", "Debug path", false, CaveBot.Config.lureWindow.content, "Marks the Mage Run chosen path with colored tiles for a short time.")
  CaveBot.Config.lureMageRunWidgets = {mageRunSeparator, mageRunSection, adjacentPanel, minRangePanel, maxRangePanel, arenaPanel, decisionPanel, carryPanel, debugPanel}

  addSection("Ignore remaining", "Controls when the bot can leave End Lure with a few configured creatures still alive.")
  CaveBot.Config.addSlider("lureIgnoreRemaining", "Ignore remaining", 0, 32, 0, CaveBot.Config.lureWindow.content, "Maximum configured creatures allowed to remain before leaving End Lure.")
  CaveBot.Config.addSlider("lureIgnoreHp", "HP %", 0, 100, 0, CaveBot.Config.lureWindow.content, "Remaining creatures above this HP can be ignored. Creatures at or below this HP are killed. 0 disables HP filtering.")

  CaveBot.Config.lureWindow.closeButton.onClick = function()
    CaveBot.Config.lureWindow:hide()
  end

  CaveBot.Config.refreshTargetMode()

  return CaveBot.Config.lureWindow
end

CaveBot.Config.setup = function()
  CaveBot.Config.ui = UI.createWidget("CaveBotConfigPanel")
  local ui = CaveBot.Config.ui
  local add = CaveBot.Config.add
  
  add("ping", "Server ping", 100)
  add("walkDelay", "Walk delay", 10)
  add("floorChangeDelay", "Floor change delay", 850)
  add("recordDistance", "Record distance", 5)

  CaveBot.Config.registerVirtualSlider("lureMinCreature", "Min creature", 1)
  CaveBot.Config.registerVirtualSlider("lureCreatureRange", "Creature range", 8)
  CaveBot.Config.registerVirtualSlider("minLure", "Min lure (walk)", 1)
  CaveBot.Config.registerVirtualSlider("lureMaxToWalk", "Max lure (walk)", 8)
  CaveBot.Config.registerVirtualSlider("lureWalkDelay", "Lure walk delay", 100)
  CaveBot.Config.registerVirtualSlider("lureAdjacentMax", "Adjacent lure", 1)
  CaveBot.Config.registerVirtualSlider("lureMageRunMinRange", "Safe distance", 3)
  CaveBot.Config.registerVirtualSlider("lureMageRunMaxRange", "Kiting max distance", 6)
  CaveBot.Config.registerVirtualSlider("lureMageRunArenaRadius", "Arena radius", 5)
  CaveBot.Config.registerVirtualSlider("lureMageRunDecisionDelay", "Decision hold", 650)
  CaveBot.Config.registerVirtualBoolean("lureMageRunCarryRemaining", "Carry remaining", false)
  CaveBot.Config.registerVirtualBoolean("lureMageRunDebugPath", "Debug path", false)
  CaveBot.Config.registerVirtualSlider("lureIgnoreRemaining", "Ignore remaining", 0)
  CaveBot.Config.registerVirtualSlider("lureIgnoreHp", "HP %", 0)

  local lureButton = UI.createWidget("CaveBotConfigOpenButton", CaveBot.Config.ui)
  lureButton:setText("Config")
  lureButton:setTooltip("Open lure settings.")
  lureButton.onClick = function()
    local window = CaveBot.Config.ensureLureWindow()
    CaveBot.Config.refreshTargetMode()
    window:show()
    window:raise()
    window:focus()
  end

  add("mapClick", "Use map click", false)
  add("mapClickDelay", "Map click delay", 100)
  add("ignoreFields", "Ignore fields", false)  
  add("skipBlocked", "Skip blocked path", false)  
  add("useDelay", "Delay after use", 400)
end

CaveBot.Config.refreshTargetMode = function()
  local showMageRun = TargetBot and TargetBot.isMageRunMode and TargetBot.isMageRunMode()
  for _, widget in ipairs(CaveBot.Config.lureMageRunWidgets or {}) do
    if widget then
      if showMageRun then
        widget:show()
      else
        widget:hide()
      end
    end
  end
end

CaveBot.Config.show = function()
  CaveBot.Config.ui:show()
end

CaveBot.Config.hide = function()
  CaveBot.Config.ui:hide()
  if CaveBot.Config.lureWindow then
    CaveBot.Config.lureWindow:hide()
  end
end

CaveBot.Config.onConfigChange = function(configName, isEnabled, configData)
  for k, v in pairs(CaveBot.Config.default_values) do
    CaveBot.Config.value_setters[k](v)
  end
  if not configData then return end
  for k, v in pairs(configData) do
    if CaveBot.Config.value_setters[k] then
      CaveBot.Config.value_setters[k](v)
    end
  end
end

CaveBot.Config.save = function()
  local data = {}
  for k, v in pairs(CaveBot.Config.default_values) do
    data[k] = v
  end
  for k, v in pairs(CaveBot.Config.values) do
    data[k] = v
  end
  return data
end

CaveBot.Config.add = function(id, title, defaultValue)
  if CaveBot.Config.values[id] then
    return warn("Duplicated config key: " .. id)
  end
    
  local panel
  local setter -- sets value
  if type(defaultValue) == "number" then
    panel = UI.createWidget("CaveBotConfigNumberValuePanel", CaveBot.Config.ui)
    panel:setId(id)
    setter = function(value)
      CaveBot.Config.values[id] = value
      panel.value:setText(value, true)
    end
    setter(defaultValue)
    panel.value.onTextChange = function(widget, newValue)
      newValue = tonumber(newValue)
      if newValue then
        CaveBot.Config.values[id] = newValue
        CaveBot.save()
      end
    end
  elseif type(defaultValue) == "boolean" then
    panel = UI.createWidget("CaveBotConfigBooleanValuePanel", CaveBot.Config.ui)
    panel:setId(id)
    setter = function(value)
      CaveBot.Config.values[id] = value
      panel.value:setOn(value, true)
    end
    setter(defaultValue)
    panel.value.onClick = function(widget)
      widget:setOn(not widget:isOn())
      CaveBot.Config.values[id] = widget:isOn()
      CaveBot.save()
    end
  else
    return warn("Invalid default value of config for key " .. id .. ", should be number or boolean")      
  end
  
  panel.title:setText(tostring(title or "") .. ":")
  
  CaveBot.Config.value_setters[id] = setter
  CaveBot.Config.values[id] = defaultValue
  CaveBot.Config.default_values[id] = defaultValue
  CaveBot.Config.widgets[id] = panel
end

CaveBot.Config.addCheckBox = function(id, title, defaultValue, parent, tooltip)
  if CaveBot.Config.widgets[id] then
    return warn("Duplicated config key: " .. id)
  end

  local panel = UI.createWidget("CaveBotConfigBooleanValuePanel", parent or CaveBot.Config.ui)
  panel:setId(id)
  if tooltip then
    panel:setTooltip(tooltip)
    panel.title:setTooltip(tooltip)
    panel.value:setTooltip(tooltip)
  end

  local currentValue = CaveBot.Config.values[id]
  if currentValue == nil then
    currentValue = defaultValue and true or false
  end

  local setter = function(value)
    value = value and true or false
    CaveBot.Config.values[id] = value
    panel.value:setOn(value, true)
  end

  panel.title:setText(tostring(title or "") .. ":")
  panel.value.onClick = function(widget)
    widget:setOn(not widget:isOn())
    CaveBot.Config.values[id] = widget:isOn()
    CaveBot.save()
  end

  CaveBot.Config.value_setters[id] = setter
  CaveBot.Config.default_values[id] = defaultValue and true or false
  CaveBot.Config.widgets[id] = panel
  setter(currentValue)
  return panel
end

CaveBot.Config.addSlider = function(id, title, minValue, maxValue, defaultValue, parent, tooltip)
  if CaveBot.Config.widgets[id] then
    return warn("Duplicated config key: " .. id)
  end

  local panel = UI.createWidget("CaveBotConfigSliderValuePanel", parent or CaveBot.Config.ui)
  panel:setId(id)
  if tooltip then
    panel:setTooltip(tooltip)
    panel.title:setTooltip(tooltip)
    panel.scroll:setTooltip(tooltip)
  end
  local silent = false

  local function setLabel(value)
    panel.title:setText(tostring(title or "") .. ": " .. value)
  end

  local currentValue = CaveBot.Config.values[id]
  if currentValue == nil then
    currentValue = defaultValue
  end

  local setter = function(value)
    value = tonumber(value) or defaultValue
    CaveBot.Config.values[id] = value
    silent = true
    panel.scroll:setValue(value)
    silent = false
    setSliderLabel(panel, title, value)
  end

  panel.scroll:setRange(minValue, maxValue)
  if maxValue - minValue > 1000 then
    panel.scroll:setStep(100)
  elseif maxValue - minValue > 100 then
    panel.scroll:setStep(10)
  else
    panel.scroll:setStep(1)
  end

  panel.scroll.onValueChange = function(widget, value)
    CaveBot.Config.values[id] = value
    setSliderLabel(panel, title, value)
    if silent then return end
    CaveBot.save()
  end

  CaveBot.Config.value_setters[id] = setter
  CaveBot.Config.default_values[id] = defaultValue
  CaveBot.Config.widgets[id] = panel
  setter(currentValue)
  return panel
end

CaveBot.Config.get = function(id)
  if CaveBot.Config.values[id] == nil then
    return warn("Invalid CaveBot.Config.get, id: " .. id)
  end
  return CaveBot.Config.values[id]
end

CaveBot.Config.set = function(id, value)
  local valueType = CaveBot.Config.get(id)
  local panel = CaveBot.Config.widgets[id] or CaveBot.Config.ui[id] or (CaveBot.Config.lureWindow and CaveBot.Config.lureWindow.content[id])

  if not panel then
    CaveBot.Config.values[id] = value
    CaveBot.save()
    return
  end

  if type(valueType) == 'boolean' then
    CaveBot.Config.values[id] = value
    panel.value:setOn(value, true)
    CaveBot.save()
  elseif panel.scroll then
    CaveBot.Config.values[id] = value
    panel.scroll:setValue(value)
    CaveBot.save()
  else
    CaveBot.Config.values[id] = value
    panel.value:setText(value, true)
    CaveBot.save()
  end
end
