CaveBot.Extensions.SellAll = {}

local SELL = 2

local MAX_RETRIES = 180
local MAX_TRADE_ATTEMPTS = 8
local MAX_NO_PROGRESS = 6

local state = {
  key = nil,
  lastTalkAt = 0,
  tradeAttempts = 0,
  tradeOpenedAt = 0,
  lastFingerprint = nil,
  lastSellAt = 0,
  noProgress = 0
}

local function resetState(key)
  state.key = key
  state.lastTalkAt = 0
  state.tradeAttempts = 0
  state.tradeOpenedAt = 0
  state.lastFingerprint = nil
  state.lastSellAt = 0
  state.noProgress = 0
end

local function trim(text)
  return tostring(text or ""):gsub("^%s+", ""):gsub("%s+$", "")
end

local function nowMs()
  if type(now) == "number" then
    return now
  end

  if g_clock and g_clock.millis then
    local ok, result = pcall(function()
      return g_clock.millis()
    end)

    if ok and result then
      return result
    end
  end

  return os.time() * 1000
end

local function hasAnyEntry(tbl)
  if type(tbl) ~= "table" then
    return false
  end

  for _, _ in pairs(tbl) do
    return true
  end

  return false
end

local function getTalkDelay(default)
  default = default or 1000

  if storage and storage.coreSettings and storage.coreSettings.talkDelay then
    return math.max(
      tonumber(storage.coreSettings.talkDelay) or default,
      300
    )
  end

  return math.max(default, 300)
end

local function stopMoving()
  pcall(function()
    player:stopAutoWalk()
  end)

  pcall(function()
    g_game.stop()
  end)
end

local function sayNpc(text)
  if NPC and NPC.say then
    local ok = pcall(function()
      NPC.say(text)
    end)

    if ok then
      return true
    end
  end

  if g_game and g_game.talkChannel then
    local ok = pcall(function()
      g_game.talkChannel(11, 0, text)
    end)

    if ok then
      return true
    end
  end

  if type(say) == "function" then
    local ok = pcall(function()
      say(text)
    end)

    if ok then
      return true
    end
  end

  return false
end

local function widgetVisible(widget)
  if not widget or not widget.isVisible then
    return false
  end

  local ok, visible = pcall(function()
    return widget:isVisible()
  end)

  return ok and visible
end

local function findNpcTradeWindow()
  local tradeModule = modules and modules.game_npctrade

  if tradeModule and tradeModule.npcWindow then
    return tradeModule.npcWindow
  end

  local roots = {}

  if rootWidget then
    table.insert(roots, rootWidget)
  end

  if g_ui and g_ui.getRootWidget then
    local ok, root = pcall(function()
      return g_ui.getRootWidget()
    end)

    if ok and root then
      table.insert(roots, root)
    end
  end

  if modules and modules.game_interface then
    if modules.game_interface.getRootPanel then
      local ok, root = pcall(function()
        return modules.game_interface.getRootPanel()
      end)

      if ok and root then
        table.insert(roots, root)
      end
    end
  end

  for _, root in ipairs(roots) do
    if root and root.recursiveGetChildById then
      local ok, widget = pcall(function()
        return root:recursiveGetChildById("npcWindow")
      end)

      if ok and widget then
        return widget
      end
    end
  end

  return nil
end

local function isTradeOpen()
  if NPC and NPC.isTrading then
    local ok, result = pcall(function()
      return NPC.isTrading()
    end)

    if ok and result then
      return true
    end
  end

  return widgetVisible(findNpcTradeWindow())
end

local function closeTrade()
  if NPC and NPC.closeTrade then
    pcall(function()
      NPC.closeTrade()
    end)
    return
  end

  if modules
    and modules.game_npctrade
    and modules.game_npctrade.closeNpcTrade then

    pcall(function()
      modules.game_npctrade.closeNpcTrade()
    end)
    return
  end

  if g_game and g_game.closeNpcTrade then
    pcall(function()
      g_game.closeNpcTrade()
    end)
  end
end

local function getTradeModule()
  return modules and modules.game_npctrade
end

local function getSellTradeList()
  local tradeModule = getTradeModule()

  if not tradeModule or type(tradeModule.tradeItems) ~= "table" then
    return nil
  end

  local sellIndex = tradeModule.SELL or SELL
  local list = tradeModule.tradeItems[sellIndex]

  if type(list) == "table" then
    return list
  end

  return nil
end

local function getPlayerItems()
  local tradeModule = getTradeModule()

  if tradeModule and type(tradeModule.playerItems) == "table" then
    return tradeModule.playerItems
  end

  return {}
end

local function shouldIgnoreEquipped()
  local tradeModule = getTradeModule()
  local widget = tradeModule and tradeModule.ignoreEquipped

  if widget and widget.isChecked then
    local ok, checked = pcall(function()
      return widget:isChecked()
    end)

    if ok then
      return checked
    end
  end

  -- Mais seguro: não vender itens equipados por padrão.
  return true
end

local function getEquippedAmount(id)
  local localPlayer = nil

  if g_game and g_game.getLocalPlayer then
    localPlayer = g_game.getLocalPlayer()
  end

  if not localPlayer then
    return 0
  end

  local firstSlot = InventorySlotFirst or 1
  local lastSlot = InventorySlotLast or 10
  local amount = 0

  for slot = firstSlot, lastSlot do
    local item = localPlayer:getInventoryItem(slot)

    if item and item:getId() == id then
      amount = amount + math.max(item:getCount(), 1)
    end
  end

  return amount
end

local function getSellQuantity(id, itemPtr, ignoreEquipped)
  local tradeModule = getTradeModule()

  if tradeModule
    and tradeModule.getSellQuantity
    and itemPtr then

    local ok, amount = pcall(function()
      return tradeModule.getSellQuantity(itemPtr)
    end)

    if ok and type(amount) == "number" then
      return math.max(amount, 0)
    end
  end

  local playerItems = getPlayerItems()
  local amount = tonumber(playerItems[id]) or 0

  if ignoreEquipped then
    amount = amount - getEquippedAmount(id)
  end

  return math.max(amount, 0)
end

local function getMaxSellAmount()
  if g_game
    and g_game.getFeature
    and GameDoubleShopSellAmount
    and g_game.getFeature(GameDoubleShopSellAmount) then

    return 10000
  end

  return 100
end

local function buildExceptionList(exceptions)
  local list = {}

  if type(exceptions) ~= "table" then
    return list
  end

  for id, enabled in pairs(exceptions) do
    if enabled then
      table.insert(list, tonumber(id) or id)
    end
  end

  table.sort(list, function(a, b)
    return tostring(a) < tostring(b)
  end)

  return list
end

local function runNativeSellAll(delayed, exceptions)
  local tradeModule = getTradeModule()

  if not tradeModule or type(tradeModule.sellAll) ~= "function" then
    return false
  end

  local ok = pcall(function()
    tradeModule.sellAll(delayed, buildExceptionList(exceptions))
  end)

  return ok
end

local function parseSettings(value)
  local parts = string.split(tostring(value or ""), ",")
  local npcName = trim(parts[1])
  local sellWithDelay = false
  local exceptions = {}

  for i = 2, #parts do
    local token = trim(parts[i])
    local lowerToken = token:lower()

    if lowerToken == "yes"
      or lowerToken == "sim"
      or lowerToken == "true" then

      sellWithDelay = true
    else
      local id = tonumber(token)

      if id then
        exceptions[id] = true
      elseif token ~= "" then
        warn(
          "CaveBot[SellAll]: invalid parameter ignored: " ..
          token
        )
      end
    end
  end

  -- Itens configurados em cavebotSell continuam sendo exceções.
  if storage and type(storage.cavebotSell) == "table" then
    for _, item in ipairs(storage.cavebotSell) do
      local id = nil

      if type(item) == "number" then
        id = item
      elseif type(item) == "table" then
        id = tonumber(item.id)
      end

      if id then
        exceptions[id] = true
      end
    end
  end

  return npcName, sellWithDelay, exceptions
end

local function buildSellList(exceptions)
  local tradeList = getSellTradeList()
  local ignoreEquipped = shouldIgnoreEquipped()
  local sellList = {}
  local seen = {}

  if type(tradeList) ~= "table" then
    return sellList
  end

  for _, tradeData in pairs(tradeList) do
    local itemPtr = tradeData and tradeData.ptr

    if itemPtr and itemPtr.getId then
      local ok, id = pcall(function()
        return itemPtr:getId()
      end)

      if ok
        and id
        and not seen[id]
        and not exceptions[id] then

        seen[id] = true

        local amount = getSellQuantity(
          id,
          itemPtr,
          ignoreEquipped
        )

        if amount > 0 then
          table.insert(sellList, {
            id = id,
            amount = amount,
            ptr = itemPtr
          })
        end
      end
    end
  end

  table.sort(sellList, function(a, b)
    return a.id < b.id
  end)

  return sellList
end

local function getFingerprint(sellList)
  local parts = {}

  for _, entry in ipairs(sellList) do
    table.insert(
      parts,
      tostring(entry.id) .. ":" .. tostring(entry.amount)
    )
  end

  return table.concat(parts, "|")
end

local function sellEntry(entry, ignoreEquipped)
  if not entry or not entry.ptr then
    return false
  end

  if not g_game or not g_game.sellItem then
    return false
  end

  local amount = math.max(
    0,
    math.min(tonumber(entry.amount) or 0, getMaxSellAmount())
  )

  if amount <= 0 then
    return false
  end

  local ok = pcall(function()
    g_game.sellItem(
      entry.ptr,
      amount,
      ignoreEquipped
    )
  end)

  return ok
end

CaveBot.Extensions.SellAll.setup = function()
  CaveBot.registerAction(
    "SellAll",
    "#C300FF",
    function(value, retries)

      local npcName, sellWithDelay, exceptions =
        parseSettings(value)

      if npcName == "" then
        warn("CaveBot[SellAll]: NPC name is empty")
        return false
      end

      local stateKey =
        npcName ..
        "|" ..
        tostring(value or "")

      if state.key ~= stateKey then
        resetState(stateKey)
      end

      if retries > MAX_RETRIES then
        print(
          "CaveBot[SellAll]: too many retries, stopping"
        )

        resetState(nil)
        return false
      end

      local npc = getCreatureByName(npcName)

      if not npc then
        if retries < 15 then
          CaveBot.delay(400)
          return "retry"
        end

        print(
          "CaveBot[SellAll]: NPC not found: " ..
          npcName
        )

        resetState(nil)
        return false
      end

      local npcPos = npc:getPosition()

      if getDistanceBetween(pos(), npcPos) > 4 then
        CaveBot.GoTo(npcPos, 3)
        CaveBot.delay(300)
        return "retry"
      end

      if not isTradeOpen() then
        state.tradeOpenedAt = 0
        state.lastFingerprint = nil

        local currentTime = nowMs()
        local talkDelay = getTalkDelay(1000)
        local cooldown = math.max(talkDelay * 3, 2500)

        local canTalk =
          state.lastTalkAt == 0
          or currentTime - state.lastTalkAt >= cooldown

        if canTalk then
          state.tradeAttempts =
            state.tradeAttempts + 1

          state.lastTalkAt = currentTime

          if state.tradeAttempts > MAX_TRADE_ATTEMPTS then
            print(
              "CaveBot[SellAll]: trade window did not open"
            )

            resetState(nil)
            return false
          end

          stopMoving()

          print(
            "CaveBot[SellAll]: opening trade with " ..
            npcName ..
            " attempt " ..
            state.tradeAttempts
          )

          sayNpc("hi")

          schedule(talkDelay, function()
            sayNpc("trade")
          end)
        end

        CaveBot.delay(300)
        return "retry"
      end

      state.tradeAttempts = 0

      local currentTime = nowMs()

      if state.tradeOpenedAt == 0 then
        state.tradeOpenedAt = currentTime

        -- Espera a lista do NPC e os player goods carregarem.
        CaveBot.delay(800)
        return "retry"
      end

      local tradeElapsed =
        currentTime - state.tradeOpenedAt

      local tradeList = getSellTradeList()

      if not hasAnyEntry(tradeList) then
        if tradeElapsed < 3500 then
          CaveBot.delay(300)
          return "retry"
        end

        print(
          "CaveBot[SellAll]: trade opened, but sell list is unavailable"
        )

        resetState(nil)
        return false
      end

      local playerItems = getPlayerItems()

      if not hasAnyEntry(playerItems)
        and tradeElapsed < 2500 then

        CaveBot.delay(300)
        return "retry"
      end

      local sellList = buildSellList(exceptions)

      if #sellList == 0 then
        closeTrade()

        print(
          "CaveBot[SellAll]: sold everything, proceeding"
        )

        resetState(nil)
        return true
      end

      local fingerprint =
        getFingerprint(sellList)

      if state.lastFingerprint then
        if fingerprint == state.lastFingerprint then
          local updateDelay

          if sellWithDelay then
            updateDelay = getTalkDelay(500)
          else
            updateDelay = 800
          end

          if currentTime - state.lastSellAt < updateDelay then
            CaveBot.delay(200)
            return "retry"
          end

          state.noProgress =
            state.noProgress + 1

          if state.noProgress > MAX_NO_PROGRESS then
            print(
              "CaveBot[SellAll]: items are not decreasing; " ..
              "check NPC, containers or server restrictions"
            )

            resetState(nil)
            return false
          end
        else
          state.noProgress = 0
        end
      end

      local ignoreEquipped =
        shouldIgnoreEquipped()

      local usedNativeSellAll =
        runNativeSellAll(sellWithDelay, exceptions)

      if usedNativeSellAll then
        if sellWithDelay then
          print("CaveBot[SellAll]: selling with native delay")
        else
          print("CaveBot[SellAll]: selling with native sell all")
        end
      elseif sellWithDelay then
        local entry = sellList[1]

        print(
          "CaveBot[SellAll]: selling " ..
          math.min(entry.amount, getMaxSellAmount()) ..
          "x item " ..
          entry.id ..
          " with delay"
        )

        if not sellEntry(entry, ignoreEquipped) then
          print(
            "CaveBot[SellAll]: failed to sell item " ..
            entry.id
          )
        end
      else
        print(
          "CaveBot[SellAll]: selling " ..
          #sellList ..
          " item types"
        )

        for _, entry in ipairs(sellList) do
          local remaining = tonumber(entry.amount) or 0

          while remaining > 0 do
            local chunk = math.min(
              remaining,
              getMaxSellAmount()
            )

            local sent =
              sellEntry({
                id = entry.id,
                amount = chunk,
                ptr = entry.ptr
              }, ignoreEquipped)

            if not sent then
              print(
                "CaveBot[SellAll]: failed to sell item " ..
                entry.id
              )
              break
            end

            remaining = remaining - chunk
          end
        end
      end

      state.lastFingerprint = fingerprint
      state.lastSellAt = currentTime

      if sellWithDelay then
        CaveBot.delay(getTalkDelay(500))
      else
        CaveBot.delay(800)
      end

      return "retry"
    end
  )

  CaveBot.Editor.registerAction(
    "sellall",
    "sell all",
    {
      value = "NPC",
      title = "Sell All",
      description =
        "NPC Name, 'yes' for delay, exceptions separated by comma"
    }
  )
end
