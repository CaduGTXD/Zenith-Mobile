-- walking
local expectedDirs = {}
local isWalking = {}
local walkPath = {}
local walkPathIter = 0
local usingClientAutoWalk = false
local floorTransitionGuardUntil = 0

local function getFloorTransitionDelay()
  if CaveBot.Config and CaveBot.Config.values and CaveBot.Config.values.floorChangeDelay ~= nil then
    return math.max(0, tonumber(CaveBot.Config.values.floorChangeDelay) or 850)
  end
  return 850
end

CaveBot.startFloorTransitionGuard = function(delayMs)
  local guardDelay = math.max(0, tonumber(delayMs) or getFloorTransitionDelay())
  floorTransitionGuardUntil = math.max(floorTransitionGuardUntil, now + guardDelay)

  CaveBot.resetWalking()
  if g_game and g_game.stop then
    g_game.stop()
  end

  if CaveBot.delay then
    CaveBot.delay(guardDelay)
  end
end

CaveBot.isFloorTransitionGuardActive = function()
  return now < floorTransitionGuardUntil
end

CaveBot.getFloorTransitionGuardRemaining = function()
  return math.max(0, floorTransitionGuardUntil - now)
end

local function isLureWalkDelayActive()
  return CaveBot.isLureWalkDelayActive
    and CaveBot.isLureWalkDelayActive() or false
end

local function getWalkDelay()
  if CaveBot.getWalkDelay then
    return CaveBot.getWalkDelay()
  end
  return CaveBot.Config.get("walkDelay")
end

local function shouldUseClientAutoWalk()
  if isLureWalkDelayActive() then
    return false
  end
  if CaveBot.Config.get("mapClick") and not isLureWalkDelayActive() then
    return false
  end
  return true
end

local function getQueuedStepDelay(dir)
  local stepDuration = player:getStepDuration(false, dir)
  if isLureWalkDelayActive() then
    return getWalkDelay() + stepDuration
  end
  local configDelay = math.max(getWalkDelay(), CaveBot.Config.get("ping"))
  local queuedDelay = math.floor(stepDuration / 3)

  if queuedDelay < 20 then
    queuedDelay = 20
  end

  return math.min(stepDuration, math.max(configDelay, queuedDelay))
end

CaveBot.resetWalking = function()
  expectedDirs = {}
  walkPath = {}
  isWalking = false
  usingClientAutoWalk = false
end

CaveBot.doWalking = function()
  if usingClientAutoWalk then
    return false
  end
  if CaveBot.Config.get("mapClick") then
    return false
  end
  if #expectedDirs == 0 then
    return false
  end
  if #expectedDirs >= 3 then
    CaveBot.resetWalking()
  end
  local dir = walkPath[walkPathIter]
  if dir then
    g_game.walk(dir)
    table.insert(expectedDirs, dir)
    walkPathIter = walkPathIter + 1
    CaveBot.delay(getQueuedStepDelay(dir))
    return true
  end
  return false  
end

-- called when player position has been changed (step has been confirmed by server)
onPlayerPositionChange(function(newPos, oldPos)
  if not oldPos or not newPos then return end

  if newPos.z ~= oldPos.z then
    -- Stop every old path and wait for the new floor/map to settle before the
    -- next waypoint can run. This covers stairs, holes, ladders and spells.
    CaveBot.startFloorTransitionGuard()
    return
  end
  
  local dirs = {{NorthWest, North, NorthEast}, {West, 8, East}, {SouthWest, South, SouthEast}}
  local dir = dirs[newPos.y - oldPos.y + 2]
  if dir then
    dir = dir[newPos.x - oldPos.x + 2]
  end
  if not dir then
    dir = 8 -- 8 is invalid dir, it's fine
  end

  if usingClientAutoWalk then
    return
  end

  if not isWalking or not expectedDirs[1] then
    -- some other walk action is taking place (for example use on ladder), wait
    walkPath = {}
    CaveBot.delay(CaveBot.Config.get("ping") + player:getStepDuration(false, dir) + 150)
    return
  end
  
  if expectedDirs[1] ~= dir then
    if CaveBot.Config.get("mapClick") and not isLureWalkDelayActive() then
      CaveBot.delay(getWalkDelay() + player:getStepDuration(false, dir))
    else
      CaveBot.delay(getQueuedStepDelay(dir))
    end
    return
  end
  
  table.remove(expectedDirs, 1)  
  if CaveBot.Config.get("mapClick")
    and not isLureWalkDelayActive()
    and #expectedDirs > 0 then
    CaveBot.delay(CaveBot.Config.get("mapClickDelay") + player:getStepDuration(false, dir))
  end
end)

CaveBot.walkTo = function(dest, maxDist, params)
  local path = getPath(player:getPosition(), dest, maxDist, params)
  if not path or not path[1] then
    return false
  end
  local dir = path[1]
  
  if CaveBot.Config.get("mapClick") and not isLureWalkDelayActive() then
    local ret = autoWalk(path)
    if ret then
      isWalking = true
      usingClientAutoWalk = false
      expectedDirs = path
      CaveBot.delay(CaveBot.Config.get("mapClickDelay") + math.max(CaveBot.Config.get("ping") + player:getStepDuration(false, dir), player:getStepDuration(false, dir) * 2))
    end
    return ret
  end

  if shouldUseClientAutoWalk() then
    local clientWalk = autoWalk(dest, maxDist, params)
    if clientWalk then
      isWalking = true
      usingClientAutoWalk = true
      expectedDirs = {}
      walkPath = {}
      walkPathIter = 0
      CaveBot.delay(math.max(getWalkDelay(), CaveBot.Config.get("ping")))
      return true
    end
  end

  usingClientAutoWalk = false
  
  g_game.walk(dir)
  isWalking = true    
  walkPath = path
  walkPathIter = 2
  expectedDirs = { dir }
  CaveBot.delay(getQueuedStepDelay(dir))
  return true
end
