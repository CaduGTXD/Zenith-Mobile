CaveBot.Extensions.Depositor = {}

--local variables
local destination = nil
local lootTable = nil
local reopenedContainers = false
local stowRemoveBoxIndex = 1
local stowLootScope = {}
local stowPendingLootContainerId = nil
local stowOpenedLootItems = {}
local stowStoreReopened = false

local function resetCache()
	reopenedContainers = false
	destination = nil
	lootTable = nil
	stowRemoveBoxIndex = 1
	stowLootScope = {}
	stowPendingLootContainerId = nil
	stowOpenedLootItems = {}
	stowStoreReopened = false

	for i, container in ipairs(getContainers()) do
		if container:getName():lower():find("depot") or container:getName():lower():find("locker") then
			g_game.close(container)
		end
	end

	if storage.caveBot.backStop then
		storage.caveBot.backStop = false
		CaveBot.setOff()
	elseif storage.caveBot.backTrainers then
		storage.caveBot.backTrainers = false
		CaveBot.gotoLabel('toTrainers')
	elseif storage.caveBot.backOffline then
		storage.caveBot.backOffline = false
		CaveBot.gotoLabel('toOfflineTraining')
	end
end

local description = g_game.getClientVersion() > 960 and "No - just deposit \n Yes - also reopen loot containers" or "currently not supported, will be added in near future"

local function getStowSettings()
	if type(getStowAllSettings) == "function" then
		return getStowAllSettings()
	end

	storage.specialDeposit = storage.specialDeposit or {}
	storage.specialDeposit.storeItems = storage.specialDeposit.storeItems or {}
	storage.specialDeposit.removeItems = storage.specialDeposit.removeItems or {}
	storage.specialDeposit.lootContainers = storage.specialDeposit.lootContainers or {}
	storage.specialDeposit.delay = tonumber(storage.specialDeposit.delay) or 300
	return storage.specialDeposit
end

local function getEntryId(entry)
	if type(entry) == "number" then
		return entry
	end
	if type(entry) == "table" then
		return tonumber(entry.id)
	end
end

local function itemInList(list, id)
	if type(list) ~= "table" then
		return false
	end

	for _, entry in ipairs(list) do
		if getEntryId(entry) == id then
			return true
		end
	end

	return false
end

local function listHasItems(list)
	if type(list) ~= "table" then
		return false
	end

	for _, entry in ipairs(list) do
		local id = getEntryId(entry)
		if id and id > 0 then
			return true
		end
	end

	return false
end

local function isDepotContainer(container)
	if not container then return false end
	local name = container:getName():lower()
	return name:find("depot")
		or name:find("locker")
		or name:find("your inbox")
end

local function findFreeBackpack()
	for _, container in pairs(getContainers()) do
		local name = container:getName():lower()
		if not name:find("depot")
			and not name:find("locker")
			and not name:find("your inbox")
			and not name:find("quiver")
			and container:getCapacity() > #container:getItems() then
			return container
		end
	end
end

local function getContainerKey(container)
	if container and container.getId then
		return container:getId()
	end
end

local function getItemKey(item)
	if not item then return nil end
	local itemPos = item:getPosition()
	if not itemPos then return tostring(item:getId()) end
	return table.concat({
		tostring(item:getId()),
		tostring(itemPos.x),
		tostring(itemPos.y),
		tostring(itemPos.z),
		tostring(item:getStackPos() or 0)
	}, ":")
end

local function markLootScope(settings)
	local lootContainers = settings.lootContainers or {}
	if not listHasItems(lootContainers) then
		return
	end

	for _, container in pairs(getContainers()) do
		if not isDepotContainer(container) then
			local containerItem = container:getContainerItem()
			local id = containerItem and containerItem:getId()
			if itemInList(lootContainers, id)
				or id == stowPendingLootContainerId then
				local key = getContainerKey(container)
				if key then
					stowLootScope[key] = true
				end
			end
		end
	end

	stowPendingLootContainerId = nil
end

local function isLootScopeContainer(container, settings)
	local lootContainers = settings.lootContainers or {}
	if not listHasItems(lootContainers) then
		return false
	end

	local key = getContainerKey(container)
	if key and stowLootScope[key] then
		return true
	end

	local containerItem = container and container:getContainerItem()
	local id = containerItem and containerItem:getId()
	return itemInList(lootContainers, id)
end

local function openLootRoot(settings)
	local lootContainers = settings.lootContainers or {}
	if not listHasItems(lootContainers) then
		return false
	end

	for _, container in pairs(getContainers()) do
		if not isDepotContainer(container) then
			local containerItem = container:getContainerItem()
			local id = containerItem and containerItem:getId()
			if itemInList(lootContainers, id) then
				local key = getContainerKey(container)
				if key then stowLootScope[key] = true end
				return "ready"
			end
		end
	end

	for _, container in pairs(getContainers()) do
		if not isDepotContainer(container) then
			for _, item in ipairs(container:getItems()) do
				if item:isContainer() and itemInList(lootContainers, item:getId()) then
					local itemKey = getItemKey(item)
					if itemKey then stowOpenedLootItems[itemKey] = true end
					stowPendingLootContainerId = item:getId()
					g_game.open(item, container)
					return "opened"
				end
			end
		end
	end

	for slot = InventorySlotFirst, InventorySlotLast do
		local item = getInventoryItem(slot)
		if item and item:isContainer() and itemInList(lootContainers, item:getId()) then
			local itemKey = getItemKey(item)
			if itemKey then stowOpenedLootItems[itemKey] = true end
			stowPendingLootContainerId = item:getId()
			g_game.open(item)
			return "opened"
		end
	end

	return false
end

local function openNextLootChild(settings)
	for _, container in pairs(getContainers()) do
		if isLootScopeContainer(container, settings) then
			for _, item in ipairs(container:getItems()) do
				if item:isContainer() then
					local itemKey = getItemKey(item)
					if not (itemKey and stowOpenedLootItems[itemKey]) then
						if itemKey then stowOpenedLootItems[itemKey] = true end
						stowPendingLootContainerId = item:getId()
						g_game.open(item, container)
						return true
					end
				end
			end
		end
	end

	return false
end

local function closeLootScope(settings)
	for _, container in pairs(getContainers()) do
		if isLootScopeContainer(container, settings) then
			g_game.close(container)
		end
	end

	stowLootScope = {}
	stowPendingLootContainerId = nil
	stowOpenedLootItems = {}
end

local function runStowStore(settings)
	local items = settings.storeItems or {}
	if #items == 0 then
		print("CaveBot[StowAll]: no items configured to guardar")
		resetCache()
		return true
	end

	if not listHasItems(settings.lootContainers) then
		print("CaveBot[StowAll]: no loot container configured")
		resetCache()
		return false
	end

	if type(g_game.stashStowItem) ~= "function" then
		warn("CaveBot[StowAll]: g_game.stashStowItem is not available in this client")
		resetCache()
		return false
	end

	if not CaveBot.ReachAndOpenDepot() then
		return "retry"
	end

	markLootScope(settings)

	local lootRootState = openLootRoot(settings)
	if not lootRootState then
		print("CaveBot[StowAll]: no loot container found/open")
		resetCache()
		return false
	elseif lootRootState == "opened" then
		CaveBot.delay(math.max(tonumber(settings.delay) or 300, 0))
		return "retry"
	end

	for _, container in pairs(getContainers()) do
		if isLootScopeContainer(container, settings) then
			for _, item in pairs(container:getItems()) do
				local id = item:getId()
				if itemInList(items, id) then
					statusMessage("[Stow All] stowing all items of type: " .. id)
					g_game.stashStowItem(item:getPosition(), id, 0, item:getStackPos(), 2)
					CaveBot.delay(math.max(tonumber(settings.delay) or 300, 0))
					return "retry"
				end
			end
		end
	end

	if openNextLootChild(settings) then
		CaveBot.delay(math.max(tonumber(settings.delay) or 300, 0))
		return "retry"
	end

	if listHasItems(settings.lootContainers) and not stowStoreReopened then
		stowStoreReopened = true
		closeLootScope(settings)
		if openLootRoot(settings) then
			CaveBot.delay(math.max(tonumber(settings.delay) or 300, 0))
			return "retry"
		end
	end

	print("CaveBot[StowAll]: guardar list finished")
	resetCache()
	return true
end

local function runStowRemove(settings)
	local items = settings.removeItems or {}
	if #items == 0 then
		print("CaveBot[StowAll]: no items configured to remover")
		resetCache()
		return true
	end

	if not CaveBot.ReachAndOpenDepot() then
		return "retry"
	end

	local destination = findFreeBackpack()
	if not destination then
		print("CaveBot[StowAll]: no backpack with free slots to remove items")
		resetCache()
		return false
	end

	for _, container in pairs(getContainers()) do
		if isDepotContainer(container) then
			for _, item in pairs(container:getItems()) do
				local id = item:getId()
				if itemInList(items, id) then
					statusMessage("[Stow All] removing item: " .. id)
					g_game.move(item, destination:getSlotPosition(destination:getItemsCount()), item:getCount())
					CaveBot.delay(math.max(tonumber(settings.delay) or 300, 0))
					return "retry"
				end
			end
		end
	end

	if stowRemoveBoxIndex <= 17 then
		for _, container in pairs(getContainers()) do
			if container:getName():lower():find("depot box") then
				g_game.close(container)
			end
		end

		CaveBot.OpenDepotBox(stowRemoveBoxIndex)
		stowRemoveBoxIndex = stowRemoveBoxIndex + 1
		CaveBot.delay(math.max(tonumber(settings.delay) or 300, 0))
		return "retry"
	end

	print("CaveBot[StowAll]: remover list finished")
	resetCache()
	return true
end

CaveBot.Extensions.Depositor.setup = function()
	CaveBot.registerAction("stow all", "#00D4AA", function(value, retries)
		local mode = tostring(value or "guardar"):lower():trim()
		local settings = getStowSettings()

		if retries > 400 then
			print("CaveBot[StowAll]: actions limit reached, proceeding")
			resetCache()
			return true
		end

		if mode == "guardar" or mode == "store" or mode == "stash" then
			return runStowStore(settings)
		elseif mode == "remover" or mode == "remove" or mode == "withdraw" then
			return runStowRemove(settings)
		end

		warn("CaveBot[StowAll]: invalid mode " .. tostring(value))
		resetCache()
		return false
	end)

	if CaveBot.Editor and CaveBot.Editor.registerAction then
		CaveBot.Editor.registerAction("stow all", "stow all", {
			value="guardar",
			title="Stow All",
			description="Choose Guardar to stash the guardar list or Remover to withdraw the remover list.",
			multiline=false,
			customEditor=function(currentValue, callback)
				CaveBot.Editor.openStowAllEditor(currentValue, callback)
			end
		})
	end

	CaveBot.registerAction("depositor", "#002FFF", function(value, retries)
		-- version check, TODO old tibia
		if g_game.getClientVersion() < 960 then
			resetCache()
			warn("CaveBot[Depositor]: unsupported Tibia version, will be added in near future")
			return false
		end

		-- loot list check
		lootTable = lootTable or CaveBot.GetLootItems()
		if #lootTable == 0 then
			print("CaveBot[Depositor]: no items in loot list. Wrong TargetBot Config? Proceeding")
			resetCache()
			return true
		end

		delay(70)

		-- backpacks etc
		if value:lower() == "yes" then
			if not reopenedContainers then
				CaveBot.CloseAllLootContainers()
				delay(3000)
				reopenedContainers = true
				return "retry"
			end
			-- open next backpacks if no more loot
			if not CaveBot.HasLootItems() then
				local lootContainers = CaveBot.GetLootContainers()
				for _, container in ipairs(getContainers()) do
					local cId = container:getContainerItem():getId()
					if table.find(lootContainers, cId) then
						for i, item in ipairs(container:getItems()) do
							if item:getId() == cId then
								g_game.open(item, container)
								delay(100)
								return "retry"
							end
						end
					end
				end
				-- couldn't find next container, so we done
				print("CaveBot[Depositor]: all items stashed, no backpack to open next, proceeding")
				CaveBot.CloseAllLootContainers()
				delay(3000)
				resetCache()
				return true
			end
		end

		-- first check items
		if retries == 0 then
			if not CaveBot.HasLootItems() then -- resource consuming function
				print("CaveBot[Depositor]: no items to stash, proceeding")
				resetCache()
				return true
			end
		end

		-- next check retries
		if retries > 400 then 
			print("CaveBot[Depositor]: Depositor actions limit reached, proceeding")
			resetCache()
			return true 
		end

		-- reaching and opening depot 
		if not CaveBot.ReachAndOpenDepot() then
			return "retry"
		end

		-- add delay to prevent bugging
		CaveBot.PingDelay(2)

		-- prep time and stashing
		destination = destination or getContainerByName("Depot chest")
		if not destination then return "retry" end

		for _, container in pairs(getContainers()) do
    	    local name = container:getName():lower()
    	    if not name:find("depot") and not name:find("your inbox") then
    	        for _, item in pairs(container:getItems()) do
    	            local id = item:getId()
					if table.find(lootTable, id) then
						local index = getStashingIndex(id) or item:isStackable() and 1 or 0
						statusMessage("[Depositer] stashing item: " ..id.. " to depot: "..index+1)
						CaveBot.StashItem(item, index, destination)
						return "retry"
					end
				end
			end
		end

		-- we gucci
		resetCache()
		return true
	end)

	CaveBot.Editor.registerAction("depositor", "depositor", {
	 value="no",
	 title="Depositor",
	 description=description,
	 validation="(yes|Yes|YES|no|No|NO)"
	})
end
