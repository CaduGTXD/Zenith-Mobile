-- Lure extension for CaveBot
-- v14.0: optional Mage Run carry of up to two extra survivors to the next waypoint.

CaveBot.Extensions = CaveBot.Extensions or {}
CaveBot.Extensions.Lure = CaveBot.Extensions.Lure or {}

local Lure = CaveBot.Extensions.Lure

Lure._state = Lure._state or {}
local state = Lure._state

if state.active == nil then state.active = false end
if state.rushingEnd == nil then state.rushingEnd = false end
if state.killingEnd == nil then state.killingEnd = false end
if state.endWidget == nil then state.endWidget = nil end
if state.endLureArrivedAt == nil then state.endLureArrivedAt = 0 end
if state.endLureLowCountStreak == nil then state.endLureLowCountStreak = 0 end
if state.endLureClearStreak == nil then state.endLureClearStreak = 0 end
if state.walkDelayActive == nil then state.walkDelayActive = false end
if state.walkDelayValue == nil then state.walkDelayValue = -1 end
if state.ignoreExitAllowedUntil == nil then state.ignoreExitAllowedUntil = 0 end
if state.ignoreExitCandidateSince == nil then state.ignoreExitCandidateSince = 0 end
if state.carryingRemaining == nil then state.carryingRemaining = false end
if state.carryTargetWidget == nil then state.carryTargetWidget = nil end
if state.carryTargetPos == nil then state.carryTargetPos = nil end
if state.carryTargetAction == nil then state.carryTargetAction = nil end
if state.carryTargetSeen == nil then state.carryTargetSeen = false end
if state.carryAtTargetSince == nil then state.carryAtTargetSince = 0 end
if state.carryOriginPos == nil then state.carryOriginPos = nil end
if state.carryIgnoreLimit == nil then state.carryIgnoreLimit = 0 end
if state.carryBelowIgnore == nil then state.carryBelowIgnore = false end
if state.carryCandidateSince == nil then state.carryCandidateSince = 0 end
if state.carryStartedAt == nil then state.carryStartedAt = 0 end
if state.carryReleaseUntil == nil then state.carryReleaseUntil = 0 end
state.statsCache = state.statsCache or {}
state.monsterTrack = state.monsterTrack or {}

local oldTibia = g_game.getClientVersion() < 960
local CARRY_REMAINING_EXTRA_LIMIT = 2

local function clockMillis()
  if type(now) == "number" then
    return now
  end

  if g_clock and g_clock.millis then
    return g_clock.millis()
  end

  return 0
end

local function configNumber(id, defaultValue, minValue, maxValue)
  local value = defaultValue

  if CaveBot.Config and CaveBot.Config.values and CaveBot.Config.values[id] ~= nil then
    value = tonumber(CaveBot.Config.values[id]) or defaultValue
  end

  value = math.floor(value)

  if minValue and value < minValue then value = minValue end
  if maxValue and value > maxValue then value = maxValue end

  return value
end

local function configBoolean(id, defaultValue)
  local value = defaultValue and true or false

  if CaveBot.Config and CaveBot.Config.values
    and CaveBot.Config.values[id] ~= nil then
    value = CaveBot.Config.values[id] and true or false
  end

  return value
end

local function copyPosition(position)
  if not position then return nil end
  return {x=position.x, y=position.y, z=position.z}
end

local function originalConfigGet(id)
  if Lure._originalConfigGet then
    return Lure._originalConfigGet(id)
  end

  if CaveBot.Config and CaveBot.Config.values then
    return CaveBot.Config.values[id]
  end

  return nil
end

local function normalWalkDelay()
  local value = tonumber(originalConfigGet("walkDelay"))

  if value == nil and CaveBot.Config and CaveBot.Config.values then
    value = tonumber(CaveBot.Config.values.walkDelay)
  end

  return math.max(0, math.floor(value or 100))
end

local function isAliveMonster(creature)
  if not creature or not creature:isMonster() then return false end

  local hp = creature:getHealthPercent()
  if not hp or hp <= 0 then return false end

  if not oldTibia and creature:getType() >= 3 then
    return false
  end

  return true
end

local function isMageRunEnabled()
  return TargetBot and TargetBot.isMageRunMode and TargetBot.isMageRunMode()
end

local function isCarryRemainingEnabled()
  return isMageRunEnabled()
    and configBoolean("lureMageRunCarryRemaining", false)
end

local function setMageRunState(activeValue, center)
  if TargetBot and TargetBot.setMageRunLureState then
    TargetBot.setMageRunLureState(activeValue, center)
  end
end

local function parseWaypointPosition(value)
  local match = regexMatch(value or "", "^\\s*([0-9]+)\\s*,\\s*([0-9]+)\\s*,\\s*([0-9]+)")

  if not match[1] then
    return nil
  end

  return {
    x = tonumber(match[1][2]),
    y = tonumber(match[1][3]),
    z = tonumber(match[1][4])
  }
end

local function isInsideMageRunEndArea(endPos)
  if not endPos then return false end
  local playerPos = player and player:getPosition() or nil
  if not playerPos or playerPos.z ~= endPos.z then return false end

  -- Precision 1 in both axes means the complete 3x3 area centered on End Lure.
  return math.abs(playerPos.x - endPos.x) <= 1
    and math.abs(playerPos.y - endPos.y) <= 1
end

local function tileDistance(a, b)
  return math.max(math.abs(a.x - b.x), math.abs(a.y - b.y))
end

local function clearStatsCache()
  state.statsCache = {}
end

local function clearCarryRemainingState()
  state.carryingRemaining = false
  state.carryTargetWidget = nil
  state.carryTargetPos = nil
  state.carryTargetAction = nil
  state.carryTargetSeen = false
  state.carryAtTargetSince = 0
  state.carryOriginPos = nil
  state.carryIgnoreLimit = 0
  state.carryBelowIgnore = false
  state.carryCandidateSince = 0
  state.carryStartedAt = 0
end

local function resetLureState()
  state.active = false
  state.rushingEnd = false
  state.killingEnd = false
  state.endWidget = nil
  state.endLureArrivedAt = 0
  state.endLureLowCountStreak = 0
  state.endLureClearStreak = 0
  state.walkDelayActive = false
  state.walkDelayValue = -1
  state.ignoreExitAllowedUntil = 0
  state.ignoreExitCandidateSince = 0
  state.carryReleaseUntil = 0
  clearCarryRemainingState()
  state.monsterTrack = {}
  clearStatsCache()
  setMageRunState(false)
end

local function creatureId(creature)
  return creature and creature.getId and creature:getId() or tostring(creature)
end

local function getSharedMonsterSource()
  local snapshot = TargetBot and TargetBot.getMageRunSnapshot
    and TargetBot.getMageRunSnapshot(350)

  -- The MageRun snapshot is centered on the player. During a wide kite it may
  -- not contain monsters that are still inside the End Lure radius on the
  -- opposite side. Count from all currently visible spectators and use the
  -- snapshot only as a fast configured-id hint.
  return (getSpectators(false) or {}), snapshot and snapshot.configuredIds or nil
end

local function isConfiguredMonster(creature, configuredIds)
  local id = creatureId(creature)
  if configuredIds and configuredIds[id] == true then
    return true
  end

  -- A false/missing snapshot entry is not authoritative because the snapshot
  -- may cover only part of the End Lure area. getConfigs is name-cached by
  -- TargetBot, so this fallback is both accurate and inexpensive.
  if not TargetBot or not TargetBot.Creature or not TargetBot.Creature.getConfigs then
    return configuredIds == nil
  end
  local configs = TargetBot.Creature.getConfigs(creature)
  return configs and #configs > 0 or false
end

local function configuredMonsterStats(hpIgnoreLimit, centerPos, rangeOverride, includePlayerRadius)
  local localPlayer = player or g_game.getLocalPlayer()
  if not localPlayer then return 0, 0 end

  local playerPos = localPlayer:getPosition()
  if not playerPos then return 0, 0 end

  centerPos = centerPos or playerPos
  if not centerPos then return 0, 0 end
  local creatureRange = rangeOverride or configNumber("lureCreatureRange", 8, 1, 15)
  local hpLimit = tonumber(hpIgnoreLimit) or 0
  includePlayerRadius = math.max(0, tonumber(includePlayerRadius) or 0)
  local currentTime = clockMillis()
  local cacheKey = table.concat({
    centerPos.x, centerPos.y, centerPos.z,
    playerPos.x, playerPos.y, playerPos.z,
    creatureRange, hpLimit, includePlayerRadius
  }, ":")

  local cached = state.statsCache[cacheKey]
  if cached and cached.expiresAt > currentTime then
    return cached.count, cached.mustKill
  end

  local count = 0
  local mustKill = 0
  local monsters, configuredIds = getSharedMonsterSource()
  local counted = {}
  local visible = {}

  local function insideCountArea(creaturePos)
    if not creaturePos then return false end
    local insideCenter = creaturePos.z == centerPos.z
      and tileDistance(centerPos, creaturePos) <= creatureRange
    local insidePlayerSafety = includePlayerRadius > 0
      and creaturePos.z == playerPos.z
      and tileDistance(playerPos, creaturePos) <= includePlayerRadius
    return insideCenter or insidePlayerSafety
  end

  local function addCount(id, hp)
    if counted[id] then return end
    counted[id] = true
    count = count + 1
    if hpLimit > 0 and (tonumber(hp) or 0) <= hpLimit then
      mustKill = mustKill + 1
    end
  end

  for _, creature in ipairs(monsters or {}) do
    local id = creatureId(creature)

    if isAliveMonster(creature) then
      local creaturePos = creature:getPosition()
      local hp = tonumber(creature:getHealthPercent()) or 0

      if creaturePos then
        if isConfiguredMonster(creature, configuredIds) then
          visible[id] = true
          state.monsterTrack[id] = {
            pos = {x=creaturePos.x, y=creaturePos.y, z=creaturePos.z},
            hp = hp,
            lastSeen = currentTime
          }
          if insideCountArea(creaturePos) then
            addCount(id, hp)
          end
        else
          state.monsterTrack[id] = nil
        end
      end
      -- A creature can disappear between getSpectators() and getPosition().
      -- Keep its previous tracked position until the visibility grace expires
      -- instead of dropping it from Ignore Remaining for one frame.
    else
      state.monsterTrack[id] = nil
    end
  end

  -- Keep recently seen configured monsters in the count for a short grace
  -- window. This prevents a player movement/screen edge from temporarily
  -- dropping two or three monsters and authorizing an early End Lure exit.
  local visibilityGrace = 1200
  for id, tracked in pairs(state.monsterTrack) do
    if currentTime - (tracked.lastSeen or 0) > visibilityGrace then
      state.monsterTrack[id] = nil
    elseif not visible[id] and insideCountArea(tracked.pos) then
      addCount(id, tracked.hp)
    end
  end

  state.statsCache[cacheKey] = {
    count = count,
    mustKill = mustKill,
    expiresAt = currentTime + 160
  }

  if currentTime % 2000 < 200 then
    for key, value in pairs(state.statsCache) do
      if value.expiresAt <= currentTime then
        state.statsCache[key] = nil
      end
    end
  end

  return count, mustKill
end

local function configuredMonsterCount()
  local count = configuredMonsterStats()
  return count
end

local function getEndLureExitStats(endPos)
  local mageRun = isMageRunEnabled()
  local ignoreRemaining = configNumber("lureIgnoreRemaining", 0, 0, 32)
  local ignoreHp = configNumber("lureIgnoreHp", 0, 0, 100)
  local statsCenter = mageRun and endPos or nil
  local playerSafetyRadius = mageRun
    and configNumber("lureCreatureRange", 8, 1, 15) or 0
  local creatures, mustKill = configuredMonsterStats(
    ignoreHp, statsCenter, nil, playerSafetyRadius
  )

  return {
    mageRun = mageRun,
    ignoreRemaining = ignoreRemaining,
    ignoreHp = ignoreHp,
    creatures = creatures,
    mustKill = mustKill,
    countBlocks = creatures > ignoreRemaining,
    hpBlocks = ignoreHp > 0 and mustKill > 0
  }
end

local function updateIgnoreExitAllowance(exitStats, strictSafetyBlocksExit)
  local currentTime = clockMillis()
  local qualifies = state.active
    and state.killingEnd
    and exitStats
    and not exitStats.countBlocks
    and not exitStats.hpBlocks
    and not strictSafetyBlocksExit

  -- Require the valid count to remain stable across more than one scan. A
  -- single stale frame can no longer release CaveBot past End Lure.
  if qualifies then
    if state.ignoreExitCandidateSince == 0 then
      state.ignoreExitCandidateSince = currentTime
    end
  else
    state.ignoreExitCandidateSince = 0
  end

  local allowed = qualifies
    and currentTime - state.ignoreExitCandidateSince >= 180

  if allowed then
    -- Short lease, continuously renewed by lureTick/endLure while the exact
    -- configured limit remains valid.
    state.ignoreExitAllowedUntil = currentTime + 380
  else
    state.ignoreExitAllowedUntil = 0
  end

  return allowed
end

CaveBot.isLureIgnoreExitAllowed = function()
  local currentTime = clockMillis()
  if state.carryingRemaining then
    return true
  end
  if state.carryReleaseUntil > currentTime then
    return true
  end
  return state.active
    and state.killingEnd
    and state.ignoreExitAllowedUntil > currentTime
end

CaveBot.isMageRunCarryRemainingActive = function()
  return state.carryingRemaining and isMageRunEnabled()
end

local function adjacentMonsterCount()
  local localPlayer = player or g_game.getLocalPlayer()
  if not localPlayer then return 0 end

  local playerPos = localPlayer:getPosition()
  if not playerPos then return 0 end

  local count = configuredMonsterStats(nil, playerPos, 1)
  return count
end

local function hasBlockingTrap(radius)
  local localPlayer = player or g_game.getLocalPlayer()
  if not localPlayer then return false end

  local playerPos = localPlayer:getPosition()
  if not playerPos then return false end

  radius = radius or 1

  for _, creature in ipairs(getSpectators(false) or {}) do
    if isAliveMonster(creature) then
      local creaturePos = creature:getPosition()

      if creaturePos
        and creaturePos.z == playerPos.z
        and math.abs(creaturePos.x - playerPos.x) <= radius
        and math.abs(creaturePos.y - playerPos.y) <= radius then
        return true
      end
    end
  end

  return false
end

local function hasImmediateEndLureThreat(radius)
  radius = radius or 1
  if hasBlockingTrap(radius) then
    return true
  end

  local attacking = g_game.getAttackingCreature and g_game.getAttackingCreature() or nil
  if isAliveMonster(attacking) then
    local localPlayer = player or g_game.getLocalPlayer()
    local playerPos = localPlayer and localPlayer:getPosition() or nil
    local targetPos = attacking:getPosition()
    if playerPos and targetPos
      and playerPos.z == targetPos.z
      and tileDistance(playerPos, targetPos) <= math.max(2, radius) then
      return true
    end
  end

  return false
end

local function countFreeAdjacentTiles()
  local localPlayer = player or g_game.getLocalPlayer()
  if not localPlayer then return 0 end

  local playerPos = localPlayer:getPosition()
  if not playerPos then return 0 end

  local free = 0

  for dx = -1, 1 do
    for dy = -1, 1 do
      if dx ~= 0 or dy ~= 0 then
        local checkPos = {
          x = playerPos.x + dx,
          y = playerPos.y + dy,
          z = playerPos.z
        }

        local tile = g_map.getTile(checkPos)
        if tile and tile:isWalkable() then
          local occupied = false

          if tile.getCreatures then
            local creatures = tile:getCreatures() or {}
            occupied = #creatures > 0
          elseif tile.getTopCreature then
            occupied = tile:getTopCreature() ~= nil
          end

          if not occupied then
            free = free + 1
          end
        end
      end
    end
  end

  return free
end

local function isHardTrappedAtEndLure()
  -- Ignore Remaining may leave monsters alive, but it must not advance when
  -- the player has effectively no route to leave the End Lure.
  return countFreeAdjacentTiles() <= 1
end

local function shouldUseLureWalkDelay(creatures)
  if not state.active or state.killingEnd then
    return false
  end

  -- Carry Remaining deliberately behaves like a temporary Ignore Remaining
  -- walk: use the configured lure delay while the extra survivors are still
  -- above Ignore Remaining. Adjacent lure may temporarily remove that delay
  -- so the character can move away instead of getting boxed.
  if state.carryingRemaining then
    return not state.carryBelowIgnore and not state.rushingEnd
  end

  -- Outside Carry Remaining, Min/Max lure settings remain authoritative.
  if creatures == nil then
    creatures = configuredMonsterCount()
  end

  local minLure = configNumber("minLure", 1, 0, 50)
  local maxToWalk = configNumber("lureMaxToWalk", 8, 0, 50)

  if creatures < minLure then
    return false
  end

  if maxToWalk > 0 and creatures > maxToWalk then
    return false
  end

  return true
end

local function effectiveWalkDelay()
  if shouldUseLureWalkDelay() then
    -- The UI describes this as an extra delay, so preserve the normal CaveBot
    -- delay and add the configured lure value on top of it.
    return normalWalkDelay()
      + configNumber("lureWalkDelay", 100, 0, 5000)
  end

  return nil
end

local function installWalkDelayHook()
  if Lure._walkDelayHookInstalled then return end
  if not CaveBot.Config or not CaveBot.Config.get then return end

  Lure._originalConfigGet = CaveBot.Config.get

  -- cavebot/walking.lua reads CaveBot.Config.get("walkDelay") directly.
  -- Hooking only CaveBot.getWalkDelay has no effect on actual walking.
  CaveBot.Config.get = function(id)
    if id == "walkDelay" then
      local extension = CaveBot.Extensions
        and CaveBot.Extensions.Lure

      if extension and extension._effectiveWalkDelay then
        local delay = extension._effectiveWalkDelay()
        if delay ~= nil then
          return delay
        end
      end
    end

    return Lure._originalConfigGet(id)
  end

  Lure._walkDelayHookInstalled = true
end

CaveBot.getWalkDelay = function()
  return effectiveWalkDelay() or normalWalkDelay()
end

CaveBot.isLureWalkDelayActive = function()
  return shouldUseLureWalkDelay()
end

local function syncWalkDelayMode()
  local activeNow = shouldUseLureWalkDelay()
  local delayNow = activeNow and effectiveWalkDelay() or normalWalkDelay()

  if state.walkDelayActive == activeNow
    and state.walkDelayValue == delayNow then
    return
  end

  state.walkDelayActive = activeNow
  state.walkDelayValue = delayNow

  -- A client/map-click auto-walk already in progress cannot change its interval.
  -- Stop it once when either activation or the configured delay changes.
  if CaveBot.resetWalking then
    CaveBot.resetWalking()
  end

  if g_game and g_game.stop then
    pcall(function()
      g_game.stop()
    end)
  end
end

local function findNextEndLure()
  if not CaveBot.actionList then return nil end

  local focused = CaveBot.actionList:getFocusedChild()
  local startIndex = focused and CaveBot.actionList:getChildIndex(focused) or 1
  local children = CaveBot.actionList:getChildren()

  for i = startIndex + 1, #children do
    if children[i].action == "endlure" then
      return children[i]
    end
  end

  -- Keep support for circular waypoint lists.
  for i = 1, startIndex - 1 do
    if children[i].action == "endlure" then
      return children[i]
    end
  end

  return nil
end

local carryWaypointActions = {
  ["goto"]=true,
  stand=true,
  startlure=true
}

local function findNextCarryWaypoint()
  if not CaveBot.actionList then return nil, nil end

  local focused = CaveBot.actionList:getFocusedChild()
  local startIndex = focused and CaveBot.actionList:getChildIndex(focused) or 1
  local children = CaveBot.actionList:getChildren()

  local function candidateAt(index)
    local child = children[index]
    if not child or not carryWaypointActions[child.action] then
      return nil, nil
    end

    local waypointPos = parseWaypointPosition(child.value)
    if not waypointPos then return nil, nil end
    return child, waypointPos
  end

  for index = startIndex + 1, #children do
    local child, waypointPos = candidateAt(index)
    if child then return child, waypointPos end
  end

  -- Preserve circular waypoint profiles without carrying back to the same End Lure.
  for index = 1, startIndex - 1 do
    local child, waypointPos = candidateAt(index)
    if child then return child, waypointPos end
  end

  return nil, nil
end

local function isAtCarryTarget()
  local targetPos = state.carryTargetPos
  local localPlayer = player or g_game.getLocalPlayer()
  local playerPos = localPlayer and localPlayer:getPosition() or nil
  if not targetPos or not playerPos or targetPos.z ~= playerPos.z then
    return false
  end

  local precision = state.carryTargetAction == "stand" and 0 or 1
  return tileDistance(targetPos, playerPos) <= precision
end

local function carryTargetCompleted(focused)
  if not state.carryTargetWidget then return true end

  if focused == state.carryTargetWidget then
    state.carryTargetSeen = true
  elseif state.carryTargetSeen then
    return true
  end

  if isAtCarryTarget() then
    if state.carryAtTargetSince == 0 then
      state.carryAtTargetSince = clockMillis()
    elseif clockMillis() - state.carryAtTargetSince >= 350 then
      return true
    end
  else
    state.carryAtTargetSince = 0
  end

  return false
end

local function allowCavebotWhileLuring()
  if not state.active or not TargetBot or not TargetBot.allowCaveBot then return end

  -- Respect the same condition used by the actual walk delay.
  -- Outside the configured creature range, use the normal CaveBot delay.
  local wait = effectiveWalkDelay() or normalWalkDelay()
  if state.carryingRemaining then
    -- The carry tick runs every 300 ms. Keep a small overlap so TargetBot does
    -- not revoke CaveBot movement between two renewals when Adjacent is rushing.
    wait = math.max(wait, 300)
  end
  TargetBot.allowCaveBot(wait + 250)
end

local function beginCarryRemaining(endPos, exitStats)
  local targetWidget, targetPos = findNextCarryWaypoint()
  if not targetWidget or not targetPos then
    return false
  end

  clearCarryRemainingState()
  state.carryingRemaining = true
  state.carryTargetWidget = targetWidget
  state.carryTargetPos = copyPosition(targetPos)
  state.carryTargetAction = targetWidget.action
  state.carryOriginPos = copyPosition(endPos)
  state.carryIgnoreLimit = exitStats.ignoreRemaining or 0
  state.carryBelowIgnore = false
  state.carryStartedAt = clockMillis()

  state.active = true
  state.killingEnd = false
  local adjacentMax = configNumber("lureAdjacentMax", 1, 0, 8)
  state.rushingEnd = adjacentMonsterCount() > adjacentMax
  state.endWidget = nil
  state.endLureArrivedAt = 0
  state.endLureLowCountStreak = 0
  state.endLureClearStreak = 0
  state.ignoreExitCandidateSince = 0
  state.ignoreExitAllowedUntil = clockMillis() + 700
  state.carryReleaseUntil = 0
  clearStatsCache()

  -- Keep the Mage Run lure state marked active during the handoff. Movement
  -- planning itself only runs while End Lure is focused, but TargetBot uses
  -- this flag together with isLureIgnoreExitAllowed() to avoid stopping the
  -- CaveBot walk when creature configs have Stop/Chase enabled.
  setMageRunState(true, endPos)
  if TargetBot and TargetBot.setOn then
    TargetBot.setOn()
  end
  if TargetBot and TargetBot.allowCaveBot then
    TargetBot.allowCaveBot(700)
  end

  syncWalkDelayMode()
  return true
end

local function finishCarryRemaining(belowIgnore)
  local allowance = belowIgnore and 1800 or 400
  resetLureState()
  state.carryReleaseUntil = clockMillis() + allowance

  if TargetBot and TargetBot.allowCaveBot then
    TargetBot.allowCaveBot(allowance)
  end

  syncWalkDelayMode()
end

local function cappedRetries(retries)
  retries = tonumber(retries) or 0

  if retries < 0 then
    return 0
  end

  return math.min(retries, 4)
end

local function hasActiveAttackTarget()
  local creature = g_game.getAttackingCreature()
  return isAliveMonster(creature)
end

local function hasCombatPressure()
  return hasActiveAttackTarget()
    or hasBlockingTrap(1)
    or configuredMonsterCount() > 0
end

local function runGoto(value, retries, prev)
  local action = CaveBot.Actions.goto
  if not action or not action.callback then return false end

  return action.callback(value, cappedRetries(retries), prev)
end

local function runStand(value, retries, prev)
  local action = CaveBot.Actions.stand
  if not action or not action.callback then return false end

  return action.callback(value, cappedRetries(retries), prev)
end

local function startLure(value, retries, prev)
  local result = runGoto(value, retries, prev)

  if result ~= true then
    if result == false and hasCombatPressure() then
      if TargetBot and TargetBot.setOn then
        TargetBot.setOn()
      end

      CaveBot.delay(250)
      return "retry"
    end

    return result
  end

  if state.carryingRemaining then
    clearCarryRemainingState()
  end
  state.carryReleaseUntil = 0
  setMageRunState(false)
  state.active = true
  state.rushingEnd = false
  state.killingEnd = false
  state.endWidget = findNextEndLure()
  state.endLureArrivedAt = 0
  state.endLureLowCountStreak = 0
  state.endLureClearStreak = 0
  state.walkDelayActive = false
  state.walkDelayValue = -1
  clearStatsCache()
  syncWalkDelayMode()
  allowCavebotWhileLuring()

  return true
end

local function endLure(value, retries, prev)
  local endPos = parseWaypointPosition(value)
  local mageRun = isMageRunEnabled()
  local shouldHoldStand = not mageRun

  if shouldHoldStand or not state.killingEnd then
    local result

    if mageRun and not state.killingEnd then
      -- Mage Run starts as soon as the player enters the 3x3 area around the
      -- End Lure marker. The generic Goto precision only accepted a vertical
      -- line, so it could unnecessarily chase the exact waypoint tile.
      if isInsideMageRunEndArea(endPos) then
        result = true
      else
        result = runGoto(value, retries, prev)
      end
    else
      result = runStand(value, retries, prev)
    end

    if result ~= true then
      if state.active or state.killingEnd or hasCombatPressure() then
        state.active = true

        if TargetBot and TargetBot.setOn then
          TargetBot.setOn()
        end

        allowCavebotWhileLuring()
        CaveBot.delay(250)
        return "retry"
      end

      return result
    end

    -- End Lure reached: leave lure-walk/rush movement modes.
    state.rushingEnd = false
    state.walkDelayActive = false
    state.walkDelayValue = -1

    if state.endLureArrivedAt == 0 then
      state.endLureArrivedAt = clockMillis()
      state.endLureLowCountStreak = 0
      state.endLureClearStreak = 0
    end
  end

  local minCreature = configNumber("lureMinCreature", 1, 0, 50)
  local exitStats = getEndLureExitStats(endPos)
  local creatures = exitStats.creatures
  local immediateThreat = state.killingEnd and hasImmediateEndLureThreat(1)
  local hardTrap = state.killingEnd and isHardTrappedAtEndLure()

  -- Ignore Remaining and HP % are authoritative once enabled:
  --   creatures <= Ignore Remaining
  --   and no remaining creature is at/below HP %
  -- Nearby survivors or a local trap may only block exit in strict mode
  -- (Ignore Remaining = 0).
  local strictSafetyBlocksExit = exitStats.ignoreRemaining == 0
    and (hardTrap or immediateThreat)
  local ignoreExitAllowed = updateIgnoreExitAllowance(exitStats, strictSafetyBlocksExit)

  if not state.killingEnd and creatures > 0 and creatures >= minCreature then
    state.killingEnd = true
    state.endLureLowCountStreak = 0
    state.endLureClearStreak = 0

    if mageRun and endPos then
      setMageRunState(true, endPos)
    end
  elseif not state.killingEnd then
    state.endLureLowCountStreak = state.endLureLowCountStreak + 1

    local graceTime = creatures > 0 and 450 or 250
    if clockMillis() - state.endLureArrivedAt < graceTime
      or state.endLureLowCountStreak < 3 then
      CaveBot.delay(150)
      return "retry"
    end

    resetLureState()
    return true
  end

  local carryExtra = creatures - exitStats.ignoreRemaining
  local carryQualifies = state.killingEnd
    and mageRun
    and isCarryRemainingEnabled()
    and not ignoreExitAllowed
    and not exitStats.hpBlocks
    and carryExtra >= 1
    and carryExtra <= CARRY_REMAINING_EXTRA_LIMIT

  if carryQualifies then
    if state.carryCandidateSince == 0 then
      state.carryCandidateSince = clockMillis()
    end

    -- Confirm the small remainder for more than one scan. This avoids starting
    -- a carry because two creatures briefly disappeared at the screen edge.
    if clockMillis() - state.carryCandidateSince >= 180 then
      if beginCarryRemaining(endPos, exitStats) then
        return true
      end
      state.carryCandidateSince = 0
    end
  else
    state.carryCandidateSince = 0
  end

  if state.killingEnd
    and (not ignoreExitAllowed
      or strictSafetyBlocksExit) then
    state.endLureClearStreak = 0
    state.active = true
    state.rushingEnd = false

    if TargetBot and TargetBot.setOn then
      TargetBot.setOn()
    end

    allowCavebotWhileLuring()
    CaveBot.delay(250)
    return "retry"
  end

  state.endLureClearStreak = state.endLureClearStreak + 1

  if state.endLureClearStreak < 2 then
    CaveBot.delay(120)
    return "retry"
  end

  resetLureState()
  return true
end

local function lureTick()
  if CaveBot.isOn and not CaveBot.isOn() then
    if state.active or state.rushingEnd or state.killingEnd
      or state.carryReleaseUntil > clockMillis() then
      resetLureState()
    end
    return
  end

  local focused = CaveBot.actionList
    and CaveBot.actionList:getFocusedChild()

  if not state.active
    and focused
    and focused.action == "startlure"
    and TargetBot
    and TargetBot.allowCaveBot then
    TargetBot.allowCaveBot(500)
    return
  end

  if not state.active then return end

  if state.carryingRemaining then
    if not isCarryRemainingEnabled() then
      finishCarryRemaining(false)
      return
    end

    local carryStats = getEndLureExitStats(state.carryOriginPos)
    state.carryIgnoreLimit = carryStats.ignoreRemaining
    state.carryBelowIgnore = not carryStats.countBlocks
      and not carryStats.hpBlocks

    if carryTargetCompleted(focused) then
      finishCarryRemaining(state.carryBelowIgnore)
      return
    end

    if state.carryBelowIgnore then
      -- It has fallen into the normal Ignore Remaining limit. Keep the short
      -- handoff alive until the selected waypoint is reached, but stop slowing
      -- the walk or reacting to Adjacent lure.
      state.rushingEnd = false
    else
      local adjacentMax = configNumber("lureAdjacentMax", 1, 0, 8)
      state.rushingEnd = adjacentMonsterCount() > adjacentMax
    end

    syncWalkDelayMode()
    allowCavebotWhileLuring()
    return
  end

  if state.killingEnd and focused and focused.action == "endlure" then
    local endPos = parseWaypointPosition(focused.value)
    local exitStats = getEndLureExitStats(endPos)
    local strictSafetyBlocksExit = exitStats.ignoreRemaining == 0
      and (isHardTrappedAtEndLure() or hasImmediateEndLureThreat(1))

    if updateIgnoreExitAllowance(exitStats, strictSafetyBlocksExit)
      and TargetBot
      and TargetBot.allowCaveBot then
      TargetBot.allowCaveBot(650)
    end
  end

  if isMageRunEnabled() and not state.killingEnd then
    local adjacentMax = configNumber("lureAdjacentMax", 1, 0, 8)
    local adjacentCount = adjacentMonsterCount()
    local shouldRush = adjacentCount > adjacentMax

    if shouldRush then
      state.endWidget = state.endWidget or findNextEndLure()
      shouldRush = state.endWidget ~= nil
    end

    -- Rush is now dynamic. A temporary adjacent spike no longer disables the
    -- configured Lure walk delay for the entire remaining route.
    state.rushingEnd = shouldRush
  else
    state.rushingEnd = false
  end

  syncWalkDelayMode()

  -- Keep renewing the CaveBot allowance. The action list must continue
  -- sequentially so stairs, doors, uses and intermediate waypoints are kept.
  allowCavebotWhileLuring()
end

-- Dynamic targets used by the one-time wrappers below. Reloading this file updates
-- behavior without registering another action callback or macro.
Lure._effectiveWalkDelay = effectiveWalkDelay
Lure._startLure = startLure
Lure._endLure = endLure
Lure._tick = lureTick
Lure.reset = resetLureState
Lure.isActive = function()
  return state.active
end

Lure.setup = function()
  installWalkDelayHook()

  if not Lure._actionsRegistered then
    CaveBot.registerAction("startlure", "#FF0090", function(value, retries, prev)
      local extension = CaveBot.Extensions.Lure
      return extension._startLure(value, retries, prev)
    end)

    CaveBot.registerAction("endlure", "#FF55CC", function(value, retries, prev)
      local extension = CaveBot.Extensions.Lure
      return extension._endLure(value, retries, prev)
    end)

    Lure._actionsRegistered = true
  end

  if not Lure._editorActionsRegistered then
    CaveBot.Editor.registerAction("startlure", "Start Lure", {
      value = function()
        return posx() .. "," .. posy() .. "," .. posz()
      end,
      title = "Start Lure",
      description = "Start lure at position (x,y,z,precision optional)",
      multiline = false,
      validation = "^\\s*([0-9]+)\\s*,\\s*([0-9]+)\\s*,\\s*([0-9]+),?\\s*([0-9]?)$"
    })

    CaveBot.Editor.registerAction("endlure", "End Lure", {
      value = function()
        return posx() .. "," .. posy() .. "," .. posz()
      end,
      title = "End Lure",
      description = "Mage Run uses a 3x3 arrival area; other styles stand on the exact position",
      multiline = false,
      validation = "^\\s*([0-9]+)\\s*,\\s*([0-9]+)\\s*,\\s*([0-9]+)$"
    })

    Lure._editorActionsRegistered = true
  end

  if not Lure._macroRegistered then
    Lure._macroRegistered = true

    Lure._macro = macro(300, function()
      local extension = CaveBot.Extensions
        and CaveBot.Extensions.Lure

      if extension and extension._tick then
        extension._tick()
      end
    end)
  end
end
