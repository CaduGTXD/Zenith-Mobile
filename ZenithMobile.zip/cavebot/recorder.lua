-- auto recording for cavebot
CaveBot.Recorder = {}

local isEnabled = nil
local lastPos = nil
local lastWaypointWidget = nil
local lastWaypointPos = nil
local lastWaypointType = nil

local function copyPos(pos)
  return {x = pos.x, y = pos.y, z = pos.z}
end

local function samePos(a, b)
  return a and b and a.x == b.x and a.y == b.y and a.z == b.z
end

local function setup()
  local function getRecordDistance()
    local distance = 5

    if CaveBot.Config and CaveBot.Config.values and CaveBot.Config.values.recordDistance ~= nil then
      distance = tonumber(CaveBot.Config.values.recordDistance) or distance
    end

    distance = math.floor(distance)
    if distance < 1 then distance = 1 end
    if distance > 50 then distance = 50 end

    return distance
  end

  local function addPosition(pos)
    if lastWaypointType == "goto" and samePos(lastWaypointPos, pos) then
      lastPos = copyPos(pos)
      return
    end
    lastWaypointWidget = CaveBot.addAction("goto", pos.x .. "," .. pos.y .. "," .. pos.z, true)
    lastWaypointPos = copyPos(pos)
    lastWaypointType = "goto"
    lastPos = copyPos(pos)
  end
  local function addStand(pos)
    if samePos(lastWaypointPos, pos) then
      if lastWaypointType == "stand" then
        lastPos = copyPos(pos)
        return
      end
      if lastWaypointType == "goto" and lastWaypointWidget and CaveBot.editAction then
        CaveBot.editAction(lastWaypointWidget, "stand", pos.x .. "," .. pos.y .. "," .. pos.z)
        lastWaypointType = "stand"
        lastPos = copyPos(pos)
        return
      end
    end
    lastWaypointWidget = CaveBot.addAction("stand", pos.x .. "," .. pos.y .. "," .. pos.z, true)
    lastWaypointPos = copyPos(pos)
    lastWaypointType = "stand"
    lastPos = copyPos(pos)
  end

  local function addStairs(pos)
    if samePos(lastWaypointPos, pos) then
      if lastWaypointType == "stairs" then
        lastPos = copyPos(pos)
        return
      end
      if lastWaypointType == "goto" and lastWaypointWidget and CaveBot.editAction then
        CaveBot.editAction(lastWaypointWidget, "goto", pos.x .. "," .. pos.y .. "," .. pos.z .. ",0")
        lastWaypointType = "stairs"
        lastPos = copyPos(pos)
        return
      end
    end
    lastWaypointWidget = CaveBot.addAction("goto", pos.x .. "," .. pos.y .. "," .. pos.z .. ",0", true)
    lastWaypointPos = copyPos(pos)
    lastWaypointType = "stairs"
    lastPos = copyPos(pos)
  end

  onPlayerPositionChange(function(newPos, oldPos)
    if CaveBot.isOn() or not isEnabled then return end    
    if not lastPos then
      -- first step
      addPosition(oldPos)
    elseif newPos.z ~= oldPos.z then
      -- floor change: require the exact origin tile, then record the landing tile
      addStand(oldPos)
      addPosition(newPos)
    elseif math.abs(oldPos.x - newPos.x) > 1 or math.abs(oldPos.y - newPos.y) > 1 then
      -- stairs/teleport
      addStairs(oldPos)
    elseif math.max(math.abs(lastPos.x - newPos.x), math.abs(lastPos.y - newPos.y)) >= getRecordDistance() then
      -- configured steps from last recorded pos
      addPosition(newPos)
    end
  end)
  
  onUse(function(pos, itemId, stackPos, subType)
    if CaveBot.isOn() or not isEnabled then return end
    if pos.x ~= 0xFFFF then 
      lastPos = copyPos(pos)
      lastWaypointWidget = nil
      lastWaypointPos = nil
      lastWaypointType = nil
      CaveBot.addAction("use", pos.x .. "," .. pos.y .. "," .. pos.z, true)
    end
  end)
  
  onUseWith(function(pos, itemId, target, subType)
    if CaveBot.isOn() or not isEnabled then return end
    if not target:isItem() then return end
    local targetPos = target:getPosition()
    if targetPos.x == 0xFFFF then return end
    lastPos = copyPos(pos)
    lastWaypointWidget = nil
    lastWaypointPos = nil
    lastWaypointType = nil
    CaveBot.addAction("usewith", itemId .. "," .. targetPos.x .. "," .. targetPos.y .. "," .. targetPos.z, true)
  end)
end

CaveBot.Recorder.isOn = function()
  return isEnabled
end

CaveBot.Recorder.enable = function()
  CaveBot.setOff()
  if isEnabled == nil then
    setup()
  end
  -- CaveBot.Editor.ui.autoRecording:setOn(true)
  isEnabled = true
  lastPos = nil
  lastWaypointWidget = nil
  lastWaypointPos = nil
  lastWaypointType = nil
end

CaveBot.Recorder.disable = function()
  if isEnabled == true then
    isEnabled = false
  end
  -- CaveBot.Editor.ui.autoRecording:setOn(false)
  CaveBot.save()
end
