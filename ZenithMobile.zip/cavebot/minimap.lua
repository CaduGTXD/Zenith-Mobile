local function setupCaveBotMinimap(retries)
  retries = retries or 0
  local minimap = modules.game_minimap and modules.game_minimap.minimapWidget

  if not minimap then
    if retries < 20 then
      schedule(250, function()
        setupCaveBotMinimap(retries + 1)
      end)
    else
      warn("[CaveBot] Unable to hook minimap menu: minimap widget not found.")
    end
    return
  end

  if minimap._cavebotMinimapHooked then
    return
  end

  minimap._cavebotMinimapHooked = true
  minimap._cavebotOriginalOnMouseRelease = minimap.onMouseRelease

  minimap.onMouseRelease = function(widget,pos,button)
    local original = minimap._cavebotOriginalOnMouseRelease

    if not minimap.allowNextRelease then
      if original then
        return original(widget, pos, button)
      end
      return false
    end
    minimap.allowNextRelease = false

    if button ~= 2 then
      if original then
        return original(widget, pos, button)
      end
      return false
    end

    if not minimap.getTilePosition or not CaveBot or not CaveBot.addAction or not CaveBot.save then
      if original then
        return original(widget, pos, button)
      end
      return false
    end

    local mapPos = minimap:getTilePosition(pos)
    if not mapPos then
      if original then
        return original(widget, pos, button)
      end
      return false
    end

    local ok, result = pcall(function()
      local menu = g_ui.createWidget('PopupMenu')
      menu:setId("minimapMenu")
      menu:setGameMenu(true)
      if minimap.createFlagWindow then
        menu:addOption(tr('Create mark'), function() minimap:createFlagWindow(mapPos) end)
      end
      menu:addOption(tr('Add CaveBot GoTo'), function() CaveBot.addAction("goto", mapPos.x .. "," .. mapPos.y .. "," .. mapPos.z, true) CaveBot.save() end)
      menu:addOption(tr('Add CaveBot Stand'), function() CaveBot.addAction("stand", mapPos.x .. "," .. mapPos.y .. "," .. mapPos.z, true) CaveBot.save() end)
      menu:addOption(tr('Add CaveBot Start Lure'), function() CaveBot.addAction("startlure", mapPos.x .. "," .. mapPos.y .. "," .. mapPos.z, true) CaveBot.save() end)
      menu:addOption(tr('Add CaveBot End Lure'), function() CaveBot.addAction("endlure", mapPos.x .. "," .. mapPos.y .. "," .. mapPos.z, true) CaveBot.save() end)
      menu:display(pos)
      return true
    end)

    if ok then
      return result
    end

    warn("[CaveBot] Minimap hook error: " .. result)
    if original then
      return original(widget, pos, button)
    end
    return false
  end
end

setupCaveBotMinimap()
