setDefaultTab("Cave")

local panelName = "coreSettings"
storage[panelName] = storage[panelName] or {}
local settings = storage[panelName]

local defaults = {
  pathfinding = true,
  talkDelay = 1000,
  looting = 40,
  lootDelay = 200,
  huntRoutes = 50,
  killUnder = 1,
  gotoMaxDistance = 30,
  lootLast = true,
  joinBot = false,
  reachable = false,
  ignoreCreatures = "deer,rabbit",
  showTargetPriority = false,
  machete = 3308,
}

for key, value in pairs(defaults) do
  if settings[key] == nil then
    settings[key] = value
  end
end

CoreBotSettingsWindow = UI.createWindow('CoreBotSettingsWindow', rootWidget)
CoreBotSettingsWindow:hide()
CoreBotSettingsWindow.closeButton.onClick = function()
  CoreBotSettingsWindow:hide()
end

local leftPanel = CoreBotSettingsWindow.content.left
local rightPanel = CoreBotSettingsWindow.content.right

local function addCheckBox(id, title, dest, tooltip)
  local widget = UI.createWidget('CoreSettingsCheckBox', dest)
  widget:setText(title)
  widget:setTooltip(tooltip or "")
  widget:setOn(settings[id] == true)
  widget.onClick = function()
    widget:setOn(not widget:isOn())
    settings[id] = widget:isOn()
  end
end

local function addItem(id, title, dest, tooltip)
  local widget = UI.createWidget('CoreSettingsItem', dest)
  widget.text:setText(title)
  widget.text:setTooltip(tooltip or "")
  widget.item:setTooltip(tooltip or "")
  widget.item:setItemId(settings[id])
  widget.item.onItemChange = function(itemWidget)
    settings[id] = itemWidget:getItemId()
  end
end

local function addTextEdit(id, title, dest, tooltip)
  local widget = UI.createWidget('CoreSettingsTextEdit', dest)
  widget.text:setText(title)
  widget.text:setTooltip(tooltip or "")
  widget.textEdit:setText(tostring(settings[id] or ""))
  widget.textEdit.onTextChange = function(_, value)
    settings[id] = value
  end
end

local function addScrollBar(id, title, minValue, maxValue, dest, tooltip)
  local widget = UI.createWidget('CoreSettingsScrollBar', dest)
  widget.text:setTooltip(tooltip or "")
  widget.scroll:setRange(minValue, maxValue)
  widget.scroll:setTooltip(tooltip or "")

  if maxValue - minValue > 1000 then
    widget.scroll:setStep(100)
  elseif maxValue - minValue > 100 then
    widget.scroll:setStep(10)
  end

  widget.scroll.onValueChange = function(_, value)
    widget.text:setText(title .. ": " .. value)
    if value == 0 and id ~= "huntRoutes" then
      value = 1
    end
    settings[id] = value
  end

  widget.scroll:setValue(tonumber(settings[id]) or minValue)
  widget.scroll.onValueChange(widget.scroll, widget.scroll:getValue())
end

local button = UI.Button('Core Bot Settings', function()
  CoreBotSettingsWindow:show()
  CoreBotSettingsWindow:raise()
  CoreBotSettingsWindow:focus()
end)
button:setColor('orange')
button:setImageColor('#2de0d7')
button:setFont('verdana-11px-rounded')
UI.Separator()

addScrollBar('talkDelay', 'Global NPC Talk Delay', 0, 2000, leftPanel,
  'Delay between CaveBot NPC dialogue actions, in milliseconds.')
addScrollBar('looting', 'Max Loot Distance', 0, 50, leftPanel,
  'Corpses farther than this distance are ignored by TargetBot looting.')
addScrollBar('lootDelay', 'Loot Delay', 0, 2000, leftPanel,
  'Time to wait for a corpse container to open, in milliseconds.')
addScrollBar('huntRoutes', 'Hunting Rounds Limit', 0, 300, leftPanel,
  'Round limit used by supply checks. Zero disables the round limit.')
addScrollBar('killUnder', 'Kill Monsters Below', 0, 100, leftPanel,
  'Forces configured targets to be finished below this health percentage.')
addScrollBar('gotoMaxDistance', 'Max GoTo Distance', 0, 127, leftPanel,
  'Maximum waypoint distance CaveBot will attempt to reach.')
addTextEdit('ignoreCreatures', 'Ignore Creatures', leftPanel,
  'Creature names separated by commas.')
addItem('machete', 'Furniture Break Item', leftPanel,
  'Item used by CaveBot when it needs to cut blocking furniture.')

addCheckBox('pathfinding', 'CaveBot Pathfinding', rightPanel,
  'Search for another reachable waypoint after repeated failed GoTo attempts.')
addCheckBox('lootLast', 'Start Loot From Last Corpse', rightPanel,
  'Loot the newest registered corpse first.')
addCheckBox('joinBot', 'Join TargetBot and CaveBot', rightPanel,
  'Show TargetBot controls in the Cave tab.')
addCheckBox('reachable', 'Target Only Pathable Mobs', rightPanel,
  'Ignore configured creatures that cannot be reached.')
addCheckBox('showTargetPriority', 'Show Target Priority', rightPanel,
  'Display TargetBot priority information above creatures.')
