local standBySpells = false
local standByItems = false
local editingSpellIndex = nil
local editingItemIndex = nil

local red = "#ff0800" -- "#ff0800" / #ea3c53 best
local blue = "#7ef9ff"

local function formatSpellEntry(entry)
  return string.format("[%s%s%s | Mana:%s] %s", entry.origin, entry.sign, entry.value, entry.cost, entry.spell)
end

local function getSpellSourceCode(sourceText)
  if sourceText == "Current Mana" then
    return "MP"
  elseif sourceText == "Current Health" then
    return "HP"
  elseif sourceText == "Mana Percent" then
    return "MP%"
  elseif sourceText == "Health Percent" then
    return "HP%"
  end
  return "burst"
end

local function getSpellSourceText(sourceCode)
  if sourceCode == "MP" then
    return "Current Mana"
  elseif sourceCode == "HP" then
    return "Current Health"
  elseif sourceCode == "MP%" then
    return "Mana Percent"
  elseif sourceCode == "HP%" then
    return "Health Percent"
  end
  return "Burst Damage"
end

local function getSpellConditionCode(conditionText)
  if conditionText == "Above" then
    return ">"
  elseif conditionText == "Below" then
    return "<"
  end
  return "="
end

local function getSpellConditionText(conditionCode)
  if conditionCode == ">" then
    return "Above"
  elseif conditionCode == "<" then
    return "Below"
  end
  return "Equal To"
end

setDefaultTab("HP")
local healPanelName = "healbot"
local ui = setupUI([[
Panel
  height: 38

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    text-align: center
    width: 130
    !text: tr('HealBot')

  Button
    id: settings
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 3
    height: 17
    text: Setup

  Button
    id: 1
    anchors.top: prev.bottom
    anchors.left: parent.left
    text: 1
    margin-right: 2
    margin-top: 4
    size: 17 17

  Button
    id: 2
    anchors.verticalCenter: prev.verticalCenter
    anchors.left: prev.right
    text: 2
    margin-left: 4
    size: 17 17
    
  Button
    id: 3
    anchors.verticalCenter: prev.verticalCenter
    anchors.left: prev.right
    text: 3
    margin-left: 4
    size: 17 17

  Button
    id: 4
    anchors.verticalCenter: prev.verticalCenter
    anchors.left: prev.right
    text: 4
    margin-left: 4
    size: 17 17 
    
  Button
    id: 5
    anchors.verticalCenter: prev.verticalCenter
    anchors.left: prev.right
    text: 5
    margin-left: 4
    size: 17 17
    
  Label
    id: name
    anchors.verticalCenter: prev.verticalCenter
    anchors.left: prev.right
    anchors.right: parent.right
    text-align: center
    margin-left: 4
    height: 17
    text: Profile #1
    background: #292A2A
]])
ui:setId(healPanelName)

if not HealBotConfig[healPanelName] or not HealBotConfig[healPanelName][1] or #HealBotConfig[healPanelName] ~= 5 then
  HealBotConfig[healPanelName] = {
    [1] = {
      enabled = false,
      spellTable = {},
      itemTable = {},
      name = "Profile #1",
      Visible = true,
      OldSchool = false,
      Cooldown = true,
      Interval = true,
      Conditions = true,
      Delay = true,
      MessageDelay = false
    },
    [2] = {
      enabled = false,
      spellTable = {},
      itemTable = {},
      name = "Profile #2",
      Visible = true,
      OldSchool = false,
      Cooldown = true,
      Interval = true,
      Conditions = true,
      Delay = true,
      MessageDelay = false
    },
    [3] = {
      enabled = false,
      spellTable = {},
      itemTable = {},
      name = "Profile #3",
      Visible = true,
      OldSchool = false,
      Cooldown = true,
      Interval = true,
      Conditions = true,
      Delay = true,
      MessageDelay = false
    },
    [4] = {
      enabled = false,
      spellTable = {},
      itemTable = {},
      name = "Profile #4",
      Visible = true,
      OldSchool = false,
      Cooldown = true,
      Interval = true,
      Conditions = true,
      Delay = true,
      MessageDelay = false
    },
    [5] = {
      enabled = false,
      spellTable = {},
      itemTable = {},
      name = "Profile #5",
      Visible = true,
      OldSchool = false,
      Cooldown = true,
      Interval = true,
      Conditions = true,
      Delay = true,
      MessageDelay = false
    },
  }
end

if not HealBotConfig.currentHealBotProfile or HealBotConfig.currentHealBotProfile == 0 or HealBotConfig.currentHealBotProfile > 5 then 
  HealBotConfig.currentHealBotProfile = 1
end

-- finding correct table, manual unfortunately
local currentSettings
local setActiveProfile = function()
  local n = HealBotConfig.currentHealBotProfile
  currentSettings = HealBotConfig[healPanelName][n]
end
setActiveProfile()

local activeProfileColor = function()
  for i=1,5 do
    if i == HealBotConfig.currentHealBotProfile then
      ui[i]:setColor("green")
    else
      ui[i]:setColor("white")
    end
  end
end
activeProfileColor()

ui.title:setOn(currentSettings.enabled)
ui.title.onClick = function(widget)
  currentSettings.enabled = not currentSettings.enabled
  widget:setOn(currentSettings.enabled)
  vBotConfigSave("heal")
end

ui.settings.onClick = function(widget)
  healWindow:show()
  healWindow:raise()
  healWindow:focus()
end

rootWidget = g_ui.getRootWidget()
if rootWidget then
  healWindow = UI.createWindow('HealWindow', rootWidget)
  healWindow:hide()

  local clearSpellEditor
  local startSpellEdit
  local saveSpellEntry
  local clearItemEditor
  local startItemEdit
  local saveItemEntry

  healWindow.onVisibilityChange = function(widget, visible)
    if not visible then
      vBotConfigSave("heal")
      healWindow.healer:show()
      healWindow.settings:hide()
      healWindow.settingsButton:setText("Settings")
      if clearSpellEditor then
        clearSpellEditor()
      end
      if clearItemEditor then
        clearItemEditor()
      end
    end
  end

  healWindow.settingsButton.onClick = function(widget)
    if healWindow.healer:isVisible() then
      healWindow.healer:hide()
      healWindow.settings:show()
      widget:setText("Back")
    else
      healWindow.healer:show()
      healWindow.settings:hide()
      widget:setText("Settings")
    end
  end

  local setProfileName = function()
    ui.name:setText(currentSettings.name)
  end
  healWindow.settings.profiles.Name.onTextChange = function(widget, text)
    currentSettings.name = text
    setProfileName()
  end
  healWindow.settings.list.Visible.onClick = function(widget)
    currentSettings.Visible = not currentSettings.Visible
    healWindow.settings.list.Visible:setChecked(currentSettings.Visible)
  end
  healWindow.settings.list.OldSchool.onClick = function(widget)
    currentSettings.OldSchool = not currentSettings.OldSchool
    healWindow.settings.list.OldSchool:setChecked(currentSettings.OldSchool)
  end
  healWindow.settings.list.Cooldown.onClick = function(widget)
    currentSettings.Cooldown = not currentSettings.Cooldown
    healWindow.settings.list.Cooldown:setChecked(currentSettings.Cooldown)
  end
  healWindow.settings.list.Interval.onClick = function(widget)
    currentSettings.Interval = not currentSettings.Interval
    healWindow.settings.list.Interval:setChecked(currentSettings.Interval)
  end
  healWindow.settings.list.Conditions.onClick = function(widget)
    currentSettings.Conditions = not currentSettings.Conditions
    healWindow.settings.list.Conditions:setChecked(currentSettings.Conditions)
  end
  healWindow.settings.list.Delay.onClick = function(widget)
    currentSettings.Delay = not currentSettings.Delay
    healWindow.settings.list.Delay:setChecked(currentSettings.Delay)
  end
  healWindow.settings.list.MessageDelay.onClick = function(widget)
    currentSettings.MessageDelay = not currentSettings.MessageDelay
    healWindow.settings.list.MessageDelay:setChecked(currentSettings.MessageDelay)
  end

  local refreshSpells = function()
    if currentSettings.spellTable then
      healWindow.healer.spells.spellList:destroyChildren()
      for index, entry in pairs(currentSettings.spellTable) do
        local label = UI.createWidget("SpellEntry", healWindow.healer.spells.spellList)
        label.entryIndex = index
        label.enabled:setChecked(entry.enabled)
        label.enabled.onClick = function(widget)
          standBySpells = false
          standByItems = false
          entry.enabled = not entry.enabled
          label.enabled:setChecked(entry.enabled)
        end
        label.remove.onClick = function(widget)
          standBySpells = false
          standByItems = false
          if editingSpellIndex and editingSpellIndex == index and clearSpellEditor then
            clearSpellEditor()
          elseif editingSpellIndex and editingSpellIndex > index then
            editingSpellIndex = editingSpellIndex - 1
          end
          table.removevalue(currentSettings.spellTable, entry)
          reindexTable(currentSettings.spellTable)
          label:destroy()
        end
        label:setText(formatSpellEntry(entry))
      end
    end
  end
  refreshSpells()

  local refreshItems = function()
    if currentSettings.itemTable then
      healWindow.healer.items.itemList:destroyChildren()
      for index, entry in pairs(currentSettings.itemTable) do
        local label = UI.createWidget("ItemEntry", healWindow.healer.items.itemList)
        label.entryIndex = index
        label.onClick = function(widget)
          healWindow.healer.items.itemList:focusChild(widget)
        end
        label.enabled:setChecked(entry.enabled)
        label.enabled.onClick = function(widget)
          standBySpells = false
          standByItems = false
          entry.enabled = not entry.enabled
          label.enabled:setChecked(entry.enabled)
        end
        label.remove.onClick = function(widget)
          standBySpells = false
          standByItems = false
          if editingItemIndex and editingItemIndex == index and clearItemEditor then
            clearItemEditor()
          elseif editingItemIndex and editingItemIndex > index then
            editingItemIndex = editingItemIndex - 1
          end
          table.removevalue(currentSettings.itemTable, entry)
          reindexTable(currentSettings.itemTable)
          label:destroy()
        end
        label.onDoubleClick = function(widget)
          healWindow.healer.items.itemList:focusChild(widget)
          startItemEdit(index)
        end
        label.id:setItemId(entry.item)
        label.id:setItemSubType(entry.subType)
        label:setText(entry.origin .. entry.sign .. entry.value .. ": " .. entry.item)
      end
    end
  end
  refreshItems()

  healWindow.healer.spells.MoveUp.onClick = function(widget)
    local input = healWindow.healer.spells.spellList:getFocusedChild()
    if not input then return end
    local index = healWindow.healer.spells.spellList:getChildIndex(input)
    if index < 2 then return end

    local t = currentSettings.spellTable

    t[index],t[index-1] = t[index-1], t[index]
    if editingSpellIndex == index then
      editingSpellIndex = index - 1
    elseif editingSpellIndex == index - 1 then
      editingSpellIndex = index
    end
    healWindow.healer.spells.spellList:moveChildToIndex(input, index - 1)
    healWindow.healer.spells.spellList:ensureChildVisible(input)
  end

  healWindow.healer.spells.MoveDown.onClick = function(widget)
    local input = healWindow.healer.spells.spellList:getFocusedChild()
    if not input then return end
    local index = healWindow.healer.spells.spellList:getChildIndex(input)
    if index >= healWindow.healer.spells.spellList:getChildCount() then return end

    local t = currentSettings.spellTable

    t[index],t[index+1] = t[index+1],t[index]
    if editingSpellIndex == index then
      editingSpellIndex = index + 1
    elseif editingSpellIndex == index + 1 then
      editingSpellIndex = index
    end
    healWindow.healer.spells.spellList:moveChildToIndex(input, index + 1)
    healWindow.healer.spells.spellList:ensureChildVisible(input)
  end

  clearSpellEditor = function()
    editingSpellIndex = nil
    healWindow.healer.spells.spellFormula:setText('')
    healWindow.healer.spells.spellValue:setText('')
    healWindow.healer.spells.manaCost:setText('')
    healWindow.healer.spells.spellSource:setOption("Current Mana")
    healWindow.healer.spells.spellCondition:setOption("Below")
    healWindow.healer.spells.addSpell:setText("Add")
    healWindow.healer.spells.editSpell:setText("Edit")
  end

  startSpellEdit = function(index)
    local entry = currentSettings.spellTable[index]
    if not entry then return end

    editingSpellIndex = index
    healWindow.healer.spells.spellFormula:setText(entry.spell or '')
    healWindow.healer.spells.spellValue:setText(tostring(entry.value or ''))
    healWindow.healer.spells.manaCost:setText(tostring(entry.cost or ''))
    healWindow.healer.spells.spellSource:setOption(getSpellSourceText(entry.origin))
    healWindow.healer.spells.spellCondition:setOption(getSpellConditionText(entry.sign))
    healWindow.healer.spells.addSpell:setText("Save")
    healWindow.healer.spells.editSpell:setText("Cancel")
  end

  saveSpellEntry = function()
    local spellFormula = healWindow.healer.spells.spellFormula:getText():trim()
    local manaCost = tonumber(healWindow.healer.spells.manaCost:getText())
    local spellTrigger = tonumber(healWindow.healer.spells.spellValue:getText())
    local spellSource = healWindow.healer.spells.spellSource:getCurrentOption().text
    local spellCondition = healWindow.healer.spells.spellCondition:getCurrentOption().text
    local source = getSpellSourceCode(spellSource)
    local equation = getSpellConditionCode(spellCondition)

    if not manaCost then
      warn("HealBot: incorrect mana cost value!")
      healWindow.healer.spells.spellFormula:setText('')
      healWindow.healer.spells.spellValue:setText('')
      healWindow.healer.spells.manaCost:setText('')
      return false
    end

    if not spellTrigger then
      warn("HealBot: incorrect condition value!")
      healWindow.healer.spells.spellFormula:setText('')
      healWindow.healer.spells.spellValue:setText('')
      healWindow.healer.spells.manaCost:setText('')
      return false
    end

    if spellFormula:len() < 1 then
      return false
    end

    local entry = {
      spell = spellFormula,
      sign = equation,
      origin = source,
      cost = manaCost,
      value = spellTrigger,
      enabled = true
    }

    if editingSpellIndex and currentSettings.spellTable[editingSpellIndex] then
      entry.index = editingSpellIndex
      entry.enabled = currentSettings.spellTable[editingSpellIndex].enabled
      currentSettings.spellTable[editingSpellIndex] = entry
    else
      entry.index = #currentSettings.spellTable + 1
      table.insert(currentSettings.spellTable, entry)
    end

    standBySpells = false
    standByItems = false
    refreshSpells()
    clearSpellEditor()
    return true
  end

  healWindow.healer.spells.editSpell.onClick = function(widget)
    if editingSpellIndex then
      clearSpellEditor()
      return
    end

    local input = healWindow.healer.spells.spellList:getFocusedChild()
    if not input then return end
    local index = healWindow.healer.spells.spellList:getChildIndex(input)
    if not index or not currentSettings.spellTable[index] then return end
    startSpellEdit(index)
  end

  healWindow.healer.items.MoveUp.onClick = function(widget)
    local input = healWindow.healer.items.itemList:getFocusedChild()
    if not input then return end
    local index = healWindow.healer.items.itemList:getChildIndex(input)
    if index < 2 then return end

    local t = currentSettings.itemTable

    t[index],t[index-1] = t[index-1], t[index]
    if editingItemIndex == index then
      editingItemIndex = index - 1
    elseif editingItemIndex == index - 1 then
      editingItemIndex = index
    end
    healWindow.healer.items.itemList:moveChildToIndex(input, index - 1)
    healWindow.healer.items.itemList:ensureChildVisible(input)
  end

  healWindow.healer.items.MoveDown.onClick = function(widget)
    local input = healWindow.healer.items.itemList:getFocusedChild()
    if not input then return end
    local index = healWindow.healer.items.itemList:getChildIndex(input)
    if index >= healWindow.healer.items.itemList:getChildCount() then return end

    local t = currentSettings.itemTable

    t[index],t[index+1] = t[index+1],t[index]
    if editingItemIndex == index then
      editingItemIndex = index + 1
    elseif editingItemIndex == index + 1 then
      editingItemIndex = index
    end
    healWindow.healer.items.itemList:moveChildToIndex(input, index + 1)
    healWindow.healer.items.itemList:ensureChildVisible(input)
  end

  clearItemEditor = function()
    editingItemIndex = nil
    healWindow.healer.items.itemId:setItemId(0)
    if healWindow.healer.items.itemId.setItemSubType then
      healWindow.healer.items.itemId:setItemSubType(0)
    end
    healWindow.healer.items.itemValue:setText('')
    healWindow.healer.items.itemSource:setOption("Current Mana")
    healWindow.healer.items.itemCondition:setOption("Below")
    healWindow.healer.items.addItem:setText("Add")
    healWindow.healer.items.editItem:setText("Edit")
  end

  startItemEdit = function(index)
    local entry = currentSettings.itemTable[index]
    if not entry then return end

    editingItemIndex = index
    healWindow.healer.items.itemId:setItemId(entry.item)
    if healWindow.healer.items.itemId.setItemSubType then
      healWindow.healer.items.itemId:setItemSubType(entry.subType or 0)
    end
    healWindow.healer.items.itemValue:setText(tostring(entry.value or ''))
    healWindow.healer.items.itemSource:setOption(getSpellSourceText(entry.origin))
    healWindow.healer.items.itemCondition:setOption(getSpellConditionText(entry.sign))
    healWindow.healer.items.addItem:setText("Save")
    healWindow.healer.items.editItem:setText("Cancel")
  end

  saveItemEntry = function()
    local id = healWindow.healer.items.itemId:getItemId()
    local thing = g_things.getThingType(id)
    local subType = g_game.getClientVersion() >= 860 and 0 or 1
    if thing and thing:isFluidContainer() then
      subType = healWindow.healer.items.itemId:getItem():getSubType()
    end
    local trigger = tonumber(healWindow.healer.items.itemValue:getText())
    local src = healWindow.healer.items.itemSource:getCurrentOption().text
    local eq = healWindow.healer.items.itemCondition:getCurrentOption().text
    local source = getSpellSourceCode(src)
    local equation = getSpellConditionCode(eq)

    if not trigger then
      warn("HealBot: incorrect trigger value!")
      healWindow.healer.items.itemId:setItemId(0)
      healWindow.healer.items.itemValue:setText('')
      return false
    end

    if id <= 100 then
      return false
    end

    local entry = {
      item = id,
      sign = equation,
      origin = source,
      value = trigger,
      enabled = true,
      subType = subType
    }

    if editingItemIndex and currentSettings.itemTable[editingItemIndex] then
      entry.index = editingItemIndex
      entry.enabled = currentSettings.itemTable[editingItemIndex].enabled
      currentSettings.itemTable[editingItemIndex] = entry
    else
      entry.index = #currentSettings.itemTable + 1
      table.insert(currentSettings.itemTable, entry)
    end

    standBySpells = false
    standByItems = false
    refreshItems()
    clearItemEditor()
    return true
  end

  healWindow.healer.items.editItem.onClick = function(widget)
    if editingItemIndex then
      clearItemEditor()
      return
    end

    local input = healWindow.healer.items.itemList:getFocusedChild()
    if not input then return end
    local index = healWindow.healer.items.itemList:getChildIndex(input)
    if not index or not currentSettings.itemTable[index] then return end
    startItemEdit(index)
  end

  healWindow.healer.spells.addSpell.onClick = function(widget)
    saveSpellEntry()
  end

  healWindow.healer.items.addItem.onClick = function(widget)
    saveItemEntry()
  end

  healWindow.closeButton.onClick = function(widget)
    healWindow:hide()
  end

  local loadSettings = function()
    ui.title:setOn(currentSettings.enabled)
    setProfileName()
    clearSpellEditor()
    clearItemEditor()
    healWindow.settings.profiles.Name:setText(currentSettings.name)
    refreshSpells()
    refreshItems()
    healWindow.settings.list.Visible:setChecked(currentSettings.Visible)
    healWindow.settings.list.OldSchool:setChecked(currentSettings.OldSchool)
    healWindow.settings.list.Cooldown:setChecked(currentSettings.Cooldown)
    healWindow.settings.list.Delay:setChecked(currentSettings.Delay)
    healWindow.settings.list.MessageDelay:setChecked(currentSettings.MessageDelay)
    healWindow.settings.list.Interval:setChecked(currentSettings.Interval)
    healWindow.settings.list.Conditions:setChecked(currentSettings.Conditions)
  end
  loadSettings()

  local profileChange = function()
    setActiveProfile()
    activeProfileColor()
    loadSettings()
    vBotConfigSave("heal")
  end

  local resetSettings = function()
    currentSettings.enabled = false
    currentSettings.spellTable = {}
    currentSettings.itemTable = {}
    currentSettings.Visible = true
    currentSettings.OldSchool = false
    currentSettings.Cooldown = true
    currentSettings.Delay = true
    currentSettings.MessageDelay = false
    currentSettings.Interval = true
    currentSettings.Conditions = true
    currentSettings.name = "Profile #" .. HealBotConfig.currentBotProfile
  end

  -- profile buttons
  for i=1,5 do
    local button = ui[i]
      button.onClick = function()
      HealBotConfig.currentHealBotProfile = i
      profileChange()
    end
  end

  healWindow.settings.profiles.ResetSettings.onClick = function()
    resetSettings()
    loadSettings()
  end


  -- public functions
  HealBot = {} -- global table

  HealBot.isOn = function()
    return currentSettings.enabled
  end

  HealBot.isOff = function()
    return not currentSettings.enabled
  end

  HealBot.setOff = function()
    currentSettings.enabled = false
    ui.title:setOn(currentSettings.enabled)
    vBotConfigSave("atk")
  end

  HealBot.setOn = function()
    currentSettings.enabled = true
    ui.title:setOn(currentSettings.enabled)
    vBotConfigSave("atk")
  end

  HealBot.getActiveProfile = function()
    return HealBotConfig.currentHealBotProfile -- returns number 1-5
  end

  HealBot.setActiveProfile = function(n)
    if not n or not tonumber(n) or n < 1 or n > 5 then
      return error("[HealBot] wrong profile parameter! should be 1 to 5 is " .. n)
    else
      HealBotConfig.currentHealBotProfile = n
      profileChange()
    end
  end

  HealBot.show = function()
    healWindow:show()
    healWindow:raise()
    healWindow:focus()
  end
end

-- spells
macro(100, function()
  if standBySpells then return end
  if not currentSettings.enabled then return end
  local somethingIsOnCooldown = false

  for _, entry in pairs(currentSettings.spellTable) do
    if entry.enabled and entry.cost < mana() then
      if canCast(entry.spell, not currentSettings.Conditions, not currentSettings.Cooldown) then
        if entry.origin == "HP%" then
          if entry.sign == "=" and hppercent() == entry.value then
            say(entry.spell)
            return
          elseif entry.sign == ">" and hppercent() >= entry.value then
            say(entry.spell)
            return
          elseif entry.sign == "<" and hppercent() <= entry.value then
            say(entry.spell)
            return
          end
        elseif entry.origin == "HP" then
          if entry.sign == "=" and hp() == entry.value then
            say(entry.spell)
            return
          elseif entry.sign == ">" and hp() >= entry.value then
            say(entry.spell)
            return
          elseif entry.sign == "<" and hp() <= entry.value then
            say(entry.spell)
            return
          end
        elseif entry.origin == "MP%" then
          if entry.sign == "=" and manapercent() == entry.value then
            say(entry.spell)
            return
          elseif entry.sign == ">" and manapercent() >= entry.value then
            say(entry.spell)
            return
          elseif entry.sign == "<" and manapercent() <= entry.value then
            say(entry.spell)
            return
          end
        elseif entry.origin == "MP" then
          if entry.sign == "=" and mana() == entry.value then
            say(entry.spell)
            return
          elseif entry.sign == ">" and mana() >= entry.value then
            say(entry.spell)
            return
          elseif entry.sign == "<" and mana() <= entry.value then
            say(entry.spell)
            return
          end    
        elseif entry.origin == "burst" then
          if entry.sign == "=" and burstDamageValue() == entry.value then
            say(entry.spell)
            return
          elseif entry.sign == ">" and burstDamageValue() >= entry.value then
            say(entry.spell)
            return
          elseif entry.sign == "<" and burstDamageValue() <= entry.value then
            say(entry.spell)
            return
          end    
        end
      else
        somethingIsOnCooldown = true
      end
    end
  end
  if not somethingIsOnCooldown then
    standBySpells = true 
  end
end)

-- items
macro(100, function()
  if standByItems then return end
  if not currentSettings.enabled or #currentSettings.itemTable == 0 then return end
  if currentSettings.Delay and vBot.isUsing then return end
  if currentSettings.MessageDelay and vBot.isUsingPotion then return end

  if not currentSettings.MessageDelay then
    delay(400)
  end

  if TargetBot.isOn() and TargetBot.Looting.getStatus():len() > 0 and currentSettings.Interval then
    if not currentSettings.MessageDelay then
      delay(700)
    else
      delay(200)
    end
  end

  for _, entry in pairs(currentSettings.itemTable) do
    local item = findItem(entry.item)
    if (not currentSettings.Visible or item) and (currentSettings.OldSchool or item) and entry.enabled then
      local useItem = currentSettings.OldSchool and item or entry.item
      if entry.origin == "HP%" then
        if entry.sign == "=" and hppercent() == entry.value then
          useWith(useItem, player, entry.subType)
          return
        elseif entry.sign == ">" and hppercent() >= entry.value then
          useWith(useItem, player, entry.subType)
          return
        elseif entry.sign == "<" and hppercent() <= entry.value then
          useWith(useItem, player, entry.subType)
          return
        end
      elseif entry.origin == "HP" then
        if entry.sign == "=" and hp() == tonumberentry.value then
          useWith(useItem, player, entry.subType)
          return
        elseif entry.sign == ">" and hp() >= entry.value then
          useWith(useItem, player, entry.subType)
          return
        elseif entry.sign == "<" and hp() <= entry.value then
          useWith(useItem, player, entry.subType)
          return
        end
      elseif entry.origin == "MP%" then
        if entry.sign == "=" and manapercent() == entry.value then
          useWith(useItem, player, entry.subType)
          return
        elseif entry.sign == ">" and manapercent() >= entry.value then
          useWith(useItem, player, entry.subType)
          return
        elseif entry.sign == "<" and manapercent() <= entry.value then
          useWith(useItem, player, entry.subType)
          return
        end
      elseif entry.origin == "MP" then
        if entry.sign == "=" and mana() == entry.value then
          useWith(useItem, player, entry.subType)
          return
        elseif entry.sign == ">" and mana() >= entry.value then
          useWith(useItem, player, entry.subType)
          return
        elseif entry.sign == "<" and mana() <= entry.value then
          useWith(useItem, player, entry.subType)
          return
        end   
      elseif entry.origin == "burst" then
        if entry.sign == "=" and burstDamageValue() == entry.value then
          useWith(useItem, player, entry.subType)
          return
        elseif entry.sign == ">" and burstDamageValue() >= entry.value then
          useWith(useItem, player, entry.subType)
          return
        elseif entry.sign == "<" and burstDamageValue() <= entry.value then
          useWith(useItem, player, entry.subType)
          return
        end   
      end
    end
  end
  standByItems = true
end)
UI.Separator()

onPlayerHealthChange(function(healthPercent)
  standByItems = false
  standBySpells = false
end)

onManaChange(function(player, mana, maxMana, oldMana, oldMaxMana)
  standByItems = false
  standBySpells = false
end)
