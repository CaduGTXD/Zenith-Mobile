-- Zenith Mobile floating interface.
-- Redirects the legacy bot tab helpers to an independent floating window.

local root = g_ui.getRootWidget()

storage.zenithMobileUI = storage.zenithMobileUI or {}
local uiStorage = storage.zenithMobileUI
if uiStorage.open == nil then
  uiStorage.open = true
end

local window = g_ui.createWidget('ZenithMobileWindow', root)
window.botWidget = true
window:hide()

local toggleButton = g_ui.createWidget('ZenithMobileToggleButton', root)
toggleButton.botWidget = true

local tabBar = window.zenithTabs
local tabContent = window.zenithTabContent
tabBar:setContentWidget(tabContent)

local currentPanel = nil
local tabPanels = {}

local function normalizeTabName(name)
  name = tostring(name or 'Main')
  local lowered = name:lower()

  if lowered == 'hp' then
    return 'HP'
  elseif lowered == 'cave' then
    return 'Cave'
  elseif lowered == 'target' then
    return 'Target'
  elseif lowered == 'tools' then
    return 'Tools'
  elseif lowered == 'main' then
    return 'Main'
  end

  return name
end

local function updateToggleAppearance()
  if window:isVisible() then
    toggleButton:setText('CLOSE')
    toggleButton:setColor('#2de0d7')
  else
    toggleButton:setText('ZENITH')
    toggleButton:setColor('#ffffff')
  end
end

local function showWindow()
  window:show()
  window:raise()
  window:focus()
  uiStorage.open = true
  updateToggleAppearance()
end

local function hideWindow()
  window:hide()
  uiStorage.open = false
  updateToggleAppearance()
end

local function toggleWindow()
  if window:isVisible() then
    hideWindow()
  else
    showWindow()
  end
end

local function createTab(name)
  name = normalizeTabName(name)

  if tabPanels[name] then
    return tabPanels[name]
  end

  local existing = tabBar:getTab(name)
  if existing and existing.tabPanel and existing.tabPanel.content then
    tabPanels[name] = existing.tabPanel.content
    return tabPanels[name]
  end

  local botPanel = g_ui.createWidget('BotPanel')
  botPanel.botWidget = true
  botPanel:setId('zenithMobile' .. name:gsub('[^%w]', '') .. 'Tab')

  local tab = tabBar:addTab(name, botPanel)
  tabBar:setOn(true)

  if #tabBar.tabs >= 5 then
    for _, tabButton in pairs(tabBar.tabs) do
      tabButton:setFont('small-9px')
    end
  end

  tabPanels[name] = tab.tabPanel.content
  return tabPanels[name]
end

-- Replace the bot's legacy tab routing with the floating Zenith window.
addTab = function(name)
  return createTab(name)
end

getTab = addTab

setDefaultTab = function(name)
  currentPanel = createTab(name)
  panel = currentPanel
  return currentPanel
end

setupUI = function(otml, parent)
  parent = parent or currentPanel or panel or createTab('Main')
  local widget = g_ui.loadUIFromString(otml, parent)
  widget.botWidget = true
  return widget
end

createWidget = function(name, parent)
  parent = parent or currentPanel or panel or createTab('Main')
  local widget = g_ui.createWidget(name, parent)
  widget.botWidget = true
  return widget
end

addSwitch = function(id, text, callback, parent)
  local widget = createWidget('BotSwitch', parent)
  widget:setId(id)
  widget:setText(text)
  widget.onClick = callback
  return widget
end

addButton = function(id, text, callback, parent)
  local widget = createWidget('BotButton', parent)
  widget:setId(id)
  widget:setText(text)
  widget.onClick = callback
  return widget
end

addLabel = function(id, text, parent)
  local widget = createWidget('BotLabel', parent)
  widget:setId(id)
  widget:setText(text)
  return widget
end

addTextEdit = function(id, text, callback, parent)
  local widget = createWidget('BotTextEdit', parent)
  widget:setId(id)
  widget:setText(text)
  widget.onTextChange = callback
  return widget
end

addSeparator = function(id, parent)
  local widget = createWidget('BotSeparator', parent)
  widget:setId(id)
  return widget
end

-- Modern UI helpers also default to the floating tab currently selected by scripts.
UI.createWidget = function(name, parent)
  parent = parent or currentPanel or panel or createTab('Main')
  local widget = g_ui.createWidget(name, parent)
  widget.botWidget = true
  return widget
end

-- Make built-in helpers that depend on context.panel follow our window.
local firstPanel = createTab('Cave')
currentPanel = firstPanel
panel = firstPanel
mainTab = firstPanel
tabs = tabBar

window.closeButton.onClick = hideWindow
window.onEscape = hideWindow
toggleButton.onClick = toggleWindow

-- Keep the floating window usable on both desktop and smaller mobile layouts.
local rootWidth = root:getWidth()
local rootHeight = root:getHeight()
window:setWidth(math.min(430, math.max(240, rootWidth - 20)))
window:setHeight(math.min(560, math.max(300, rootHeight - 40)))
local windowWidth = window:getWidth()
local windowHeight = window:getHeight()
window:setPosition({
  x = math.max(0, math.floor((rootWidth - windowWidth) / 2)),
  y = math.max(0, math.floor((rootHeight - windowHeight) / 2))
})

-- The original sidebar stays alive internally because it owns the bot executor,
-- but it is hidden so the floating interface is the only visible bot UI.
if modules.game_bot then
  if modules.game_bot.botWindow then
    modules.game_bot.botWindow:hide()
  end
  -- Keep the native top button available as a recovery/configuration entry.
  -- The actual bot modules no longer render there.
  if modules.game_bot.botButton then
    modules.game_bot.botButton:setOn(false)
  end
end

if uiStorage.open then
  showWindow()
else
  hideWindow()
end

ZenithMobileUI = {
  window = window,
  button = toggleButton,
  show = showWindow,
  hide = hideWindow,
  toggle = toggleWindow,
  getTab = createTab,
}
