setDefaultTab("Tools")

local panelName = "quiverManagerUI"
local idSlots = 4

if type(storage[panelName]) ~= "table" then
  storage[panelName] = {
    enabled = false,
    quiverIds = {0, 0, 0, 0},
    ammoIds = {0, 0, 0, 0},
    ammoContainerId = 0,
    min = 50,
    max = 200
  }
end

local config = storage[panelName]

local function clamp(value, minValue, maxValue)
  value = tonumber(value) or minValue
  if value < minValue then return minValue end
  if value > maxValue then return maxValue end
  return value
end

local function normalizeIdList(list, legacyValue)
  local result = {}
  if type(list) == "table" then
    for i = 1, idSlots do
      result[i] = tonumber(list[i]) or 0
    end
  else
    result[1] = tonumber(legacyValue) or 0
    for i = 2, idSlots do
      result[i] = 0
    end
  end
  return result
end

local hold = false

config.enabled = config.enabled == true
config.quiverIds = normalizeIdList(config.quiverIds, config.quiverId)
config.ammoIds = normalizeIdList(config.ammoIds, config.ammoId)
config.ammoContainerId = tonumber(config.ammoContainerId) or 0
config.min = clamp(config.min or 50, 0, 1000)
config.max = clamp(config.max or 200, 0, 1000)
if config.max < config.min then
  config.max = config.min
end
config.quiverId = nil
config.ammoId = nil

local mainPanel = setupUI([[
Panel
  height: 25

  BotSwitch
    id: enabled
    anchors.top: parent.top
    anchors.left: parent.left
    width: 125
    height: 20
    text-align: center
    text: Quiver Manager

  Button
    id: setup
    anchors.top: parent.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 4
    height: 20
    text: Setup

  HorizontalSeparator
    anchors.top: enabled.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
]])

g_ui.loadUIFromString([[
QuiverManagerWindow < MainWindow
  !text: tr('Quiver Manager')
  size: 230 430
  @onEscape: self:hide()

  Label
    id: quiverLabel
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 18
    text-align: center
    text: Quivers

  Panel
    id: quiverGrid
    anchors.top: quiverLabel.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 72
    layout:
      type: grid
      cell-size: 32 32
      cell-spacing: 8
      num-columns: 2
      fit-children: true

    BotItem
      id: quiver1
      tooltip: Drag a quiver item here

    BotItem
      id: quiver2
      tooltip: Drag a quiver item here

    BotItem
      id: quiver3
      tooltip: Drag a quiver item here

    BotItem
      id: quiver4
      tooltip: Drag a quiver item here

  Label
    id: ammoLabel
    anchors.top: quiverGrid.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 18
    text-align: center
    text: Ammo

  Panel
    id: ammoGrid
    anchors.top: ammoLabel.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 72
    layout:
      type: grid
      cell-size: 32 32
      cell-spacing: 8
      num-columns: 2
      fit-children: true

    BotItem
      id: ammo1
      tooltip: Drag an arrow or bolt here

    BotItem
      id: ammo2
      tooltip: Drag an arrow or bolt here

    BotItem
      id: ammo3
      tooltip: Drag an arrow or bolt here

    BotItem
      id: ammo4
      tooltip: Drag an arrow or bolt here

  Label
    id: ammoContainerLabel
    anchors.top: ammoGrid.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 18
    text-align: center
    text: Ammo Backpack

  BotItem
    id: ammoContainerItem
    anchors.top: ammoContainerLabel.bottom
    anchors.horizontalCenter: parent.horizontalCenter
    margin-top: 4
    size: 32 32
    tooltip: Drag the backpack that stores the ammo here

  Label
    id: minLabel
    anchors.top: ammoContainerItem.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 6
    height: 18
    text-align: center
    text: Min: 50

  HorizontalScrollBar
    id: minSlider
    anchors.top: minLabel.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 10
    margin-right: 10
    margin-top: 2
    height: 16

  Label
    id: maxLabel
    anchors.top: minSlider.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 4
    height: 18
    text-align: center
    text: Max: 200

  HorizontalScrollBar
    id: maxSlider
    anchors.top: maxLabel.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-left: 10
    margin-right: 10
    margin-top: 2
    height: 16

  Label
    id: status
    anchors.top: maxSlider.bottom
    anchors.bottom: closeButton.top
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 8
    margin-bottom: 8
    text-align: center
    text-vertical-auto-resize: true
    text-wrap: true
    text: Status: waiting
    color: #aaaaaa

  Button
    id: closeButton
    anchors.bottom: parent.bottom
    anchors.horizontalCenter: parent.horizontalCenter
    margin-bottom: 10
    width: 70
    height: 22
    !text: tr('Close')
]], g_ui.getRootWidget())

local setupWindow = nil
local rootWidget = g_ui.getRootWidget()
if rootWidget then
  setupWindow = UI.createWindow("QuiverManagerWindow", rootWidget)
  setupWindow:hide()
end

local function setStatus(text)
  if not setupWindow then return end
  local statusLabel = setupWindow.recursiveGetChildById and setupWindow:recursiveGetChildById("status") or nil
  if statusLabel then
    statusLabel:setText("Status: " .. text)
  end
end

local function syncIdWidgets(prefix, list)
  if not setupWindow then return end
  for i = 1, idSlots do
    local widget = setupWindow.recursiveGetChildById and setupWindow:recursiveGetChildById(prefix .. i) or nil
    if widget then
      widget:setItemId(tonumber(list[i]) or 0)
      widget.onItemChange = function(widget)
        list[i] = widget:getItemId()
        hold = false
      end
    end
  end
end

local function setSlider(slider, label, key, title)
  local value = clamp(config[key], 0, 1000)
  config[key] = value

  pcall(function()
    slider:setMinimum(0)
    slider:setMaximum(1000)
    slider:setValue(value)
  end)

  label:setText(title .. ": " .. value)

  slider.onValueChange = function(widget, newValue)
    newValue = clamp(newValue, 0, 1000)
    config[key] = newValue
    hold = false

    if key == "min" and config.max < newValue then
      config.max = newValue
      local maxSlider = setupWindow and setupWindow.recursiveGetChildById and setupWindow:recursiveGetChildById("maxSlider") or nil
      local maxLabel = setupWindow and setupWindow.recursiveGetChildById and setupWindow:recursiveGetChildById("maxLabel") or nil
      if maxSlider then maxSlider:setValue(newValue) end
      if maxLabel then maxLabel:setText("Max: " .. newValue) end
    elseif key == "max" and config.min > newValue then
      config.min = newValue
      local minSlider = setupWindow and setupWindow.recursiveGetChildById and setupWindow:recursiveGetChildById("minSlider") or nil
      local minLabel = setupWindow and setupWindow.recursiveGetChildById and setupWindow:recursiveGetChildById("minLabel") or nil
      if minSlider then minSlider:setValue(newValue) end
      if minLabel then minLabel:setText("Min: " .. newValue) end
    end

    label:setText(title .. ": " .. newValue)
  end
end

mainPanel.enabled:setOn(config.enabled)
mainPanel.enabled.onClick = function(widget)
  config.enabled = not config.enabled
  widget:setOn(config.enabled)
  hold = false
end

local function openSetupWindow()
  if not setupWindow then
    return
  end

  setupWindow:show()
  setupWindow:raise()
  setupWindow:focus()
  hold = false
end

mainPanel.setup.onClick = function(widget)
  openSetupWindow()
end

if setupWindow then
  syncIdWidgets("quiver", config.quiverIds)
  syncIdWidgets("ammo", config.ammoIds)

  local ammoContainerItem = setupWindow.recursiveGetChildById and setupWindow:recursiveGetChildById("ammoContainerItem") or nil
  local minSlider = setupWindow.recursiveGetChildById and setupWindow:recursiveGetChildById("minSlider") or nil
  local minLabel = setupWindow.recursiveGetChildById and setupWindow:recursiveGetChildById("minLabel") or nil
  local maxSlider = setupWindow.recursiveGetChildById and setupWindow:recursiveGetChildById("maxSlider") or nil
  local maxLabel = setupWindow.recursiveGetChildById and setupWindow:recursiveGetChildById("maxLabel") or nil

  if ammoContainerItem then
    ammoContainerItem:setItemId(config.ammoContainerId)
    ammoContainerItem.onItemChange = function(widget)
      config.ammoContainerId = widget:getItemId()
      hold = false
    end
  end

  if minSlider and minLabel then
    setSlider(minSlider, minLabel, "min", "Min")
  end
  if maxSlider and maxLabel then
    setSlider(maxSlider, maxLabel, "max", "Max")
  end

  local closeButton = setupWindow.recursiveGetChildById and setupWindow:recursiveGetChildById("closeButton") or nil
  if closeButton then
    closeButton.onClick = function()
      setupWindow:hide()
    end
  end
end

local function hasConfiguredIds(list)
  for _, id in ipairs(list) do
    if tonumber(id) and tonumber(id) > 0 then
      return true
    end
  end
  return false
end

local function containsConfiguredId(list, value)
  value = tonumber(value) or 0
  if value <= 0 then return false end
  for _, id in ipairs(list) do
    if tonumber(id) == value then
      return true
    end
  end
  return false
end

local function getEquippedQuiverSlot()
  if not hasConfiguredIds(config.quiverIds) then
    return nil
  end

  local slots = {getAmmo(), getRight(), getLeft()}
  for _, slot in ipairs(slots) do
    if slot and slot.getId and slot.isContainer and slot:isContainer() and containsConfiguredId(config.quiverIds, slot:getId()) then
      return slot
    end
  end

  return nil
end

local function getQuiverContainer()
  local slot = getEquippedQuiverSlot()
  if slot then
    local container = getContainerByItem(slot:getId())
    if container then
      return container
    end
  end

  for _, container in pairs(getContainers()) do
    local name = container:getName() and container:getName():lower() or ""
    local containerItem = container:getContainerItem()
    local containerId = containerItem and containerItem:getId() or 0
    if name:find("quiver") or containsConfiguredId(config.quiverIds, containerId) then
      return container
    end
  end

  return nil
end

local function isAllowedAmmo(itemId)
  return containsConfiguredId(config.ammoIds, itemId)
end

local function getAmmoCount(container)
  local count = 0
  for _, item in pairs(container:getItems()) do
    if isAllowedAmmo(item:getId()) then
      count = count + item:getCount()
    end
  end
  return count
end

local function getConfiguredAmmoContainers(quiverContainer)
  local expectedId = tonumber(config.ammoContainerId) or 0
  local result = {}

  for _, container in pairs(getContainers()) do
    if container ~= quiverContainer then
      local containerItem = container:getContainerItem()
      local containerId = containerItem and containerItem:getId() or 0
      if expectedId <= 0 or containerId == expectedId then
        table.insert(result, container)
      end
    end
  end

  return result
end

local function getAllSourceContainers(quiverContainer)
  local result = {}
  for _, container in pairs(getContainers()) do
    if container ~= quiverContainer then
      table.insert(result, container)
    end
  end
  return result
end

local function getDepositContainer(quiverContainer)
  local preferredId = tonumber(config.ammoContainerId) or 0
  if preferredId > 0 then
    for _, container in ipairs(getConfiguredAmmoContainers(quiverContainer)) do
      if not containerIsFull(container) then
        return container
      end
    end
  end

  for _, container in pairs(getContainers()) do
    if container ~= quiverContainer and not containerIsFull(container) then
      local name = container:getName():lower()
      if not name:find("quiver") and not name:find("loot") and not name:find("depot") then
        return container
      end
    end
  end

  return nil
end

local function getContainerInsertPosition(container)
  if not container or not container.getSlotPosition or not container.getItemsCount then
    return nil
  end

  local count = container:getItemsCount() or 0
  local ok, pos = pcall(function()
    return container:getSlotPosition(count + 1)
  end)
  if ok and pos then
    return pos
  end

  ok, pos = pcall(function()
    return container:getSlotPosition(count)
  end)
  if ok and pos then
    return pos
  end

  return nil
end

local function getQuiverMovePosition(container)
  if not container or not container.getSlotPosition then
    return nil
  end

  local ok, pos = pcall(function()
    return container:getSlotPosition(1)
  end)
  if ok and pos then
    return pos
  end

  return getContainerInsertPosition(container)
end

local function moveWrongItemOut(quiverContainer)
  local dest = getDepositContainer(quiverContainer)
  if not dest then
    return false
  end

  for _, item in pairs(quiverContainer:getItems()) do
    if not isAllowedAmmo(item:getId()) then
      local insertPos = getContainerInsertPosition(dest)
      if insertPos then
        g_game.move(item, insertPos, item:getCount())
        return true
      end
      return false
    end
  end

  return false
end

local function moveAmmoToQuiver(quiverContainer)
  if quiverContainer and quiverContainer.hasPages and quiverContainer.getId and quiverContainer.getFirstIndex and quiverContainer.getCapacity then
    local hasPages = false
    pcall(function()
      hasPages = quiverContainer:hasPages()
    end)

    if hasPages then
      pcall(function()
        g_game.seekInContainer(quiverContainer:getId(), quiverContainer:getFirstIndex() + quiverContainer:getCapacity())
      end)
    end
  end

  local quiverPos = getQuiverMovePosition(quiverContainer)

  if not quiverPos then
    return false, false
  end

  local usedFallback = false
  local sourceContainers = getConfiguredAmmoContainers(quiverContainer)

  if #sourceContainers == 0 then
    sourceContainers = getAllSourceContainers(quiverContainer)
    usedFallback = true
  end

  for _, container in ipairs(sourceContainers) do
    for _, item in pairs(container:getItems()) do
      if isAllowedAmmo(item:getId()) then
        g_game.move(item, quiverPos, item:getCount())
        return true, usedFallback
      end
    end
  end

  if not usedFallback then
    for _, container in ipairs(getAllSourceContainers(quiverContainer)) do
      for _, item in pairs(container:getItems()) do
        if isAllowedAmmo(item:getId()) then
          g_game.move(item, quiverPos, item:getCount())
          return true, true
        end
      end
    end
  end

  return false, usedFallback
end

local function pauseCheck(ms)
  hold = true
  schedule(ms or 250, function()
    hold = false
  end)
end

onContainerOpen(function(container, previousContainer)
  hold = false
end)

onContainerClose(function(container)
  hold = false
end)

onAddItem(function(container, slot, item, oldItem)
  hold = false
end)

onRemoveItem(function(container, slot, item)
  hold = false
end)

onContainerUpdateItem(function(container, slot, item, oldItem)
  hold = false
end)

macro(150, function()
  if not config.enabled or hold then
    return
  end

  local minAmmo = clamp(config.min, 0, 1000)
  local maxAmmo = clamp(config.max, 0, 1000)

  if not hasConfiguredIds(config.quiverIds) then
    setStatus("configure quivers")
    return
  end

  if not hasConfiguredIds(config.ammoIds) then
    setStatus("configure ammo")
    return
  end

  if (tonumber(config.ammoContainerId) or 0) <= 0 then
    setStatus("configure ammo backpack")
    return
  end

  if maxAmmo < minAmmo then
    maxAmmo = minAmmo
    config.max = maxAmmo
    if setupWindow then
      local maxSlider = setupWindow.recursiveGetChildById and setupWindow:recursiveGetChildById("maxSlider") or nil
      local maxLabel = setupWindow.recursiveGetChildById and setupWindow:recursiveGetChildById("maxLabel") or nil
      if maxSlider then maxSlider:setValue(maxAmmo) end
      if maxLabel then maxLabel:setText("Max: " .. maxAmmo) end
    end
  end

  local quiverContainer = getQuiverContainer()
  if not quiverContainer then
    setStatus("equipped quiver not open")
    return
  end

  if not getQuiverMovePosition(quiverContainer) then
    setStatus("quiver slot invalid")
    return
  end

  local configuredAmmoContainers = getConfiguredAmmoContainers(quiverContainer)
  if #configuredAmmoContainers == 0 then
    setStatus("ammo bp id mismatch, using open containers")
  end

  if moveWrongItemOut(quiverContainer) then
    setStatus("cleaning quiver")
    return
  end

  local currentAmmo = getAmmoCount(quiverContainer)
  if currentAmmo >= maxAmmo then
    setStatus("ready: " .. currentAmmo)
    return
  end

  if currentAmmo <= minAmmo or currentAmmo < maxAmmo then
    local moved, usedFallback = moveAmmoToQuiver(quiverContainer)
    if moved then
      pauseCheck(300)
      if usedFallback then
        setStatus("refilling from open containers")
      else
        setStatus("refilling: " .. currentAmmo .. "/" .. maxAmmo)
      end
      return
    end

    if currentAmmo <= minAmmo then
      if usedFallback then
        setStatus("low ammo, not found in open containers")
      else
        setStatus("low ammo: " .. currentAmmo)
      end
    else
      setStatus("no ammo found")
    end
    return
  end

  setStatus("ready: " .. currentAmmo)
end)
