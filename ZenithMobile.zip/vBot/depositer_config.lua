setDefaultTab("Cave")

local panelName = "specialDeposit"
local depositerPanel

UI.Button("Stashing Settings", function()
  depositerPanel:show()
  depositerPanel:raise()
  depositerPanel:focus()
end)

if not storage[panelName] then
  storage[panelName] = {
    items = {},
    storeItems = {},
    removeItems = {},
    lootContainers = {},
    delay = 300,
    height = 310
  }
end

local config = storage[panelName]
config.items = config.items or {}
config.storeItems = config.storeItems or {}
config.removeItems = config.removeItems or {}
config.lootContainers = config.lootContainers or {}
config.delay = tonumber(config.delay) or 300
if not config.height or config.height < 240 or config.height > 380 then
  config.height = 310
end

local function normalizeContainerItems(list)
  for index, entry in ipairs(list) do
    if type(entry) == "number" then
      list[index] = {id=entry, count=0}
    elseif type(entry) == "table" then
      entry.id = tonumber(entry.id) or 0
      entry.count = tonumber(entry.count) or 0
    end
  end
end

normalizeContainerItems(config.storeItems)
normalizeContainerItems(config.removeItems)
normalizeContainerItems(config.lootContainers)

depositerPanel = UI.createWindow("DepositerPanel", rootWidget)
depositerPanel:hide()
depositerPanel:setHeight(config.height or 310)

depositerPanel.CloseButton.onClick = function()
  depositerPanel:hide()
end

depositerPanel.onGeometryChange = function(widget, old, new)
  if old.height == 0 then return end
  config.height = new.height
end

local function attachContainer(target, items, onChange)
  local container = UI.Container(function(widget, newItems)
    normalizeContainerItems(newItems)
    onChange(newItems)
  end, true)

  container:setHeight(35)
  container:setWidth(230)
  container:setItems(items)
  container:setParent(target)
  container:setMarginTop(3)
  container:setMarginLeft(3)
  return container
end

attachContainer(depositerPanel.addContainer, config.storeItems, function(items)
  config.storeItems = items
end)

attachContainer(depositerPanel.removeContainer, config.removeItems, function(items)
  config.removeItems = items
end)

attachContainer(depositerPanel.lootContainer, config.lootContainers, function(items)
  config.lootContainers = items
end)

depositerPanel.delayValue:setText(tostring(config.delay))
depositerPanel.delayValue.onTextChange = function(widget, text)
  local value = tonumber(text)
  if value then
    config.delay = math.max(0, value)
  end
end

function getStashingIndex(id)
  for _, v in pairs(config.items) do
    if v.id == id then
      return v.index - 1
    end
  end
end

function getStowAllSettings()
  return config
end

UI.Separator()
UI.Label("Sell Exeptions")

if type(storage.cavebotSell) ~= "table" then
  storage.cavebotSell = {23544, 3081}
end

local sellContainer = UI.Container(function(widget, items)
  storage.cavebotSell = items
end, true)
sellContainer:setHeight(35)
sellContainer:setItems(storage.cavebotSell)
