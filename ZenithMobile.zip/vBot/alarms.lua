setDefaultTab("Tools")
local panelName = "alarms"

local soundFiles = {
  lowSupplies = "/sounds/Low Supplies.ogg",
  lowHealth = "/sounds/Low Health.ogg",
  lowMana = "/sounds/Low Mana.ogg",
  damageTaken = "/sounds/Damage Taken.ogg",
  playerAttack = "/sounds/Player Attack.ogg",
  privateMsg = "/sounds/Private Message.ogg",
  defaultMsg = "/sounds/Default Message.ogg",
  customMessage = "/sounds/Custom Message.ogg",
  creatureDetected = "/sounds/Creature Detected.ogg",
  playerDetected = "/sounds/Player Detected.ogg",
  gmDetected = "/sounds/GM Detected.ogg",
  creatureName = "/sounds/Creature Name.ogg",
}

local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    text-align: center
    width: 130
    !text: tr('Alarms')

  Button
    id: alerts
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 3
    height: 17
    text: Edit

]])
ui:setId(panelName)

if not storage[panelName] then
  storage[panelName] = {}
end

local config = storage[panelName]

ui.title:setOn(config.enabled)
ui.title.onClick = function(widget)
  config.enabled = not config.enabled
  widget:setOn(config.enabled)
end

local window = UI.createWindow("AlarmsWindow")
window:hide()

ui.alerts.onClick = function()
  window:show()
  window:raise()
  window:focus()
end

local widgets = 
{
  "AlarmCheckBox", 
  "AlarmCheckBoxAndSpinBox", 
  "AlarmCheckBoxAndTextEdit"
}

local parents = 
{
  window.list, 
  window.settingsList
}


-- type
addAlarm = function(id, title, defaultValue, alarmType, parent, tooltip)
  local widget = UI.createWidget(widgets[alarmType], parents[parent])
  widget:setId(id)

  if type(config[id]) ~= 'table' then
    config[id] = {
      enabled = alarmType == 1 and defaultValue or false,
      value = (alarmType == 2 or alarmType == 3) and defaultValue or nil,
    }
  elseif alarmType == 3 and config[id].value == nil then
    -- Migração das versões antigas, que salvavam o texto em config[id].text.
    config[id].value = config[id].text or defaultValue or ""
    config[id].text = nil
  end

  widget.tick:setText(title)
  widget.tick:setChecked(config[id].enabled)
  widget.tick:setTooltip(tooltip)
  
  widget.tick.onClick = function()
    config[id].enabled = not config[id].enabled
    widget.tick:setChecked(config[id].enabled)
  end

  if alarmType == 2 then
    widget.value:setValue(config[id].value)
    widget.value.onValueChange = function(widget, value)
      config[id].value = value
    end
  elseif alarmType == 3 then
    widget.text:setText(config[id].value)
    widget.text.onTextChange = function(widget, newText)
      config[id].value = newText
    end
  end

end

-- settings
addAlarm("ignoreFriends", "Ignore Friends", true, 1, 2)
addAlarm("flashClient", "Flash Client", true, 1, 2)
addAlarm("alarmIcon", "Create Icon", true, 1, 2)

-- alarm list
addAlarm("lowSupplies", "Low Supplies", false, 1, 1, "You have to configure 'Supply Settings' in CaveBot.")
addAlarm("lowHealth", "Low Health", 20, 2, 1)
addAlarm("lowMana", "Low Mana", 20, 2, 1)
addAlarm("damageTaken", "Damage Taken", false, 1, 1)
addAlarm("playerAttack", "Player Attack", false, 1, 1)

UI.Separator(window.list)

addAlarm("privateMsg", "Private Message", false, 1, 1)
addAlarm("defaultMsg", "Default Message", false, 1, 1)
addAlarm("customMessage", "Custom Message:", "", 3, 1, "You can add text, that if found in any incoming message will trigger alert.\n You can add many, just separate them by comma.")

UI.Separator(window.list)

addAlarm("creatureDetected", "Creature Detected", false, 1, 1)
addAlarm("playerDetected", "Player Detected", false, 1, 1)
addAlarm("gmDetected", "GM Detected", false, 1, 1, "Detects visible or talking staff names using common prefixes: GM, [GM], CM, [CM], GOD and [GOD].")
addAlarm("creatureName", "Creature Name:", "", 3, 1, "You can add a name or part of it, that if found in any visible creature name will trigger alert.\nYou can add many, just separate them by comma.")


local function isGmName(name)
  name = tostring(name or ""):trim():lower()
  if name:len() == 0 then return false end

  -- Detecta cargos comuns com ou sem colchetes.
  -- Ex.: GM Thiago, [GM] Thiago, ADM Thiago, [ADM] Thiago.
  local roles = {
    "gm",
    "cm",
    "god",
    "adm",
    "admin",
    "dono",
    "owner",
    "tutor",
    "gamemaster",
  }

  for _, role in ipairs(roles) do
    if name == role then
      return true
    end

    if name:match("^%[" .. role .. "%]%s*") then
      return true
    end

    if name:match("^" .. role .. "[%s%-%_]") then
      return true
    end
  end

  return false
end

-- Permite que um alarme dispare imediatamente após carregar o script.
local lastCall = now - 2000
local function alarm(file, windowText)
  if now - lastCall < 2000 then return end -- 2s delay
  lastCall = now

  if not g_resources.fileExists(file) then
    file = "/sounds/alarm.ogg"
  end
  
  if file == "/sounds/alarm.ogg" then
    lastCall = now + 4000 -- alarm.ogg length is 6s
  end
  
  if modules.game_bot.g_app.getOs() == "windows" and config.flashClient.enabled then
    g_window.flash()
  end
  g_window.setTitle(player:getName() .. " - " .. windowText)
  playSound(file)
end

-- damage taken & custom message
onTextMessage(function(mode, text)
  if not config.enabled then return end
  if mode == 22 and config.damageTaken.enabled then
    return alarm(soundFiles.damageTaken, "Damage Received!")
  end

  if config.customMessage.enabled then
    local alertText = config.customMessage.value
    if alertText:len() > 0 then
      text = text:lower()
      local parts = string.split(alertText, ",")

      for i=1,#parts do
        local part = parts[i]
        part = part:trim()
        part = part:lower()

        if part:len() > 0 and text:find(part, 1, true) then
          return alarm(soundFiles.customMessage, "Special Message!")
        end
      end
    end
  end
end)

-- default, private message & custom message
onTalk(function(name, level, mode, text, channelId, pos)
  if not config.enabled then return end
  if name == player:getName() then return end -- ignore self messages

  if config.gmDetected.enabled and isGmName(name) then
    return alarm(soundFiles.gmDetected, "GM Detected!")
  end

  if config.ignoreFriends.enabled and isFriend(name) then return end -- ignore friends if enabled

  if mode == 1 and config.defaultMsg.enabled then
    return alarm(soundFiles.defaultMsg, "Default Message!")
  end

  if mode == 4 and config.privateMsg.enabled then
    return alarm(soundFiles.privateMsg, "Private Message!")
  end

  if config.customMessage.enabled then
    local alertText = config.customMessage.value
    if alertText:len() > 0 then
      text = text:lower()
      local parts = string.split(alertText, ",")

      for i=1,#parts do
        local part = parts[i]
        part = part:trim()
        part = part:lower()

        if part:len() > 0 and text:find(part, 1, true) then
          return alarm(soundFiles.customMessage, "Special Message!")
        end
      end
    end
  end
end)

-- health, mana, specs & supplies
macro(500, function() 
  if not config.enabled then return end
  if config.lowHealth.enabled then
    if hppercent() < config.lowHealth.value then
      return alarm(soundFiles.lowHealth, "Low Health!")
    end
  end

  if config.lowMana.enabled then
    if manapercent() < config.lowMana.value then
      return alarm(soundFiles.lowMana, "Low Mana!")
    end
  end

  if config.lowSupplies.enabled then
    if hasSupplies() ~= true then
      return alarm(soundFiles.lowSupplies, "Low Supplies!")
    end
  end

  for _, spec in ipairs(getSpectators()) do
    if not spec:isLocalPlayer() then
      local specName = spec:getName() or ""

      -- GM sempre é verificado antes do filtro de amigos.
      if spec:isPlayer() and config.gmDetected.enabled and isGmName(specName) then
        return alarm(soundFiles.gmDetected, "GM Detected!")
      end

      local ignoredFriend = config.ignoreFriends.enabled and isFriend(spec)
      if not ignoredFriend then
        if config.creatureDetected.enabled then
          return alarm(soundFiles.creatureDetected, "Creature Detected!")
        end

        if spec:isPlayer() then
          if spec:isTimedSquareVisible() and config.playerAttack.enabled then
            return alarm(soundFiles.playerAttack, "Player Attack!")
          end
          if config.playerDetected.enabled then
            return alarm(soundFiles.playerDetected, "Player Detected!")
          end
        end

        if config.creatureName.enabled and config.creatureName.value:len() > 0 then
          local name = specName:lower()
          local fragments = string.split(config.creatureName.value, ",")

          for _, fragment in ipairs(fragments) do
            local frag = fragment:trim():lower()
            if frag:len() > 0 and name:find(frag, 1, true) then
              return alarm(soundFiles.creatureName, "Special Creature Detected!")
            end
          end
        end
      end
    end
  end
end)

Alarms = {} -- global table

Alarms.isOff = function()
  return not config.enabled
end

Alarms.isOn = function()
  return config.enabled
end

Alarms.setOff = function()
  config.enabled = false
  ui.title:setOn(config.enabled)
end

Alarms.setOn = function()
  config.enabled = true
  ui.title:setOn(config.enabled)
end

-- icon
if true then
  aIcon = addIcon("aI",{text="Alarms",switchable=false,moveable=true}, function()
    if Alarms.isOff() then 
      Alarms.setOn()
    else 
      Alarms.setOff()
    end
  end)
  aIcon:setSize({height=30,width=50})
  aIcon.text:setFont('verdana-11px-rounded')
  aIcon:breakAnchors()
  aIcon:move(200,135)
  aIcon:hide()

  macro(50,function()
    local a = config.alarmIcon.enabled
    if a then
      aIcon:show()
      if Alarms.isOn() then
        aIcon.text:setColoredText({"Alarms\n","white","ON","green"})
      else
        aIcon.text:setColoredText({"Alarms\n","white","OFF","red"})
      end
    else
      aIcon:hide()
    end
  end)
end

UI.Separator()