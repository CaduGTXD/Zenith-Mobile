setDefaultTab("Hp")
local panelName = "newHealer"
local ui = setupUI([[
Panel
  height: 19

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    text-align: center
    width: 130
    !text: tr('Friend Healer')

  Button
    id: edit
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 3
    height: 17
    text: Setup
      
]])
ui:setId(panelName)

-- validate current settings
if not storage[panelName] or not storage[panelName].priorities then
    storage[panelName] = nil
end

if not storage[panelName] then
    storage[panelName] = {
        enabled = false,
        customPlayers = {},
        vocations = {},
        groups = {},
        sCheckRL = false,
        priorities = {

            {name="Custom Spell",           enabled=false, custom=true},
            {name="Exura Gran Sio",         enabled=true,              strong = true},
            {name="Exura Sio",              enabled=true,                            normal = true},
            {name="Exura Gran Mas Res",     enabled=true,                                          area = true},
            {name="Health Item",            enabled=true,                                                      health=true},
            {name="Mana Item",              enabled=true,                                                                  mana=true}

        },
        settings = {

            {type="HealItem",       text="Mana Item ",                   value=268},
            {type="HealScroll",     text="Item Range: ",                 value=6},
            {type="HealItem",       text="Health Item ",                 value=3160},
            {type="HealScroll",     text="Mas Res Players: ",            value=2},
            {type="HealScroll",     text="Heal Friend at: ",             value=80},
            {type="HealScroll",     text="Use Gran Sio at: ",            value=80},
            {type="HealScroll",     text="Min Player HP%: ",             value=80},
            {type="HealScroll",     text="Min Player MP%: ",             value=50},
            {type="HealScroll",     text="My HP for Mas Res: ",          value=80},

        },
        conditions = {
            knights = true,
            paladins = true,
            druids = false,
            sorcerers = false,
            party = true,
            guild = false,
            botserver = false,
            friends = false
        }
    }
end

local config = storage[panelName]

-- v15: keep old setting indexes stable and append the local-player Mas Res HP.
if not config.settings[9] then
    config.settings[9] = {
        type = "HealScroll",
        text = "My HP for Mas Res: ",
        value = tonumber(config.settings[5] and config.settings[5].value) or 80
    }
else
    config.settings[9].type = "HealScroll"
    config.settings[9].text = "My HP for Mas Res: "
    config.settings[9].value = tonumber(config.settings[9].value) or 80
end

-- The required amount now counts every injured target, including the local player.
if config.settings[4] then config.settings[4].text = "Mas Res targets: " end

local function cleanPlayerName(name)
    local clean = tostring(name or ""):trim()
    clean = clean:gsub("%s+", " ")
    return clean
end

local function normalizePlayerName(name)
    return cleanPlayerName(name):lower()
end

-- Migrate old custom-player entries. Older versions stored HP percentages and
-- could also save a leading space before the character name.
local migratedCustomPlayers = {}
for savedName, savedValue in pairs(config.customPlayers or {}) do
    local sourceName = type(savedValue) == "string" and savedValue or savedName
    local displayName = cleanPlayerName(sourceName)
    if displayName:len() > 0 then
        migratedCustomPlayers[normalizePlayerName(displayName)] = displayName
    end
end
config.customPlayers = migratedCustomPlayers

-- Clarify that these limits protect the local player; they are not target HP.
if config.settings[7] then config.settings[7].text = "Pause if my HP <= " end
if config.settings[8] then config.settings[8].text = "Pause if my MP <= " end

local function isCustomPlayer(name)
    return config.customPlayers[normalizePlayerName(name)] ~= nil
end

local healerWindow = UI.createWindow('FriendHealer')
healerWindow:hide()
healerWindow:setId(panelName)

ui.title:setOn(config.enabled)
ui.title.onClick = function(widget)
    config.enabled = not config.enabled
    widget:setOn(config.enabled)
end

ui.edit.onClick = function()
    healerWindow:show()
    healerWindow:raise()
    healerWindow:focus()
end

-- Modified by F.Almeida
-- Switch, stop in PZ
healerWindow.sCheckRL:setOn(config.sCheckRL)
healerWindow.sCheckRL.onClick = function(widget)
  config.sCheckRL = not config.sCheckRL
  widget:setOn(config.sCheckRL)
end

local conditions = healerWindow.conditions
local targetSettings = healerWindow.targetSettings
local customList = healerWindow.customList
local priority = healerWindow.priority

customList.addPanel.name:setText("friend name")

-- Custom players are an explicit allow-list. They use the same global
-- Heal Friend / Gran Sio percentages as every other eligible player.
local function createCustomPlayerEntry(key, displayName)
    local widget = UI.createWidget("HealerPlayerEntry", customList.playerList.list)
    widget.customPlayerKey = key
    widget:setText(displayName)
    widget.remove.onClick = function()
        config.customPlayers[key] = nil
        widget:destroy()
    end
    return widget
end

local customPlayerKeys = {}
for key in pairs(config.customPlayers) do
    table.insert(customPlayerKeys, key)
end
table.sort(customPlayerKeys, function(a, b)
    return config.customPlayers[a]:lower() < config.customPlayers[b]:lower()
end)

for _, key in ipairs(customPlayerKeys) do
    createCustomPlayerEntry(key, config.customPlayers[key])
end

local function clearFields()
    customList.addPanel.name:setText("friend name")
end

customList.addPanel.add.onClick = function()
    local displayName = cleanPlayerName(customList.addPanel.name:getText())
    local key = normalizePlayerName(displayName)

    if displayName:len() == 0 or key == "friend name" then
        return warn("[Friend Healer] Please enter friend name to be added!")
    end

    local existing = config.customPlayers[key] ~= nil
    config.customPlayers[key] = displayName

    if existing then
        for _, child in ipairs(customList.playerList.list:getChildren()) do
            if child.customPlayerKey == key then
                child:setText(displayName)
                clearFields()
                return
            end
        end
    end

    createCustomPlayerEntry(key, displayName)
    clearFields()
end

local function validate(widget, category)
    local list = widget:getParent()
    local label = list:getParent().title
    -- 1 - priorities | 2 - vocation
    category = category or 0

    label:setColor("#dfdfdf")
    label:setTooltip("")

    local checked = false
    for _, child in ipairs(list:getChildren()) do
        if category == 1 then
            checked = child.enabled and child.enabled:isChecked() or false
        else
            checked = child:isChecked()
        end

        if checked then
            break
        end
    end

    if not checked then
        label:setColor("#d9321f")
        label:setTooltip("! WARNING ! \nNo category selected!")
    else
        label:setColor("#dfdfdf")
        label:setTooltip("")
    end
end
-- targetSettings
targetSettings.vocations.box.knights:setChecked(config.conditions.knights)
targetSettings.vocations.box.knights.onClick = function(widget)
    config.conditions.knights = not config.conditions.knights
    widget:setChecked(config.conditions.knights)
    validate(widget, 2)
end

targetSettings.vocations.box.paladins:setChecked(config.conditions.paladins)
targetSettings.vocations.box.paladins.onClick = function(widget)
    config.conditions.paladins = not config.conditions.paladins
    widget:setChecked(config.conditions.paladins)
    validate(widget, 2)
end

targetSettings.vocations.box.druids:setChecked(config.conditions.druids)
targetSettings.vocations.box.druids.onClick = function(widget)
    config.conditions.druids = not config.conditions.druids
    widget:setChecked(config.conditions.druids)
    validate(widget, 2)
end

targetSettings.vocations.box.sorcerers:setChecked(config.conditions.sorcerers)
targetSettings.vocations.box.sorcerers.onClick = function(widget)
    config.conditions.sorcerers = not config.conditions.sorcerers
    widget:setChecked(config.conditions.sorcerers)
    validate(widget, 2)
end

targetSettings.groups.box.friends:setChecked(config.conditions.friends)
targetSettings.groups.box.friends.onClick = function(widget)
    config.conditions.friends = not config.conditions.friends
    widget:setChecked(config.conditions.friends)
    validate(widget)
end

targetSettings.groups.box.party:setChecked(config.conditions.party)
targetSettings.groups.box.party.onClick = function(widget)
    config.conditions.party = not config.conditions.party
    widget:setChecked(config.conditions.party)
    validate(widget)
end

targetSettings.groups.box.guild:setChecked(config.conditions.guild)
targetSettings.groups.box.guild.onClick = function(widget)
    config.conditions.guild = not config.conditions.guild
    widget:setChecked(config.conditions.guild)
    validate(widget)
end

targetSettings.groups.box.botserver:setChecked(config.conditions.botserver)
targetSettings.groups.box.botserver.onClick = function(widget)
    config.conditions.botserver = not config.conditions.botserver
    widget:setChecked(config.conditions.botserver)
    validate(widget)
end

validate(targetSettings.vocations.box.knights)
validate(targetSettings.groups.box.friends)
validate(targetSettings.vocations.box.sorcerers, 2)

-- conditions
-- Keep the stored indexes stable while displaying related Mas Res settings together.
local settingDisplayOrder = {1, 2, 3, 4, 5, 9, 6, 7, 8}

for _, settingIndex in ipairs(settingDisplayOrder) do
    local setting = config.settings[settingIndex]
    local widget = UI.createWidget(setting.type, conditions.box)
    local text = setting.text
    local val = tonumber(setting.value) or 0
    local compactSlider = settingIndex == 2 or settingIndex == 4 -- range/count, not percentages

    widget.text:setText(text)

    if setting.type == "HealScroll" then
        widget.text:setText(text .. val .. (compactSlider and "" or "%"))
        widget.scroll:setValue(val)
        widget.scroll.onValueChange = function(scroll, value)
            setting.value = value
            widget.text:setText(text .. value .. (compactSlider and "" or "%"))
        end

        if compactSlider then
            widget.scroll:setMaximum(10)
        else
            widget.scroll:setMaximum(100)
        end
    else
        widget.item:setItemId(val)
        widget.item:setShowCount(false)
        widget.item.onItemChange = function(itemWidget)
            setting.value = itemWidget:getItemId()
        end
    end
end



-- priority and toggles
local function setCrementalButtons()
    local children = priority.list:getChildren()
    for i, child in ipairs(children) do
        if i > 1 then child.increment:enable() else child.increment:disable() end
        if i < #children then child.decrement:enable() else child.decrement:disable() end
    end
end

for i, action in ipairs(config.priorities) do
    local widget = UI.createWidget("PriorityEntry", priority.list)

    widget:setText(action.name)
    widget.increment.onClick = function()
        local index = priority.list:getChildIndex(widget)
        local table = config.priorities

        priority.list:moveChildToIndex(widget, index-1)
        table[index], table[index-1] = table[index-1], table[index]
        setCrementalButtons()
    end
    widget.decrement.onClick = function()
        local index = priority.list:getChildIndex(widget)
        local table = config.priorities

        priority.list:moveChildToIndex(widget, index+1)
        table[index], table[index+1] = table[index+1], table[index]
        setCrementalButtons()
    end
    widget.enabled:setChecked(action.enabled)
    widget:setColor(action.enabled and "#98BF64" or "#dfdfdf")
    widget.enabled.onClick = function()
        action.enabled = not action.enabled
        widget:setColor(action.enabled and "#98BF64" or "#dfdfdf")
        widget.enabled:setChecked(action.enabled)
        validate(widget, 1)  
    end
    if action.custom then
        widget.onDoubleClick = function()
            local window = modules.client_textedit.show(widget, {title = "Custom Spell", description = "Enter below formula for a custom healing spell"})
            schedule(50, function() 
              window:raise()
              window:focus() 
            end)
        end
        widget.onTextChange = function(widget,text)
            action.name = text
        end
        widget:setTooltip("Double click to set spell formula.")
    end

    if i == #config.priorities then
        validate(widget, 1)
        setCrementalButtons()
    end
end

local lastItemUse = now

local function isPriorityEnabled(flag)
    for _, action in ipairs(config.priorities) do
        if action.enabled and action[flag] then
            return true
        end
    end
    return false
end

local function friendHealerAction(spec, targetsInRange, onlyArea)
    local hasTarget = spec ~= nil
    local name = hasTarget and spec:getName() or ""
    local health = hasTarget and (tonumber(spec:getHealthPercent()) or 100) or 100
    local mana = hasTarget and (tonumber(spec:getManaPercent()) or 100) or 100
    local dist = hasTarget and distanceFromPlayer(spec:getPosition()) or 99
    targetsInRange = targetsInRange or 0

    local masResAmount = tonumber(config.settings[4].value) or 2
    local itemRange = tonumber(config.settings[2].value) or 6
    local healItem = config.settings[3].value
    local manaItem = config.settings[1].value
    local normalHeal = tonumber(config.settings[5].value) or 80
    local strongHeal = tonumber(config.settings[6].value) or normalHeal
    strongHeal = math.min(strongHeal, normalHeal)
    local ignoreRL = not config.sCheckRL

    for _, action in ipairs(config.priorities) do
        if action.enabled then
            -- Mas Res does not require a selected friend; this lets the local
            -- player trigger it when counted by My HP for Mas Res.
            if action.area and targetsInRange >= masResAmount and canCast("exura gran mas res", ignoreRL) then
                return say("exura gran mas res")
            end

            if hasTarget and not onlyArea then
                -- Mana Item intentionally shares the global Friend percentage.
                if action.mana and findItem(manaItem) and mana <= normalHeal and dist <= itemRange and now - lastItemUse > 1000 then
                    lastItemUse = now
                    return useWith(manaItem, spec)
                end

                if action.health and findItem(healItem) and health <= normalHeal and dist <= itemRange and now - lastItemUse > 1000 then
                    lastItemUse = now
                    return useWith(healItem, spec)
                end

                if action.strong and health <= strongHeal and canCast("exura gran sio", ignoreRL) then
                    return say('exura gran sio "' .. name)
                end

                if (action.normal or action.custom) and health <= normalHeal then
                    local spell = tostring(action.name or ""):trim()
                    if spell:len() > 0 and canCast(spell, ignoreRL) then
                        return say(spell .. ' "' .. name)
                    end
                end
            end
        end
    end
end

local function passesVocationFilter(spec, customPlayer)
    if customPlayer then
        return true
    end

    -- Vocation filtering remains compatible with any text overlay supplied by the client
    -- or another module, but no longer depends on the removed Extras player scanner.
    local specText = tostring(spec:getText() or "")
    if specText:len() == 0 then
        return true
    end

    if specText:find("EK", 1, true) then return config.conditions.knights end
    if specText:find("RP", 1, true) then return config.conditions.paladins end
    if specText:find("ED", 1, true) then return config.conditions.druids end
    if specText:find("MS", 1, true) then return config.conditions.sorcerers end
    return true
end

local function matchesSelectedGroup(spec)
    local name = spec:getName()
    local okParty = config.conditions.party and spec:isPartyMember()
    local okFriend = config.conditions.friends and isFriend(spec)
    local okGuild = config.conditions.guild and spec:getEmblem() == 1
    local okBotServer = config.conditions.botserver
        and vBot
        and vBot.BotServerMembers
        and vBot.BotServerMembers[name] ~= nil

    return okParty or okFriend or okGuild or okBotServer
end

local function getCandidateInfo(spec, manaActionEnabled)
    if spec:isLocalPlayer() or not spec:isPlayer() then
        return nil
    end

    local name = spec:getName()
    local customPlayer = isCustomPlayer(name)

    -- A custom player is an explicit allow-list entry and therefore bypasses
    -- group and vocation filters. Everyone still needs line of sight.
    if not customPlayer and not matchesSelectedGroup(spec) then
        return nil
    end
    if not passesVocationFilter(spec, customPlayer) then
        return nil
    end
    if not spec:canShoot() then
        return nil
    end

    local health = tonumber(spec:getHealthPercent()) or 100
    local mana = tonumber(spec:getManaPercent()) or 100
    local normalHeal = tonumber(config.settings[5].value) or 80
    local needsHealth = health <= normalHeal
    local needsMana = manaActionEnabled and mana <= normalHeal

    if not needsHealth and not needsMana then
        return nil
    end

    local dist = distanceFromPlayer(spec:getPosition())
    local score = needsHealth and health or (1000 + mana)

    return {
        creature = spec,
        health = health,
        mana = mana,
        dist = dist,
        needsHealth = needsHealth,
        needsMana = needsMana,
        score = score
    }
end

macro(100, function()
    if not config.enabled then return end
    if modules.game_cooldown.isGroupCooldownIconActive(2) then return end

    local minHp = tonumber(config.settings[7].value) or 0
    local minMp = tonumber(config.settings[8].value) or 0
    local myHp = hppercent()
    local myMp = manapercent()
    local myMasResHp = tonumber(config.settings[9].value) or 80
    local selfNeedsMasRes = myHp <= myMasResHp

    -- Low mana still pauses every friend-heal action. Low HP pauses targeted
    -- friend healing, but an eligible Mas Res is allowed because it heals us too.
    if myMp <= minMp then return end
    local onlyArea = myHp <= minHp

    local manaActionEnabled = isPriorityEnabled("mana")
    local healTarget = nil
    local inMasResRange = selfNeedsMasRes and 1 or 0

    for _, spec in ipairs(getSpectators()) do
        local info = getCandidateInfo(spec, manaActionEnabled)
        if info then
            if info.needsHealth and info.dist <= 3 then
                inMasResRange = inMasResRange + 1
            end

            if not healTarget
                or info.score < healTarget.score
                or (info.score == healTarget.score and info.dist < healTarget.dist) then
                healTarget = info
            end
        end
    end

    if onlyArea then
        if selfNeedsMasRes then
            return friendHealerAction(nil, inMasResRange, true)
        end
        return
    end

    if healTarget or selfNeedsMasRes then
        return friendHealerAction(healTarget and healTarget.creature or nil, inMasResRange, false)
    end
end)
