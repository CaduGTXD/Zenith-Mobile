# Zenith Mobile — versão enxuta

Esta versão mantém somente o núcleo e os módulos ainda utilizados.

## Mantido

- CaveBot e TargetBot, sem rotas ou perfis prontos
- AttackBot, sem perfis salvos
- HealBot, Friend Healer e Conditions, sem perfis salvos
- Simple Equipper
- Quiver Manager, Supplies e Dropper, sem perfis de Supplies salvos
- Auto Buff
- Alarmes
- Core Bot Settings

## Core Bot Settings

As configurações compartilhadas pelo CaveBot e TargetBot ficam em `vBot/core_settings.lua`.

Ele mantém somente:

- Pathfinding do CaveBot
- Delay global de NPC
- Distância e delay de loot
- Limite de rounds
- Percentual para finalizar monstros
- Distância máxima de GoTo
- Ordem de loot
- União das abas CaveBot/TargetBot
- Filtro de criaturas alcançáveis
- Lista de criaturas ignoradas
- Exibição da prioridade do target
- Item usado para cortar obstáculos

## Removido nesta etapa

- Exeta automático por HP baixo ou jogador próximo
- Equipment Manager e suas regras avançadas
- Container Manager e automações de abertura/organização
- Depot Withdraw automático e waypoint `dpwithdraw`
- Auto Party, Auto Share e convite por mensagem
- Todas as rotas salvas do CaveBot
- Perfil salvo do TargetBot
- Perfis salvos do AttackBot, HealBot e Supplies
- Referências salvas aos módulos e perfis removidos

## Removido anteriormente

- Extras básicos
- Extras PVP
- Analyzers e ferramentas auxiliares
- Editor e runtime de scripts personalizados
- Scripts da pasta `ingame_scripts`
- Coleções avulsas, exemplos não carregados, backups e snapshots temporários
