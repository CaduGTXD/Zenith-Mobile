-- Smart Mage Run v9.5 - rejected-step watchdog
local dest
local maxDist
local params
local lastMageRunStepAt = 0
local mageRunPausedUntil = 0
local mageRunCommandPos = nil
local mageRunCommandAt = 0

local function copyWalkParams(source)
  local result = {}
  for key, value in pairs(source or {}) do
    result[key] = value
  end
  return result
end

local function sameWalkPosition(first, second)
  return first and second
    and first.x == second.x
    and first.y == second.y
    and first.z == second.z
end

local function copyWalkPosition(position)
  if not position then return nil end
  return {x = position.x, y = position.y, z = position.z}
end

local function getMageRunStepTimeout()
  local timeout = 900

  if player and player.getStepDuration then
    local ok, duration = pcall(function()
      return tonumber(player:getStepDuration())
    end)
    if ok and duration and duration > 0 then
      timeout = math.max(700, math.min(1800, duration + 350))
    end
  end

  return timeout
end

local function clearMageRunStepWatchdog()
  mageRunCommandPos = nil
  mageRunCommandAt = 0
end

local function checkMageRunStepWatchdog(position)
  if not mageRunCommandPos or mageRunCommandAt <= 0 then
    return false
  end

  if not sameWalkPosition(position, mageRunCommandPos) then
    clearMageRunStepWatchdog()
    return false
  end

  if now - mageRunCommandAt < getMageRunStepTimeout() then
    return false
  end

  -- A step was sent but the character never left the original tile. Clear the
  -- client walking state and force an immediate new Mage Run decision.
  pcall(function()
    player:stopAutoWalk()
  end)
  if g_game and g_game.stop then
    pcall(function()
      g_game.stop()
    end)
  end

  if TargetBot.invalidateMageRunDestination then
    TargetBot.invalidateMageRunDestination()
  end

  dest = nil
  maxDist = nil
  params = nil
  lastMageRunStepAt = 0
  clearMageRunStepWatchdog()
  return true
end

TargetBot.walkTo = function(_dest, _maxDist, _params)
  dest = _dest
  maxDist = _maxDist
  params = _params
end

TargetBot.stopWalk = function()
  dest = nil
  maxDist = nil
  params = nil
  clearMageRunStepWatchdog()
end

-- Small movement pause used by directional spells. It only prevents the next
-- step from being issued; it does not cancel the current tile movement.
TargetBot.pauseMageRunMovement = function(milliseconds)
  milliseconds = math.max(0, tonumber(milliseconds) or 0)
  mageRunPausedUntil = math.max(mageRunPausedUntil, now + milliseconds)
end

TargetBot.isMageRunMovementPaused = function()
  return mageRunPausedUntil > now
end

-- Directional waves pause movement only long enough to face the selected side.
-- As soon as the cast packet is sent, clear that pause and immediately reuse the
-- current Mage Run destination. This prevents the character from standing still
-- for the remainder of the old turn timeout after successfully casting a wave.
TargetBot.resumeMageRunMovement = function(forceStep)
  mageRunPausedUntil = 0

  if not forceStep
    or not (TargetBot.isMageRunActive and TargetBot.isMageRunActive())
    or not dest then
    return false
  end

  -- The previous step timestamp may belong to the movement made before turning.
  -- Reset it so a stationary mage can leave on the very next instruction. The
  -- player:isWalking() guard in TargetBot.walk still prevents duplicate steps.
  lastMageRunStepAt = 0
  return TargetBot.walk(true)
end

-- called every 100ms if targeting or looting is active
TargetBot.walk = function(forceFast)
  if not dest then return false end

  local pos = player:getPosition()
  if pos.z ~= dest.z then return false end

  local walkParams = params or {}
  local dist = math.max(math.abs(pos.x - dest.x), math.abs(pos.y - dest.y))

  if walkParams.precision and walkParams.precision >= dist then
    return true
  end

  if walkParams.marginMin and walkParams.marginMax then
    if dist >= walkParams.marginMin and dist <= walkParams.marginMax then
      return true
    end
  end

  if TargetBot.isMageRunActive and TargetBot.isMageRunActive() then
    if mageRunPausedUntil > now then
      local emergencyMovement = TargetBot.isMageRunEmergencyMovement
        and TargetBot.isMageRunEmergencyMovement()
      if not emergencyMovement then
        return true
      end

      -- Safety beats spell alignment. A wave may wait for the next opening,
      -- but the mage must not stand still with monsters already closing in.
      mageRunPausedUntil = 0
    end

    -- Mage Run intentionally uses normal one-tile walking instead of autoWalk.
    -- This makes creature avoidance responsive and prevents map-click-like
    -- routes from continuing toward a tile that has just become unsafe.
    if checkMageRunStepWatchdog(pos) then
      return false
    end

    if player:isWalking() then
      return true
    end

    local minimumStepDelay = forceFast and 20 or 45
    if now - lastMageRunStepAt < minimumStepDelay then
      return true
    end

    local pathParams = copyWalkParams(walkParams)
    -- The real movement path must respect creatures. Candidate evaluation may
    -- look through them, but execution must never try to walk through one.
    pathParams.ignoreCreatures = false

    local path = getPath(pos, dest, maxDist, pathParams)
    if not path or not path[1] then
      -- A monster can occupy the route after the destination was selected.
      -- Drop that decision immediately so the next TargetBot cycle chooses a
      -- different escape tile instead of waiting at the blocked route.
      if TargetBot.invalidateMageRunDestination then
        TargetBot.invalidateMageRunDestination()
      end
      dest = nil
      maxDist = nil
      params = nil
      clearMageRunStepWatchdog()
      return false
    end

    lastMageRunStepAt = now
    mageRunCommandPos = copyWalkPosition(pos)
    mageRunCommandAt = now
    walk(path[1])
    return true
  end

  if player:isWalking() then return true end

  local path = getPath(pos, dest, maxDist, walkParams)
  if path and path[1] then
    walk(path[1])
    return true
  end

  return false
end

macro(20, function()
  if not (TargetBot and TargetBot.isMageRunActive and TargetBot.isMageRunActive()) then
    return
  end
  if not dest then
    return
  end
  TargetBot.walk(true)
end)
