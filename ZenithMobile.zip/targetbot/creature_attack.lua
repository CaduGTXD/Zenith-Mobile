-- Smart Mage Run v15.0 - stricter anti-trap and cardinal-first Mage Run
local anchorPosition = nil
local lastCall = now
local lastMageRunMove = 0
local mageRunLastMoveDiagonal = false
local mageRunDiagonalOpportunity = 0
local mageRunLastDebugAt = 0
local mageRunDebugSignature = nil
local mageRunDirectStepOrigin = nil
local mageRunDirectStepTarget = nil
local mageRunDirectStepAt = 0
local mageRunDirectStepDirection = nil
local mageRunDecision = {
  target = nil,
  origin = nil,
  chosenAt = 0,
  expiresAt = 0,
  lastEvaluationAt = 0,
  arrivedAt = 0,
  lastDx = 0,
  lastDy = 0,
  centerKey = nil,
  escapeMode = false,
  orbitMode = false,
  orbitDirection = 0,
  orbitLockedUntil = 0,
  centerRecovery = false,
  reserveEscape = false,
  escapePhase = "inside",
  escapeStartedAt = 0,
  reentryTarget = nil,
  route = nil,
  routeOrigin = nil
}

-- Runtime safety state shared with the walking layer and AttackBot. Directional
-- spells may briefly pause normal kiting, but that pause must never win over an
-- actual emergency with monsters already closing the character.
local mageRunRuntime = {
  emergency = false,
  pressure = false,
  adjacent = 0,
  nearTwo = 0,
  nearestHazard = 99,
  reason = "idle",
  updatedAt = 0,
  hazards = {}
}

local mageRunDebugTiles = {}

local visibleMonsterCache = {
  key = nil,
  expiresAt = 0,
  hazards = {},
  configured = {}
}

local staticTileSafetyCache = {
  z = nil,
  expiresAt = 0,
  values = {}
}

local magicFieldCache = {
  z = nil,
  expiresAt = 0,
  values = {}
}

-- Creature positions are read dozens of times during one strategic pass. Cache
-- them for the current movement slice so pcall/getPosition is not repeated for
-- every candidate tile.
local mageRunCreaturePositionCache = {
  z = nil,
  expiresAt = 0,
  values = {}
}

-- The fast layer often checks the player, the held target and the next route
-- step in the same tick. Reusing local mobility for a short window removes a
-- large amount of repeated getNearTiles/tile inspection work.
local mageRunFastMobilityCache = {
  z = nil,
  expiresAt = 0,
  values = {}
}

local function safeCreaturePosition(creature, expectedZ)
  if not creature or not creature.getPosition then return nil end

  local cacheKey = nil
  if expectedZ ~= nil then
    if mageRunCreaturePositionCache.z ~= expectedZ
      or mageRunCreaturePositionCache.expiresAt <= now then
      mageRunCreaturePositionCache.z = expectedZ
      mageRunCreaturePositionCache.expiresAt = now + 90
      mageRunCreaturePositionCache.values = {}
    end

    local okId, id = pcall(function()
      return creature.getId and creature:getId() or nil
    end)
    cacheKey = okId and id or tostring(creature)
    local cached = mageRunCreaturePositionCache.values[cacheKey]
    if cached ~= nil then
      return cached or nil
    end
  end

  local ok, creaturePos = pcall(function()
    return creature:getPosition()
  end)
  if not ok or not creaturePos
    or (expectedZ ~= nil and creaturePos.z ~= expectedZ) then
    if cacheKey ~= nil then
      mageRunCreaturePositionCache.values[cacheKey] = false
    end
    return nil
  end

  if cacheKey ~= nil then
    mageRunCreaturePositionCache.values[cacheKey] = creaturePos
  end
  return creaturePos
end

local function filterValidMageRunCreatures(creatures, expectedZ)
  local result = {}
  for _, creature in ipairs(creatures or {}) do
    local creaturePos = safeCreaturePosition(creature, expectedZ)
    local okHp, hp = pcall(function()
      return creature and creature.getHealthPercent and creature:getHealthPercent() or 0
    end)
    hp = okHp and tonumber(hp) or 0
    if creaturePos and hp > 0 then
      result[#result + 1] = creature
    end
  end
  return result
end

local function tileHasCreature(tile)
  if not tile then return false end
  if tile.hasCreature then
    return tile:hasCreature()
  end
  if tile.getCreatures then
    local creatures = tile:getCreatures()
    return creatures and #creatures > 0 or false
  end
  return false
end

local function callBooleanMethod(object, methodName)
  if not object then return false, false end
  local okMethod, method = pcall(function() return object[methodName] end)
  if not okMethod or type(method) ~= "function" then
    return false, false
  end
  local ok, value = pcall(function()
    return method(object)
  end)
  return ok, ok and value == true
end

local function isStaticMageRunTileSafe(position)
  if not position then return false end

  if staticTileSafetyCache.z ~= position.z
    or staticTileSafetyCache.expiresAt <= now then
    staticTileSafetyCache.z = position.z
    staticTileSafetyCache.expiresAt = now + 900
    staticTileSafetyCache.values = {}
  end

  local key = position.x .. ":" .. position.y .. ":" .. position.z
  if staticTileSafetyCache.values[key] ~= nil then
    return staticTileSafetyCache.values[key]
  end

  local tile = g_map.getTile(position)
  if not tile then
    staticTileSafetyCache.values[key] = false
    return false
  end

  local safe = true
  if tile.isPathable then
    local ok, pathable = pcall(function() return tile:isPathable() end)
    if ok and not pathable then safe = false end
  end

  local minimapColor = g_map.getMinimapColor and g_map.getMinimapColor(position) or 0
  if minimapColor >= 210 and minimapColor <= 213 then
    safe = false
  end

  for _, methodName in ipairs({"isProtectionZone", "isPz", "isTeleport", "isFloorChange"}) do
    local ok, value = callBooleanMethod(tile, methodName)
    if ok and value then safe = false break end
  end

  if safe and tile.getItems then
    local ok, items = pcall(function() return tile:getItems() end)
    if ok and items then
      for _, item in ipairs(items) do
        for _, methodName in ipairs({"isTeleport", "isFloorChange"}) do
          local methodOk, value = callBooleanMethod(item, methodName)
          if methodOk and value then
            safe = false
            break
          end
        end
        if not safe then break end
      end
    end
  end

  staticTileSafetyCache.values[key] = safe and true or false
  return staticTileSafetyCache.values[key]
end

local function hasMageRunMagicField(position)
  if not position then return false end

  -- Magic fields are dynamic hazards, not permanent geometry. A short cache
  -- prevents a removed field from remaining risky for almost a full second.
  if magicFieldCache.z ~= position.z
    or magicFieldCache.expiresAt <= now then
    magicFieldCache.z = position.z
    magicFieldCache.expiresAt = now + 120
    magicFieldCache.values = {}
  end

  local key = position.x .. ":" .. position.y .. ":" .. position.z
  if magicFieldCache.values[key] ~= nil then
    return magicFieldCache.values[key]
  end

  local field = false
  local tile = g_map.getTile(position)
  if tile and tile.getItems then
    local ok, items = pcall(function() return tile:getItems() end)
    if ok and items then
      for _, item in ipairs(items) do
        local methodOk, value = callBooleanMethod(item, "isMagicField")
        if methodOk and value then
          field = true
          break
        end
      end
    end
  end

  magicFieldCache.values[key] = field and true or false
  return magicFieldCache.values[key]
end

local function hasLineOfSight(fromPos, toPos, cache)
  if not fromPos or not toPos or fromPos.z ~= toPos.z then return false end
  if fromPos.x == toPos.x and fromPos.y == toPos.y then return true end

  local key = fromPos.x .. ":" .. fromPos.y .. ":" .. fromPos.z
    .. ">" .. toPos.x .. ":" .. toPos.y .. ":" .. toPos.z
  if cache and cache[key] ~= nil then
    return cache[key]
  end

  local result = true
  if g_map and g_map.isSightClear then
    local ok, clear = pcall(function()
      return g_map.isSightClear(fromPos, toPos)
    end)
    if ok then result = clear == true end
  end

  if cache then cache[key] = result end
  return result
end

function getWalkableTilesCount(position)
  local count = 0

  for _, tile in pairs(getNearTiles(position)) do
    if tile:isWalkable() or tileHasCreature(tile) then
      count = count + 1
    end
  end

  return count
end

function rePosition(minTiles)
  minTiles = minTiles or 8
  if now - lastCall < 500 then return end
  local pPos = player:getPosition()
  local tiles = getNearTiles(pPos)
  local playerTilesCount = getWalkableTilesCount(pPos)
  local tilesTable = {}

  if playerTilesCount > minTiles then return end
  for _, tile in ipairs(tiles) do
    tilesTable[tile] = not tileHasCreature(tile) and tile:isWalkable() and getWalkableTilesCount(tile:getPosition()) or nil
  end

  local best = 0
  local target = nil
  for tile, value in pairs(tilesTable) do
    if value > best and value > playerTilesCount then
      best = value
      target = tile:getPosition()
    end
  end

  if target then
    lastCall = now
    return CaveBot.GoTo(target, 0)
  end
end

local function canStepTo(position)
  local tile = g_map.getTile(position)
  return tile and tile:isWalkable() and not tileHasCreature(tile)
    and isStaticMageRunTileSafe(position)
end

local function getTargetDistanceInfo(fromPos, toPos)
  local fallbackDistance = math.max(math.abs(fromPos.x - toPos.x), math.abs(fromPos.y - toPos.y))
  local path = findPath(fromPos, toPos, 10, {ignoreCreatures=true, ignoreNonPathable=true, ignoreCost=true})
  if path then
    return path, #path
  end
  return nil, fallbackDistance
end

local function samePosition(a, b)
  return a and b and a.x == b.x and a.y == b.y and a.z == b.z
end

local function copyPosition(pos)
  if not pos then return nil end
  return {x=pos.x, y=pos.y, z=pos.z}
end

local function tileDistance(a, b)
  if not a or not b or a.z ~= b.z then return 99 end
  return math.max(math.abs(a.x - b.x), math.abs(a.y - b.y))
end

local function getTileMobility(position, cache)
  local key = position.x .. ":" .. position.y .. ":" .. position.z
  if cache and cache[key] then return cache[key] end

  local openTiles = 0
  local orthogonalOpen = 0
  local magicFieldTiles = 0

  for _, tile in pairs(getNearTiles(position)) do
    local tilePos = tile:getPosition()
    if tile:isWalkable()
      and not tileHasCreature(tile)
      and isStaticMageRunTileSafe(tilePos) then
      openTiles = openTiles + 1
      if hasMageRunMagicField(tilePos) then
        magicFieldTiles = magicFieldTiles + 1
      end
      if tilePos.x == position.x or tilePos.y == position.y then
        orthogonalOpen = orthogonalOpen + 1
      end
    end
  end

  local tile = g_map.getTile(position)
  local canShoot = tile and tile.canShoot and tile:canShoot() or false
  local result = {
    openTiles = openTiles,
    orthogonalOpen = orthogonalOpen,
    magicFieldTiles = magicFieldTiles,
    canShoot = canShoot
  }
  if cache then cache[key] = result end
  return result
end

local function getVisibleMonsters(snapshot)
  local playerPos = player:getPosition()
  snapshot = snapshot or (TargetBot.getMageRunSnapshot and TargetBot.getMageRunSnapshot(900))
  if snapshot then
    return filterValidMageRunCreatures(snapshot.hazards, playerPos.z),
      filterValidMageRunCreatures(snapshot.configured, playerPos.z)
  end

  local scanRange = TargetBot.getMageRunScanRange and TargetBot.getMageRunScanRange() or 8
  local cacheKey = table.concat({playerPos.x, playerPos.y, playerPos.z, scanRange}, ":")
  if visibleMonsterCache.key == cacheKey and visibleMonsterCache.expiresAt > now then
    return filterValidMageRunCreatures(visibleMonsterCache.hazards, playerPos.z),
      filterValidMageRunCreatures(visibleMonsterCache.configured, playerPos.z)
  end

  local hazards = {}
  local configured = {}
  local oldTibia = g_game.getClientVersion() < 960
  for _, creature in ipairs(getSpectators(false)) do
    local cpos = safeCreaturePosition(creature, playerPos.z)
    local okHp, hp = pcall(function()
      return creature and creature.getHealthPercent and creature:getHealthPercent() or 0
    end)
    hp = okHp and tonumber(hp) or 0
    if creature and creature.isMonster and creature:isMonster()
      and cpos
      and tileDistance(playerPos, cpos) <= scanRange
      and hp > 0
      and (oldTibia or creature:getType() < 3) then
      hazards[#hazards + 1] = creature
      local configs = TargetBot.Creature.getConfigs and TargetBot.Creature.getConfigs(creature) or nil
      if configs and #configs > 0 then configured[#configured + 1] = creature end
    end
  end

  visibleMonsterCache.key = cacheKey
  visibleMonsterCache.expiresAt = now + 350
  visibleMonsterCache.hazards = hazards
  visibleMonsterCache.configured = configured
  return hazards, configured
end

local function getMageRunConfigNumber(id, defaultValue, minValue, maxValue)
  local value = defaultValue

  if CaveBot and CaveBot.Config and CaveBot.Config.values and CaveBot.Config.values[id] ~= nil then
    value = tonumber(CaveBot.Config.values[id]) or defaultValue
  end

  value = math.floor(value)
  if minValue and value < minValue then value = minValue end
  if maxValue and value > maxValue then value = maxValue end
  return value
end

local function isProjectedOnScreen(position, creaturePos)
  return math.abs(creaturePos.x - position.x) <= 7
    and math.abs(creaturePos.y - position.y) <= 5
    and creaturePos.z == position.z
end

local function countNearbyMonsters(position, monsters, maxDistance)
  local count = 0
  for _, creature in ipairs(monsters or {}) do
    local creaturePos = safeCreaturePosition(creature, position.z)
    if creaturePos and tileDistance(position, creaturePos) <= maxDistance then
      count = count + 1
    end
  end
  return count
end

local function nearestMonsterDistance(position, monsters)
  local best = 99
  for _, creature in ipairs(monsters or {}) do
    local creaturePos = safeCreaturePosition(creature, position.z)
    if creaturePos then
      local dist = tileDistance(position, creaturePos)
      if dist < best then
        best = dist
      end
    end
  end
  return best
end

local directionOffsets = {
  [0] = {0, -1},
  [1] = {1, 0},
  [2] = {0, 1},
  [3] = {-1, 0},
  [4] = {1, -1},
  [5] = {1, 1},
  [6] = {-1, 1},
  [7] = {-1, -1}
}

local function getDirectionFromOffset(dx, dy)
  for direction, offset in pairs(directionOffsets) do
    if offset[1] == dx and offset[2] == dy then
      return direction
    end
  end
  return nil
end

local function copyDirectionPath(path)
  local result = {}
  for index, direction in ipairs(path or {}) do
    result[index] = direction
  end
  return result
end

local function buildMageRunRoutePositions(origin, path)
  local positions = {}
  local current = copyPosition(origin)
  for _, direction in ipairs(path or {}) do
    local offset = directionOffsets[direction]
    if not offset then return nil end
    current = {
      x = current.x + offset[1],
      y = current.y + offset[2],
      z = current.z
    }
    positions[#positions + 1] = copyPosition(current)
  end
  return positions
end

local function setMageRunPlannedRoute(origin, path)
  mageRunDecision.routeOrigin = copyPosition(origin)
  mageRunDecision.route = buildMageRunRoutePositions(origin, path)
end

local function clearMageRunPlannedRoute()
  mageRunDecision.route = nil
  mageRunDecision.routeOrigin = nil
end

local function getMageRunPlannedStep(currentPos)
  local route = mageRunDecision.route
  if not route or #route == 0 then return nil, nil end

  while route[1] and samePosition(route[1], currentPos) do
    table.remove(route, 1)
  end
  if #route == 0 then return nil, nil end

  local nextPos = route[1]
  local dx = nextPos.x - currentPos.x
  local dy = nextPos.y - currentPos.y
  if math.abs(dx) > 1 or math.abs(dy) > 1 or (dx == 0 and dy == 0) then
    clearMageRunPlannedRoute()
    return nil, nil
  end

  return getDirectionFromOffset(dx, dy), copyPosition(nextPos)
end

local function isDiagonalOffset(offset)
  return offset and offset[1] ~= 0 and offset[2] ~= 0
end

local function isDiagonalDirection(direction)
  return isDiagonalOffset(directionOffsets[direction])
end

local function getMageRunDiagonalPenalty(count, length, emergency)
  count = tonumber(count) or 0
  if count <= 0 then return 0 end
  length = math.max(1, tonumber(length) or count)
  -- Pathfinding liked diagonal chains too much. Treat diagonals as a reserve:
  -- one diagonal is acceptable when it really wins an escape, but a path made
  -- mostly of diagonals should lose to any safe cardinal route.
  local ratioPenalty = (count / length) * (emergency and 900 or 2400)
  return count * (emergency and 950 or 3600) + ratioPenalty
end

-- Cardinal moves first. Diagonals stay available, but only as a reserve when
-- straight steps cannot keep the player safe.
local trapOffsets = {
  {0, -1}, {1, 0}, {0, 1}, {-1, 0},
  {1, -1}, {1, 1}, {-1, 1}, {-1, -1}
}

local cardinalOffsets = {
  {0, -1}, {1, 0}, {0, 1}, {-1, 0}
}

local function positionKey(position)
  return position.x .. ":" .. position.y .. ":" .. position.z
end

local function isMageRunDebugPathEnabled()
  return CaveBot
    and CaveBot.Config
    and CaveBot.Config.values
    and CaveBot.Config.values.lureMageRunDebugPath == true
end

local function clearMageRunDebugPath()
  for key, data in pairs(mageRunDebugTiles) do
    local tile = data.pos and g_map.getTile(data.pos) or nil
    local thing = tile and (tile:getTopUseThing() or tile:getTopThing()) or nil
    if thing then
      thing:setMarked("")
    end
    mageRunDebugTiles[key] = nil
  end
end

local function setMageRunDebugTile(position, color, duration)
  local tile = position and g_map.getTile(position) or nil
  if not tile then return end
  local thing = tile:getTopUseThing() or tile:getTopThing()
  if not thing then return end

  local key = positionKey(position)
  local previous = mageRunDebugTiles[key]
  if previous and previous.color == color then
    thing:setMarked(color)
    previous.expiresAt = now + (duration or 850)
  else
    thing:setMarked(color)
    mageRunDebugTiles[key] = {
      pos=copyPosition(position),
      color=color,
      expiresAt=now + (duration or 850)
    }
  end

  schedule(duration or 850, function()
    local current = mageRunDebugTiles[key]
    local currentTile = current and current.pos and g_map.getTile(current.pos) or nil
    local currentThing = currentTile and (currentTile:getTopUseThing() or currentTile:getTopThing()) or nil
    if current and current.expiresAt and current.expiresAt > now then
      return
    end
    if currentThing then
      currentThing:setMarked("")
    end
    if mageRunDebugTiles[key] == current then
      mageRunDebugTiles[key] = nil
    end
  end)
end

local function getMageRunDebugDirectPath(fromPos, toPos)
  local path = {}
  if not fromPos or not toPos or fromPos.z ~= toPos.z then return path end

  local current = copyPosition(fromPos)
  while not samePosition(current, toPos) and #path < 8 do
    local dx = toPos.x > current.x and 1 or (toPos.x < current.x and -1 or 0)
    local dy = toPos.y > current.y and 1 or (toPos.y < current.y and -1 or 0)
    current = {x=current.x + dx, y=current.y + dy, z=current.z}
    path[#path + 1] = copyPosition(current)
  end
  return path
end

local function showMageRunDebugPath(fromPos, toPos, reason, maxDist, params, firstDirection)
  if not isMageRunDebugPathEnabled() then
    clearMageRunDebugPath()
    mageRunDebugSignature = nil
    return
  end
  if not fromPos or not toPos or fromPos.z ~= toPos.z then return end

  local signature = positionKey(fromPos) .. ">" .. positionKey(toPos)
    .. ":" .. tostring(reason or "")
    .. ":" .. tostring(firstDirection or -1)
    .. ":" .. tostring(mageRunDecision.reserveEscape and 1 or 0)
  -- Debug marking is visual only; never rebuild it on every movement step.
  if now - mageRunLastDebugAt < 550 then
    return
  end
  mageRunDebugSignature = signature
  mageRunLastDebugAt = now
  clearMageRunDebugPath()

  if mageRunDecision.route and #mageRunDecision.route > 0 then
    for index, position in ipairs(mageRunDecision.route) do
      if index > 8 then break end
      local color = samePosition(position, toPos) and "#00FF66"
        or (mageRunDecision.reserveEscape and "#FF66FF" or "#00CCFF")
      setMageRunDebugTile(position, color, 900)
    end
    return
  end

  local current = copyPosition(fromPos)
  local shown = 0
  local path = nil

  if firstDirection and directionOffsets[firstDirection] then
    local offset = directionOffsets[firstDirection]
    current = {
      x = current.x + offset[1],
      y = current.y + offset[2],
      z = current.z
    }
    shown = shown + 1
    local color = samePosition(current, toPos) and "#00FF66" or "#00CCFF"
    setMageRunDebugTile(current, color, 900)

    if not samePosition(current, toPos) then
      path = getPath(current, toPos, math.max(1, (maxDist or 4) - 1), params or {})
    else
      path = {}
    end
  else
    path = getPath(fromPos, toPos, maxDist or 4, params or {})
  end

  for index, direction in ipairs(path or {}) do
    local offset = directionOffsets[direction]
    if not offset then break end
    current = {
      x = current.x + offset[1],
      y = current.y + offset[2],
      z = current.z
    }
    shown = shown + 1
    local color = samePosition(current, toPos) and "#00FF66" or "#00CCFF"
    setMageRunDebugTile(current, color, 900)
  end

  if shown == 0 then
    local directPath = getMageRunDebugDirectPath(fromPos, toPos)
    for index, position in ipairs(directPath) do
      shown = shown + 1
      local color = samePosition(position, toPos) and "#00FF66" or "#00CCFF"
      setMageRunDebugTile(position, color, 900)
    end
  end

  if shown == 0 then
    setMageRunDebugTile(toPos, "#00FF66", 900)
  end
end

local function getMageRunEmergencyArenaRadius(arenaRadius)
  return arenaRadius + 2
end

local function getDirectionToAdjacent(fromPos, toPos)
  if not fromPos or not toPos or fromPos.z ~= toPos.z then return nil end
  local dx = toPos.x - fromPos.x
  local dy = toPos.y - fromPos.y
  for direction, offset in pairs(directionOffsets) do
    if offset[1] == dx and offset[2] == dy then
      return direction
    end
  end
  return nil
end

local function getMageRunFirstPathDirection(fromPos, toPos, path, maxDist, params)
  local direction = path and path[1] or nil
  if not direction then return nil, false end
  return direction, isDiagonalDirection(direction)
end

local function shouldAvoidMageRunDiagonal()
  mageRunDiagonalOpportunity = (mageRunDiagonalOpportunity % 5) + 1

  -- v15: do not merely avoid 60% of diagonals. Always try to split a diagonal
  -- into a straight step first; the caller falls back to the diagonal only when
  -- both straight options are worse or blocked.
  return true
end


local function buildMageRunTrapContext(center, hazards, playerPos, arenaRadius, emergency)
  local outerAllowance = emergency and 2 or 0
  local scanRadius = math.max(6, arenaRadius + outerAllowance)
  local context = {
    center = copyPosition(center),
    hazards = hazards,
    playerPos = copyPosition(playerPos),
    playerKey = positionKey(playerPos),
    -- The topology analyzer must obey the same boundary as candidate movement.
    -- Only a real emergency may temporarily use two tiles outside the arena.
    maxCenterDistance = math.max(
      arenaRadius + outerAllowance, tileDistance(playerPos, center)
    ),
    minX = math.min(center.x - scanRadius, playerPos.x - 6),
    maxX = math.max(center.x + scanRadius, playerPos.x + 6),
    minY = math.min(center.y - scanRadius, playerPos.y - 6),
    maxY = math.max(center.y + scanRadius, playerPos.y + 6),
    z = playerPos.z,
    walkable = {},
    threat = {},
    occupied = {},
    mobilityCache = {},
    topologyCache = {},
    sightCache = {},
    pathRiskCache = {}
  }

  local function addThreatRing(origin, centerLevel, adjacentLevel, outerLevel)
    for dx = -2, 2 do
      for dy = -2, 2 do
        local dist = math.max(math.abs(dx), math.abs(dy))
        local level = dist == 0 and centerLevel
          or (dist == 1 and adjacentLevel or (dist == 2 and outerLevel or 0))
        if level and level > 0 then
          local key = (origin.x + dx) .. ":" .. (origin.y + dy) .. ":" .. origin.z
          context.threat[key] = math.max(context.threat[key] or 0, level)
        end
      end
    end
  end

  for _, creature in ipairs(hazards or {}) do
    local cpos = safeCreaturePosition(creature, context.z)
    if cpos then
      context.occupied[positionKey(cpos)] = true
      addThreatRing(cpos, 4, 3, 1)

      -- Reserve where the creature is likely to move next. This prevents the
      -- route planner from choosing a corridor that is open now but will close
      -- before the player reaches it.
      local stepX = context.playerPos.x > cpos.x and 1
        or (context.playerPos.x < cpos.x and -1 or 0)
      local stepY = context.playerPos.y > cpos.y and 1
        or (context.playerPos.y < cpos.y and -1 or 0)
      local projected = {
        x = cpos.x + stepX,
        y = cpos.y + stepY,
        z = cpos.z
      }
      addThreatRing(projected, 3, 2, 1)
    end
  end

  return context
end

local function trapContextContains(context, position)
  return position
    and position.z == context.z
    and position.x >= context.minX
    and position.x <= context.maxX
    and position.y >= context.minY
    and position.y <= context.maxY
end

local function isTrapStaticWalkable(context, position)
  if not trapContextContains(context, position) then return false end
  if tileDistance(position, context.center) > context.maxCenterDistance then return false end

  local key = positionKey(position)
  if context.walkable[key] ~= nil then
    return context.walkable[key]
  end

  if context.occupied[key] then
    context.walkable[key] = false
    return false
  end

  local tile = g_map.getTile(position)
  local walkable = tile and (key == context.playerKey or (tile:isWalkable()
    and not tileHasCreature(tile)
    and isStaticMageRunTileSafe(position))) or false
  context.walkable[key] = walkable and true or false
  return context.walkable[key]
end

local function isTrapEscapeTile(context, position, startKey, blockThreatLevel)
  local key = positionKey(position)
  if key == startKey then return true end
  if not isTrapStaticWalkable(context, position) then return false end
  return (context.threat[key] or 0) < blockThreatLevel
end

local function canTraverseTrapEdge(context, fromPos, toPos, startKey, blockThreatLevel)
  if not isTrapEscapeTile(context, toPos, startKey, blockThreatLevel) then
    return false
  end

  local dx = toPos.x - fromPos.x
  local dy = toPos.y - fromPos.y
  if dx ~= 0 and dy ~= 0 then
    local sideA = {x=fromPos.x + dx, y=fromPos.y, z=fromPos.z}
    local sideB = {x=fromPos.x, y=fromPos.y + dy, z=fromPos.z}
    if not isTrapEscapeTile(context, sideA, startKey, blockThreatLevel)
      and not isTrapEscapeTile(context, sideB, startKey, blockThreatLevel) then
      return false
    end
  end

  return true
end

local function addEscapeSectors(sectors, origin, position)
  local dx = position.x - origin.x
  local dy = position.y - origin.y
  local absX = math.abs(dx)
  local absY = math.abs(dy)

  if absX >= absY and dx ~= 0 then
    sectors[dx > 0 and "east" or "west"] = true
  end
  if absY >= absX and dy ~= 0 then
    sectors[dy > 0 and "south" or "north"] = true
  end
end

local function countKeys(values)
  local count = 0
  for _ in pairs(values) do
    count = count + 1
  end
  return count
end

local function analyzeEscapeTopology(position, context, blockThreatLevel, lookahead)
  lookahead = lookahead or 4
  local startKey = positionKey(position)
  local queue = {{pos=copyPosition(position), depth=0, branch=nil}}
  local visited = {[startKey]=true}
  local branchDepth = {}
  local sectors = {}
  local head = 1
  local area = 0
  local maxDepth = 0
  local immediateSafe = 0
  local threatExposure = 0

  while head <= #queue do
    local node = queue[head]
    head = head + 1
    area = area + 1
    maxDepth = math.max(maxDepth, node.depth)

    if node.branch then
      branchDepth[node.branch] = math.max(branchDepth[node.branch] or 0, node.depth)
    end

    if node.depth >= lookahead - 1 then
      addEscapeSectors(sectors, position, node.pos)
    end

    if node.depth < lookahead then
      for _, offset in ipairs(trapOffsets) do
        local nextPos = {
          x = node.pos.x + offset[1],
          y = node.pos.y + offset[2],
          z = node.pos.z
        }
        local key = positionKey(nextPos)

        if not visited[key]
          and canTraverseTrapEdge(context, node.pos, nextPos, startKey, blockThreatLevel) then
          visited[key] = true
          local branch = node.branch or key
          local depth = node.depth + 1
          if depth == 1 then
            immediateSafe = immediateSafe + 1
          end
          threatExposure = threatExposure + (context.threat[key] or 0)
          table.insert(queue, {pos=nextPos, depth=depth, branch=branch})
        end
      end
    end
  end

  local viableBranches = 0
  local neededDepth = math.min(3, lookahead)
  for _, depth in pairs(branchDepth) do
    if depth >= neededDepth then
      viableBranches = viableBranches + 1
    end
  end

  return {
    area = area,
    maxDepth = maxDepth,
    immediateSafe = immediateSafe,
    viableBranches = viableBranches,
    sectors = countKeys(sectors),
    threatExposure = threatExposure
  }
end

local function getTopologyPenalty(topology, future)
  local multiplier = future and 1.25 or 1
  local penalty = 0

  if topology.immediateSafe <= 1 then
    penalty = penalty + 1100
  elseif topology.immediateSafe == 2 then
    penalty = penalty + 260
  end

  if topology.area <= 4 then
    penalty = penalty + 1900
  elseif topology.area <= 7 then
    penalty = penalty + 950
  elseif topology.area <= 11 then
    penalty = penalty + 360
  end

  if topology.maxDepth <= 1 then
    penalty = penalty + 1500
  elseif topology.maxDepth == 2 then
    penalty = penalty + 720
  elseif topology.maxDepth == 3 then
    penalty = penalty + 160
  end

  if topology.viableBranches == 0 then
    penalty = penalty + 1800
  elseif topology.viableBranches == 1 then
    penalty = penalty + 850
  elseif topology.viableBranches == 2 then
    penalty = penalty + 110
  end

  if topology.sectors == 0 then
    penalty = penalty + 900
  elseif topology.sectors == 1 then
    penalty = penalty + 380
  end

  -- A route with only one future branch/sector is a trap waiting to close.
  -- Make this effectively a hard rule unless every other position is worse.
  if future then
    if topology.viableBranches == 0 then
      penalty = penalty + 6000
    elseif topology.viableBranches == 1 then
      penalty = penalty + 2400
    elseif topology.viableBranches == 2 then
      penalty = penalty + 320
    end

    if topology.sectors <= 1 then
      penalty = penalty + 1800
    elseif topology.sectors == 2 then
      penalty = penalty + 220
    end

    if topology.area <= 5 then
      penalty = penalty + 4500
    elseif topology.area <= 9 then
      penalty = penalty + 1100
    end
  end

  penalty = penalty + math.min(topology.threatExposure, 20) * (future and 10 or 4)
  return math.floor(penalty * multiplier)
end

local function analyzeMageRunTrap(position, context)
  local cacheKey = positionKey(position)
  if context.topologyCache[cacheKey] then
    return context.topologyCache[cacheKey]
  end

  -- Hard projection: tiles a monster can occupy on its next movement.
  local hard = analyzeEscapeTopology(position, context, 3, 2)
  -- Future projection: also reserves the second ring to spot a closing corridor early.
  local future = analyzeEscapeTopology(position, context, 1, 2)
  local nearestHazard = nearestMonsterDistance(position, context.hazards)
  local risk = getTopologyPenalty(hard, false) + getTopologyPenalty(future, true)

  if nearestHazard <= 4 and future.viableBranches <= 1 then
    risk = risk + 1400
  end
  if nearestHazard <= 3 and future.immediateSafe <= 2 then
    risk = risk + 900
  end
  if hard.area > future.area + 8 then
    risk = risk + math.min(900, (hard.area - future.area) * 45)
  end

  local result = {
    risk = risk,
    escapeArea = hard.area,
    escapeDepth = hard.maxDepth,
    escapeBranches = hard.viableBranches,
    escapeSectors = hard.sectors,
    futureEscapeArea = future.area,
    futureEscapeDepth = future.maxDepth,
    futureEscapeBranches = future.viableBranches,
    futureEscapeSectors = future.sectors,
    futureImmediateSafe = future.immediateSafe
  }
  context.topologyCache[cacheKey] = result
  return result
end


local function getMageRunPathThreat(position, hazards, stepIndex)
  local adjacent = 0
  local nearTwo = 0
  local projectedNearest = 99
  local projectedAdjacent = 0
  local projectedNearTwo = 0
  local horizon = math.min(3, math.max(0, tonumber(stepIndex) or 0))

  for _, creature in ipairs(hazards or {}) do
    local cpos = safeCreaturePosition(creature, position.z)
    if cpos then
      local distance = tileDistance(position, cpos)
      if distance <= 1 then
        adjacent = adjacent + 1
      elseif distance == 2 then
        nearTwo = nearTwo + 1
      end

      local projectedDistance = math.max(0, distance - horizon)
      projectedNearest = math.min(projectedNearest, projectedDistance)
      if projectedDistance <= 1 then
        projectedAdjacent = projectedAdjacent + 1
      elseif projectedDistance == 2 then
        projectedNearTwo = projectedNearTwo + 1
      end
    end
  end

  return adjacent, nearTwo, projectedNearest, projectedAdjacent, projectedNearTwo
end

local function getMageRunCardinalEscapeQuality(position, center, hazards)
  if not position then return 0, 0, 0, 0 end
  local open = 0
  local bestAdjacent = 99
  local bestProjectedAdjacent = 99
  local bestNearest = 0

  for _, offset in ipairs(cardinalOffsets) do
    local nextPos = {
      x = position.x + offset[1],
      y = position.y + offset[2],
      z = position.z
    }
    if canStepTo(nextPos) then
      open = open + 1
      local adjacent, _, projectedNearest, projectedAdjacent =
        getMageRunPathThreat(nextPos, hazards, 1)
      if adjacent < bestAdjacent then bestAdjacent = adjacent end
      if projectedAdjacent < bestProjectedAdjacent then
        bestProjectedAdjacent = projectedAdjacent
      end
      if projectedNearest > bestNearest then bestNearest = projectedNearest end
    end
  end

  if bestAdjacent == 99 then bestAdjacent = 0 end
  if bestProjectedAdjacent == 99 then bestProjectedAdjacent = 0 end
  return open, bestAdjacent, bestProjectedAdjacent, bestNearest
end

local function isMageRunDiagonalActuallyNeeded(fromPos, diagonalDirection, center,
    walkLimit, hazards)
  if not fromPos or not center then return false end
  if not isDiagonalDirection(diagonalDirection) then return false end

  local offset = directionOffsets[diagonalDirection]
  if not offset then return false end

  local diagonalPos = {
    x = fromPos.x + offset[1],
    y = fromPos.y + offset[2],
    z = fromPos.z
  }
  if tileDistance(diagonalPos, center) > walkLimit or not canStepTo(diagonalPos) then
    return false
  end

  local baseAdjacent, _, baseProjectedNearest, baseProjectedAdjacent =
    getMageRunPathThreat(diagonalPos, hazards, 1)
  local diagOpen, diagBestAdjacent, diagBestProjectedAdjacent =
    getMageRunCardinalEscapeQuality(diagonalPos, center, hazards)

  -- A diagonal that lands in a pocket with no straight exits is exactly what
  -- causes the trap shown in the screenshot. Only allow it if it immediately
  -- reduces direct contact in a real emergency.
  if diagOpen <= 1
    and not (mageRunRuntime.emergency
      and (baseAdjacent < mageRunRuntime.adjacent
        or baseProjectedAdjacent < mageRunRuntime.adjacent
        or baseProjectedNearest > mageRunRuntime.nearestHazard)) then
    return false
  end

  local alternatives = {
    {x=fromPos.x + offset[1], y=fromPos.y, z=fromPos.z},
    {x=fromPos.x, y=fromPos.y + offset[2], z=fromPos.z}
  }

  for _, stepPos in ipairs(alternatives) do
    if tileDistance(stepPos, center) <= walkLimit and canStepTo(stepPos) then
      local adjacent, _, projectedNearest, projectedAdjacent =
        getMageRunPathThreat(stepPos, hazards, 1)
      local open, bestAdjacent, bestProjectedAdjacent =
        getMageRunCardinalEscapeQuality(stepPos, center, hazards)
      local straightSafe = adjacent <= baseAdjacent
        and projectedAdjacent <= baseProjectedAdjacent
        and open >= 2
        and bestAdjacent <= math.max(baseAdjacent, diagBestAdjacent)
        and bestProjectedAdjacent <= math.max(baseProjectedAdjacent, diagBestProjectedAdjacent)
      if straightSafe then
        return false
      end
    end
  end

  return true
end

local function chooseMageRunOrthogonalSplit(fromPos, diagonalDirection, center,
    walkLimit, hazards)
  if not isDiagonalDirection(diagonalDirection) then return nil, nil end
  if not shouldAvoidMageRunDiagonal() then return nil, nil end

  local offset = directionOffsets[diagonalDirection]
  if not offset then return nil, nil end

  local diagonalPos = {
    x=fromPos.x + offset[1],
    y=fromPos.y + offset[2],
    z=fromPos.z
  }
  local baseAdjacent, baseNear, _, baseProjectedAdjacent =
    getMageRunPathThreat(diagonalPos, hazards, 1)

  local alternatives = {
    {x=fromPos.x + offset[1], y=fromPos.y, z=fromPos.z},
    {x=fromPos.x, y=fromPos.y + offset[2], z=fromPos.z}
  }
  local best = nil
  local currentCenterDistance = tileDistance(fromPos, center)

  for _, stepPos in ipairs(alternatives) do
    if tileDistance(stepPos, center) <= walkLimit and canStepTo(stepPos) then
      local adjacent, near, projectedNearest, projectedAdjacent =
        getMageRunPathThreat(stepPos, hazards, 1)

      -- Do not trade a safe diagonal for an orthogonal step that enters contact.
      local contactSafe = adjacent <= baseAdjacent
        and projectedAdjacent <= baseProjectedAdjacent
      if contactSafe then
        local mobility = getTileMobility(stepPos)
        local centerDistance = tileDistance(stepPos, center)
        local escapeOpen, escapeBestAdjacent, escapeBestProjectedAdjacent =
          getMageRunCardinalEscapeQuality(stepPos, center, hazards)
        local score = adjacent * 6000
          + projectedAdjacent * 3500
          + near * 420
          + math.max(0, 3 - projectedNearest) * 260
          - (mobility.openTiles or 0) * 24
          - (mobility.orthogonalOpen or 0) * 35
          - escapeOpen * 110
          + escapeBestAdjacent * 1800
          + escapeBestProjectedAdjacent * 1100

        if escapeOpen <= 1 then
          score = score + (mageRunRuntime.emergency and 900 or 5200)
        end

        if hasMageRunMagicField(stepPos) then
          score = score + (mageRunRuntime.emergency and 900 or 4200)
        end
        if mageRunDecision.centerRecovery
          or mageRunDecision.reserveEscape
          or currentCenterDistance > walkLimit - 1 then
          score = score + (centerDistance - currentCenterDistance) * 700
        end

        local direction = getDirectionToAdjacent(fromPos, stepPos)
        if direction and (not best or score < best.score) then
          best = {direction=direction, pos=copyPosition(stepPos), score=score}
        end
      end
    end
  end

  if best then return best.direction, best.pos end
  return nil, nil
end


local function getPathRisk(fromPos, toPos, hazards, context, emergency, suppliedPath)
  if samePosition(fromPos, toPos) then
    return 0, 0
  end

  local cacheKey = positionKey(fromPos) .. ">" .. positionKey(toPos)
    .. (emergency and ":e" or ":n")
  if suppliedPath then
    cacheKey = cacheKey .. ":p" .. #suppliedPath
  end
  if context and context.pathRiskCache[cacheKey] then
    local cached = context.pathRiskCache[cacheKey]
    return cached.risk, cached.length
  end

  local maxPathDistance = math.max(4, math.min(12, tileDistance(fromPos, toPos) + 5))
  local path = suppliedPath or findPath(fromPos, toPos, maxPathDistance, {
    ignoreCreatures = true,
    ignoreNonPathable = true,
    ignoreCost = true
  })
  if not path or #path == 0 then
    return nil, nil
  end

  local current = copyPosition(fromPos)
  local risk = 0
  local diagonalCount = 0
  local previousDirection = nil

  for stepIndex, direction in ipairs(path) do
    local offset = directionOffsets[direction]
    if not offset then return nil, nil end
    local directionDiagonal = isDiagonalDirection(direction)
    if directionDiagonal then
      diagonalCount = diagonalCount + 1
    end

    current.x = current.x + offset[1]
    current.y = current.y + offset[2]

    local tile = g_map.getTile(current)
    if not tile or not tile:isWalkable() or tileHasCreature(tile)
      or not isStaticMageRunTileSafe(current) then
      return nil, nil
    end

    if context and tileDistance(current, context.center) > context.maxCenterDistance then
      return nil, nil
    end

    local adjacent, near, projectedNearest, projectedAdjacent, projectedNearTwo =
      getMageRunPathThreat(current, hazards, stepIndex)
    risk = risk + adjacent * 900 + near * 135

    if directionDiagonal then
      local escapeOpen, escapeBestAdjacent, escapeBestProjectedAdjacent =
        getMageRunCardinalEscapeQuality(current, context and context.center or current, hazards)
      if escapeOpen <= 1 then
        risk = risk + (emergency and 1600 or 7200)
      end
      risk = risk + escapeBestAdjacent * (emergency and 800 or 2200)
      risk = risk + escapeBestProjectedAdjacent * (emergency and 500 or 1500)
    end

    risk = risk + projectedAdjacent * (emergency and 650 or 1250)
    risk = risk + projectedNearTwo * (emergency and 120 or 260)
    if projectedNearest <= 0 then
      risk = risk + (emergency and 1800 or 4200)
    elseif projectedNearest == 1 then
      risk = risk + (emergency and 700 or 1600)
    elseif projectedNearest == 2 then
      risk = risk + (emergency and 120 or 320)
    end

    if context then
      local threatLevel = context.threat[positionKey(current)] or 0
      risk = risk + threatLevel * threatLevel * (emergency and 70 or 160)
    end

    if hasMageRunMagicField(current) then
      -- Crossing a field is undesirable, but still preferable to being boxed.
      risk = risk + (emergency and 650 or 2600)
    end

    if previousDirection and previousDirection ~= direction then
      risk = risk + (emergency and 8 or 22)
    end
    previousDirection = direction
  end

  risk = risk + getMageRunDiagonalPenalty(diagonalCount, #path, emergency)

  if context then
    context.pathRiskCache[cacheKey] = {risk=risk, length=#path}
  end
  return risk, #path
end

local function evaluateMageRunTile(position, center, hazards, configured, targetPosition, playerPos, trapContext)
  local mobility = getTileMobility(position, trapContext and trapContext.mobilityCache or nil)
  local adjacent = 0
  local orthogonalAdjacent = 0
  local nearTwo = 0
  local nearThree = 0
  local nearestHazard = 99
  local north = false
  local south = false
  local east = false
  local west = false

  for _, creature in ipairs(hazards or {}) do
    local cpos = safeCreaturePosition(creature, position.z)
    if cpos then
    local diffx = cpos.x - position.x
    local diffy = cpos.y - position.y
    local dist = math.max(math.abs(diffx), math.abs(diffy))
    nearestHazard = math.min(nearestHazard, dist)

    if dist <= 1 then
      adjacent = adjacent + 1
      if diffx == 0 or diffy == 0 then
        orthogonalAdjacent = orthogonalAdjacent + 1
      end
    elseif dist == 2 then
      nearTwo = nearTwo + 1
    elseif dist == 3 then
      nearThree = nearThree + 1
    end

    if dist <= 2 then
      if diffy < 0 then north = true end
      if diffy > 0 then south = true end
      if diffx > 0 then east = true end
      if diffx < 0 then west = true end
    end
    end
  end

  local sideCount = 0
  if north then sideCount = sideCount + 1 end
  if south then sideCount = sideCount + 1 end
  if east then sideCount = sideCount + 1 end
  if west then sideCount = sideCount + 1 end

  local oppositePairs = 0
  if north and south then oppositePairs = oppositePairs + 1 end
  if east and west then oppositePairs = oppositePairs + 1 end

  local packVisible = 0
  local clusterX = 0
  local clusterY = 0
  local sightCache = trapContext and trapContext.sightCache or nil
  local configuredCount = 0
  local nearestConfigured = 99
  for _, creature in ipairs(configured or {}) do
    local cpos = safeCreaturePosition(creature, position.z)
    if cpos then
    configuredCount = configuredCount + 1
    nearestConfigured = math.min(nearestConfigured, tileDistance(position, cpos))
    -- "Visible" now means both projected on the game screen and actually
    -- shootable from the candidate tile; walls no longer count as keeping the
    -- pack available for spells/runes.
    if isProjectedOnScreen(position, cpos)
      and hasLineOfSight(position, cpos, sightCache) then
      packVisible = packVisible + 1
    end
    clusterX = clusterX + cpos.x
    clusterY = clusterY + cpos.y
    end
  end

  local clusterDistance = 99
  if configuredCount > 0 then
    clusterX = clusterX / configuredCount
    clusterY = clusterY / configuredCount
    clusterDistance = math.max(math.abs(clusterX - position.x), math.abs(clusterY - position.y))
  end

  local targetShootable = not targetPosition
    or hasLineOfSight(position, targetPosition, sightCache)

  if nearestConfigured == 99 and targetPosition then
    nearestConfigured = tileDistance(position, targetPosition)
  end

  local trap = trapContext and analyzeMageRunTrap(position, trapContext) or {
    risk = 0,
    escapeArea = 99,
    escapeDepth = 4,
    escapeBranches = 8,
    escapeSectors = 4,
    futureEscapeArea = 99,
    futureEscapeDepth = 4,
    futureEscapeBranches = 8,
    futureEscapeSectors = 4,
    futureImmediateSafe = 8
  }

  return {
    adjacent = adjacent,
    orthogonalAdjacent = orthogonalAdjacent,
    nearTwo = nearTwo,
    nearThree = nearThree,
    nearestHazard = nearestHazard,
    nearestConfigured = nearestConfigured,
    packVisible = packVisible,
    packTotal = configuredCount,
    clusterDistance = clusterDistance,
    centerDistance = tileDistance(position, center),
    playerDistance = tileDistance(position, playerPos),
    targetDistance = targetPosition and tileDistance(position, targetPosition) or 99,
    openTiles = mobility.openTiles,
    orthogonalOpen = mobility.orthogonalOpen,
    canShoot = mobility.canShoot,
    targetShootable = targetShootable,
    sideCount = sideCount,
    oppositePairs = oppositePairs,
    trapRisk = trap.risk,
    escapeArea = trap.escapeArea,
    escapeDepth = trap.escapeDepth,
    escapeBranches = trap.escapeBranches,
    escapeSectors = trap.escapeSectors,
    futureEscapeArea = trap.futureEscapeArea,
    futureEscapeDepth = trap.futureEscapeDepth,
    futureEscapeBranches = trap.futureEscapeBranches,
    futureEscapeSectors = trap.futureEscapeSectors,
    futureImmediateSafe = trap.futureImmediateSafe,
    magicField = hasMageRunMagicField(position),
    magicFieldTiles = mobility.magicFieldTiles or 0
  }
end

local function evaluateMageRunImmediate(position, center, hazards, configured, playerPos, context)
  local mobilityCache = context and context.mobilityCache or nil
  if not mobilityCache then
    if mageRunFastMobilityCache.z ~= position.z
      or mageRunFastMobilityCache.expiresAt <= now then
      mageRunFastMobilityCache.z = position.z
      mageRunFastMobilityCache.expiresAt = now + 120
      mageRunFastMobilityCache.values = {}
    end
    mobilityCache = mageRunFastMobilityCache.values
  end
  local mobility = getTileMobility(position, mobilityCache)
  local adjacent = 0
  local orthogonalAdjacent = 0
  local nearTwo = 0
  local nearThree = 0
  local nearestHazard = 99
  local nearestConfigured = 99
  local north, south, east, west = false, false, false, false

  for _, creature in ipairs(hazards or {}) do
    local cpos = safeCreaturePosition(creature, position.z)
    if cpos then
    local dx = cpos.x - position.x
    local dy = cpos.y - position.y
    local dist = math.max(math.abs(dx), math.abs(dy))
    nearestHazard = math.min(nearestHazard, dist)
    if dist <= 1 then
      adjacent = adjacent + 1
      if dx == 0 or dy == 0 then orthogonalAdjacent = orthogonalAdjacent + 1 end
    elseif dist == 2 then
      nearTwo = nearTwo + 1
    elseif dist == 3 then
      nearThree = nearThree + 1
    end
    if dist <= 2 then
      if dy < 0 then north = true elseif dy > 0 then south = true end
      if dx < 0 then west = true elseif dx > 0 then east = true end
    end
    end
  end

  for _, creature in ipairs(configured or {}) do
    local cpos = safeCreaturePosition(creature, position.z)
    if cpos then
      nearestConfigured = math.min(nearestConfigured, tileDistance(position, cpos))
    end
  end

  local sideCount = (north and 1 or 0) + (south and 1 or 0)
    + (east and 1 or 0) + (west and 1 or 0)
  local oppositePairs = (north and south and 1 or 0) + (east and west and 1 or 0)

  return {
    adjacent = adjacent,
    orthogonalAdjacent = orthogonalAdjacent,
    nearTwo = nearTwo,
    nearThree = nearThree,
    nearestHazard = nearestHazard,
    nearestConfigured = nearestConfigured,
    openTiles = mobility.openTiles,
    orthogonalOpen = mobility.orthogonalOpen,
    canShoot = mobility.canShoot,
    sideCount = sideCount,
    oppositePairs = oppositePairs,
    centerDistance = tileDistance(position, center),
    playerDistance = tileDistance(position, playerPos),
    magicField = hasMageRunMagicField(position),
    magicFieldTiles = mobility.magicFieldTiles or 0
  }
end

-- Candidate graph scans only need distance/pressure information. Full tile
-- mobility, magic-field and topology checks are reserved for the small final
-- shortlist. This is the main CPU reduction on mobile/low-end clients.
local function evaluateMageRunCheap(position, center, hazards, configured, playerPos)
  local adjacent = 0
  local orthogonalAdjacent = 0
  local nearTwo = 0
  local nearThree = 0
  local nearestHazard = 99
  local nearestConfigured = 99
  local north, south, east, west = false, false, false, false

  for _, creature in ipairs(hazards or {}) do
    local cpos = safeCreaturePosition(creature, position.z)
    if cpos then
      local dx = cpos.x - position.x
      local dy = cpos.y - position.y
      local dist = math.max(math.abs(dx), math.abs(dy))
      nearestHazard = math.min(nearestHazard, dist)
      if dist <= 1 then
        adjacent = adjacent + 1
        if dx == 0 or dy == 0 then orthogonalAdjacent = orthogonalAdjacent + 1 end
      elseif dist == 2 then
        nearTwo = nearTwo + 1
      elseif dist == 3 then
        nearThree = nearThree + 1
      end
      if dist <= 2 then
        if dy < 0 then north = true elseif dy > 0 then south = true end
        if dx < 0 then west = true elseif dx > 0 then east = true end
      end
    end
  end

  for _, creature in ipairs(configured or {}) do
    local cpos = safeCreaturePosition(creature, position.z)
    if cpos then
      nearestConfigured = math.min(nearestConfigured, tileDistance(position, cpos))
    end
  end

  return {
    adjacent = adjacent,
    orthogonalAdjacent = orthogonalAdjacent,
    nearTwo = nearTwo,
    nearThree = nearThree,
    nearestHazard = nearestHazard,
    nearestConfigured = nearestConfigured,
    -- Neutral defaults: graph traversal already guarantees a walkable endpoint.
    -- Real mobility/field values are calculated for shortlisted candidates.
    openTiles = 5,
    orthogonalOpen = 3,
    canShoot = true,
    sideCount = (north and 1 or 0) + (south and 1 or 0)
      + (east and 1 or 0) + (west and 1 or 0),
    oppositePairs = (north and south and 1 or 0) + (east and west and 1 or 0),
    centerDistance = tileDistance(position, center),
    playerDistance = tileDistance(position, playerPos),
    magicField = false,
    magicFieldTiles = 0
  }
end

local function isMageRunBoundaryPressure(score, arenaRadius)
  if not score or not arenaRadius then return false end
  if score.centerDistance > arenaRadius then return true end
  if score.centerDistance < arenaRadius - 1 then return false end

  if score.centerDistance >= arenaRadius then
    return score.nearestHazard <= 3
      or score.nearTwo > 0
      or score.nearThree >= 2
      or score.sideCount >= 2
      or score.openTiles <= 4
  end

  return score.nearestHazard <= 2
    or score.nearTwo >= 2
    or score.sideCount >= 3
    or score.openTiles <= 3
end

local function isImmediateMageRunEmergency(score, minRange, arenaRadius)
  return score.adjacent > 0
    or score.orthogonalAdjacent > 0
    or score.nearTwo >= 3
    or score.nearestHazard <= 1
    or score.nearestConfigured < minRange
    or score.openTiles <= 2
    or score.orthogonalOpen <= 1
    or score.sideCount >= 3
    or score.oppositePairs > 0
    or isMageRunBoundaryPressure(score, arenaRadius)
end

local function getMageRunSoftArenaRadius(arenaRadius)
  -- Arena radius is the hard outer limit. Normal kiting should happen inside
  -- this working radius so the bot does not voluntarily ride the boundary.
  return math.max(1, arenaRadius - 2)
end

local function getMageRunPreferredArenaRadius(arenaRadius)
  -- Preferred orbit band. The next ring is still usable, but should not become
  -- the bot's permanent running track.
  return math.max(1, arenaRadius - 3)
end

local function updateMageRunCenterRecovery(centerDistance, arenaRadius)
  local innerRadius = getMageRunSoftArenaRadius(arenaRadius)
  local releaseRadius = getMageRunPreferredArenaRadius(arenaRadius)

  if centerDistance >= innerRadius then
    mageRunDecision.centerRecovery = true
  elseif mageRunDecision.centerRecovery and centerDistance <= releaseRadius then
    mageRunDecision.centerRecovery = false
  end

  return mageRunDecision.centerRecovery
end

local function isMageRunApproachingPressure(score, minRange, arenaRadius)
  if not score then return false end

  return score.nearTwo > 0
    or score.nearThree >= 2
    or score.nearestHazard <= minRange + 1
    or score.nearestConfigured <= minRange + 1
    or score.sideCount >= 2
    or score.openTiles <= 4
    or score.orthogonalOpen <= 2
    or score.centerDistance > getMageRunPreferredArenaRadius(arenaRadius)
end

local function isMageRunHardHoldBreak(score, minRange, arenaRadius)
  if not score then return true end

  return score.adjacent > 0
    or score.orthogonalAdjacent > 0
    or score.nearestHazard <= 1
    or score.nearestConfigured < minRange
    or score.openTiles <= 1
    or score.orthogonalOpen <= 1
    or score.oppositePairs > 0
    or score.centerDistance > arenaRadius
end

local function getMageRunArenaPenalty(centerDistance, arenaRadius, emergency)
  local preferredRadius = getMageRunPreferredArenaRadius(arenaRadius)
  local softRadius = getMageRunSoftArenaRadius(arenaRadius)
  local emergencyRadius = getMageRunEmergencyArenaRadius(arenaRadius)
  local hardLimit = emergency and emergencyRadius or arenaRadius

  if centerDistance > hardLimit then
    return 12000 + (centerDistance - hardLimit) * 2200
  end

  local total = centerDistance * (emergency and 3 or 20)

  if emergency and centerDistance > arenaRadius then
    local emergencyDepth = centerDistance - arenaRadius
    total = total + 1800 + emergencyDepth * emergencyDepth * 650
  end

  if centerDistance > preferredRadius then
    local edgeDepth = centerDistance - preferredRadius
    total = total + edgeDepth * edgeDepth * (emergency and 70 or 380)
  end

  if centerDistance > softRadius then
    local reserveDepth = centerDistance - softRadius
    -- The outer reserve rings are for emergencies, not normal movement.
    total = total + reserveDepth * reserveDepth * (emergency and 130 or 2200)
  end

  return total
end

local function getCheapCandidateScore(score, minRange, maxRange, preferredRange, arenaRadius, emergency)
  local total = score.adjacent * 1500
    + score.orthogonalAdjacent * 400
    + score.nearTwo * 170
    + score.nearThree * 30
    + score.sideCount * 45
    + score.oppositePairs * 220

  if score.magicField then
    total = total + (emergency and 420 or 2800)
  end
  if score.openTiles <= 2 then total = total + 700
  elseif score.openTiles == 3 then total = total + 180 end
  if score.orthogonalOpen <= 1 then total = total + 300 end
  if not score.canShoot then total = total + 160 end
  if score.nearestConfigured < minRange then
    total = total + (minRange - score.nearestConfigured) * 350
  elseif score.nearestConfigured > maxRange then
    total = total + (score.nearestConfigured - maxRange)
      * (emergency and 420 or 900) + (emergency and 240 or 1200)
  else
    total = total + math.abs(score.nearestConfigured - preferredRange) * 20
  end
  total = total + getMageRunArenaPenalty(
    score.centerDistance, arenaRadius, emergency
  )

  local idealDistance = emergency
    and math.min(6, arenaRadius + 1) or math.min(5, arenaRadius)
  local moveDistance = tonumber(score.playerDistance) or 0
  if moveDistance < idealDistance then
    total = total + (idealDistance - moveDistance) * (emergency and 150 or 260)
  elseif moveDistance > idealDistance + 2 then
    total = total + (moveDistance - idealDistance - 2) * (emergency and 35 or 70)
  end
  return total
end

local function isMageRunEmergency(score, minRange, arenaRadius)
  return score.adjacent > 0
    or score.orthogonalAdjacent > 0
    or score.nearTwo >= 3
    or score.nearestHazard <= 1
    or score.nearestConfigured < minRange
    or score.openTiles <= 2
    or score.orthogonalOpen <= 1
    or score.sideCount >= 3
    or score.oppositePairs > 0
    or score.escapeArea <= 5
    or score.futureEscapeArea <= 5
    or (score.futureEscapeBranches <= 1 and score.nearestHazard <= 4)
    or (score.futureImmediateSafe <= 1 and score.nearestHazard <= 4)
    or isMageRunBoundaryPressure(score, arenaRadius)
end

local function getMageRunCompositeScore(score, currentScore, pathRisk, emergency, minRange, maxRange, preferredRange, arenaRadius, reverseMove)
  local total = 0

  total = total + score.adjacent * 1200
  total = total + score.orthogonalAdjacent * 350
  total = total + score.nearTwo * 140
  total = total + score.nearThree * 28
  total = total + score.sideCount * 40
  total = total + score.oppositePairs * 180
  total = total + (score.trapRisk or 0)

  if score.magicField then
    total = total + (emergency and 350 or 3200)
  end

  if score.openTiles <= 2 then
    total = total + 500
  elseif score.openTiles == 3 then
    total = total + 160
  elseif score.openTiles == 4 then
    total = total + 45
  end

  if score.orthogonalOpen <= 1 then
    total = total + 240
  elseif score.orthogonalOpen == 2 then
    total = total + 60
  end

  if not score.canShoot then
    total = total + 180
  end
  if score.packTotal > 0 and score.packVisible == 0 then
    total = total + (emergency and 220 or 1500)
  end
  if not score.targetShootable then
    total = total + (emergency and 120 or 850)
  end

  if score.nearestConfigured < minRange then
    total = total + (minRange - score.nearestConfigured) * 300
  elseif score.nearestConfigured > maxRange then
    total = total + (score.nearestConfigured - maxRange)
      * (emergency and 450 or 1100) + (emergency and 250 or 1600)
  else
    total = total + math.abs(score.nearestConfigured - preferredRange) * 18
  end

  local lostPack = math.max(0, currentScore.packVisible - score.packVisible)
  local missingPack = math.max(0, score.packTotal - score.packVisible)
  total = total + lostPack * (emergency and 150 or 500)
  total = total + missingPack * (emergency and 80 or 220)

  if score.clusterDistance > maxRange then
    total = total + (score.clusterDistance - maxRange)
      * (emergency and 220 or 520)
  elseif score.clusterDistance > 6 then
    total = total + (score.clusterDistance - 6) * 90
  elseif score.clusterDistance < minRange then
    total = total + (minRange - score.clusterDistance) * 55
  end

  total = total + getMageRunArenaPenalty(
    score.centerDistance, arenaRadius, emergency
  )

  local preferredArenaRadius = getMageRunPreferredArenaRadius(arenaRadius)
  local centerDrift = score.centerDistance - currentScore.centerDistance
  if not emergency then
    if score.centerDistance > preferredArenaRadius and centerDrift > 0 then
      total = total + centerDrift * 720
    elseif currentScore.centerDistance > preferredArenaRadius and centerDrift < 0 then
      total = total - math.abs(centerDrift) * 420
    end
  end

  local idealDistance = emergency
    and math.min(6, arenaRadius + 1) or math.min(5, arenaRadius)
  local moveDistance = tonumber(score.playerDistance) or 0
  if moveDistance < idealDistance then
    total = total + (idealDistance - moveDistance) * (emergency and 180 or 320)
  elseif moveDistance > idealDistance + 2 then
    total = total + (moveDistance - idealDistance - 2) * (emergency and 40 or 80)
  end
  total = total + (pathRisk or 0)

  if reverseMove and not emergency then
    total = total + 180
  elseif reverseMove then
    total = total + 35
  end

  return total
end

local function isBetterMageRunCandidate(candidate, best)
  if not best then return true end
  if candidate.composite ~= best.composite then
    return candidate.composite < best.composite
  end
  if candidate.score.adjacent ~= best.score.adjacent then
    return candidate.score.adjacent < best.score.adjacent
  end
  if candidate.score.orthogonalAdjacent ~= best.score.orthogonalAdjacent then
    return candidate.score.orthogonalAdjacent < best.score.orthogonalAdjacent
  end
  if candidate.score.trapRisk ~= best.score.trapRisk then
    return candidate.score.trapRisk < best.score.trapRisk
  end
  if candidate.score.futureEscapeBranches ~= best.score.futureEscapeBranches then
    return candidate.score.futureEscapeBranches > best.score.futureEscapeBranches
  end
  if candidate.score.futureEscapeArea ~= best.score.futureEscapeArea then
    return candidate.score.futureEscapeArea > best.score.futureEscapeArea
  end
  if candidate.score.packVisible ~= best.score.packVisible then
    return candidate.score.packVisible > best.score.packVisible
  end
  if candidate.score.nearestConfigured ~= best.score.nearestConfigured then
    return candidate.score.nearestConfigured > best.score.nearestConfigured
  end
  if candidate.score.openTiles ~= best.score.openTiles then
    return candidate.score.openTiles > best.score.openTiles
  end
  if candidate.score.orthogonalOpen ~= best.score.orthogonalOpen then
    return candidate.score.orthogonalOpen > best.score.orthogonalOpen
  end
  if candidate.score.centerDistance ~= best.score.centerDistance then
    return candidate.score.centerDistance < best.score.centerDistance
  end
  return candidate.score.playerDistance > best.score.playerDistance
end

local function isMageRunInRangeOption(candidate, currentScore, minRange, maxRange)
  if not candidate or not candidate.score then return false end
  local score = candidate.score

  return score.nearestConfigured <= maxRange
    and score.nearestConfigured >= math.max(1, minRange - 1)
    and score.adjacent <= currentScore.adjacent
    and score.orthogonalAdjacent <= currentScore.orthogonalAdjacent
    and score.openTiles >= 2
end

local function isMageRunRangeBridge(candidate, maxRange, arenaRadius)
  if not candidate or not candidate.score then return false end
  return candidate.score.nearestConfigured > maxRange
    and candidate.score.centerDistance <= arenaRadius
end

local function isMageRunRecoveryCandidate(candidate, currentScore, arenaRadius, edgeRecovery)
  if not candidate or not candidate.score then return false end
  local score = candidate.score

  if score.centerDistance > arenaRadius then return false end
  if score.adjacent > currentScore.adjacent then return false end
  if score.orthogonalAdjacent > currentScore.orthogonalAdjacent then return false end
  if edgeRecovery and score.centerDistance > currentScore.centerDistance then
    return false
  end

  local improvesCenter = edgeRecovery
    and score.centerDistance < currentScore.centerDistance
  local improvesSpace = score.openTiles > currentScore.openTiles
    or score.orthogonalOpen > currentScore.orthogonalOpen
  local improvesEscape = score.futureEscapeArea > currentScore.futureEscapeArea + 2
    or score.futureEscapeBranches > currentScore.futureEscapeBranches
  local improvesRisk = score.trapRisk + 250 < currentScore.trapRisk

  return improvesCenter or improvesSpace or improvesEscape or improvesRisk
end

local function canTraverseMageRunRoute(fromPos, toPos)
  if not canStepTo(toPos) then return false end
  local dx = toPos.x - fromPos.x
  local dy = toPos.y - fromPos.y
  if dx ~= 0 and dy ~= 0 then
    local sideA = {x=fromPos.x + dx, y=fromPos.y, z=fromPos.z}
    local sideB = {x=fromPos.x, y=fromPos.y + dy, z=fromPos.z}
    if not canStepTo(sideA) and not canStepTo(sideB) then
      return false
    end
  end
  return true
end

local function buildMageRunCandidatePath(entry)
  if not entry then return {} end
  if entry.path then return copyDirectionPath(entry.path) end

  local reversed = {}
  local node = entry.node
  while node and node.parent do
    reversed[#reversed + 1] = node.direction
    node = node.parent
  end

  local path = {}
  for index = #reversed, 1, -1 do
    path[#path + 1] = reversed[index]
  end
  return path
end

local function collectMageRunCandidates(pos, center, arenaRadius, includeWide,
    emergency, allowReserve, centerRecovery)
  local candidates = {}
  local seen = {}
  local currentCenterDistance = tileDistance(pos, center)
  local innerRadius = getMageRunSoftArenaRadius(arenaRadius)
  local emergencyRadius = getMageRunEmergencyArenaRadius(arenaRadius)
  local maxAllowed = allowReserve
    and math.max(emergencyRadius, currentCenterDistance)
    or math.max(innerRadius, currentCenterDistance)

  -- Keep a useful strategic horizon without exploring almost the whole arena
  -- on every decision. Emergency bypass still reaches farther than normal kite.
  local maxDepth
  if allowReserve then
    maxDepth = math.min(7, math.max(5, arenaRadius))
  elseif emergency then
    maxDepth = math.min(6, math.max(4, arenaRadius - 1))
  elseif includeWide then
    maxDepth = math.min(5, math.max(4, arenaRadius - 2))
  else
    maxDepth = math.min(4, math.max(3, arenaRadius - 3))
  end

  local root = {
    pos=copyPosition(pos),
    depth=0,
    parent=nil,
    direction=nil,
    leftArena=currentCenterDistance > arenaRadius,
    outsideSteps=currentCenterDistance > arenaRadius and 1 or 0,
    maxCenterDistance=currentCenterDistance,
    firstDirection=nil,
    diagonalCount=0
  }
  local queue = {root}
  local head = 1
  local startState = positionKey(pos) .. ":" .. ((currentCenterDistance > arenaRadius) and "1" or "0")
  seen[startState] = true
  local processed = 0
  local maxNodes = allowReserve and 140 or 84

  while head <= #queue and processed < maxNodes do
    local node = queue[head]
    head = head + 1
    processed = processed + 1
    candidates[#candidates + 1] = {
      pos=node.pos,
      depth=node.depth,
      node=node,
      leftArena=node.leftArena,
      outsideSteps=node.outsideSteps,
      maxCenterDistance=node.maxCenterDistance,
      firstDirection=node.firstDirection,
      diagonalCount=node.diagonalCount or 0
    }

    if node.depth < maxDepth then
      for _, offset in ipairs(trapOffsets) do
        local nextPos = {
          x = node.pos.x + offset[1],
          y = node.pos.y + offset[2],
          z = node.pos.z
        }
        local centerDistance = tileDistance(nextPos, center)
        local nextLeftArena = node.leftArena or centerDistance > arenaRadius
        local direction = getDirectionFromOffset(offset[1], offset[2])
        local nextFirstDirection = node.firstDirection or direction
        local nextDiagonalCount = (node.diagonalCount or 0)
          + (isDiagonalOffset(offset) and 1 or 0)
        local stateKey = positionKey(nextPos) .. ":" .. (nextLeftArena and "1" or "0")
        if allowReserve then
          stateKey = stateKey .. ":" .. tostring(nextFirstDirection)
        end
        local arenaAllowed = false

        if allowReserve then
          arenaAllowed = centerDistance <= maxAllowed
        elseif currentCenterDistance > innerRadius then
          arenaAllowed = centerDistance <= currentCenterDistance
        elseif centerRecovery then
          arenaAllowed = centerDistance <= currentCenterDistance
        else
          arenaAllowed = centerDistance <= innerRadius
        end

        if not samePosition(nextPos, pos)
          and not seen[stateKey]
          and arenaAllowed
          and canTraverseMageRunRoute(node.pos, nextPos) then
          seen[stateKey] = true
          queue[#queue + 1] = {
            pos=nextPos,
            depth=node.depth + 1,
            parent=node,
            direction=direction,
            leftArena=nextLeftArena,
            outsideSteps=node.outsideSteps + (centerDistance > arenaRadius and 1 or 0),
            maxCenterDistance=math.max(node.maxCenterDistance, centerDistance),
            firstDirection=nextFirstDirection,
            diagonalCount=nextDiagonalCount
          }
        end
      end
    end
  end

  return candidates
end

local function isViableMageRunInternalEscape(candidate, currentScore, arenaRadius)
  if not candidate or not candidate.score then return false end
  local score = candidate.score
  if score.centerDistance > arenaRadius then return false end
  if score.adjacent > currentScore.adjacent then return false end
  if score.orthogonalAdjacent > currentScore.orthogonalAdjacent then return false end
  if (candidate.pathRisk or 0) > 9000 then return false end

  local opensRoute = score.futureEscapeBranches >= 2
    and score.futureEscapeArea >= 8
    and score.openTiles >= 3
  local breaksContact = score.adjacent < currentScore.adjacent
    or score.orthogonalAdjacent < currentScore.orthogonalAdjacent
    or score.nearestHazard > currentScore.nearestHazard
  local improvesTopology = score.futureEscapeBranches > currentScore.futureEscapeBranches
    or score.futureEscapeArea > currentScore.futureEscapeArea + 3
    or score.trapRisk + 500 < currentScore.trapRisk
  local safelyRecenters = score.centerDistance < currentScore.centerDistance
    and score.openTiles >= 2
    and score.futureEscapeArea >= 5
    and (candidate.pathRisk or 0) <= 6500

  return opensRoute or safelyRecenters or (breaksContact and improvesTopology)
end

local function chooseMageRunReserveRoute(pos, center, arenaRadius, hazards,
    configured, targetPosition, currentScore, minRange, maxRange, preferredRange)
  local reserveContext = buildMageRunTrapContext(
    center, hazards, pos, arenaRadius, true
  )
  local currentCenterDistance = tileDistance(pos, center)
  local softRadius = getMageRunSoftArenaRadius(arenaRadius)
  local preferredRadius = getMageRunPreferredArenaRadius(arenaRadius)
  local emergencyRadius = getMageRunEmergencyArenaRadius(arenaRadius)
  local reserveLimit = math.max(emergencyRadius, currentCenterDistance)
  local alreadyOutside = currentCenterDistance > arenaRadius
    or mageRunDecision.reserveEscape

  -- Cheap pass over the larger emergency graph. Full topology analysis is
  -- intentionally limited to a shortlist so a boxed situation does not freeze
  -- the client while hundreds of paths are evaluated.
  local cheapCandidates = {}
  for _, entry in ipairs(collectMageRunCandidates(
      pos, center, arenaRadius, true, true, true, true)) do
    if entry.depth >= 2
      and entry.maxCenterDistance <= reserveLimit
      and (alreadyOutside or entry.leftArena) then
      local quick = evaluateMageRunCheap(
        entry.pos, center, hazards, configured, pos
      )
      quick.playerDistance = entry.depth
      local endpointDepth = math.max(0, quick.centerDistance - arenaRadius)
      local outsideDepth = math.max(0, entry.maxCenterDistance - arenaRadius)
      local cheap = getCheapCandidateScore(
        quick, minRange, maxRange, preferredRange, arenaRadius, true
      ) + entry.outsideSteps * 120
        + outsideDepth * outsideDepth * 650

      if quick.centerDistance <= preferredRadius then
        cheap = cheap - 6200
      elseif quick.centerDistance <= softRadius then
        cheap = cheap - 4300
      elseif quick.centerDistance <= arenaRadius then
        cheap = cheap - 2500
      else
        cheap = cheap + 1800 + endpointDepth * endpointDepth * 900
        if alreadyOutside and quick.centerDistance > currentCenterDistance then
          cheap = cheap + (quick.centerDistance - currentCenterDistance) * 3200
        elseif quick.centerDistance < currentCenterDistance then
          cheap = cheap - 500
        end
      end

      cheapCandidates[#cheapCandidates + 1] = {
        entry=entry,
        quick=quick,
        cheap=cheap,
        category=quick.centerDistance <= preferredRadius and "preferred"
          or (quick.centerDistance <= arenaRadius and "inside" or "outside")
      }
    end
  end
  table.sort(cheapCandidates, function(a, b) return a.cheap < b.cheap end)

  local shortlist = {}
  local added = {}
  local function addCandidate(index)
    local candidate = cheapCandidates[index]
    if candidate and not added[index] then
      added[index] = true
      shortlist[#shortlist + 1] = candidate
    end
  end

  for index = 1, math.min(4, #cheapCandidates) do
    addCandidate(index)
  end

  local foundCategory = {}
  local foundFirstDirection = {}
  for index, candidate in ipairs(cheapCandidates) do
    if not foundCategory[candidate.category] then
      foundCategory[candidate.category] = true
      addCandidate(index)
    end
    local firstDirection = candidate.entry.firstDirection
    if firstDirection ~= nil and not foundFirstDirection[firstDirection] then
      foundFirstDirection[firstDirection] = true
      addCandidate(index)
    end
    if #shortlist >= 6 then break end
  end

  local bestReentry = nil
  local bestInside = nil
  local bestOutside = nil
  local bestRelaxed = nil

  for _, cheapCandidate in ipairs(shortlist) do
    local entry = cheapCandidate.entry
    local entryPath = buildMageRunCandidatePath(entry)
    local pathRisk, pathLength = getPathRisk(
      pos, entry.pos, hazards, reserveContext, true, entryPath
    )
    if pathRisk then
      local score = evaluateMageRunTile(
        entry.pos, center, hazards, configured, targetPosition,
        pos, reserveContext
      )
      score.playerDistance = pathLength or entry.depth

      local reverseMove = false
      if mageRunDecision.lastDx ~= 0 or mageRunDecision.lastDy ~= 0 then
        local dx = entry.pos.x - pos.x
        local dy = entry.pos.y - pos.y
        reverseMove = (dx * mageRunDecision.lastDx
          + dy * mageRunDecision.lastDy) < 0
      end

      local composite = getMageRunCompositeScore(
        score, currentScore, pathRisk, true,
        minRange, maxRange, preferredRange, arenaRadius, reverseMove
      )

      local outsideDepth = math.max(0, entry.maxCenterDistance - arenaRadius)
      composite = composite + entry.outsideSteps * 190
        + outsideDepth * outsideDepth * 950

      local endpointInside = score.centerDistance <= arenaRadius
      local endpointSafeInside = score.centerDistance <= softRadius
      local endpointPreferred = score.centerDistance <= preferredRadius
      local improvesContact = score.adjacent < currentScore.adjacent
        or score.orthogonalAdjacent < currentScore.orthogonalAdjacent
        or score.nearTwo < currentScore.nearTwo
        or score.nearestHazard > currentScore.nearestHazard
      local routeUsable = score.adjacent <= currentScore.adjacent
        and score.orthogonalAdjacent <= currentScore.orthogonalAdjacent
        and score.openTiles >= 2

      local candidate = {
        pos=copyPosition(entry.pos),
        score=score,
        pathRisk=pathRisk,
        composite=composite,
        path=entryPath,
        reserveEscape=true,
        reentry=endpointInside,
        reentryTarget=endpointInside and copyPosition(entry.pos) or nil,
        escapePhase=endpointInside and "return" or "outside"
      }

      if endpointPreferred then
        candidate.composite = candidate.composite - 9000
        candidate.reason = "emergency re-entry"
        if routeUsable and isBetterMageRunCandidate(candidate, bestReentry) then
          bestReentry = candidate
        elseif isBetterMageRunCandidate(candidate, bestRelaxed) then
          bestRelaxed = candidate
        end
      elseif endpointSafeInside or endpointInside then
        candidate.composite = candidate.composite
          - (endpointSafeInside and 6200 or 3800)
        candidate.reason = "returning inside"
        if routeUsable and isBetterMageRunCandidate(candidate, bestInside) then
          bestInside = candidate
        elseif isBetterMageRunCandidate(candidate, bestRelaxed) then
          bestRelaxed = candidate
        end
      else
        local endpointDepth = score.centerDistance - arenaRadius
        candidate.composite = candidate.composite
          + 3200 + endpointDepth * endpointDepth * 1300
        candidate.reason = "external emergency bypass"

        -- Once outside, do not keep running farther away unless that is the
        -- only way to reduce immediate contact.
        if alreadyOutside and score.centerDistance > currentCenterDistance then
          candidate.composite = candidate.composite
            + (score.centerDistance - currentCenterDistance) * 5500
        elseif score.centerDistance < currentCenterDistance then
          candidate.composite = candidate.composite - 850
        end

        if (routeUsable or improvesContact)
          and isBetterMageRunCandidate(candidate, bestOutside) then
          bestOutside = candidate
        elseif isBetterMageRunCandidate(candidate, bestRelaxed) then
          bestRelaxed = candidate
        end
      end
    end
  end

  local returnCandidate = bestReentry or bestInside
  if returnCandidate and bestOutside
    and returnCandidate.composite > bestOutside.composite + 1800 then
    -- A return path exists, but crossing the pack now would be substantially
    -- more dangerous than extending the bypass by one safe segment.
    return bestOutside
  end
  return returnCandidate or bestOutside or bestRelaxed
end

local function getMageRunOrbitCenter(configured, fallbackCenter, expectedZ)
  local totalX = 0
  local totalY = 0
  local count = 0

  for _, creature in ipairs(configured or {}) do
    local creaturePos = safeCreaturePosition(creature, expectedZ)
    if creaturePos then
      totalX = totalX + creaturePos.x
      totalY = totalY + creaturePos.y
      count = count + 1
    end
  end

  if count == 0 then
    return fallbackCenter
  end

  return {
    x = totalX / count,
    y = totalY / count,
    z = expectedZ
  }
end

-- When no tile is objectively safer, standing still is usually the worst choice
-- for a mage. This fallback keeps a persistent clockwise/counter-clockwise orbit
-- around the pack and only changes direction when that side is blocked or much
-- more dangerous. It evaluates only the eight adjacent tiles, so it stays cheap.
local function chooseMageRunOrbitFallback(pos, center, arenaRadius, hazards, configured,
    minRange, maxRange, currentScore, trapContext, emergency, allowReserve)
  local orbitCenter = getMageRunOrbitCenter(configured, center, pos.z)
  if not orbitCenter then return nil end

  local currentCenterDistance = tileDistance(pos, center)
  local softArenaRadius = getMageRunSoftArenaRadius(arenaRadius)
  local preferredArenaRadius = getMageRunPreferredArenaRadius(arenaRadius)
  local packCenterDistance = tileDistance(orbitCenter, center)

  -- If the pack itself drifts toward the outer ring, orbiting only around the
  -- pack pulls the player to the boundary. Blend the orbit center back toward
  -- the End Lure center, preserving the rotation while keeping it internal.
  if not emergency
    and (currentCenterDistance > preferredArenaRadius
      or packCenterDistance > preferredArenaRadius) then
    local centerPull = currentCenterDistance >= arenaRadius - 1 and 0.55 or 0.35
    orbitCenter = {
      x = orbitCenter.x * (1 - centerPull) + center.x * centerPull,
      y = orbitCenter.y * (1 - centerPull) + center.y * centerPull,
      z = pos.z
    }
  end

  local radialX = pos.x - orbitCenter.x
  local radialY = pos.y - orbitCenter.y
  if math.abs(radialX) < 0.01 and math.abs(radialY) < 0.01 then
    radialX = pos.x - center.x
    radialY = pos.y - center.y
  end
  if math.abs(radialX) < 0.01 and math.abs(radialY) < 0.01 then
    radialX = 0
    radialY = -1
  end

  local radialNorm = math.max(1, math.abs(radialX), math.abs(radialY))
  local edgeX = pos.x - center.x
  local edgeY = pos.y - center.y
  local edgeNorm = math.max(1, math.abs(edgeX), math.abs(edgeY))
  local emergencyRadius = getMageRunEmergencyArenaRadius(arenaRadius)
  local maxAllowed = allowReserve and math.max(emergencyRadius, currentCenterDistance)
    or math.max(softArenaRadius, currentCenterDistance)

  local function bestForDirection(direction, requireProgress)
    local tangentX
    local tangentY
    if direction == 1 then
      -- Screen coordinates have Y growing downwards.
      tangentX = -radialY
      tangentY = radialX
    else
      tangentX = radialY
      tangentY = -radialX
    end
    local tangentNorm = math.max(1, math.abs(tangentX), math.abs(tangentY))
    local best = nil

    for _, offset in ipairs(trapOffsets) do
      local candidatePos = {
        x = pos.x + offset[1],
        y = pos.y + offset[2],
        z = pos.z
      }
      local centerDistance = tileDistance(candidatePos, center)
      local arenaAllowed
      if allowReserve then
        arenaAllowed = centerDistance <= maxAllowed
          and (centerDistance <= emergencyRadius
            or centerDistance < currentCenterDistance)
      elseif currentCenterDistance > softArenaRadius
        or mageRunDecision.centerRecovery then
        -- At or outside the inner boundary, orbit may only move laterally or in.
        arenaAllowed = centerDistance <= currentCenterDistance
      else
        arenaAllowed = centerDistance <= softArenaRadius
      end

      if arenaAllowed and canStepTo(candidatePos) then
        local moveX = offset[1]
        local moveY = offset[2]
        local tangentProgress = (moveX * tangentX + moveY * tangentY) / tangentNorm

        if not requireProgress or tangentProgress > 0.05 then
          local quick = evaluateMageRunImmediate(
            candidatePos, center, hazards, configured, pos, trapContext
          )
          local score = getCheapCandidateScore(
            quick, minRange, maxRange, math.min(maxRange, minRange + 1),
            arenaRadius, emergency
          )

          -- Never prefer walking deeper into contact merely to preserve rotation.
          score = score + math.max(0, quick.adjacent - currentScore.adjacent) * 3200
          score = score + math.max(0,
            quick.orthogonalAdjacent - currentScore.orthogonalAdjacent) * 950
          score = score + math.max(0, quick.nearTwo - currentScore.nearTwo) * 260
          if quick.nearestHazard < currentScore.nearestHazard then
            score = score + (currentScore.nearestHazard - quick.nearestHazard) * 700
          end

          -- Tangential movement is the core of continuous kiting.
          score = score - tangentProgress * 360

          local radialProgress = (moveX * radialX + moveY * radialY) / radialNorm
          if currentScore.nearestConfigured < minRange then
            -- Too close: drift away from the pack while orbiting.
            score = score - radialProgress * 260
          elseif currentScore.nearestConfigured > maxRange then
            -- Too far: curve slightly back toward the pack.
            score = score + radialProgress * 220
          else
            -- Inside the desired band, prefer a clean tangent.
            score = score + math.abs(radialProgress) * 45
          end

          -- Start curving inward before the hard boundary. The outer two
          -- rings are an escape reserve, not the normal orbit track.
          local edgeProgress = (moveX * edgeX + moveY * edgeY) / edgeNorm
          if currentCenterDistance >= preferredArenaRadius then
            local edgeDepth = currentCenterDistance - preferredArenaRadius + 1
            score = score + edgeProgress * edgeDepth
              * (emergency and 150 or 520)

            if centerDistance > currentCenterDistance then
              score = score + edgeDepth * (emergency and 120 or 720)
            elseif centerDistance < currentCenterDistance then
              score = score - edgeDepth * (emergency and 35 or 260)
            end
          elseif centerDistance > currentCenterDistance then
            score = score + (emergency and 8 or 45)
          end

          -- Keep momentum and avoid left-right jitter.
          if mageRunDecision.lastDx ~= 0 or mageRunDecision.lastDy ~= 0 then
            local momentum = moveX * mageRunDecision.lastDx
              + moveY * mageRunDecision.lastDy
            if momentum < 0 then
              score = score + (emergency and 120 or 420)
            elseif momentum > 0 then
              score = score - 75
            end
          end

          if moveX ~= 0 and moveY ~= 0 then
            local diagonalDirection = getDirectionFromOffset(moveX, moveY)
            if isMageRunDiagonalActuallyNeeded(
                pos, diagonalDirection, center, maxAllowed, hazards) then
              score = score + (emergency and 700 or 2600)
            else
              score = score + (emergency and 4200 or 16000)
            end
          end

          score = score - quick.openTiles * 18
          score = score - quick.orthogonalOpen * 14

          local candidate = {
            pos = candidatePos,
            quick = quick,
            score = score,
            direction = direction,
            tangentProgress = tangentProgress
          }
          if not best or candidate.score < best.score then
            best = candidate
          end
        end
      end
    end

    return best
  end

  local currentDirection = mageRunDecision.orbitDirection
  if currentDirection ~= 1 and currentDirection ~= -1 then
    currentDirection = 1
  end

  local primary = bestForDirection(currentDirection, true)
  local opposite = bestForDirection(-currentDirection, true)
  local chosen = nil

  if mageRunDecision.orbitDirection == 0 then
    if primary and opposite then
      chosen = primary.score <= opposite.score and primary or opposite
    else
      chosen = primary or opposite
    end
  elseif now < mageRunDecision.orbitLockedUntil and primary then
    local oppositeClearlySafer = opposite
      and (opposite.quick.adjacent < primary.quick.adjacent
        or opposite.quick.orthogonalAdjacent < primary.quick.orthogonalAdjacent
        or opposite.score + 900 < primary.score)
    chosen = oppositeClearlySafer and opposite or primary
  else
    if primary and opposite then
      chosen = primary.score <= opposite.score + 180 and primary or opposite
    else
      chosen = primary or opposite
    end
  end

  -- A narrow corridor may have no positive tangential step. Still keep moving
  -- through the least-bad legal adjacent tile instead of freezing.
  if not chosen then
    local broadPrimary = bestForDirection(currentDirection, false)
    local broadOpposite = bestForDirection(-currentDirection, false)
    if broadPrimary and broadOpposite then
      chosen = broadPrimary.score <= broadOpposite.score and broadPrimary or broadOpposite
    else
      chosen = broadPrimary or broadOpposite
    end
  end

  if chosen then
    chosen.reserveEscape = allowReserve and true or false
    local decisionHold = getMageRunConfigNumber(
      "lureMageRunDecisionDelay", 650, 200, 1500
    )

    if mageRunDecision.orbitDirection ~= chosen.direction then
      mageRunDecision.orbitDirection = chosen.direction
      mageRunDecision.orbitLockedUntil = now + decisionHold
    elseif now >= mageRunDecision.orbitLockedUntil then
      mageRunDecision.orbitLockedUntil = now + decisionHold
    end
  end

  return chosen
end

local function commitMageRunOrbitDecision(orbit, pos, emergency, preserveUntil)
  if not orbit or not orbit.pos then return nil end

  local decisionHold = getMageRunConfigNumber(
    "lureMageRunDecisionDelay", 650, 200, 1500
  )
  local holdDuration = emergency
    and math.min(decisionHold, 400) or decisionHold
  local preserved = tonumber(preserveUntil)
  local expiresAt = preserved and preserved > now
    and preserved or (now + holdDuration)

  mageRunDecision.origin = copyPosition(pos)
  mageRunDecision.target = copyPosition(orbit.pos)
  if not preserved or preserved <= now then
    mageRunDecision.chosenAt = now
  end
  mageRunDecision.escapeMode = emergency and true or false
  mageRunDecision.orbitMode = true
  mageRunDecision.reserveEscape = orbit.reserveEscape and true or false
  mageRunDecision.escapePhase = mageRunDecision.reserveEscape and "outside" or "inside"
  if mageRunDecision.reserveEscape and mageRunDecision.escapeStartedAt == 0 then
    mageRunDecision.escapeStartedAt = now
  end
  mageRunDecision.reentryTarget = nil
  setMageRunPlannedRoute(pos, {
    getDirectionFromOffset(orbit.pos.x - pos.x, orbit.pos.y - pos.y)
  })
  mageRunDecision.expiresAt = expiresAt
  mageRunDecision.orbitLockedUntil = math.max(
    mageRunDecision.orbitLockedUntil, expiresAt
  )
  mageRunDecision.lastDx = orbit.pos.x - pos.x
  mageRunDecision.lastDy = orbit.pos.y - pos.y
  mageRunDecision.arrivedAt = 0
  mageRunRuntime.reason = orbit.direction == 1
    and "orbiting clockwise" or "orbiting counter-clockwise"
  return copyPosition(orbit.pos)
end

local function clearMageRunDecision()
  mageRunDecision.target = nil
  mageRunDecision.chosenAt = 0
  mageRunDecision.expiresAt = 0
  mageRunDecision.escapeMode = false
  mageRunDecision.orbitMode = false
  mageRunDecision.reserveEscape = false
  mageRunDecision.escapePhase = "inside"
  mageRunDecision.escapeStartedAt = 0
  mageRunDecision.reentryTarget = nil
  clearMageRunPlannedRoute()
end

local function clearMageRunTargetPreserveEscape()
  mageRunDecision.target = nil
  mageRunDecision.chosenAt = 0
  mageRunDecision.expiresAt = 0
  mageRunDecision.orbitMode = false
  mageRunDecision.reentryTarget = nil
  clearMageRunPlannedRoute()
end

local function clearMageRunDirectStep()
  mageRunDirectStepOrigin = nil
  mageRunDirectStepTarget = nil
  mageRunDirectStepAt = 0
  mageRunDirectStepDirection = nil
end

local function stopMageRunClientMovement()
  pcall(function()
    player:stopAutoWalk()
  end)
  if g_game and g_game.stop then
    pcall(function()
      g_game.stop()
    end)
  end
end

local function getMageRunDirectStepTimeout()
  local timeout = 650
  if player and player.getStepDuration then
    local ok, duration = pcall(function()
      return tonumber(player:getStepDuration())
    end)
    if ok and duration and duration > 0 then
      timeout = math.max(500, math.min(1500, duration + 250))
    end
  end
  return timeout
end

local function checkMageRunDirectStepWatchdog(position)
  if not mageRunDirectStepOrigin or mageRunDirectStepAt <= 0 then
    return false
  end

  if not samePosition(position, mageRunDirectStepOrigin) then
    clearMageRunDirectStep()
    return false
  end

  if now - mageRunDirectStepAt < getMageRunDirectStepTimeout() then
    return false
  end

  stopMageRunClientMovement()
  clearMageRunDecision()
  mageRunDecision.lastEvaluationAt = 0
  mageRunRuntime.reason = "step retry"
  mageRunRuntime.updatedAt = now
  lastMageRunMove = 0
  clearMageRunDirectStep()
  return true
end

local function recordMageRunDirectStep(origin, target, direction)
  mageRunDirectStepOrigin = copyPosition(origin)
  mageRunDirectStepTarget = copyPosition(target)
  mageRunDirectStepDirection = direction
  mageRunDirectStepAt = now
end

local function resetMageRunDecisionState()
  clearMageRunDecision()
  clearMageRunDirectStep()
  mageRunDecision.origin = nil
  mageRunDecision.lastEvaluationAt = 0
  mageRunDecision.arrivedAt = 0
  mageRunDecision.lastDx = 0
  mageRunDecision.lastDy = 0
  mageRunDecision.centerKey = nil
  mageRunDecision.escapeMode = false
  mageRunDecision.orbitMode = false
  mageRunDecision.orbitDirection = 0
  mageRunDecision.orbitLockedUntil = 0
  mageRunDecision.centerRecovery = false
  mageRunDecision.reserveEscape = false
  mageRunDecision.escapePhase = "inside"
  mageRunDecision.escapeStartedAt = 0
  mageRunDecision.reentryTarget = nil
  clearMageRunPlannedRoute()
  mageRunLastMoveDiagonal = false
  mageRunDiagonalOpportunity = 0
  mageRunLastDebugAt = 0
  mageRunDebugSignature = nil
  lastMageRunMove = 0
  visibleMonsterCache.key = nil
  visibleMonsterCache.expiresAt = 0
  visibleMonsterCache.hazards = {}
  visibleMonsterCache.configured = {}
  staticTileSafetyCache.expiresAt = 0
  staticTileSafetyCache.values = {}
  mageRunCreaturePositionCache.expiresAt = 0
  mageRunCreaturePositionCache.values = {}
  mageRunFastMobilityCache.expiresAt = 0
  mageRunFastMobilityCache.values = {}

  mageRunRuntime.emergency = false
  mageRunRuntime.pressure = false
  mageRunRuntime.adjacent = 0
  mageRunRuntime.nearTwo = 0
  mageRunRuntime.nearestHazard = 99
  mageRunRuntime.reason = "idle"
  mageRunRuntime.updatedAt = now
  mageRunRuntime.hazards = {}
end

TargetBot.resetMageRunMovement = function()
  resetMageRunDecisionState()
  if TargetBot.stopWalk then
    TargetBot.stopWalk()
  end
  stopMageRunClientMovement()
end

-- Called by the walking layer when a creature has just blocked the selected
-- route. Re-evaluate immediately instead of waiting for the decision hold time.
TargetBot.invalidateMageRunDestination = function()
  clearMageRunDecision()
  clearMageRunDirectStep()
  mageRunDecision.lastEvaluationAt = 0
  mageRunRuntime.reason = "path blocked"
  mageRunRuntime.updatedAt = now
end

TargetBot.isMageRunEmergencyMovement = function()
  return mageRunRuntime.emergency
    and mageRunRuntime.updatedAt + 500 >= now
end

TargetBot.getMageRunMovementState = function()
  return {
    emergency = mageRunRuntime.emergency,
    pressure = mageRunRuntime.pressure,
    adjacent = mageRunRuntime.adjacent,
    nearTwo = mageRunRuntime.nearTwo,
    nearestHazard = mageRunRuntime.nearestHazard,
    reason = mageRunRuntime.reason,
    updatedAt = mageRunRuntime.updatedAt
  }
end

local function markMageRunNoPack()
  clearMageRunDecision()
  clearMageRunDebugPath()
  mageRunDecision.lastEvaluationAt = now
  mageRunDecision.centerRecovery = false
  mageRunRuntime.emergency = false
  mageRunRuntime.pressure = false
  mageRunRuntime.adjacent = 0
  mageRunRuntime.nearTwo = 0
  mageRunRuntime.nearestHazard = 99
  mageRunRuntime.reason = "no pack"
  mageRunRuntime.updatedAt = now
  mageRunRuntime.hazards = {}
end

local function hasMageRunConfiguredPack(snapshot)
  return snapshot and #(snapshot.configured or {}) > 0
end

local function getMageRunStepReason(candidate, currentScore, emergency, minRange, maxRange, arenaRadius)
  local score = candidate.score
  if emergency then return "escaping" end
  if score.centerDistance < currentScore.centerDistance
    and currentScore.centerDistance >= getMageRunPreferredArenaRadius(arenaRadius) then
    return "recovery move"
  end
  if score.nearestConfigured > maxRange then
    return "range bridge"
  end
  if score.nearestConfigured < minRange then
    return "spacing"
  end
  return "kiting"
end

local function getMageRunStepScore(candidate, currentScore, minRange, maxRange,
    preferredRange, arenaRadius, emergency, edgeRecovery, originPos, center, hazards)
  local score = candidate.score
  local total = 0

  total = total + score.adjacent * 6500
  total = total + score.orthogonalAdjacent * 2400
  total = total + score.nearTwo * 520
  total = total + score.nearThree * 110
  total = total + score.sideCount * 90
  total = total + score.oppositePairs * 900
  total = total + (score.trapRisk or 0)

  if score.magicField then
    total = total + (emergency and 900 or 9000)
  end

  if score.openTiles <= 1 then
    total = total + 5000
  elseif score.openTiles == 2 then
    total = total + 1600
  elseif score.openTiles == 3 then
    total = total + 450
  end

  if score.orthogonalOpen <= 1 then
    total = total + 1200
  elseif score.orthogonalOpen == 2 then
    total = total + 320
  end

  if score.packTotal > 0 and score.packVisible == 0 then
    total = total + (emergency and 350 or 1800)
  end
  if not score.targetShootable then
    total = total + (emergency and 160 or 850)
  end

  if score.nearestConfigured < minRange then
    total = total + (minRange - score.nearestConfigured) * 1700
  elseif score.nearestConfigured > maxRange then
    total = total + (score.nearestConfigured - maxRange)
      * (emergency and 450 or 1350) + (emergency and 250 or 1600)
  else
    total = total + math.abs(score.nearestConfigured - preferredRange) * 55
  end

  local preferredArenaRadius = getMageRunPreferredArenaRadius(arenaRadius)
  local centerDrift = score.centerDistance - currentScore.centerDistance
  if score.centerDistance > arenaRadius then
    total = total + 25000 + (score.centerDistance - arenaRadius) * 4500
  elseif score.centerDistance > preferredArenaRadius then
    local edgeDepth = score.centerDistance - preferredArenaRadius
    total = total + edgeDepth * edgeDepth * (emergency and 180 or 950)
  end

  if edgeRecovery or currentScore.centerDistance >= preferredArenaRadius then
    if centerDrift < 0 then
      total = total - math.abs(centerDrift) * (emergency and 800 or 1600)
    elseif centerDrift > 0 then
      total = total + centerDrift * (emergency and 700 or 3600)
    end
  end

  if score.clusterDistance > maxRange then
    total = total + (score.clusterDistance - maxRange) * 380
  end

  total = total - score.openTiles * 85
  total = total - score.orthogonalOpen * 70
  total = total - math.min(score.futureEscapeArea or 0, 20) * 18
  total = total - math.min(score.futureEscapeBranches or 0, 6) * 55

  if mageRunDecision.lastDx ~= 0 or mageRunDecision.lastDy ~= 0 then
    local momentum = candidate.dx * mageRunDecision.lastDx
      + candidate.dy * mageRunDecision.lastDy
    if momentum > 0 then
      total = total - 420
    elseif momentum < 0 then
      total = total + (emergency and 450 or 1500)
    end
  end

  if candidate.dx ~= 0 and candidate.dy ~= 0 then
    local diagonalDirection = getDirectionFromOffset(candidate.dx, candidate.dy)
    local walkLimit = arenaRadius + (emergency and 2 or 0)
    if isMageRunDiagonalActuallyNeeded(
        originPos, diagonalDirection, center or originPos, walkLimit,
        hazards or mageRunRuntime.hazards) then
      total = total + (emergency and 900 or 4200)
    else
      total = total + (emergency and 5200 or 18000)
    end
  end

  candidate.composite = total
  candidate.inRange = score.nearestConfigured <= maxRange
  candidate.bridge = score.nearestConfigured > maxRange
    and score.centerDistance <= arenaRadius
  candidate.recovery = score.centerDistance < currentScore.centerDistance
    or score.openTiles > currentScore.openTiles
    or score.orthogonalOpen > currentScore.orthogonalOpen
  candidate.reason = getMageRunStepReason(
    candidate, currentScore, emergency, minRange, maxRange, arenaRadius
  )
  return total
end

local function isBetterMageRunStep(candidate, best)
  if not candidate then return false end
  if not best then return true end
  if candidate.composite ~= best.composite then
    return candidate.composite < best.composite
  end
  if candidate.score.adjacent ~= best.score.adjacent then
    return candidate.score.adjacent < best.score.adjacent
  end
  if candidate.score.orthogonalAdjacent ~= best.score.orthogonalAdjacent then
    return candidate.score.orthogonalAdjacent < best.score.orthogonalAdjacent
  end
  if candidate.score.centerDistance ~= best.score.centerDistance then
    return candidate.score.centerDistance < best.score.centerDistance
  end
  return candidate.score.openTiles > best.score.openTiles
end

local function isMageRunStepAllowed(score, currentScore, arenaRadius, emergency, edgeRecovery, relaxed)
  if not score then return false end

  local hardArena = emergency and getMageRunEmergencyArenaRadius(arenaRadius)
    or arenaRadius
  if score.centerDistance > hardArena then return false end

  if relaxed then
    if edgeRecovery and not emergency
      and score.centerDistance > currentScore.centerDistance
      and score.openTiles <= currentScore.openTiles then
      return false
    end
    return score.openTiles >= 1
      or score.centerDistance < currentScore.centerDistance
      or emergency
  end

  if edgeRecovery and not emergency
    and score.centerDistance > currentScore.centerDistance then
    return false
  end
  if not emergency
    and score.adjacent > currentScore.adjacent
    and currentScore.adjacent == 0 then
    return false
  end
  if not emergency
    and score.orthogonalAdjacent > currentScore.orthogonalAdjacent
    and currentScore.orthogonalAdjacent == 0 then
    return false
  end
  return true
end

local function buildMageRunStepCandidate(candidatePos, pos, center, hazards,
    configured, targetPosition, currentScore, minRange, maxRange,
    preferredRange, arenaRadius, emergency, edgeRecovery, trapContext, relaxed)
  local score = evaluateMageRunTile(
    candidatePos, center, hazards, configured, targetPosition, pos, trapContext
  )
  if not isMageRunStepAllowed(score, currentScore, arenaRadius, emergency, edgeRecovery, relaxed) then
    return nil
  end

  local candidate = {
    pos = copyPosition(candidatePos),
    score = score,
    dx = candidatePos.x - pos.x,
    dy = candidatePos.y - pos.y,
    reserveEscape = score.centerDistance > arenaRadius,
    relaxed = relaxed and true or false
  }
  getMageRunStepScore(
    candidate, currentScore, minRange, maxRange, preferredRange,
    arenaRadius, emergency, edgeRecovery, pos, center, hazards
  )
  if relaxed then
    candidate.composite = candidate.composite + (emergency and 1800 or 4500)
    candidate.reason = emergency and "forced escape" or "forced step"
  end
  return candidate
end

local function commitMageRunStepDecision(pos, candidate, emergency, decisionDelay, preserveUntil)
  if not candidate or not candidate.pos then return nil end

  local preserved = tonumber(preserveUntil)
  local expiresAt = preserved and preserved > now
    and preserved
    or now + (emergency and math.min(decisionDelay, 400) or decisionDelay)

  mageRunDecision.origin = copyPosition(pos)
  mageRunDecision.target = copyPosition(candidate.pos)
  mageRunDecision.chosenAt = preserved and preserved > now
    and mageRunDecision.chosenAt or now
  mageRunDecision.escapeMode = emergency and true or false
  mageRunDecision.orbitMode = false
  mageRunDecision.reserveEscape = candidate.reserveEscape and true or false
  mageRunDecision.escapePhase = mageRunDecision.reserveEscape and "outside" or "inside"
  mageRunDecision.escapeStartedAt = mageRunDecision.reserveEscape
    and (mageRunDecision.escapeStartedAt > 0 and mageRunDecision.escapeStartedAt or now) or 0
  mageRunDecision.reentryTarget = nil
  setMageRunPlannedRoute(pos, {
    getDirectionFromOffset(candidate.pos.x - pos.x, candidate.pos.y - pos.y)
  })
  mageRunDecision.expiresAt = expiresAt
  mageRunDecision.lastDx = candidate.dx
  mageRunDecision.lastDy = candidate.dy
  mageRunDecision.arrivedAt = 0
  mageRunRuntime.reason = candidate.reason or (emergency and "escaping" or "kiting")
  return copyPosition(candidate.pos)
end

local function chooseMageRunAdjacentStep(pos, center, hazards, configured,
    targetPosition, minRange, maxRange, preferredRange, arenaRadius,
    decisionDelay)
  local trapContext = buildMageRunTrapContext(center, hazards, pos, arenaRadius, true)
  local currentScore = evaluateMageRunTile(
    pos, center, hazards, configured, targetPosition, pos, trapContext
  )
  local emergency = isMageRunEmergency(currentScore, minRange, arenaRadius)
  local approachingPressure = emergency
    or isMageRunApproachingPressure(currentScore, minRange, arenaRadius)
  local edgeRecovery = updateMageRunCenterRecovery(
    currentScore.centerDistance, arenaRadius
  )

  mageRunRuntime.emergency = emergency and true or false
  mageRunRuntime.pressure = approachingPressure and true or false
  mageRunRuntime.adjacent = currentScore.adjacent
  mageRunRuntime.nearTwo = currentScore.nearTwo
  mageRunRuntime.nearestHazard = currentScore.nearestHazard
  mageRunRuntime.updatedAt = now

  local preferredArenaRadius = getMageRunPreferredArenaRadius(arenaRadius)
  local shouldMove = emergency
    or approachingPressure
    or edgeRecovery
    or currentScore.nearestConfigured < preferredRange
    or currentScore.nearestConfigured > maxRange
    or currentScore.centerDistance > preferredArenaRadius
    or currentScore.openTiles <= 4
    or currentScore.orthogonalOpen <= 2
    or currentScore.packVisible < currentScore.packTotal

  if not shouldMove then
    clearMageRunDecision()
    mageRunRuntime.reason = "stable"
    return nil
  end

  local function candidateForOffset(offset, relaxed)
    local candidatePos = {
      x = pos.x + offset[1],
      y = pos.y + offset[2],
      z = pos.z
    }
    if not canStepTo(candidatePos) then return nil end
    if offset[1] ~= 0 and offset[2] ~= 0 then
      local sideA = {x=pos.x + offset[1], y=pos.y, z=pos.z}
      local sideB = {x=pos.x, y=pos.y + offset[2], z=pos.z}
      if not canStepTo(sideA) and not canStepTo(sideB) then
        return nil
      end
    end
    return buildMageRunStepCandidate(
      candidatePos, pos, center, hazards, configured, targetPosition,
      currentScore, minRange, maxRange, preferredRange, arenaRadius,
      emergency, edgeRecovery, trapContext, relaxed
    )
  end

  if mageRunDecision.expiresAt > now
    and (mageRunDecision.lastDx ~= 0 or mageRunDecision.lastDy ~= 0) then
    local held = candidateForOffset({mageRunDecision.lastDx, mageRunDecision.lastDy}, false)
    if held and (not isMageRunHardHoldBreak(currentScore, minRange, arenaRadius)
        or held.score.adjacent < currentScore.adjacent
        or held.score.nearestHazard > currentScore.nearestHazard) then
      held.reason = "decision hold"
      return commitMageRunStepDecision(
        pos, held, emergency, decisionDelay, mageRunDecision.expiresAt
      )
    end
  end

  local bestInRange = nil
  local bestRecovery = nil
  local bestBridge = nil
  local bestAny = nil
  local bestRelaxed = nil

  for _, offset in ipairs(trapOffsets) do
    local candidate = candidateForOffset(offset, false)
    if candidate then
      if isBetterMageRunStep(candidate, bestAny) then
        bestAny = candidate
      end
      if candidate.recovery and isBetterMageRunStep(candidate, bestRecovery) then
        bestRecovery = candidate
      end
      if candidate.inRange and isBetterMageRunStep(candidate, bestInRange) then
        bestInRange = candidate
      elseif candidate.bridge and isBetterMageRunStep(candidate, bestBridge) then
        bestBridge = candidate
      end
    end
  end

  if not bestAny then
    for _, offset in ipairs(trapOffsets) do
      local candidate = candidateForOffset(offset, true)
      if candidate and isBetterMageRunStep(candidate, bestRelaxed) then
        bestRelaxed = candidate
      end
    end
  end

  local chosen = nil
  if emergency then
    chosen = bestAny or bestRelaxed
  elseif edgeRecovery and bestRecovery then
    chosen = bestRecovery
  elseif bestInRange then
    chosen = bestInRange
  elseif bestBridge then
    chosen = bestBridge
  else
    chosen = bestAny or bestRelaxed
  end

  if not chosen then
    clearMageRunDecision()
    mageRunRuntime.reason = emergency and "no legal escape" or "no legal move"
    return nil
  end

  return commitMageRunStepDecision(pos, chosen, emergency, decisionDelay)
end

local function commitMageRunStrategicDecision(pos, candidate, emergency, decisionDelay)
  if not candidate or not candidate.pos then return nil end

  mageRunDecision.origin = copyPosition(pos)
  mageRunDecision.target = copyPosition(candidate.pos)
  mageRunDecision.chosenAt = now
  mageRunDecision.escapeMode = emergency and true or false
  mageRunDecision.orbitMode = false
  mageRunDecision.reserveEscape = candidate.reserveEscape and true or false
  mageRunDecision.escapePhase = candidate.escapePhase
    or (mageRunDecision.reserveEscape and "outside" or "inside")
  if mageRunDecision.reserveEscape and mageRunDecision.escapeStartedAt == 0 then
    mageRunDecision.escapeStartedAt = now
  elseif not mageRunDecision.reserveEscape then
    mageRunDecision.escapeStartedAt = 0
  end
  mageRunDecision.reentryTarget = candidate.reentryTarget
    and copyPosition(candidate.reentryTarget) or nil
  mageRunDecision.expiresAt = now + (mageRunDecision.reserveEscape
    and math.max(1400, decisionDelay * 2)
    or (emergency and math.min(decisionDelay, 500) or decisionDelay))
  mageRunDecision.lastDx = candidate.pos.x - pos.x
  mageRunDecision.lastDy = candidate.pos.y - pos.y
  mageRunDecision.arrivedAt = 0
  setMageRunPlannedRoute(pos, candidate.path or {})
  mageRunRuntime.reason = candidate.reason
    or (mageRunDecision.reserveEscape and "external emergency bypass"
      or (emergency and "escaping" or "kiting"))
  return copyPosition(candidate.pos)
end

local function findMageRunTile(creature, snapshot)
  local center = TargetBot.getMageRunCenter and TargetBot.getMageRunCenter() or player:getPosition()
  if not center then return nil end

  local pos = player:getPosition()
  if pos.z ~= center.z then
    resetMageRunDecisionState()
    return nil
  end

  local centerKey = center.x .. ":" .. center.y .. ":" .. center.z
  if mageRunDecision.centerKey ~= centerKey then
    resetMageRunDecisionState()
    mageRunDecision.centerKey = centerKey
  end

  local hazards, configured = getVisibleMonsters(snapshot)
  mageRunRuntime.hazards = hazards
  if #configured == 0 then
    markMageRunNoPack()
    return nil
  end

  local targetPosition = safeCreaturePosition(creature, pos.z)
  local minRange = getMageRunConfigNumber("lureMageRunMinRange", 3, 1, 6)
  local maxRange = getMageRunConfigNumber("lureMageRunMaxRange", 6, minRange, 8)
  local preferredRange = math.min(maxRange, minRange + 1)
  local arenaRadius = getMageRunConfigNumber("lureMageRunArenaRadius", 5, 3, 15)
  local decisionDelay = getMageRunConfigNumber("lureMageRunDecisionDelay", 650, 200, 1500)

  -- Fast layer: immediate contact/mobility only. No pathfinding, line-of-sight or
  -- corridor flood fill is performed on every 100-ms TargetBot cycle.
  local immediate = evaluateMageRunImmediate(pos, center, hazards, configured, pos)
  local emergency = isImmediateMageRunEmergency(immediate, minRange, arenaRadius)
  local approachingPressure = isMageRunApproachingPressure(immediate, minRange, arenaRadius)
  mageRunRuntime.emergency = emergency and true or false
  mageRunRuntime.pressure = approachingPressure and true or false
  mageRunRuntime.adjacent = immediate.adjacent
  mageRunRuntime.nearTwo = immediate.nearTwo
  mageRunRuntime.nearestHazard = immediate.nearestHazard
  mageRunRuntime.reason = emergency and "danger" or "stable"
  mageRunRuntime.updatedAt = now
  local softArenaRadius = getMageRunSoftArenaRadius(arenaRadius)
  local preferredArenaRadius = getMageRunPreferredArenaRadius(arenaRadius)
  local edgeRecovery = updateMageRunCenterRecovery(
    immediate.centerDistance, arenaRadius
  )
  local hardHoldBreak = isMageRunHardHoldBreak(
    immediate, minRange, arenaRadius
  )

  local reserveActive = mageRunDecision.reserveEscape
    or immediate.centerDistance > arenaRadius
  if reserveActive
    and immediate.centerDistance <= preferredArenaRadius
    and not emergency then
    mageRunDecision.reserveEscape = false
    mageRunDecision.escapePhase = "inside"
    mageRunDecision.escapeStartedAt = 0
    mageRunDecision.reentryTarget = nil
    reserveActive = false
  end

  local arrivedDecision = false
  if mageRunDecision.target and samePosition(pos, mageRunDecision.target) then
    mageRunDecision.arrivedAt = now
    arrivedDecision = true
    if mageRunDecision.reserveEscape then
      -- Reaching an external waypoint is not a place to wait. Re-plan
      -- immediately so the next destination bends back into the arena.
      clearMageRunTargetPreserveEscape()
    else
      mageRunDecision.target = nil
      clearMageRunPlannedRoute()
    end
  end

  -- Decision Hold must survive an adjacent one-SQM step. External escape
  -- waypoints are the exception: they always trigger immediate re-entry work.
  if arrivedDecision and mageRunDecision.reserveEscape then
    mageRunRuntime.reason = "planning re-entry"
  elseif arrivedDecision and now < mageRunDecision.expiresAt and not hardHoldBreak then
    mageRunRuntime.reason = "decision hold"
    return nil
  elseif arrivedDecision then
    clearMageRunDecision()
  end

  if mageRunDecision.target then
    local heldImmediate = evaluateMageRunImmediate(
      mageRunDecision.target, center, hazards, configured, pos
    )
    local holdActive = now < mageRunDecision.expiresAt
    local heldLimit = mageRunDecision.reserveEscape
      and getMageRunEmergencyArenaRadius(arenaRadius)
      or math.max(softArenaRadius, immediate.centerDistance)
    local _, plannedStep = getMageRunPlannedStep(pos)
    local plannedImmediate = plannedStep and evaluateMageRunImmediate(
      plannedStep, center, hazards, configured, pos
    ) or nil
    local plannedUnsafe = plannedStep and (
      not canStepTo(plannedStep)
      or plannedImmediate.centerDistance > heldLimit
      or plannedImmediate.adjacent > immediate.adjacent
      or plannedImmediate.orthogonalAdjacent > immediate.orthogonalAdjacent
      or (plannedImmediate.openTiles <= 1
        and plannedImmediate.adjacent >= immediate.adjacent)
      or (plannedImmediate.futureEscapeBranches
        and plannedImmediate.futureEscapeBranches <= 1
        and plannedImmediate.nearTwo >= immediate.nearTwo)
      or (plannedImmediate.nearestHazard < immediate.nearestHazard
        and plannedImmediate.nearestHazard <= 1)
      or (hasMageRunMagicField(plannedStep)
        and not emergency and not approachingPressure)
    )
    local heldUnsafe = not canStepTo(mageRunDecision.target)
      or plannedUnsafe
      or (hasMageRunMagicField(mageRunDecision.target)
        and not emergency and not approachingPressure)
      or heldImmediate.centerDistance > heldLimit
      or heldImmediate.adjacent > immediate.adjacent
      or heldImmediate.orthogonalAdjacent > immediate.orthogonalAdjacent
      or (heldImmediate.openTiles <= 1
        and not (heldImmediate.adjacent < immediate.adjacent
          or heldImmediate.nearestHazard > immediate.nearestHazard))
      or (heldImmediate.futureEscapeBranches
        and heldImmediate.futureEscapeBranches <= 1
        and heldImmediate.adjacent >= immediate.adjacent)
      or heldImmediate.nearestConfigured < math.max(1, minRange - 1)
      or (not holdActive and edgeRecovery and not emergency
        and heldImmediate.centerDistance > immediate.centerDistance)

    local heldImprovesEmergency = heldImmediate.adjacent < immediate.adjacent
      or heldImmediate.orthogonalAdjacent < immediate.orthogonalAdjacent
      or heldImmediate.nearestHazard > immediate.nearestHazard
      or heldImmediate.openTiles > immediate.openTiles

    local routeActive = mageRunDecision.route
      and #mageRunDecision.route > 0
    if (holdActive or (mageRunDecision.reserveEscape and routeActive))
      and not heldUnsafe
      and (not hardHoldBreak
        or mageRunDecision.escapeMode
        or mageRunDecision.reserveEscape
        or heldImprovesEmergency) then
      if mageRunDecision.orbitMode then
        mageRunRuntime.reason = mageRunDecision.orbitDirection == 1
          and "orbiting clockwise" or "orbiting counter-clockwise"
      else
        mageRunRuntime.reason = mageRunDecision.reserveEscape
          and (mageRunDecision.escapePhase == "return"
            and "returning inside" or "external emergency bypass")
          or (hardHoldBreak and "escaping" or "decision hold")
      end
      return copyPosition(mageRunDecision.target)
    end

    if heldUnsafe then clearMageRunDecision() end
  end

  -- Strategic work is adaptive. Approaching pressure gets a much shorter
  -- interval even before it reaches the full emergency threshold.
  reserveActive = mageRunDecision.reserveEscape
    or immediate.centerDistance > arenaRadius
  local evaluationDelay = reserveActive and 260
    or (emergency and 320 or (approachingPressure and 480 or 850))
  if now - mageRunDecision.lastEvaluationAt < evaluationDelay then
    if mageRunDecision.target and canStepTo(mageRunDecision.target) then
      if mageRunDecision.orbitMode then
        mageRunRuntime.reason = mageRunDecision.orbitDirection == 1
          and "orbiting clockwise" or "orbiting counter-clockwise"
      else
        mageRunRuntime.reason = mageRunDecision.escapeMode and "escaping" or "moving"
      end
      return copyPosition(mageRunDecision.target)
    end

    -- Never spend the waiting window standing still while the pack is closing.
    -- The orbit fallback is cheap and uses only adjacent tiles.
    if approachingPressure and not reserveActive then
      local orbit = chooseMageRunOrbitFallback(
        pos, center, arenaRadius, hazards, configured,
        minRange, maxRange, immediate, nil, emergency, false
      )
      if orbit then
        return commitMageRunOrbitDecision(orbit, pos, emergency)
      end
    end

    mageRunRuntime.reason = emergency and "recalculating escape" or "holding"
    return nil
  end
  mageRunDecision.lastEvaluationAt = now

  if not emergency and not approachingPressure and not reserveActive
    and mageRunDecision.arrivedAt > 0
    and (now < mageRunDecision.expiresAt
      or now - mageRunDecision.arrivedAt < 180) then
    mageRunRuntime.reason = now < mageRunDecision.expiresAt
      and "decision hold" or "holding after step"
    return nil
  end

  -- Internal planning must evaluate the arena as a closed boundary. The
  -- external allowance is evaluated separately only after no safe inner route
  -- exists. While already outside, keep the larger context for re-entry.
  local planningEmergency = reserveActive
  local trapContext = buildMageRunTrapContext(
    center, hazards, pos, arenaRadius, planningEmergency
  )
  local currentScore = evaluateMageRunTile(pos, center, hazards, configured, targetPosition, pos, trapContext)
  emergency = isMageRunEmergency(currentScore, minRange, arenaRadius)
  approachingPressure = emergency
    or isMageRunApproachingPressure(currentScore, minRange, arenaRadius)
  mageRunRuntime.emergency = emergency and true or false
  mageRunRuntime.pressure = approachingPressure and true or false
  mageRunRuntime.adjacent = currentScore.adjacent
  mageRunRuntime.nearTwo = currentScore.nearTwo
  mageRunRuntime.nearestHazard = currentScore.nearestHazard
  mageRunRuntime.updatedAt = now

  reserveActive = mageRunDecision.reserveEscape
    or currentScore.centerDistance > arenaRadius
  if reserveActive then
    local reserveCandidate = chooseMageRunReserveRoute(
      pos, center, arenaRadius, hazards, configured, targetPosition,
      currentScore, minRange, maxRange, preferredRange
    )
    if reserveCandidate then
      return commitMageRunStrategicDecision(
        pos, reserveCandidate, true, decisionDelay
      )
    end

    -- Do not discard the external state simply because a single scan failed.
    -- The next fast tick may reveal the re-entry corridor after the pack moves.
    mageRunRuntime.emergency = true
    mageRunRuntime.pressure = true
    mageRunRuntime.reason = "searching re-entry"
    return nil
  end

  local currentComposite = getMageRunCompositeScore(
    currentScore, currentScore, 0, emergency,
    minRange, maxRange, preferredRange, arenaRadius, false
  )
  local best = {
    pos = copyPosition(pos), score = currentScore,
    composite = currentComposite, pathRisk = 0
  }
  local bestMoving = nil
  local forcedEmergencyMove = false
  local forcedRangeBridge = false
  local forcedRecoveryMove = false
  local includeWide = emergency
    or approachingPressure
    or currentScore.openTiles <= 4
    or currentScore.nearestConfigured < minRange
    or currentScore.centerDistance > preferredArenaRadius
    or currentScore.packVisible < currentScore.packTotal
    or currentScore.futureEscapeArea <= 10
    or currentScore.futureEscapeBranches <= 2

  -- Stage 1: score all reachable candidates using only cheap local geometry.
  local cheapCandidates = {}
  for _, entry in ipairs(collectMageRunCandidates(
      pos, center, arenaRadius, includeWide, emergency, false, edgeRecovery)) do
    local candidatePos = entry.pos
    if not samePosition(candidatePos, pos) then
      local quick = evaluateMageRunCheap(
        candidatePos, center, hazards, configured, pos
      )
      quick.playerDistance = entry.depth
      cheapCandidates[#cheapCandidates + 1] = {
        pos = copyPosition(candidatePos),
        entry = entry,
        depth = entry.depth,
        quick = quick,
        cheap = getCheapCandidateScore(
          quick, minRange, maxRange, preferredRange, arenaRadius, emergency
        ) + ((entry.diagonalCount or 0) * (emergency and 850 or 4200))
      }
    end
  end
  table.sort(cheapCandidates, function(a, b) return a.cheap < b.cheap end)

  -- Stage 2: expensive path/LOS/corridor analysis only for the best shortlist.
  local shortlist = emergency and 3 or 2
  local maxStrategicCandidates = emergency and 4 or 3
  local evaluatedCandidates = {}
  local strategicShortlist = {}
  local addedCheapCandidate = {}
  local function addCheapCandidate(index)
    if #strategicShortlist >= maxStrategicCandidates then return end
    local candidate = cheapCandidates[index]
    if candidate and not addedCheapCandidate[index] then
      addedCheapCandidate[index] = true
      strategicShortlist[#strategicShortlist + 1] = candidate
    end
  end

  for index = 1, math.min(shortlist, #cheapCandidates) do
    addCheapCandidate(index)
  end
  for index, candidate in ipairs(cheapCandidates) do
    if candidate.quick.nearestConfigured <= maxRange then
      addCheapCandidate(index)
      break
    end
  end
  for index, candidate in ipairs(cheapCandidates) do
    if candidate.quick.nearestConfigured > maxRange
      and candidate.quick.centerDistance <= arenaRadius then
      addCheapCandidate(index)
      break
    end
  end
  for index, candidate in ipairs(cheapCandidates) do
    if candidate.quick.centerDistance < currentScore.centerDistance
      and candidate.quick.centerDistance <= arenaRadius then
      addCheapCandidate(index)
      break
    end
  end
  for index, candidate in ipairs(cheapCandidates) do
    if candidate.quick.centerDistance <= arenaRadius
      and (candidate.quick.openTiles > currentScore.openTiles
        or candidate.quick.orthogonalOpen > currentScore.orthogonalOpen) then
      addCheapCandidate(index)
      break
    end
  end

  for _, cheapCandidate in ipairs(strategicShortlist) do
    local candidatePos = cheapCandidate.pos
    local candidatePath = buildMageRunCandidatePath(cheapCandidate.entry)
    local pathRisk, pathLength = getPathRisk(
      pos, candidatePos, hazards, trapContext, emergency, candidatePath
    )
    if pathRisk then
      local score = evaluateMageRunTile(candidatePos, center, hazards, configured, targetPosition, pos, trapContext)
      score.playerDistance = pathLength or score.playerDistance
      local dx = candidatePos.x - pos.x
      local dy = candidatePos.y - pos.y
      local reverseMove = mageRunDecision.lastDx ~= 0 or mageRunDecision.lastDy ~= 0
      if reverseMove then
        reverseMove = (dx * mageRunDecision.lastDx + dy * mageRunDecision.lastDy) < 0
      end
      if mageRunDecision.origin and samePosition(candidatePos, mageRunDecision.origin) then
        reverseMove = true
      end

      local composite = getMageRunCompositeScore(
        score, currentScore, pathRisk, emergency,
        minRange, maxRange, preferredRange, arenaRadius, reverseMove
      )
      if edgeRecovery then
        local inwardGain = currentScore.centerDistance - score.centerDistance
        if inwardGain > 0 then
          composite = composite - inwardGain * (emergency and 700 or 950)
        elseif inwardGain < 0 then
          composite = composite + math.abs(inwardGain) * 5000
        else
          composite = composite + (emergency and 40 or 180)
        end
      end

      local candidate = {
        pos = copyPosition(candidatePos),
        score = score,
        pathRisk = pathRisk,
        composite = composite,
        path = candidatePath
      }
      evaluatedCandidates[#evaluatedCandidates + 1] = candidate
      if isBetterMageRunCandidate(candidate, bestMoving) then bestMoving = candidate end
    end
  end

  local bestInRange = nil
  local bestRangeBridge = nil
  local bestAnyMoving = nil
  local bestRecovery = nil
  local hasViableInternalEscape = false
  local needsRecovery = edgeRecovery
    or currentScore.openTiles <= 4
    or currentScore.orthogonalOpen <= 2
    or currentScore.futureEscapeArea <= 10
    or currentScore.futureEscapeBranches <= 1
  for _, candidate in ipairs(evaluatedCandidates) do
    if isViableMageRunInternalEscape(candidate, currentScore, arenaRadius) then
      hasViableInternalEscape = true
    end
    if isBetterMageRunCandidate(candidate, bestAnyMoving) then
      bestAnyMoving = candidate
    end
    if needsRecovery
      and isMageRunRecoveryCandidate(
        candidate, currentScore, arenaRadius, edgeRecovery
      ) then
      if isBetterMageRunCandidate(candidate, bestRecovery) then
        bestRecovery = candidate
      end
    end
    if isMageRunInRangeOption(candidate, currentScore, minRange, maxRange) then
      if isBetterMageRunCandidate(candidate, bestInRange) then
        bestInRange = candidate
      end
    elseif isMageRunRangeBridge(candidate, maxRange, arenaRadius) then
      if isBetterMageRunCandidate(candidate, bestRangeBridge) then
        bestRangeBridge = candidate
      end
    end
  end

  if emergency and not hasViableInternalEscape then
    local reserveCandidate = chooseMageRunReserveRoute(
      pos, center, arenaRadius, hazards, configured, targetPosition,
      currentScore, minRange, maxRange, preferredRange
    )
    if reserveCandidate then
      return commitMageRunStrategicDecision(
        pos, reserveCandidate, true, decisionDelay
      )
    end
  end

  if bestRecovery
    and (not bestInRange
      or not isMageRunRecoveryCandidate(
        bestInRange, currentScore, arenaRadius, edgeRecovery
      )
      or isBetterMageRunCandidate(bestRecovery, bestInRange)) then
    best = bestRecovery
    forcedRecoveryMove = true
    forcedRangeBridge = isMageRunRangeBridge(bestRecovery, maxRange, arenaRadius)
  elseif bestInRange then
    best = bestInRange
  elseif bestRangeBridge then
    best = bestRangeBridge
    forcedRangeBridge = true
  elseif bestAnyMoving and isBetterMageRunCandidate(bestAnyMoving, best) then
    best = bestAnyMoving
  end

  if emergency and bestMoving and (not best or samePosition(best.pos, pos)) then
    local reducesContact = bestMoving.score.adjacent < currentScore.adjacent
      or bestMoving.score.orthogonalAdjacent < currentScore.orthogonalAdjacent
      or bestMoving.score.nearestHazard > currentScore.nearestHazard
      or bestMoving.score.nearestConfigured > currentScore.nearestConfigured
    local improvesEscape = bestMoving.score.futureEscapeBranches > currentScore.futureEscapeBranches
      or bestMoving.score.futureEscapeArea > currentScore.futureEscapeArea + 2
      or bestMoving.score.openTiles > currentScore.openTiles
      or bestMoving.score.trapRisk + 250 < currentScore.trapRisk
    local acceptableFallback = bestMoving.score.adjacent <= currentScore.adjacent
      and bestMoving.score.orthogonalAdjacent <= currentScore.orthogonalAdjacent
      and bestMoving.score.futureEscapeBranches >= math.max(1, currentScore.futureEscapeBranches - 1)
      and bestMoving.score.futureEscapeArea >= math.max(3, currentScore.futureEscapeArea - 3)
      and bestMoving.score.trapRisk <= currentScore.trapRisk + 1400
    if reducesContact or improvesEscape or acceptableFallback then
      best = bestMoving
      forcedEmergencyMove = true
    end
  end

  if not best or samePosition(best.pos, pos) then
    local orbit = chooseMageRunOrbitFallback(
      pos, center, arenaRadius, hazards, configured,
      minRange, maxRange, currentScore, trapContext, emergency, false
    )
    if orbit then
      return commitMageRunOrbitDecision(orbit, pos, emergency)
    end

    -- Only after every inner/lateral option failed may a real emergency use the
    -- reserve ring. Even then it cannot exceed Arena radius + 2.
    if emergency then
      local reserveOrbit = chooseMageRunOrbitFallback(
        pos, center, arenaRadius, hazards, configured,
        minRange, maxRange, currentScore, trapContext, true, true
      )
      if reserveOrbit then
        local quick = reserveOrbit.quick
        local improvesContact = quick
          and (quick.adjacent < currentScore.adjacent
            or quick.orthogonalAdjacent < currentScore.orthogonalAdjacent
            or quick.nearTwo < currentScore.nearTwo
            or quick.nearestHazard > currentScore.nearestHazard)
        if improvesContact then
          return commitMageRunOrbitDecision(reserveOrbit, pos, true)
        end
      end
    end

    clearMageRunDecision()
    mageRunRuntime.reason = emergency and "no legal escape" or "blocked hold"
    return nil
  end

  local improvement = currentComposite - best.composite
  local currentUnsafe = emergency
    or needsRecovery
    or currentScore.nearestConfigured > maxRange
    or currentScore.packVisible < currentScore.packTotal
    or currentScore.centerDistance > preferredArenaRadius
    or currentScore.openTiles <= 3
    or currentScore.trapRisk >= 1200
    or currentScore.futureEscapeArea <= 10
    or currentScore.futureEscapeBranches <= 1
  local safetyImproved = best.score.adjacent < currentScore.adjacent
    or best.score.orthogonalAdjacent < currentScore.orthogonalAdjacent
    or best.score.nearTwo < currentScore.nearTwo
    or best.score.packVisible > currentScore.packVisible
    or best.score.openTiles > currentScore.openTiles
    or best.score.orthogonalOpen > currentScore.orthogonalOpen
    or best.score.centerDistance < currentScore.centerDistance
    or best.score.trapRisk + 250 < currentScore.trapRisk
    or best.score.futureEscapeArea > currentScore.futureEscapeArea + 3
    or best.score.futureEscapeBranches > currentScore.futureEscapeBranches
  local rangeBridgeProgress = forcedRangeBridge
    and best.score.centerDistance <= arenaRadius
    and (best.score.centerDistance < currentScore.centerDistance
      or best.score.nearestConfigured < currentScore.nearestConfigured
      or (currentScore.nearestConfigured < minRange
        and best.score.nearestConfigured > currentScore.nearestConfigured)
      or best.score.openTiles > currentScore.openTiles
      or best.score.futureEscapeArea > currentScore.futureEscapeArea + 2)

  if not currentUnsafe and improvement < 40 then
    if approachingPressure then
      local orbit = chooseMageRunOrbitFallback(
        pos, center, arenaRadius, hazards, configured,
        minRange, maxRange, currentScore, trapContext, false, false
      )
      if orbit then
        return commitMageRunOrbitDecision(orbit, pos, false)
      end
    end

    clearMageRunDecision()
    mageRunRuntime.reason = "safe hold"
    return nil
  end
  if currentUnsafe
    and improvement < 6
    and not safetyImproved
    and not forcedEmergencyMove
    and not forcedRecoveryMove
    and not rangeBridgeProgress then
    local orbit = chooseMageRunOrbitFallback(
      pos, center, arenaRadius, hazards, configured,
      minRange, maxRange, currentScore, trapContext, emergency, false
    )
    if orbit then
      return commitMageRunOrbitDecision(orbit, pos, emergency)
    end

    clearMageRunDecision()
    mageRunRuntime.reason = "no legal move"
    return nil
  end

  best.reason = forcedRecoveryMove
    and "recovery move"
    or (forcedRangeBridge and "range bridge"
      or (emergency and "escaping" or "kiting"))
  best.reserveEscape = false
  best.escapePhase = "inside"
  return commitMageRunStrategicDecision(
    pos, best, emergency, decisionDelay
  )
end

local function mageRunWalk(creature, snapshot)
  local currentPos = player:getPosition()
  local watchdogRetry = checkMageRunDirectStepWatchdog(currentPos)

  local moveInterval = mageRunRuntime.emergency and 40
    or (mageRunRuntime.pressure and 55 or 70)
  if now - lastMageRunMove < moveInterval then return false end

  local targetTile = findMageRunTile(creature, snapshot)
  if not targetTile then
    -- A temporary analysis hold must not cancel a previously issued movement.
    -- Hard blocked/no-escape states still clear the destination.
    local reason = mageRunRuntime.reason
    local temporaryHold = reason == "holding"
      or reason == "holding after step"
      or reason == "decision hold"
      or reason == "recalculating escape"
      or reason == "planning re-entry"
      or reason == "searching re-entry"
    local pressureFallback = mageRunRuntime.pressure
      and (reason == "no legal escape"
        or reason == "no legal move"
        or reason == "blocked hold")

    -- Never actively freeze while the pack is closing. Keep the last legal
    -- movement alive until the next fast cycle finds a least-bad route.
    if not temporaryHold and not pressureFallback and TargetBot.stopWalk then
      TargetBot.stopWalk()
    end
    return false
  end

  local center = TargetBot.getMageRunCenter and TargetBot.getMageRunCenter() or player:getPosition()
  local arenaRadius = getMageRunConfigNumber("lureMageRunArenaRadius", 5, 3, 15)
  local currentCenterDistance = tileDistance(currentPos, center)
  local normalLimit = getMageRunSoftArenaRadius(arenaRadius)
  local walkLimit = math.max(normalLimit, currentCenterDistance)
  if mageRunDecision.reserveEscape then
    walkLimit = math.max(
      walkLimit, getMageRunEmergencyArenaRadius(arenaRadius)
    )
  end

  local walkParams = {
    ignoreNonPathable = false,
    precision = 0,
    maxDistanceFrom = {center, walkLimit}
  }

  local pathMaxDistance = math.max(
    1, math.min(12, tileDistance(currentPos, targetTile) + 4)
  )
  local path = nil
  local direction = nil
  local directionIsDiagonal = false
  local hadPlannedRoute = mageRunDecision.route
    and #mageRunDecision.route > 0
  local plannedDirection, plannedStep = getMageRunPlannedStep(currentPos)

  if plannedDirection and plannedStep then
    if tileDistance(plannedStep, center) > walkLimit
      or not canStepTo(plannedStep) then
      TargetBot.invalidateMageRunDestination()
      return false
    end
    direction = plannedDirection
    directionIsDiagonal = isDiagonalDirection(direction)
    path = {direction}
  elseif hadPlannedRoute then
    TargetBot.invalidateMageRunDestination()
    return false
  else
    path = getPath(currentPos, targetTile, pathMaxDistance, walkParams)
    if not path or not path[1] then
      TargetBot.invalidateMageRunDestination()
      return false
    end

    direction, directionIsDiagonal = getMageRunFirstPathDirection(
      currentPos, targetTile, path, pathMaxDistance, walkParams
    )
    if not direction then
      TargetBot.invalidateMageRunDestination()
      return false
    end
  end
  local stepOffset = directionOffsets[direction]
  if not stepOffset then
    TargetBot.invalidateMageRunDestination()
    return false
  end
  local stepTarget = {
    x = currentPos.x + stepOffset[1],
    y = currentPos.y + stepOffset[2],
    z = currentPos.z
  }

  if directionIsDiagonal then
    local orthogonalDirection, orthogonalStep = chooseMageRunOrthogonalSplit(
      currentPos, direction, center, walkLimit, mageRunRuntime.hazards
    )
    if orthogonalDirection and orthogonalStep then
      direction = orthogonalDirection
      directionIsDiagonal = false
      stepTarget = orthogonalStep
      stepOffset = directionOffsets[direction]
      path = {direction}
    elseif not isMageRunDiagonalActuallyNeeded(
        currentPos, direction, center, walkLimit, mageRunRuntime.hazards) then
      TargetBot.invalidateMageRunDestination()
      return false
    end
  end

  if not canStepTo(stepTarget) then
    TargetBot.invalidateMageRunDestination()
    return false
  end

  -- Last guard before sending the walk command. This catches the common trap
  -- case where the route is technically walkable but the next tile has only one
  -- straight exit and the pack is already closing.
  local stepImmediate = evaluateMageRunImmediate(
    stepTarget, center, mageRunRuntime.hazards, mageRunRuntime.hazards, currentPos
  )
  local stepImprovesContact = stepImmediate.adjacent < mageRunRuntime.adjacent
    or stepImmediate.nearestHazard > mageRunRuntime.nearestHazard
  local stepEntersPocket = stepImmediate.openTiles <= 1
    and stepImmediate.nearTwo >= mageRunRuntime.nearTwo
    and not stepImprovesContact
  if stepEntersPocket then
    TargetBot.invalidateMageRunDestination()
    return false
  end

  showMageRunDebugPath(
    currentPos, targetTile, mageRunRuntime.reason,
    pathMaxDistance, walkParams, direction
  )

  if TargetBot.stopWalk then
    TargetBot.stopWalk()
  end

  if player:isWalking() then
    if watchdogRetry then
      stopMageRunClientMovement()
    elseif mageRunDirectStepOrigin
      and samePosition(currentPos, mageRunDirectStepOrigin)
      and now - mageRunDirectStepAt >= getMageRunDirectStepTimeout() then
      stopMageRunClientMovement()
    else
      return true
    end
  end

  lastMageRunMove = now
  walk(direction)
  mageRunLastMoveDiagonal = directionIsDiagonal and true or false
  recordMageRunDirectStep(currentPos, stepTarget, direction)
  return true
end

TargetBot.Creature.mageRunTick = function(creature, snapshot)
  if not (TargetBot.isMageRunActive and TargetBot.isMageRunActive()) then
    return false
  end

  if CaveBot
    and CaveBot.isLureIgnoreExitAllowed
    and CaveBot.isLureIgnoreExitAllowed() then
    clearMageRunDecision()
    clearMageRunDirectStep()
    if TargetBot.stopWalk then
      TargetBot.stopWalk()
    end
    stopMageRunClientMovement()
    if TargetBot.allowCaveBot then
      TargetBot.allowCaveBot(650)
    end
    mageRunRuntime.reason = "ignore remaining"
    mageRunRuntime.updatedAt = now
    return false
  end

  snapshot = snapshot or (TargetBot.getMageRunSnapshot
    and TargetBot.getMageRunSnapshot(900) or nil)
  if snapshot and not hasMageRunConfiguredPack(snapshot) then
    markMageRunNoPack()
    if TargetBot.stopWalk then
      TargetBot.stopWalk()
    end
    return false
  end

  if TargetBot.disallowCaveBot then
    TargetBot.disallowCaveBot()
  end
  anchorPosition = nil
  return mageRunWalk(creature, snapshot)
end


-- Fast movement is intentionally outside target.lua's 100-ms attack macro.
-- Most ticks perform only immediate local checks; the strategic evaluator keeps
-- its own adaptive delay inside findMageRunTile.
if not TargetBot._mageRunMovementMacro then
  TargetBot._mageRunMovementMacro = macro(150, function()
    if not TargetBot.isOn or not TargetBot.isOn() then return end
    if not (TargetBot.isMageRunActive and TargetBot.isMageRunActive()) then return end
    if isInPz() then return end

    local snapshot = TargetBot.getMageRunSnapshot
      and TargetBot.getMageRunSnapshot(900) or nil
    local selected = snapshot and snapshot.selected or nil
    local creature = selected and selected.creature or nil

    if snapshot and not hasMageRunConfiguredPack(snapshot) then
      markMageRunNoPack()
      if TargetBot.stopWalk then
        TargetBot.stopWalk()
      end
      return
    end

    TargetBot.Creature.mageRunTick(creature, snapshot)
    if TargetBot.walk then
      TargetBot.walk(true)
    end
  end)
end

local function avoidWaveAttack(creature)
  local cpos = creature:getPosition()
  local pos = player:getPosition()
  if cpos.z ~= pos.z then return false end

  local diffx = cpos.x - pos.x
  local diffy = cpos.y - pos.y
  local distance = math.max(math.abs(diffx), math.abs(diffy))
  if distance < 1 or distance > 4 then return false end

  local candidates = {}
  if diffx == 0 then
    candidates = {
      {x=pos.x+1, y=pos.y, z=pos.z},
      {x=pos.x-1, y=pos.y, z=pos.z},
      {x=pos.x+1, y=pos.y + (diffy > 0 and -1 or 1), z=pos.z},
      {x=pos.x-1, y=pos.y + (diffy > 0 and -1 or 1), z=pos.z}
    }
  elseif diffy == 0 then
    candidates = {
      {x=pos.x, y=pos.y+1, z=pos.z},
      {x=pos.x, y=pos.y-1, z=pos.z},
      {x=pos.x + (diffx > 0 and -1 or 1), y=pos.y+1, z=pos.z},
      {x=pos.x + (diffx > 0 and -1 or 1), y=pos.y-1, z=pos.z}
    }
  else
    return false
  end

  for _, candidate in ipairs(candidates) do
    if canStepTo(candidate) and not hasMageRunMagicField(candidate) then
      TargetBot.walkTo(candidate, 2, {ignoreNonPathable=true, precision=0})
      return true
    end
  end

  return false
end

TargetBot.Creature.attack = function(params, targets, isLooting) -- params {config, creature, danger, priority}
  if player:isWalking() then
    lastWalk = now
  end

  local config = params.config
  local creature = params.creature
  
  if g_game.getAttackingCreature() ~= creature then
    g_game.attack(creature)
  end

  if not isLooting then -- walk only when not looting
    TargetBot.Creature.walk(creature, config, targets)
  end

  -- attacks
  local mana = player:getMana()
  if config.useGroupAttack and config.groupAttackSpell:len() > 1 and mana > config.minManaGroup then
    local creatures = g_map.getSpectatorsInRange(player:getPosition(), false, config.groupAttackRadius, config.groupAttackRadius)
    local playersAround = false
    local monsters = 0
    for _, creature in ipairs(creatures) do
      if not creature:isLocalPlayer() and creature:isPlayer() and (not config.groupAttackIgnoreParty or creature:getShield() <= 2) then
        playersAround = true
      elseif creature:isMonster() then
        monsters = monsters + 1
      end
    end
    if monsters >= config.groupAttackTargets and (not playersAround or config.groupAttackIgnorePlayers) then
      if TargetBot.sayAttackSpell(config.groupAttackSpell, config.groupAttackDelay) then
        return
      end
    end
  end

  if config.useGroupAttackRune and config.groupAttackRune > 100 then
    local creatures = g_map.getSpectatorsInRange(creature:getPosition(), false, config.groupRuneAttackRadius, config.groupRuneAttackRadius)
    local playersAround = false
    local monsters = 0
    for _, creature in ipairs(creatures) do
      if not creature:isLocalPlayer() and creature:isPlayer() and (not config.groupAttackIgnoreParty or creature:getShield() <= 2) then
        playersAround = true
      elseif creature:isMonster() then
        monsters = monsters + 1
      end
    end
    if monsters >= config.groupRuneAttackTargets and (not playersAround or config.groupAttackIgnorePlayers) then
      if TargetBot.useAttackItem(config.groupAttackRune, 0, creature, config.groupRuneAttackDelay) then
        return
      end
    end
  end
  if config.useSpellAttack and config.attackSpell:len() > 1 and mana > config.minMana then
    if TargetBot.sayAttackSpell(config.attackSpell, config.attackSpellDelay) then
      return
    end
  end
  if config.useRuneAttack and config.attackRune > 100 then
    if TargetBot.useAttackItem(config.attackRune, 0, creature, config.attackRuneDelay) then
      return
    end
  end
end

TargetBot.Creature.walk = function(creature, config, targets)
  local cpos = creature:getPosition()
  local pos = player:getPosition()

  if TargetBot.isMageRunActive and TargetBot.isMageRunActive() then
    -- Movement is owned by the independent 50-ms Mage Run macro below.
    return
  end

  if config.stop then
    if TargetBot.disallowCaveBot then
      TargetBot.disallowCaveBot()
    end
    if TargetBot.stopWalk then
      TargetBot.stopWalk()
    end
    pcall(function()
      player:stopAutoWalk()
    end)
    pcall(function()
      g_game.stop()
    end)
    anchorPosition = nil
    return
  end

  if config.avoidAttacks and avoidWaveAttack(creature) then
    if TargetBot.disallowCaveBot then
      TargetBot.disallowCaveBot()
    end
    return
  end

  if not config.chase and not config.keepDistance then
    anchorPosition = nil
    return TargetBot.allowCaveBot(150)
  end

  if TargetBot.disallowCaveBot then
    TargetBot.disallowCaveBot()
  end

  local _, currentDistance = getTargetDistanceInfo(pos, cpos)
  if (not config.chase or currentDistance == 1) and not config.avoidAttacks and not config.keepDistance and config.rePosition and (creature:getHealthPercent() >= storage.coreSettings.killUnder) then
    return rePosition(config.rePositionAmount or 6)
  end
  if ((storage.coreSettings.killUnder > 1 and (creature:getHealthPercent() < storage.coreSettings.killUnder)) or config.chase) and not config.keepDistance then
    if currentDistance > 1 then
      return TargetBot.walkTo(cpos, 10, {ignoreNonPathable=true, precision=1})
    end
  elseif config.keepDistance then
    if not anchorPosition or distanceFromPlayer(anchorPosition) > config.anchorRange then
      anchorPosition = pos
    end
    if currentDistance ~= config.keepDistanceRange and currentDistance ~= config.keepDistanceRange + 1 then
      if config.anchor and anchorPosition and getDistanceBetween(pos, anchorPosition) <= config.anchorRange*2 then
        return TargetBot.walkTo(cpos, 10, {ignoreNonPathable=true, marginMin=config.keepDistanceRange, marginMax=config.keepDistanceRange + 1, maxDistanceFrom={anchorPosition, config.anchorRange}})
      else
        return TargetBot.walkTo(cpos, 10, {ignoreNonPathable=true, marginMin=config.keepDistanceRange, marginMax=config.keepDistanceRange + 1})
      end
    end
  end

  --target only movement
  if config.faceMonster then
    local diffx = cpos.x - pos.x
    local diffy = cpos.y - pos.y
    local candidates = {}
    if diffx == 1 and diffy == 1 then
      candidates = {{x=pos.x+1, y=pos.y, z=pos.z}, {x=pos.x, y=pos.y-1, z=pos.z}}
    elseif diffx == -1 and diffy == 1 then
      candidates = {{x=pos.x-1, y=pos.y, z=pos.z}, {x=pos.x, y=pos.y-1, z=pos.z}}
    elseif diffx == -1 and diffy == -1 then
      candidates = {{x=pos.x, y=pos.y-1, z=pos.z}, {x=pos.x-1, y=pos.y, z=pos.z}} 
    elseif diffx == 1 and diffy == -1 then
      candidates = {{x=pos.x, y=pos.y-1, z=pos.z}, {x=pos.x+1, y=pos.y, z=pos.z}}       
    else
      local dir = player:getDirection()
      if diffx == 1 and dir ~= 1 then turn(1)
      elseif diffx == -1 and dir ~= 3 then turn(3)
      elseif diffy == 1 and dir ~= 2 then turn(2)
      elseif diffy == -1 and dir ~= 0 then turn(0)
      end
    end
    for _, candidate in ipairs(candidates) do
      local tile = g_map.getTile(candidate)
      if tile and tile:isWalkable() then
        return TargetBot.walkTo(candidate, 2, {ignoreNonPathable=true})
      end
    end
  end
end
