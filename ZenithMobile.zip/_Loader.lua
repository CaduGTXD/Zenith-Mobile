-- Import vBot UI styles first.
local configName = modules.game_bot.contentsPanel.config:getCurrentOption().text
local configFiles = g_resources.listDirectoryFiles("/bot/" .. configName .. "/vBot", true, false)

for _, file in ipairs(configFiles) do
  local parts = file:split(".")
  local extension = parts[#parts]:lower()
  if extension == "ui" or extension == "otui" then
    g_ui.importStyle(file)
  end
end

local function loadScript(name)
  return dofile("/" .. name .. ".lua")
end

-- Libraries first, then core bot modules and retained support modules.
local luaFiles = {
  "vBot/zenith_mobile_ui",
  "vBot/main",
  "vBot/items",
  "vBot/vlib",
  "vBot/new_cavebot_lib",
  "vBot/configs",
  "vBot/core_settings",
  "vBot/cavebot",
  "vBot/playerlist",
  "vBot/alarms",
  "vBot/AttackBot",
  "vBot/Conditions",
  "vBot/friend_healer",
  "zFreeScripts/Spells/zAutoBuff",
  "vBot/HealBot",
  "vBot/mana_train",
  "vBot/Dropper",
  "vBot/quiver_manager",
  "vBot/eat_food",
  "vBot/equip",
  "vBot/supplies",
  "vBot/depositer_config",
  "vBot/cavebot_control_panel",
}

for _, file in ipairs(luaFiles) do
  loadScript(file)
end

if modules.game_interface and modules.game_interface.registerMobileBotControls then
  modules.game_interface.registerMobileBotControls({
    toggleCaster = function()
      if not AttackBot or not AttackBot.isOn then return false end
      if AttackBot.isOn() then AttackBot.setOff() else AttackBot.setOn() end
      return AttackBot.isOn()
    end,
    toggleTargeting = function()
      if not TargetBot or not TargetBot.isOn then return false end
      if TargetBot.isOn() then TargetBot.setOff() else TargetBot.setOn() end
      return TargetBot.isOn()
    end,
    isCasterEnabled = function()
      return AttackBot and AttackBot.isOn and AttackBot.isOn() or false
    end,
    isTargetingEnabled = function()
      return TargetBot and TargetBot.isOn and TargetBot.isOn() or false
    end,
  })
end
